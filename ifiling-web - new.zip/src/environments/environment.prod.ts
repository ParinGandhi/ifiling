import { NgxLoggerLevel } from 'ngx-logger';
import { Urls } from 'src/app/constants/urls';

export const environment = {
  production: true,
  logLevel: NgxLoggerLevel.INFO,
  serverLogLevel: NgxLoggerLevel.OFF,
  EXTERNAL_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.EXTERNAL_SERVICES}`,
  COMMON_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.COMMON_SERVICES}`,
  TRIAL_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.TRIAL_SERVICES}`,
  CASEVIEWER_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.CASEVIEWER_SERVICES}`,
  IFILING_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.IFILING_SERVICES}`,
  ENV_SERVICES: `https://rbac-services.uspto.gov/rbac/services`,
  // ENV_SERVICES: `https://rbac-services-fqt.etc.uspto.gov/rbac/services`,
};
