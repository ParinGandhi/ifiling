import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
// import { AiaModalHeaderComponent } from 'src/app/components/common/aia-modal-header/aia-modal-header.component';
// import { AlertsComponent } from 'src/app/components/common/alerts/alerts.component';
import { AgGridModule } from 'ag-grid-angular';
import { DataTableComponent } from 'src/app/components/common/data-table/data-table.component';
// import { EstDatePipe } from 'src/app/utilities/est-pipe';
// import { PhonePipe } from 'src/app/utilities/phone-number-pipe';
import { FilterPipe } from 'src/app/utilities/table-filter-pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { GridRefreshComponent } from 'src/app/components/common/grid-refresh/grid-refresh.component';
// import { NgSelect2Module } from 'ng-select2';
// import { OrderModule } from 'ngx-order-pipe';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { LoadingComponent } from 'src/app/components/common/loading/loading.component';
// import { PdfViewerModule } from 'ng2-pdf-viewer';
// import { GridPaginationComponent } from 'src/app/components/common/grid-pagination/grid-pagination.component';
// import { RecordCountComponent } from 'src/app/components/common/record-count/record-count.component';
// import { RealPartyTableComponent } from 'src/app/components/common/real-party-table/real-party-table.component';
import { ListOfDocumentsComponent } from 'src/app/components/common/list-of-documents/list-of-documents.component';
import { DocumentSectionComponent } from 'src/app/components/common/document-section/document-section.component';

@NgModule({
  declarations: [
    // AiaModalHeaderComponent,
    // AlertsComponent,
    DataTableComponent,
    FilterPipe,
    // PhonePipe,
    // EstDatePipe,
    // GridRefreshComponent,
    // LoadingComponent,
    // GridPaginationComponent,
    // RecordCountComponent,
    // RealPartyTableComponent,
    ListOfDocumentsComponent,
    DocumentSectionComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    // NgSelect2Module,
    // NgbModule,
    // OrderModule,
    AgGridModule.withComponents([]),
    // PdfViewerModule,
  ],
  exports: [
    // AiaModalHeaderComponent,
    // AlertsComponent,
    DataTableComponent,
    // GridRefreshComponent,
    FilterPipe,
    // PhonePipe,
    // EstDatePipe,
    CommonModule,
    AgGridModule,
    FormsModule,
    ReactiveFormsModule,
    // NgSelect2Module,
    // NgbModule,
    // OrderModule,
    // LoadingComponent,
    // PdfViewerModule,
    // GridPaginationComponent,
    // RecordCountComponent,
    // RealPartyTableComponent,
    ListOfDocumentsComponent,
    DocumentSectionComponent,
  ],
})
export class SharedModule {}
