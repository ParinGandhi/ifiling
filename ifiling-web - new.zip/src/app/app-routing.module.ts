import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OktaCallbackComponent } from '@okta/okta-angular';
import { HomeComponent } from './components/features/home/home.component';

const routes: Routes = [
  // {
  //   path: 'ui/home',
  //   loadChildren: () =>
  //     import('./components/features/home/home-routing.module').then(
  //       (m) => m.HomeRoutingModule
  //     ),
  // },
  {
    path: 'ui/home',
    component: HomeComponent,
  },
  {
    path: 'ui/public-search',
    loadChildren: () =>
      import(
        './components/features/public-search/public-search-routing.module'
      ).then((m) => m.PublicSearchRoutingModule),
  },
  {
    path: 'ui/login',
    loadChildren: () =>
      import('./components/features/login/login-routing.module').then(
        (m) => m.LoginRoutingModule
      ),
  },
  {
    path: 'ui/case-viewer/:caseNumber',
    loadChildren: () =>
      import(
        '../app/components/features/interference/interference.module'
      ).then((m) => m.InterferenceModule),
  },
  {
    path: 'public-informations/case-viewer/:caseNumber',
    loadChildren: () =>
      import(
        '../app/components/features/interference/interference.module'
      ).then((m) => m.InterferenceModule),
  },
  {
    path: 'ui/my-docket',
    loadChildren: () =>
      import(
        '../app/components/features/my-docket/my-docket-routing.module'
      ).then((m) => m.MyDocketRoutingModule),
  },
  {
    path: '',
    redirectTo: 'ui/home',
    pathMatch: 'full',
  },
  {
    path: 'ui/callback',
    component: OktaCallbackComponent,
  },
  { path: '**', redirectTo: 'ui/home' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      onSameUrlNavigation: 'reload',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
