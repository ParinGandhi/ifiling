/**
 * !We can create new selectors based on what we need to return.
 * !Currently, the selector is returning the entire state
 */
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PtactsState } from './ptacts.state';

const ptactsData = createFeatureSelector<PtactsState>('ptactsState');

export const ptactsStateData = createSelector(ptactsData, (s) => s);

export const getUserDetailsState = createSelector(
  ptactsData,
  (s) => s.userDetails
);

// export const getMandatoryState = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeInfo
// );

// export const getMandatoryNoticeDocuments = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeDocuments
// );

// export const getMandatoryNoticeRealParty = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeRealParty
// );

// export const getMandatoryNoticeAddtionalRealParty = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeAdditionalRealParty
// );

// export const getMandatoryNoticeCounsel = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeCounsel
// );

// export const getMandatoryNoticeShowCounsel = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNoticeShowCounsel
// );

// export const getMandatoryNoticeValidations = createSelector(
//   ptactsData,
//   (s) => s.mandatoryNotice
// );

// export const getAnonymousSearch = createSelector(
//   ptactsData,
//   (s) => s.anonymousSearch
// );

// export const getPartyRepresentingState = createSelector(
//   ptactsData,
//   (s) => s.partyRepresenting
// );

// export const getPetitionIdentifierState = createSelector(
//   ptactsData,
//   (s) => s.petitionIdentifier
// );
