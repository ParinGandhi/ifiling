/**
 * ! A new reducer can be added based on what needs to be added to or accessed from the state
 */
import { Action, createReducer, on } from '@ngrx/store';
import * as PtactsActions from './ptacts.actions';
import { PtactsState, initializeState } from './ptacts.state';

const initialState = initializeState();

const reducer = createReducer(
  initialState,
  // on(PtactsActions.setUserIdAction, (state: PtactsState, { payload }) => {
  //   return { ...state, userId: payload };
  // }),
  // on(PtactsActions.getUserIdAction, (state: PtactsState, { request }) => {
  //   return { ...state, userId: request };
  // }),
  on(PtactsActions.setUserDetails, (state: PtactsState, { payload }) => {
    return { ...state, userDetails: payload };
  }),
  on(PtactsActions.getUserDetails, (state: PtactsState) => {
    return { ...state };
  }),
  on(
    PtactsActions.getLoginDetailsForNonOKTA,
    (state: PtactsState, { userName }) => {
      return { ...state, userName: userName };
    }
  )
  // on(PtactsActions.changeLoading, (state: PtactsState, { request }) => {
  //   return { ...state, isLoading: request };
  // }),
  // on(PtactsActions.setTrialInfo, (state: PtactsState, { request }) => {
  //   return { ...state, trialsInfo: request };
  // }),
  // on(PtactsActions.setNewPetitionInfo, (state: PtactsState, { request }) => {
  //   return { ...state, newPetitionInfo: request };
  // }),
  // on(
  //   PtactsActions.setMandatoryNoticeInfo,
  //   (state: PtactsState, { mnNotice }) => {
  //     return { ...state, mandatoryNoticeInfo: mnNotice };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeDocuments,
  //   (state: PtactsState, { mnDocuments }) => {
  //     return { ...state, mandatoryNoticeDocuments: mnDocuments };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeRealParty,
  //   (state: PtactsState, { mnRealParty }) => {
  //     return { ...state, mandatoryNoticeRealParty: mnRealParty };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeAdditionalRealParty,
  //   (state: PtactsState, { mnAdditionalRealParty }) => {
  //     return {
  //       ...state,
  //       mandatoryNoticeAdditionalRealParty: mnAdditionalRealParty,
  //     };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeCounsel,
  //   (state: PtactsState, { mnCounsel }) => {
  //     return { ...state, mandatoryNoticeCounsel: mnCounsel };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeShowCounsel,
  //   (state: PtactsState, { mnShowCounsel }) => {
  //     return { ...state, mandatoryNoticeShowCounsel: mnShowCounsel };
  //   }
  // ),
  // on(
  //   PtactsActions.setMandatoryNoticeValidations,
  //   (state: PtactsState, { mnValidations }) => {
  //     return { ...state, mandatoryNotice: mnValidations };
  //   }
  // ),
  // on(
  //   PtactsActions.setAnonymousSearch,
  //   (state: PtactsState, { anonymousSearch }) => {
  //     return { ...state, anonymousSearch: anonymousSearch };
  //   }
  // ),
  // on(
  //   PtactsActions.setPartyRepresenting,
  //   (state: PtactsState, { partyRepresenting }) => {
  //     return { ...state, partyRepresenting: partyRepresenting };
  //   }
  // ),
  // on(
  //   PtactsActions.getPartyRepresenting,
  //   (state: PtactsState, { proceedingNo }) => {
  //     return { ...state, proceedingNo: proceedingNo };
  //   }
  // ),
  // on(
  //   PtactsActions.getPetitionIdentifier,
  //   (state: PtactsState, { proceedingNo }) => {
  //     return { ...state, proceedingNo: proceedingNo };
  //   }
  // ),
  // on(
  //   PtactsActions.setPetitionIdentifier,
  //   (state: PtactsState, { petitionIdentifier }) => {
  //     return { ...state, petitionIdentifier: petitionIdentifier };
  //   }
  // )
  // on(
  //   PtactsActions.getAnonymousSearch,
  //   (state: PtactsState, { anonymousSearch }) => {
  //     return { ...state, anonymousSearch: anonymousSearch };
  //   }
  // )
);

export function ptactsReducer(state: PtactsState | undefined, action: Action) {
  return reducer(state, action);
}
