import { Audit } from '../common/Audit.model';
import { Party } from './Party.model';

export class InterestedParty {
  caseNo: string = null;
  applicationNo: string = null;
  // proceedingSupplementaryIdList?: Array<string> = [];
  // supplementaryIdType?: string = null;
  // caseType?: string = null;
  // identifier?: string = null;
  parties: Array<Party> = [new Party()];
  audit: Audit = new Audit();
}
