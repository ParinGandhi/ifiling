export class MailingAddress {
  addressType: string = null;
  city: string = null;
  country: string = null;
  identifier: string = null;
  state: string = null;
  streetLineOneText: string = null;
  streetLineTwoText: string = null;
  zipCode: string = null;

  constructor() {}
}
