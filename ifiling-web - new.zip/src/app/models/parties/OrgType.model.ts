import { ElectronicAddress } from './ElectronicAddress.model';
import { MailingAddress } from './MailingAddress.model';

export class OrgType {
  identifier: string = null;
  legalname: string = null;
  orgAddress: Array<MailingAddress> = [new MailingAddress()];
  electronicAddress: Array<ElectronicAddress> = [new ElectronicAddress()];
}
