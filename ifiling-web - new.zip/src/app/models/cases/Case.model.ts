export default interface CaseModel {
    artifactTypeCd: string,
    fileName?: String,
    paperNumber?: number,
    availability: string,
    contentManagementId: string,
    documentTitle: string,
    exhibitNumber?: number,
    filingDate: number,
    filingParty: string,
    pageCountQt: number,
    proceedingNumber: string,
    statusCode: String
}
