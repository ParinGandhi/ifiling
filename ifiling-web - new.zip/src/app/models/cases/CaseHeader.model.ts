// import AttorneyModel from "./CaseHeader.model";

export default interface CaseHeaderModel {
    judgementDate: string,
    allowedResourceObjectList: [],
    declarationDate: string,
    lastPaperFiledDate: string,
    inventorFullName: string,
    inventorName: string,
    relatedProceedingNo: string,
    partyGroupId: string,
    techCenter: string,
    ptabDefaultRefreshTime: number,
    ptabReadOnlyUser: boolean,
    parties: [],
    patentNo: string,
    applicationId: string,
    confindentialityInd: string,
    proceedingNo: string,
//      patentNumberText: number,
//      proceedingNumber: string,
     //derproceedingTypeDetails: string,
//      techCenterNum: number,
//      ptabReadOnlyUser:boolean,
//      mileStoneDate:any,
//      mileStoneDates: null,
//      parties: string,
//      attorneys: Array<AttorneyModel>,
//      artUnit: number,
//      casePhase: string,
//      inventionTitle: string,
//      keyDates: Array<string>,
//     joinderTypes: [],
//     petitionerPatentNumber: null,
//     petitionerinventionTitle: string,
//     petitionerTechCenterNum:  number,
//     petitionerArtUnit:  number,
//     derproceedingTypeDetails: {
//         firstListedPetitionerApplicationNumber: string,
//         firstListedPatentOwnerRespondentApplicationNumber: string,
//         aiaReviewConfidentiality: string
//     }
}

// class AttorneyModel {
//      employeeName: string;
//      rank: number
// }

