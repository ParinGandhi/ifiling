import { Audit } from '../common/Audit.model';
import { PetitionDocument } from './PetitionDocument.model';

export class DocumentToAdd {
  partyRequestTypes: Array<any> = [];
  proceedingNumberText: string = null;
  audit: Audit = new Audit();
  petitionDocuments: Array<PetitionDocument> = new Array();
  joinderOrginalIndicator: any = null;

  constructor(petitionDocuments: PetitionDocument) {
    this.petitionDocuments.push(petitionDocuments);
  }
}
