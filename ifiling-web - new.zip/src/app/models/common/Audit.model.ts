export class Audit {
  lastModifiedUserIdentifier: string;
  createUserIdentifier: string;

  constructor() {
    this.lastModifiedUserIdentifier = window.sessionStorage.getItem('email');
    this.createUserIdentifier = window.sessionStorage.getItem('email');
    // this.lastModifiedUserIdentifier = JSON.parse(window.sessionStorage.getItem('userInfo')).emailAddress;
    // this.createUserIdentifier = JSON.parse(window.sessionStorage.getItem('userInfo')).emailAddress;
  }
}
