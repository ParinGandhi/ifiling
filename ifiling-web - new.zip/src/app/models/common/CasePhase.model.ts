class CasePhaseData {
    nameText: string;
    descriptionText: string
}

export default interface CasePhaseModel {
    casePhaseData: Array<CasePhaseData>;
}