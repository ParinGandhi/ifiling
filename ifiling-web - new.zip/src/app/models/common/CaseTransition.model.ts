export default interface CaseTransitionModel {

    statusCode: string,
    statusDescription: string,
    statusCodeDates: number,
    shevoronText: string,
    phaseName: string
}