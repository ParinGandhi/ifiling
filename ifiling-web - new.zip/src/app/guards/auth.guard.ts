import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { map } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { OktaAuthService } from '@okta/okta-angular';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    private router: Router,
    public oktaAuth: OktaAuthService
  ) {}

  async canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean | UrlTree> {
    // return this.store.pipe(
    //   select(PtactsSelectors.getUserDetailsState),
    //   map((stateData) => {
    //     if (!stateData.userId) {
    //       this.logger.info(
    //         'User ID from auth guard (false):',
    //         stateData.userId
    //       );
    //       // return this.router.parseUrl('/');
    //       return ;
    //     } else {
    //       this.logger.info('User ID from auth guard (true):', stateData.userId);
    //       return true;
    //     }
    //   })
    // );
    const isAuthenticated = await this.oktaAuth.isAuthenticated();
    if (isAuthenticated) {
      return true;
    } else {
      this.router.navigateByUrl('/ui/home');
      return false;
    }
  }
}
