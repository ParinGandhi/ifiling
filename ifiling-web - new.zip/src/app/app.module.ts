import { NgModule } from '@angular/core';
import { environment } from 'src/environments/environment';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { LoggerModule } from 'ngx-logger';
import { StoreModule } from '@ngrx/store';
import { reducers } from './store/ptacts-app-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthInterceptorService } from './services/auth-interceptor.service';
import { LoginService } from './components/features/login/login.service';
import { GlobalHeaderComponent } from './components/common/global-header/global-header.component';
import { GlobalFooterComponent } from './components/common/global-footer/global-footer.component';
import { HomeComponent } from './components/features/home/home.component';
import { PublicSearchComponent } from './components/features/public-search/public-search.component';
import { GridHelperService } from './services/grid-helper.service';
import { AgGridModule } from 'ag-grid-angular';
import { RecordCountComponent } from './components/common/record-count/record-count.component';
import { SharedModule } from './shared/shared.module';
import { OpenCaseViewerComponent } from './components/common/open-case-viewer/open-case-viewer.component';
import { OpenDocumentComponent } from './components/common/open-document/open-document.component';

import { InterferencesComponent } from './components/features/my-docket/interferences/interferences.component';
import { MyDocketComponent } from './components/features/my-docket/my-docket.component';
import { LoginModule } from './components/features/login/login.module';
import { EffectsModule } from '@ngrx/effects';
import { PtactsEffects } from './store/ptacts/ptacts.effects';
import { Routes } from '@angular/router';

import { OKTA_CONFIG, OktaAuthModule } from '@okta/okta-angular';
import { OktaCallbackComponent } from '@okta/okta-angular';
import { BnNgIdleService } from 'bn-ng-idle';
import { SessionTimerComponent } from './components/common/session-timer/session-timer.component';
import { CountdownModule } from 'ngx-countdown';
import { CookieService } from 'ngx-cookie-service';

const oktaConfig = {
  // issuer: 'https://uspto-dev.oktapreview.com/oauth2/aus1a8wjq4ewzr72i0h8',
  // issuer: 'https://auth-preview.uspto.gov/oauth2/aus6a5z3zhNh8DRy31d7',
  issuer: 'https://auth-preview.uspto.gov/oauth2/aus6a5z3zhNh8DRy31d7',
  redirectUri: 'ui/callback',
  // redirectUri:
  // 'https://ptacts-extservices.pvt.uspto.gov/interferences/login/callback',
  // redirectUri: 'interferences/login/callback',
  // clientId: '0oazbbsrbgkgO55Ry0h7',
  // clientId: '0oa72k1cyxm0JZzia1d7',
  clientId: '0oa7fo2t2ioEUB0771d7',
  // scopes: ['openid', 'profile', 'uspto.read', 'uspto.trademarks.read','uspto.trademarks.ttab.read', 'uspto.trademarks.ttab.write'],
  scopes: ['openid'],
  pkce: true,
  cookies: {
    secure: false,
  },
};

// const routes: Routes = [
//   { path: '', redirectTo: '/ui/home', pathMatch: 'full' },
//   // {
//   //   path: 'ui/home',
//   //   loadChildren: () =>
//   //     import('./components/features/home/home-routing.module').then(
//   //       (m) => m.HomeRoutingModule
//   //     ),
//   // },
//   {
//     path: 'ui/home',
//     component: HomeComponent,
//   },
//   {
//     path: 'login/callback',
//     component: OktaCallbackComponent,
//   },
// ];

@NgModule({
  declarations: [
    AppComponent,
    GlobalHeaderComponent,
    GlobalFooterComponent,
    HomeComponent,
    PublicSearchComponent,
    RecordCountComponent,
    OpenCaseViewerComponent,
    OpenDocumentComponent,
    InterferencesComponent,
    MyDocketComponent,
    SessionTimerComponent,
  ],
  imports: [
    BrowserModule,
    AgGridModule,
    HttpClientModule,
    FormsModule,
    ModalModule.forRoot(),
    CountdownModule,
    EffectsModule.forRoot([PtactsEffects]),
    StoreModule.forRoot(reducers, {
      runtimeChecks: {
        strictActionImmutability: true,
        strictActionSerializability: true,
        strictStateImmutability: true,
        strictStateSerializability: true,
      },
    }),
    StoreDevtoolsModule.instrument({ maxAge: 10 }),
    LoggerModule.forRoot({
      serverLoggingUrl: '/api/logs', //? Add path to server to write the logs
      level: environment.logLevel, //? Log level to show in browser console
      serverLogLevel: environment.serverLogLevel, //? Log level to show on the server
    }),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    OktaAuthModule,
    SharedModule,
    AppRoutingModule,
    LoginModule,
  ],
  providers: [
    { provide: OKTA_CONFIG, useValue: oktaConfig },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true,
    },
    LoginService,
    GridHelperService,
    BnNgIdleService,
    CookieService
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
