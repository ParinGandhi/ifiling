import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';
import CaseHeaderModel from '../models/cases/CaseHeader.model';

@Injectable({
  providedIn: 'root',
})
export class TrialsService {
  /** Location variables */

  private port: string = '8081';

  /**
   * * LOCAL DEVELOPMENT
   * ? Uncomment below ONLY if you are running Trials Services locally.
   * ? Otherwise use the appropriate environment commands
   * ? DEV - npm run start:dev
   * ? PVT - npm run start:pvt
   */
  // private TRIALS_BASE_URL: string = `${PtabTrialConstants.ENVIRONMENTS.LOCAL}${this.port}`;
  private TRIALS_BASE_URL = environment.TRIAL_SERVICE_API;
  private EXTERNAL_SERVICE = environment.EXTERNAL_SERVICE_API;

  /** Header options */

  getHeaders(addResponseType) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
        withCredentials: true,
        crossDomain: true,
      };
    }
    if (addResponseType) {
      httpOptions.headers.set('responseType', 'arraybuffer' as 'json');
    }
    return httpOptions;
  }

  getFileUploadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          // 'Content-Type': "",
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          // 'Content-Type': "",
          // 'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    }
    return httpOptions;
  }

  getDownloadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
        responseType: 'arraybuffer' as 'json',
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          // 'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
        responseType: 'arraybuffer' as 'json',
      };
    }
    return httpOptions;
  }

  constructor(private httpclient: HttpClient) {}

  /** Counsel */

  addCounsel(proSeVal: string, counselToAdd: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.ADD}${proSeVal}`,
      counselToAdd,
      this.getHeaders(false)
    );
  }

  addInterferenceCounsel(proSeVal: string, counselToAdd: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.ADD_INTERFERENCE}`,
      counselToAdd,
      this.getHeaders(false)
    );
  }

  uploadRealParty(realPartyUpload: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`,
      realPartyUpload,
      this.getHeaders(false)
    );
  }

  findCounsel(emailOrRegNo: string): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.FIND_BY_EMAIL_OR_REGNO}` +
        emailOrRegNo,
      this.getHeaders(false)
    );
    // return this.httpclient.get("http://localhost:8081" + url);
  }

  updateCounsel(counselToUpdate: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`,
      counselToUpdate,
      this.getHeaders(false)
    );
  }

  updateRealParty(url: string, updateParty: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.UPDATE}`,
      updateParty,
      this.getHeaders(false)
    );
  }

  deleteCounsel(
    proceedingNo: string,
    proceedingPartyIdentifier: string
  ): Observable<any> {
    return this.httpclient.delete<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.DELETE}${proceedingNo}${PtabTrialConstants.GENERAL.PARTY_IDENTIFIER}${proceedingPartyIdentifier}`,
      this.getHeaders(false)
    );
  }

  switchCounsel(url: any, counseltoSwitch: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${url}`,
      counseltoSwitch,
      this.getHeaders(false)
    );
  }

  /** CaseViewer - update documents modal */

  getDocumentsForUpdate(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  expungeDocument(url: string, docToExpunge: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      docToExpunge,
      this.getHeaders(false)
    );
  }

  updateDocumentInfo(url: string, docToUpdate: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      docToUpdate,
      this.getHeaders(false)
    );
  }

  // getCaseHeaderInfo(serialNo: string, proceedingNo: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_VIEWER.DETAILS}${serialNo}&proceedingSupplementaryId=${proceedingNo}`)
  // }

  getCaseHeaderInfo(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_VIEWER.DETAILS}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  /** AIA Trials Workspace */

  reassignTasks(url: string, tasksToReassign: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      tasksToReassign,
      this.getHeaders(false)
    );
  }

  /** Mandatory notices */
  getMandatoryNotices(caseNumber: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.MANDATORY_NOTICE.GET}${caseNumber}`,
      this.getHeaders(false)
    );
  }

  getRehearingList(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  getAppealsList(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  updateAppeals(url: string, appealsData: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      appealsData,
      this.getHeaders(false)
    );
  }

  updateMotionRehearing(url: string, recordsToUpdate: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      recordsToUpdate,
      this.getHeaders(false)
    );
  }

  getMotionsList(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  approveOrRejectMandatoryNotice(
    noticeToApproveOrReject: any
  ): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.MANDATORY_NOTICE.APPROVE_REJECT}`,
      noticeToApproveOrReject,
      this.getHeaders(false)
    );
  }

  /** Get milestone data */
  getMilestoneData(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  getDecisionHistory(url: string): Observable<any> {
    return this.httpclient.get<any>(
      this.TRIALS_BASE_URL + url,
      this.getHeaders(false)
    );
  }

  updateMilestoneData(url: string, milestoneData: any): Observable<any> {
    // return this.httpclient.put<any>(this.TRIALS_BASE_URL + url, recordsToUpdate, this.getHeaders(false));
    return this.httpclient.post<any>(
      this.TRIALS_BASE_URL + url,
      milestoneData,
      this.getHeaders(false)
    );
  }

  updateDerivation(url: string, derivationData: any): Observable<any> {
    return this.httpclient.put<any>(
      this.TRIALS_BASE_URL + url,
      derivationData,
      this.getHeaders(false)
    );
  }

  updateDeclarationDate(url: string, declarationData: any): Observable<any> {
    return this.httpclient.post<any>(
      this.TRIALS_BASE_URL + url,
      declarationData,
      this.getHeaders(false)
    );
  }

  /** Pending Paneling */
  getPendingPanelingCases(): Observable<any> {
    // return this.httpclient.get('../../assets/paneling/pendingPaneling.json');
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_PENDING_PANEL}`,
      this.getHeaders(false)
    );
  }

  getJudgeList(): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_JUDGE_LIST}`,
      this.getHeaders(false)
    );
  }

  getPaneledJudges(
    proceedingNo: string,
    includeInactive: boolean
  ): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_PANELED_JUDGES}/?${PtabTrialConstants.CASE_TYPE_TRIALS}&${PtabTrialConstants.CASE_NO}${proceedingNo}&${PtabTrialConstants.INCLUDE_INACTIVE}${includeInactive}`,
      this.getHeaders(false)
    );
  }

  getDisciplineList(): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_DISCIPLINES}`,
      this.getHeaders(false)
    );
  }

  getSectionList(): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.GET_SECTIONS}`,
      this.getHeaders(false)
    );
  }

  getHeaderInfo(proceedingNo: string): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CASE_HEADER}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  assignPanelToCase(caseToPanel: any): Observable<any> {
    return this.httpclient.post(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.ASSIGN_JUDGES}`,
      caseToPanel,
      this.getHeaders(false)
    );
  }

  createTask(task: any): Observable<any> {
    return this.httpclient.post(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CREATE_TASK}`,
      task,
      this.getHeaders(false)
    );
  }

  updateTask(task: any): Observable<any> {
    return this.httpclient.put(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.UPDATE_TASK}`,
      task,
      this.getHeaders(false)
    );
  }

  clearPanel(panelToClear: any): Observable<any> {
    return this.httpclient.post(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.CLEAR_PANEL}`,
      panelToClear,
      this.getHeaders(false)
    );
  }

  getFilteredList(url: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PANEL.FILTER_BY}${url}`,
      this.getHeaders(false)
    );
  }

  getSheetNames(fileToUpload: any): Observable<any> {
    // const formData: FormData = new FormData();
    // formData.append('file', fileToUpload);
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-judges/get-sheet-names`,
      fileToUpload,
      this.getFileUploadHeaders()
    );
  }

  importPanel(formData: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-judges/bulk-import`,
      formData,
      this.getFileUploadHeaders()
    );
  }

  /** Counsel / Real party  */
  getCounselInfo(proceedingNumber: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COUNSEL.GET}${proceedingNumber}`,
      this.getHeaders(false)
    );
  }

  /**
   * Header
   */

  getCaseStatus(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/ptab-state-role?caseNumber=${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  getCaseHeader(
    serialNumber: string,
    proceedingNumber: string
  ): Observable<any> {
    return this.httpclient.get<CaseHeaderModel>(
      `${this.TRIALS_BASE_URL}
      ${PtabTrialConstants.CASE_HEADER}
      ${serialNumber}&proceedingSupplementaryId=${proceedingNumber}`,
      this.getHeaders(false)
    );
  }

  /**
   * All AIA Reviews tab
   */
  getAIAReviewsColumnDefs(reviewType: string): Observable<any> {
    return this.httpclient.get<any>(
      `../../assets/columnDefs/${reviewType}.json`,
      this.getHeaders(false)
    );
  }

  getAIAReviewsData(dataType: string): Observable<any> {
    return this.httpclient.get<any>(
      `../../assets/aiaReview/${dataType}Data.json`,
      this.getHeaders(false)
    );
  }

  getAllAIAReviews(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.AIA_REVIEWS}`,
      this.getHeaders(false)
    );
  }

  /**
   * All Initiated cases tab
   */
  getInitiatedCases() {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/proceedings?caseType=TRIAL&caseStatus=Initiated`,
      this.getHeaders(false)
    );
  }

  getInitiatedCasesNew(obj: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/meta-data`,
      obj,
      this.getHeaders(false)
    );
  }

  /**
   * All interferences tab
   */
  getInterferences(obj: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/meta-data/interference`,
      obj,
      this.getHeaders(false)
    );
  }

  /**
   * Documents
   */
  // downloadEwf(documentsToDownload: ArrayBuffer): Observable<any> {
  //   return this.httpclient.post<ArrayBuffer>(`${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EWF}`, documentsToDownload,{responseType: 'arraybuffer' as 'json'});
  // }
  downloadEwf(documentsToDownload: any): Observable<any> {
    return this.httpclient.post<ArrayBuffer>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EWF}`,
      documentsToDownload,
      this.getDownloadHeaders()
    );
  }

  downloadExcel(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENTS.DOWNLOAD_EXCEL}${proceedingNo}`,
      this.getDownloadHeaders()
    );
  }

  getTrialsInfo(url: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${url}`,
      this.getHeaders(false)
    );
  }

  saveToDocket(docsToSave: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PROCEEDING_ARTIFACTS}`,
      docsToSave,
      this.getHeaders(false)
    );
  }

  getNextPaperNumber(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.NEXT_PAPER_NUM_URL}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  /** Advanced search */
  searchByCase(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.ADVANCED_SEARCH_URL}`,
      searchCriteria,
      this.getHeaders(false)
    );
  }

  searchByDocument(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.DOCUMENT_SEARCH_URL}`,
      searchCriteria,
      this.getHeaders(false)
    );
  }

  /** Advanced interference search */
  searchInterferenceByCase(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.INTERFERENCE_CASE_SEARCH_URL}`,
      searchCriteria,
      this.getHeaders(false)
    );
  }

  searchInterferenceByDocument(searchCriteria: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.INTERFERENCE_DOCUMENT_SEARCH_URL}`,
      searchCriteria,
      this.getHeaders(false)
    );
  }

  /** Claims */
  getClaims(url: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${url}`,
      this.getHeaders(false)
    );
  }

  /** Joinders */
  getJoinderRelatedCases(caseNumber: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.RELATED_CASES}${caseNumber}`,
      this.getHeaders(false)
    );
  }

  getJoinedCaseDetails(caseNumber: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.DETAILS}${caseNumber}`,
      this.getHeaders(false)
    );
  }

  joinCases(casesToJoin: any): Observable<any> {
    return this.httpclient.post(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.JOINDER.JOIN_CASES}`,
      casesToJoin,
      this.getHeaders(false)
    );
  }

  getAssignToList(url: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.HIERARCHY.GET}${url}`,
      this.getHeaders(false)
    );
  }

  markCompleteWorkQueue(dataObj: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.UPDATE_TASK}`,
      dataObj,
      this.getHeaders(false)
    );
  }

  markCompleteTaskWorkQueue(dataObj: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.COMPLETE_TASK}`,
      dataObj,
      this.getHeaders(false)
    );
  }

  getWorkQueue(filterData: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.TASK_DETAILS}`,
      filterData,
      this.getHeaders(false)
    );
  }

  /** Claims */

  uploadClaims(claimUpload: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}`,
      claimUpload,
      this.getHeaders(false)
    );
  }

  editClaims(claimUpload: any): Observable<any> {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}`,
      claimUpload,
      this.getHeaders(false)
    );
  }

  deleteClaim(claimIdentifier: string) {
    return this.httpclient.delete<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.CLAIMS_UPLOAD}${claimIdentifier}`,
      this.getHeaders(false)
    );
  }

  getGround(): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.STATUTORY_GROUNDS}`,
      this.getHeaders(false)
    );
  }

  /** General */

  getStates(countryCode: string): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.GENERAL.STATES}${countryCode}`,
      this.getHeaders(false)
    );
  }

  getCountries(): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.GENERAL.COUNTRIES}`,
      this.getHeaders(false)
    );
  }

  getAuditList(url: string): Observable<any> {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}${url}`,
      this.getHeaders(false)
    );
  }

  codeReference(typeCode: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.REFERENCE_DATA}` + typeCode,
      this.getHeaders(false)
    );
  }

  petitionerSearch(url: string): Observable<any> {
    return this.httpclient.get<any>(
      `${url}`,
      this.getHeaders(false)
      // `${window.location.protocol}//${window.location.host}/ptacts/login-external-user-details?emailAddressText=${email}`
    );
  }

  getPDF(url: string): Observable<any> {
    return this.httpclient.get(`${url}`, this.getHeaders(false));
  }

  saveDocumentsToCMS(documentsList) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-artifacts/external-documents`,
      documentsList,
      this.getHeaders(false)
    );
  }

  createMotion(motionToCreate) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/motions/create-motion`,
      motionToCreate,
      this.getHeaders(false)
    );
  }

  createRehearing(rehearingToCreate) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/rehearing-info/create-rehearing`,
      rehearingToCreate,
      this.getHeaders(false)
    );
  }

  createPopr(poprToCreate) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-artifacts`,
      poprToCreate,
      this.getHeaders(false)
    );
  }

  createNoticeOfAppeal(noticeOfAppealToCreate) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-appeal`,
      noticeOfAppealToCreate,
      this.getHeaders(false)
    );
  }

  getExternalUsers(url) {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/users/external-users`,
      this.getHeaders(false)
    );
  }

  updateExternalUserProfile(updatedProfile) {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}/users/update-externaluser`,
      updatedProfile,
      this.getHeaders(false)
    );
  }

  getInternalUsers(url) {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/users/internal-users`,
      this.getHeaders(false)
    );
  }

  // getExternalUserAiaReviewData(url, userId) {
  getExternalUserAiaReviewData(emailId: string) {
    // const headers = new HttpHeaders({
    //   'Content-Type': 'application/json',
    //   'user-name': userId,
    // });
    // return this.httpclient.get<any>(
    //   `${url}external-user-docket/aia-reviews?caseStatus=ext-aia-reviews`,
    //   { headers }
    // );
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/users/external-user/aia-reviews?externalUserName=${emailId}`,
      this.getHeaders(false)
    );
  }

  getExternalUserPaymentInfo(emailId, userId) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'user-name': emailId,
    });
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/payments/external-user/${userId}`,
      { headers }
    );
  }

  getExternalUserPaymentReceiptInfo(emailId, paymentId) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'user-name': emailId,
    });
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/payments/receipt/${paymentId} `,
      { headers }
    );
  }

  getPayments(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.PAYMENTS}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  getCaseReviewStatus(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}/proceeding-reviews?proceedingNumber=${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  addCaseReview(caseReviewToAdd): Observable<any> {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/proceeding-reviews`,
      caseReviewToAdd,
      this.getHeaders(false)
    );
  }

  updateCaseReview(caseReviewToUpdate) {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}/proceeding-reviews/${caseReviewToUpdate.proceedingReviewIdentifier}`,
      caseReviewToUpdate,
      this.getHeaders(false)
    );
  }

  addDataQuality(dataQualityObj: any) {
    return this.httpclient.post<any>(
      `${this.TRIALS_BASE_URL}/ptab/qq/create`,
      dataQualityObj,
      this.getHeaders(false)
    );
  }

  updateDataQuality(dataQualityObj: any) {
    return this.httpclient.put<any>(
      `${this.TRIALS_BASE_URL}/ptab/qq/update`,
      dataQualityObj,
      this.getHeaders(false)
    );
  }

  caseSearch(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.TRIALS_BASE_URL}${PtabTrialConstants.GENERAL.CASE_SEARCH}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  associateApplication(applicationToAssociate) {
    return this.httpclient.post(
      `${this.TRIALS_BASE_URL}/petitions/associate-petition`,
      applicationToAssociate,
      this.getHeaders(false)
    );
  }

  getApplications(proceedingNumber) {
    return this.httpclient.get(
      `${this.TRIALS_BASE_URL}/proceeding-party-details/intf/realparties?proceedingNumber=${proceedingNumber}`,
      this.getHeaders(false)
    );
  }
}
