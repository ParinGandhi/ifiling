/**
 * ! This will intercept all http requests. This is where we can add properties to the header
 * ! using .append(). Also, the 'req' object in the intercept method has the url and other info
 * ! in case we need to perform any logic for adding properties to the header
 */

import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { take, exhaustMap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { Urls } from '../constants/urls';
import { Observable, from } from 'rxjs';
import { OktaAuthService } from '@okta/okta-angular';
declare let $: any;
import { CookieService } from 'ngx-cookie-service';

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {
  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    private oktaAuth: OktaAuthService,
    private cookieService: CookieService
  ) { }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return from(this.handleAccess(request, next));
  }

  private handleAccess(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Promise<HttpEvent<any>> {
    // Only add an access token to whitelisted origins
    // const allowedOrigins = [
    //   'albdev',
    //   'noteservice',
    //   'uspto-dev.oktapreview.com',
    // ];
    // if (allowedOrigins.some((url) => request.urlWithParams.includes(url))) {
    console.log('URL contains origin', request.urlWithParams);
    const accessToken = this.oktaAuth.getAccessToken();
    const idToken = this.oktaAuth.getIdToken();
    const userName = window.sessionStorage.getItem('user-name');
    if (accessToken) {
      request = request.clone({
        setHeaders: {
          Authorization: 'Bearer ' + accessToken,
        },
      });
    } else {
      console.error(request.urlWithParams, ': accessToken is null');
    }

    if (userName) {
      request = request.clone({
        headers: request.headers.set('user-name', userName),
      });
    } else {
      console.error('userName is null');
    }
    // } else {
    //   console.error('URL does not contain origin', request.urlWithParams);
    // }
    this.cookieService.set('token', idToken);
    return next.handle(request).toPromise();
  }

  // intercept(req: HttpRequest<any>, next: HttpHandler) {
  //   return this.store.select(PtactsSelectors.ptactsStateData).pipe(
  //     take(1),
  //     map((stateData) => {
  //       return stateData.userId;
  //       // return stateData.userDetails;
  //       // return 'sbartlett';
  //     }),
  //     exhaustMap((userId) => {
  //       if (typeof $.sessionTimeoutWidget.staySignedIn !== 'undefined') {
  //         $.sessionTimeoutWidget.staySignedIn();
  //       }
  //       userId = window.sessionStorage.getItem('email');
  //       // const cfkPatronId = window.sessionStorage.getItem('cfkPatronId');
  //       // const source = window.sessionStorage.getItem('source');

  //       let modifiedRequest = null;
  //       const userName = window.sessionStorage.getItem('email');

  //       // if (userName && req.url.includes('/login-external-user-details')) {
  //         if (userName && req.url.includes('/login-external-user-details')) {
  //           //! Remove this if statement after OKTA is integrated
  //           modifiedRequest = req.clone({
  //             headers: req.headers
  //               .set('user-name', userName)
  //               .set('USER-EMAIL', userName),
  //           });
  //           // modifiedRequest = req.clone({
  //           //   ,
  //           // });
  //           return next.handle(modifiedRequest);
  //         }  else {
  //           if (!userId) {
  //             if (req.url.includes('public-informations')) {
  //               modifiedRequest = req.clone({
  //                 headers: req.headers.append('user-name', 'anonymous'),
  //               });
  //             } else {
  //             // if (!userId.userId) {
  //             return next.handle(req);
  //             }
  //           }
  //         // if (!userId) {
  //         //   // if (!userId.userId) {
  //         //   return next.handle(req);
  //         // }

  //         // if (
  //         //   // req.url.includes('/mandatory-notice') ||
  //         //   // req.url.includes(Urls.CREATE_PETITION)
  //         //   source &&
  //         //   source === 'internal'
  //         // ) {
  //         //   if (cfkPatronId) {
  //         //     modifiedRequest = req.clone({
  //         //       headers: req.headers.append('route-id', cfkPatronId),
  //         //     });
  //         //   } else {
  //         //     modifiedRequest = req.clone({
  //         //       // headers: req.headers.append('user-name', userId.userId),
  //         //       headers: req.headers.append('user-name', userId),
  //         //     });
  //         //   }
  //         // }

  //         // // else if (
  //         // //   //req.url.includes(Urls.CREATE_PETITION) ||
  //         // //   req.url.includes(Urls.REAL_PARTY.ADD) ||
  //         // //   req.url.includes(Urls.COUNSEL.ADD) ||
  //         // //   // req.url.includes(Urls.DOCUMENTS.DELETE) ||
  //         // //   // req.url.includes(Urls.DOCUMENTS.SAVE_TO_CMS) ||
  //         // //   // req.url.includes(Urls.DOCUMENTS.EDIT) ||
  //         // //   // req.url.includes(Urls.MOTIONS.SAVE_SUBMIT) ||
  //         // //   req.url.includes(Urls.CASEVIEWER.CASE_STATUS)
  //         // // ) {
  //         // //   modifiedRequest = req.clone({
  //         // //     headers: req.headers.append('user-name', 'sbartlett'),
  //         // //   });
  //         // // }
  //         // else {
  //         //   if (req.url.includes(Urls.HELP_LINK)) {
  //         //     modifiedRequest = req.clone({
  //         //       headers: req.headers.append('user-name', 'anonymous'),
  //         //     });
  //         //   } else {
  //         //     modifiedRequest = req.clone({
  //         //       // headers: req.headers.append('user-name', userId.userId),
  //         //       headers: req.headers.append('user-name', userId),
  //         //     });
  //         //   }
  //         // }

  //         // if (req.url.includes('external-user-docket')) {
  //         //   modifiedRequest = req.clone({
  //         //     headers: req.headers.append('user-name', userId),
  //         //   });
  //         // } else {
  //         //   modifiedRequest = req.clone({
  //         //     headers: req.headers.append('user-name', userId),
  //         //   });
  //         // }

  //         // console.log(req)

  //         // modifiedRequest = req.clone({
  //         //   headers: req.headers.append('user-name', 'anonymous'),
  //         // });

  //         else {
  //           if (req.url.includes(Urls.HELP_LINK)) {
  //             modifiedRequest = req.clone({
  //               headers: req.headers.append('user-name', 'anonymous'),
  //             });
  //           } else {
  //             modifiedRequest = req.clone({
  //               // headers: req.headers.append('user-name', userId.userId),
  //               headers: req.headers.append('user-name', userId),
  //             });
  //           }
  //         }

  //         return next.handle(modifiedRequest);
  //       }
  //     })
  //   );
  // }
}
