import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Urls } from 'src/app/constants/urls';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  // private EXTERNAL_SERVICE_BASE: string = environment.EXTERNAL_SERVICE_API;
  // private EXTERNAL_SERVICE_BASE: string =
  //   'https://ptacts-extservices.pvt.uspto.gov/ptacts';

  private IFILING_BASE_URL = environment.IFILING_SERVICE_API;

  constructor(private http: HttpClient) {}

  getUsers(loginInfo): Observable<any> {
    return this.http.post<any>(Urls.USERS.GET, loginInfo).pipe(
      map((userResponse) => {
        return userResponse;
      })
    );
  }

  getUserInfo(emailAddress: string) {
    return this.http
      .get<any>(
        `${this.IFILING_BASE_URL}/login-external-user-details?emailAddressText=${emailAddress}`
      )
      .pipe(
        map((userInfo) => {
          return userInfo;
        })
      );
  }

  getOktaLinks() {
    return this.http
      // .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.OKTA_LINK}`, {
      //   headers: { 'USER-EMAIL': 'anonymous' },
      // })
      .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.OKTA_LINK}`)
      .pipe(
        map((oktaLinkResponse) => {
          return oktaLinkResponse;
        })
      );
  }

  getDST() {
    return this.http.get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.DAYLIGHT_SAVINGS}`)
      .pipe(
        map((daylightSavingsResponse) => {
          return daylightSavingsResponse;
        })
      );
  }

  getMyUSPTOLink() {
    return this.http
      // .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.MYUSPTO_LINK}`, {
      //   headers: { 'USER-EMAIL': 'anonymous' },
      // })
      .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.MYUSPTO_LINK}`)
      .pipe(
        map((myUSPTOLinkResponse) => {
          return myUSPTOLinkResponse;
        })
      );
  }

  getExternalLink() {
    return this.http
      .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.EXTERNAL_LINK}`)
      .pipe(
        map((externalLinkResponse) => {
          return externalLinkResponse;
        })
      );
  }

  getHelpLink() {
    return this.http
      // .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.HELP_LINK}`, {
      //   headers: { 'USER-EMAIL': 'anonymous' },
      // })
      .get(`${this.IFILING_BASE_URL}${Urls.PUBLIC}${Urls.HELP_LINK}`)
      .pipe(
        map((helpLinkResponse) => {
          return helpLinkResponse;
        })
      );
  }
}
