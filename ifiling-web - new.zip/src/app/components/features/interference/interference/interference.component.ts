import { Component, OnInit, ViewChild } from '@angular/core';
// import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { setUserDetails } from 'src/app/store/ptacts/ptacts.actions';
import { ActivatedRoute } from '@angular/router';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { TrialsService } from 'src/app/services/trials.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { DatePipe } from '@angular/common';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { InterferenceApplicationsComponent } from '../interference-applications/interference-applications.component';
import { OktaAuthService } from '@okta/okta-angular';

@Component({
  selector: 'app-interference',
  templateUrl: './interference.component.html',
  styleUrls: ['./interference.component.less'],
})
export class InterferenceComponent implements OnInit {
  @ViewChild(InterferenceApplicationsComponent)
  applicationsComponent: InterferenceApplicationsComponent;
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  caseInfo: CaseInfoModel = {
    // serialNo: null,
    proceedingNo: null,
    scrollToId: null,
  };
  isTrialsCase: boolean = true;
  unsavedChanges: boolean = true;
  applications = null;
  isPartyOnCase: boolean = false;
  isAuthenticated: boolean = false;
  groups: string[] = [];

  constructor(
    private store: Store<CaseViewerState>,
    private activatedRoute: ActivatedRoute,
    private trialsService: TrialsService,
    private ifilingService: IfilingService,
    private datePipe: DatePipe,
    public oktaAuth: OktaAuthService
  ) {}

  async ngOnInit() {
    this.caseInfo = {
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };
    window.sessionStorage.setItem('caseInfo', JSON.stringify(this.caseInfo));
    // this.store.dispatch(
    //   CaseViewerActions.setCaseInfoAction({ payload: this.caseInfo })
    // );
    document.title = `${this.caseInfo.proceedingNo} - Case viewer`;

    this.isAuthenticated = await this.oktaAuth.isAuthenticated();
    // Subscribe to authentication state changes
    this.oktaAuth.$authenticationState.subscribe(
      (isAuthenticated: boolean) => (this.isAuthenticated = isAuthenticated)
    );

    // Get user information
    if (this.isAuthenticated) {
      // get okta access token info and the user info if we're authenticated
      const accessToken = this.oktaAuth.getAccessToken();
      const userInfo = await this.oktaAuth.token.getUserInfo();
      console.log('User info from OIDC: ', userInfo);
      window.sessionStorage.setItem('user-name', userInfo.emailAddress);
      window.sessionStorage.setItem('email', userInfo.emailAddress);
      this.groups = userInfo.groups;
      console.log(this.groups);
      this.setUserInState(userInfo);
      this.getIfPartyOnCase();
      this.getApplications();
    }

    // this.getIfPartyOnCase();
    // this.getApplications();
  }

  setUserInState(userInfo) {
    const userDetails = {
      lastName: userInfo.lastName,
      patronId: userInfo.patronId,
      displayName: userInfo.displayName,
      roles: userInfo.groups,
      userId: userInfo.userLogin,
      employeeNumber: null,
      firstName: userInfo.firstName,
      emailAddress: userInfo.emailAddress,
      ptabDefaultRefreshTime: null,
      employeeType: userInfo.accountType,
      ptabReadOnlyUser: null,
      clientIP: null,
      middleName: userInfo.middleName,
      passwordExpired: null,
      authLevel: null,
    };
    this.store.dispatch(setUserDetails({ payload: userDetails }));
  }

  displayApplications() {
    this.applicationsComponent.gridParams.gridApi.sizeColumnsToFit();
  }

  getApplications() {
    this.ifilingService.getApplications(this.caseInfo.proceedingNo).subscribe(
      (applicationsResponse) => {
        this.applications = applicationsResponse;
        this.applications.forEach((application) => {
          if (application.filingDate) {
            application.filingDate = this.datePipe.transform(
              application.filingDate,
              'MM/dd/yyyy'
            );
          }
        });
      },
      (applicationsFailure) => {
        console.log(applicationsFailure);
      }
    );
  }

  getIfPartyOnCase() {
    this.ifilingService
      .getIfPartyOnCase(this.caseInfo.proceedingNo)
      .subscribe((partyType: any) => {
        if (
          partyType.toLowerCase() === 'jr.party' ||
          partyType.toLowerCase() === 'sr.party'
        ) {
          this.isPartyOnCase = true;
        }
      });
  }
}
