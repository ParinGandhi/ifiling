import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InterferenceComponent } from './interference/interference.component';
import { InterferenceHeaderComponent } from './interference-header/interference-header.component';
import { InterferenceDocumentsComponent } from './interference-documents/interference-documents.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { InterferenceApplicationsComponent } from './interference-applications/interference-applications.component';
import { InterferenceAttorneysComponent } from './interference-attorneys/interference-attorneys.component';
import { AddAttorneysModalComponent } from './interference-attorneys/add-attorneys-modal/add-attorneys-modal.component';
import { AddDocumentsModalComponent } from './interference-documents/add-documents-modal/add-documents-modal.component';
import { AuthGuard } from 'src/app/guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: InterferenceComponent,
    runGuardsAndResolvers: 'always',
    canActivate: [AuthGuard],
  },
];

@NgModule({
  declarations: [
    InterferenceComponent,
    InterferenceHeaderComponent,
    InterferenceDocumentsComponent,
    InterferenceApplicationsComponent,
    InterferenceAttorneysComponent,
    AddAttorneysModalComponent,
    AddDocumentsModalComponent,
  ],
  imports: [RouterModule.forChild(routes), SharedModule, CommonModule],
})
export class InterferenceModule {}
