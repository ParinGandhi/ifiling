import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterferenceAttorneysComponent } from './interference-attorneys.component';

describe('InterferenceAttorneysComponent', () => {
  let component: InterferenceAttorneysComponent;
  let fixture: ComponentFixture<InterferenceAttorneysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterferenceAttorneysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterferenceAttorneysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
