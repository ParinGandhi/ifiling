import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { InterestedParty } from 'src/app/models/parties/InterestedParty.model';

@Component({
  selector: 'app-add-attorneys-modal',
  templateUrl: './add-attorneys-modal.component.html',
  styleUrls: ['./add-attorneys-modal.component.scss'],
})
export class AddAttorneysModalComponent implements OnInit {
  loggedInUser: any;
  modal: any;
  applications;
  associating: boolean = false;
  attorneyType = 'LEAD';
  selectedApplication = null;
  registrationNumber: string;
  foundAttorney: any;

  constructor(
    public bsModalRef: BsModalRef,
    private modalService: BsModalService,
    private ifilingService: IfilingService,
    private commonUtils: CommonUtilitiesService
  ) {}

  ngOnInit(): void {
    // this.applications = this.modal.attorneys.map(
    //   ({ applicationId }) => applicationId
    // );
    const loggedInUserEmail = window.sessionStorage.getItem('email');
    this.applications = [];
    this.modal.attorneys.forEach((attorney) => {
      if (attorney.proceedingPartyMaps?.length > 0) {
        attorney.proceedingPartyMaps.forEach((el) => {
          if (el.seniorParty && el.seniorParty.parties.length > 0) {
            el.seniorParty.parties.forEach((party) => {
              if (party.personType[0].electronicAddress && party.personType[0].electronicAddress.length > 0) {
                party.personType[0].electronicAddress.forEach((elAddress) => {
                  if (elAddress.email && elAddress.email.toLowerCase() === loggedInUserEmail.toLowerCase()) {
                    this.applications.push(attorney.applicationId)
                  }
                });
              }
            });
          } else if (el.juniorParty && el.juniorParty.parties.length > 0) {
            el.juniorParty.parties.forEach((party) => {
              if (party.personType[0].electronicAddress && party.personType[0].electronicAddress.length > 0) {
                party.personType[0].electronicAddress.forEach((elAddress) => {
                  if (elAddress.email && elAddress.email.toLowerCase() === loggedInUserEmail.toLowerCase()) {
                    this.applications.push(attorney.applicationId)
                  }
                });
              }
            });
          }
        });
      }
    });
  }

  close(value) {
    this.modal.isConfirm = value;
    this.modalService.hide();
  }

  getInfo() {
    if (this.registrationNumber) {
      this.ifilingService
        .getAttorneyByNumber(this.registrationNumber)
        .pipe(take(1))
        .subscribe((success) => {
          console.log(success);
          if (success[0].parties[0]) {
            this.foundAttorney = success[0].parties[0];
          } else {
            this.foundAttorney = 'invalid';
          }
        });
    }
  }

  changeAttorneyType(type) {
    this.attorneyType = type;
  }

  setAttorneyObj() {
    const staffToAddUpdate = new InterestedParty();
    // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
    staffToAddUpdate.caseNo = this.modal.caseNo;
    staffToAddUpdate.applicationNo = this.selectedApplication;
    staffToAddUpdate.parties[0].submitterType = 'PETITIONER';
    staffToAddUpdate.parties[0].partyType = 'COUNSEL';
    staffToAddUpdate.parties[0].partySubType = this.attorneyType;
    // staffToAddUpdate.parties[0].proseIndicator = 'N';
    staffToAddUpdate.parties[0].registrationNo = this.registrationNumber;
    staffToAddUpdate.parties[0].personType[0].firstName =
      this.foundAttorney.personType[0].firstName;
    staffToAddUpdate.parties[0].personType[0].lastName =
      this.foundAttorney.personType[0].lastName;
    // staffToAddUpdate.parties[0].personType[0].mailingAddress =
    //   this.addMailingAddress(this.staffForm);
    staffToAddUpdate.parties[0].personType[0].mailingAddress[0].addressType =
      'BUS';
    staffToAddUpdate.parties[0].personType[0].electronicAddress =
      this.addElectronicAddress();
    return staffToAddUpdate;
  }

  addElectronicAddress() {
    const tempArr = [];
    const email = {
      email: this.foundAttorney.personType[0].electronicAddress[0].email,
      emailType: 'WE',
      extention: null,
      identifier: null,
    };
    const phone = {
      extension: null,
      identifier: null,
      teleCommAddresType: 'W',
      telephoneNumber: null,
    };
    const fax = {
      extension: null,
      identifier: null,
      teleCommAddresType: 'F',
      fax: null,
    };
    tempArr.push(email);
    tempArr.push(phone);
    tempArr.push(fax);

    return tempArr;
  }

  addAttorney() {
    this.associating = true;
    const payload = this.setAttorneyObj();

    console.log(payload);
    this.ifilingService
      .addAttorney(payload)
      .pipe(take(1))
      .subscribe(
        (success) => {
          // console.log('add', success);
          this.close(true);
        },
        (failure) => {
          if (this.attorneyType === 'LEAD') {
            this.commonUtils.setToastr(
              'error',
              'A lead attorney already exists on this application.'
            );
          } else {
            this.commonUtils.setToastr(
              'error',
              'Application System Error. Please contact the PTAB support team.'
            );
          }
          this.associating = false;
        }
      );
  }
}
