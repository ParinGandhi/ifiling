import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAttorneysModalComponent } from './add-attorneys-modal.component';

describe('AddAttorneysModalComponent', () => {
  let component: AddAttorneysModalComponent;
  let fixture: ComponentFixture<AddAttorneysModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAttorneysModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAttorneysModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
