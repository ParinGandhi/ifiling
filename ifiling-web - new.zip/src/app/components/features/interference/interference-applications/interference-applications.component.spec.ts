import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterferenceApplicationsComponent } from './interference-applications.component';

describe('InterferenceApplicationsComponent', () => {
  let component: InterferenceApplicationsComponent;
  let fixture: ComponentFixture<InterferenceApplicationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterferenceApplicationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterferenceApplicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
