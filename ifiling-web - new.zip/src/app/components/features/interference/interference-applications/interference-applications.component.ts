import { Component, Input, OnInit } from '@angular/core';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';

@Component({
  selector: 'app-interference-applications',
  templateUrl: './interference-applications.component.html',
  styleUrls: ['./interference-applications.component.scss'],
})
export class InterferenceApplicationsComponent implements OnInit {
  @Input() applications;
  resizeGrid = () => {
    this.gridParams.gridApi.sizeColumnsToFit();
  };
  gridParams = new GridParamsModel();

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
    resizeable: true,
  };

  columnDefs = [
    {
      field: 'applicationId',
      headerName: 'Application #',
      minWidth: 70,
    },
    {
      field: 'prcdPartyGroupTypeCd',
      headerName: 'Party type',
      minWidth: 110,
    },
    {
      field: 'inventionTitleTx',
      headerName: 'Application title',
      minWidth: 300,
    },
    {
      field: 'filingDate',
      headerName: 'Application filing date',
      minWidth: 110,
      comparator: this.gridHelper.dateComparator,
      type: 'date',
      sort: 'desc',
    },
    {
      field: 'patentNumber',
      headerName: 'Patent #',
      minWidth: 90,
    },
    {
      field: 'inventorFullNm',
      headerName: 'Inventor name',
      minWidth: 150,
    },
    {
      field: 'cfkRealPartyInInterestName',
      headerName: 'Real party in interest',
      minWidth: 150,
    },
  ];

  constructor(public gridHelper: GridHelperService) {}

  ngOnInit(): void {}

  ngOnDestroy() {
    window.removeEventListener('resize', this.resizeGrid);
  }

  onGridReady(params) {
    this.gridParams = this.gridHelper.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'Applications';
    this.gridParams.gridApi.sizeColumnsToFit();
    window.addEventListener('resize', this.resizeGrid);
  }
}
