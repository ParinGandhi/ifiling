import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterferenceDocumentsComponent } from './interference-documents.component';

describe('InterferenceDocumentsComponent', () => {
  let component: InterferenceDocumentsComponent;
  let fixture: ComponentFixture<InterferenceDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterferenceDocumentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterferenceDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
