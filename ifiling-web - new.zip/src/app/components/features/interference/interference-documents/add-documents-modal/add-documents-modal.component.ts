import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
// import { InitiatePetitionService } from '../../../../initiate-petition/initiate-petition.service';
// import { CaseViewerService } from '../../../case-viewer.service';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';

@Component({
  selector: 'app-add-documents-modal',
  templateUrl: './add-documents-modal.component.html',
  styleUrls: ['./add-documents-modal.component.scss'],
})
export class AddDocumentsModalComponent implements OnInit {
  modal: any;
  publicModalRef: BsModalRef;
  addDocumentForm: FormGroup;
  addingToList: boolean = false;
  addedDocumentsList: Array<any> = new Array<any>();
  showWarningMessage: boolean = false;
  filingPartyList: Array<any> = new Array<any>();
  availabilityList: Array<any> = new Array<any>();
  editMode: boolean = false;
  editIndex: number = null;
  showPaperErrorMessage: boolean = false;
  onePaperMin: boolean = false;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;
  paperTypeDisplayName: string = null;
  saving: boolean = false;
  partyRepresenting: string = null;
  // proceedingNumber: string;
  appealFiledDate: any = null;
  paperTypeList: any = null;
  selectedPaperType: string = '';
  nextExhibitNumbers: any;
  minExhibitNumber: number = 1;
  maxExhibitNumber: number = 9999;
  // listOfExistingExhibitNumbers = [];
  userDetails: any = null;
  currentExhibitNumber: any;
  exhibitMessage: boolean = false;
  nextNewVal: string;

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private logger: NGXLogger,
    // private caseViewerService: CaseViewerService,
    private store: Store<PtactsState>,
    public commonUtils: CommonUtilitiesService,
    private ifilingService: IfilingService // private initiatePetitionService: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    console.log(window.sessionStorage.getItem('userDetails'));
    if (window.sessionStorage.getItem('userDetails')) {
      this.userDetails = JSON.parse(
        window.sessionStorage.getItem('userDetails')
      );
    } else {
      this.store
        .select(PtactsSelectors.getUserDetailsState)
        .subscribe((data) => {
          this.userDetails = data;
        });
    }
    // this.partyRepresenting = window.sessionStorage.getItem('partyRepresenting');
    this.getFilingParties();
    this.getAvailabilities();
    this.getPaperTypes();
    this.setupForm();
    this.getNextExhibitNumber();
    // this.getAllExhibitNumbers();
  }

  getNextExhibitNumber() {
    this.ifilingService
      .getNextExhibitNumber(this.modal.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        this.nextExhibitNumbers = nextExhibitNumber;
        // const nextNumber =
        //   this.partyRepresenting.toLowerCase() === 'petitioner'
        //     ? nextExhibitNumber.petitionerExhibitSequence
        //     : nextExhibitNumber.patentownerExhibitSequence;
        // this.addDocumentForm.get('exhibitNumber').setValue(nextNumber);
        // this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  // The service does not provide a list, it is the same as getNextExhibitNumber
  // getAllExhibitNumbers() {
  //   this.ifilingService
  //     .getAllExhibitNumbers(this.modal.proceedingNo)
  //     .pipe(take(1))
  //     .subscribe((allExhibitNumbers: any) => {
  //       this.listOfExistingExhibitNumbers = allExhibitNumbers;
  //     });
  // }

  getFilingParties() {
    this.filingPartyList = [];
    // this.filingPartyList.push({
    //   partyType: 'BOARD',
    //   code: 'BPAI',
    //   displayNameText: `Board (BPAI)`,
    // });
    // console.log("All applications: ", this.modal.applications)
    // this.filingPartyList.push({
    //   partyType: 'JR.PARTY',
    //   code: this.userDetails.displayName,
    //   displayNameText: this.userDetails.displayName,
    // });
    // this.modal.applications.forEach((party) => {
    //   this.filingPartyList.push({
    //     partyType: party.prcdPartyGroupTypeCd,
    //     code: party.inventorFullNm,
    //     displayNameText: `${party.inventorFullNm} (${party.applicationId})`,
    //   });
    // });

    // this.modal.applications = [{"inventorFullNm":"Family, Given","patentNumber":null,"inventionTitleTx":"Customer Number 591234567","filingDate":"2010-03-17T04:00:00.000+0000","issueDate":null,"techCenterId":"OPIM","applicationId":"59123456","confidentialityIn":null,"artUnitCd":"OPIM","cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"SR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":49256,"prcdPartyGroupTypeId":4,"proceedingPartyMaps":[]},{"inventorFullNm":"MAILLOUX, LOUISD.","patentNumber":"5555557","inventionTitleTx":"BIT-MAP IMAGE RESOLUTION CONVERTER WITH CONTROLLED COMPENSATION FOR WRITE-WHITE XEROGRAPHIC LASER PRINTING","filingDate":"1994-11-14T05:00:00.000+0000","issueDate":"1996-09-10T04:00:00.000+0000","techCenterId":"2600","applicationId":"08338981","confidentialityIn":null,"artUnitCd":"2613","cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"SR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":49257,"prcdPartyGroupTypeId":4,"proceedingPartyMaps":[]},{"inventorFullNm":"SATO, JUN","patentNumber":"5555555","inventionTitleTx":"APPARATUS WHICH DETECTS LINES APPROXIMATING AN IMAGE BY REPEATEDLY NARROWING AN AREA OF THE IMAGE TO BE ANALYZED AND INCREASING THE RESOLUTION IN THE ANALYZED AREA","filingDate":"1994-01-19T05:00:00.000+0000","issueDate":"1996-09-10T04:00:00.000+0000","techCenterId":"2600","applicationId":"08183369","confidentialityIn":null,"artUnitCd":"2606","cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"SR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":49258,"prcdPartyGroupTypeId":4,"proceedingPartyMaps":[]},{"inventorFullNm":"TESTING PRIVATE","patentNumber":"12345678","inventionTitleTx":"PRIVATE PAIR TESTING","filingDate":"2006-12-12T05:00:00.000+0000","issueDate":"2013-03-01T05:00:00.000+0000","techCenterId":"1600","applicationId":"59314019","confidentialityIn":"N","artUnitCd":null,"cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"JR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":48954,"prcdPartyGroupTypeId":5,"proceedingPartyMaps":[{"juniorParty":{"caseNo":"200802","parties":[{"identifier":"15942239","registrationNo":"345678","rankNo":1,"partyType":"COUNSEL","partySubType":"LEAD","partySubTypeDescription":"Lead Counsel","submitterType":"JR.PARTY","proseIndicator":"N","personType":[{"identifier":"15944174","firstName":"Ericson","lastName":"Baker","mailingAddress":[{"identifier":"12207794","streetLineOneText":"   ","city":"   ","addressType":"BUS"}],"electronicAddress":[{"identifier":"12977081","telephoneNumber":"5555554781","teleCommAddresType":"W"},{"identifier":"10386133","email":"ebaker2022ptacs@gmail.com","emailType":"WE"}]}],"orgType":[]}]}}]},{"inventorFullNm":"TESTING PAIR","patentNumber":"12345679","inventionTitleTx":"PRIVATE PAIR TESTING. UPNE WAS HERE","filingDate":"2006-12-12T05:00:00.000+0000","issueDate":"2013-03-01T05:00:00.000+0000","techCenterId":"1600","applicationId":"59314018","confidentialityIn":"N","artUnitCd":null,"cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"JR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":49135,"prcdPartyGroupTypeId":5,"proceedingPartyMaps":[]},{"inventorFullNm":"DANIEL B. POURREAU","patentNumber":"5371298","inventionTitleTx":"PREPARATION OF DIALKYL PEROXIDES","filingDate":"1993-12-22T05:00:00.000+0000","issueDate":"1994-12-06T05:00:00.000+0000","techCenterId":"1600","applicationId":"08171957","confidentialityIn":"N","artUnitCd":null,"cfkRealPartyInInterestName":null,"prcdPartyGroupTypeCd":"JR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":46699,"prcdPartyGroupTypeId":5,"proceedingPartyMaps":[]},{"inventorFullNm":"HERBERT E. LITVAK","patentNumber":null,"inventionTitleTx":"OPTICAL TECHNIQUES OF MEASURING ENDPOINT DURING THE PROCESSING OF MATERIAL LAYERS IN AN OPTICALLY HOSTILE ENVIRONMENT","filingDate":"1998-06-15T04:00:00.000+0000","issueDate":null,"techCenterId":"1600","applicationId":"09097429","confidentialityIn":"N","artUnitCd":null,"cfkRealPartyInInterestName":"Â Y","prcdPartyGroupTypeCd":"JR.PARTY","lastModTs":"2010-06-18 14:21:50.0","lastModUserId":"88889","prcdInventionDisclosureId":45888,"prcdPartyGroupTypeId":5,"proceedingPartyMaps":[{"juniorParty":{"caseNo":"200802","parties":[{"identifier":"15935327","registrationNo":"10000 ","rankNo":2,"partyType":"COUNSEL","partySubType":"LEAD","partySubTypeDescription":"Lead Counsel","submitterType":"JR.PARTY","proseIndicator":"N","personType":[{"identifier":"15937262","firstName":"BOOPATHI","lastName":"KUPPUSAMY","mailingAddress":[],"electronicAddress":[]}],"orgType":[]}]}},{"juniorParty":{"caseNo":"200802","parties":[{"identifier":"15935328","registrationNo":"77777 ","rankNo":2,"partyType":"COUNSEL","partySubType":"LEAD","partySubTypeDescription":"Lead Counsel","submitterType":"JR.PARTY","proseIndicator":"N","personType":[{"identifier":"15937263","firstName":"PRASAD1","lastName":"YELLANKI","mailingAddress":[],"electronicAddress":[]}],"orgType":[]}]}}]}]
    const email = window.sessionStorage.getItem('email');
    this.modal.applications.forEach((element) => {
      if (
        element.proceedingPartyMaps &&
        element.proceedingPartyMaps.length > 0
      ) {
        element.proceedingPartyMaps.forEach((party) => {
          if (party?.juniorParty && party.juniorParty?.parties.length > 0) {
            // party.juniorParty?.parties.forEach((ele) => {
            //  console.log(ele)
            //  if (ele.personType[0].firstName.toLowerCase().trim() === this.userDetails?.firstName?.toLowerCase().trim() && ele.personType[0].lastName.toLowerCase().trim() === this.userDetails?.lastName?.toLowerCase().trim()) {
            //   this.filingPartyList.push({
            //     partyType: ele.submitterType,
            //     code: `${ele.personType[0].firstName.trim()} ${ele.personType[0].lastName.trim()}` ,
            //     displayNameText: `${ele.personType[0].firstName.trim()} ${ele.personType[0].lastName.trim()}`,
            //   });
            //  }

            // });
            this.checkForEmail(
              party.juniorParty?.parties,
              email,
              element.inventorFullNm
            );
          } else if (
            party?.seniorParty &&
            party.seniorParty?.parties.length > 0
          ) {
            this.checkForEmail(
              party.seniorParty?.parties,
              email,
              element.inventorFullNm
            );
            // party.seniorParty?.parties.forEach((ele) => {
            //   console.log(ele)
            //   if (ele.personType[0].firstName.toLowerCase().trim() === this.userDetails?.firstName?.toLowerCase().trim() && ele.personType[0].lastName.toLowerCase().trim() === this.userDetails?.lastName?.toLowerCase().trim()) {
            //   this.filingPartyList.push({
            //     partyType: ele.submitterType,
            //     code: `${ele.personType[0].firstName} ${ele.personType[0].lastName}` ,
            //     displayNameText: `${ele.personType[0].firstName} ${ele.personType[0].lastName}`,
            //   });
            //  }
            // });
          }
        });
      }
    });

    if (this.filingPartyList.length > 1) {
      this.filingPartyList.length = 1;
    }
    console.table(this.filingPartyList);
  }

  checkForEmail(parties, email, inventorFullNm) {
    // console.log(parties);
    parties.forEach((ele) => {
      // console.log(ele);
      if (
        ele.personType[0] &&
        ele.personType[0].electronicAddress &&
        ele.personType[0].electronicAddress.length > 0
      ) {
        ele.personType[0].electronicAddress.forEach((elAdd) => {
          if (
            elAdd.email &&
            elAdd.email.toLowerCase() === email.toLowerCase()
          ) {
            this.filingPartyList.push({
              partyType: ele.submitterType,
              // code: `${ele.personType[0].firstName.trim()} ${ele.personType[0].lastName.trim()}`,
              // displayNameText: `${ele.personType[0].firstName.trim()} ${ele.personType[0].lastName.trim()}`,
              code: inventorFullNm,
              displayNameText: inventorFullNm,
            });
          }
        });
      }
    });
  }

  filingPartyChanged(filingParty) {
    if (filingParty) {
      // if (filingParty.partyType == 'SR.PARTY') {
      //   this.minExhibitNumber = parseInt(
      //     this.nextExhibitNumbers.petitionerExhibitSequence
      //   );
      //   this.maxExhibitNumber = 1999;
      // } else if (filingParty.partyType == 'JR.PARTY') {
      //   this.minExhibitNumber = parseInt(
      //     this.nextExhibitNumbers.patentownerExhibitSequence
      //   );
      //   this.maxExhibitNumber = null;
      // } else {
      //   this.minExhibitNumber = parseInt(
      //     this.nextExhibitNumbers.boardExhibitSequence
      //   );
      //   this.maxExhibitNumber = 999;
      // }
      // this.addDocumentForm.get('exhibitNumber').setValue(this.minExhibitNumber);
      // this.addDocumentForm.controls['exhibitNumber'].setValidators([
      //   Validators.min(this.minExhibitNumber),
      //   Validators.max(this.maxExhibitNumber),
      // ]);
      this.addDocumentForm.get('exhibitNumber').enable();
    }
  }

  getAvailabilities() {
    this.availabilityList = [
      {
        code: 'PUBLIC',
        descriptionText: 'Available for everyone.',
        displayNameText: 'Public',
      },
      {
        code: 'PRIVATE',
        descriptionText: 'Available to parties and board.',
        displayNameText: 'Parties and Board',
      },
      {
        code: 'CONFIDENTIAL',
        descriptionText: 'Available to filing party and board.',
        displayNameText: 'Filing Party and Board',
      },
      {
        code: 'BOARD',
        descriptionText: 'Available only to board.',
        displayNameText: 'Board ',
      },
    ];
    // this.ifilingService
    //   .getAvailabilities('availability', true)
    //   .pipe(take(1))
    //   .subscribe((availabilitiesResponse) => {
    //     this.availabilityList = availabilitiesResponse;
    //     // this.logger.info('AvailabilitiesList', this.availabilityList);
    //   });
  }

  getPaperTypes() {
    this.ifilingService
      .getDocumentPaperTypes()
      .pipe(take(1))
      .subscribe((paperTypesResponse) => {
        // paperTypesResponse.stateDocumentTypes =
        //   this.commonUtils.removeSpaceFromPaperTypes(
        //     paperTypesResponse.stateDocumentTypes
        //   );

        // this.paperTypeList = this.commonUtils.sortAlphabetically(
        //   paperTypesResponse.stateDocumentTypes,
        //   'displayNameText'
        // );
        this.paperTypeList = paperTypesResponse;
      });
  }

  setupForm() {
    this.addDocumentForm = this.fb.group({
      // filingParty: [this.partyRepresenting.toLowerCase()],
      filingParty: ['', Validators.required],
      docType: ['paper', Validators.required],
      paperType: ['', Validators.required],
      exhibitNumber: [{ value: null, disabled: true }],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    this.addDocumentForm.get('fileToUpload').setValue(event.target.files[0]);
    this.addDocumentForm.get('fileName').setValue(event.target.files[0].name);
  }

  clearForm() {
    this.addDocumentForm.get('docType').enable();
    this.addDocumentForm.get('fileName').enable();
    this.addDocumentForm.reset();
    this.clearFile();
    this.setupForm();
    this.editMode = false;
    this.showWarningMessage = false;
    this.showPaperErrorMessage = false;
    this.onePaperMin = false;
    this.editIndex = null;
    this.paperTypeDisplayName = null;
    this.saving = false;
    this.addingToList = false;
    this.selectedPaperType = null;
    this.exhibitMessage = false;
  }

  clearFile() {
    const fileElement = document.getElementById('file');
    if (fileElement) {
      (<HTMLInputElement>document.getElementById('file')).value = '';
      this.addDocumentForm.get('fileToUpload').setValue(null);
      this.addDocumentForm.get('fileName').setValue(null);
    }
  }

  changeDocType(docType) {
    if (docType === 'exhibit') {
      this.getNextLowestExhibitNumber();
      this.exhibitMessage = true;
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      // let nextNum = this.nextExhibitNumbers.intf;
      // while (this.addedDocumentsList.find((d) => d.exhibitNumber === nextNum)) {
      //   nextNum++;
      // }
      // this.addDocumentForm.get('exhibitNumber').setValue(nextNum);
      this.addDocumentForm.controls['exhibitNumber'].setValidators([
        Validators.min(this.minExhibitNumber),
        Validators.max(this.maxExhibitNumber),
        Validators.required,
      ]);
      console.log('form', this.addDocumentForm);
      this.addDocumentForm.get('exhibitNumber').updateValueAndValidity();
      this.addDocumentForm.get('paperType').clearValidators();
      this.addDocumentForm.get('paperType').updateValueAndValidity();
      // if (this.addedDocumentsList.length <= 0) {
      //   this.showWarningMessage = true;
      // }
    } else {
      this.exhibitMessage = false;
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = false;
    }
  }

  addToList() {
    // if (!this.paperDocumentExists()) {      
    this.addingToList = true;
    this.addDocumentForm.disable();    
    if (
      this.addDocumentForm.value.docType.toLowerCase() ===
      CONSTANTS.DOC_TYPE.PAPER
    ) {
      this.addDocumentForm.get('exhibitNumber').setValue('');
    }
    if(this.addDocumentForm.value.exhibitNumber && this.addDocumentForm.value.exhibitNumber > 2999 && this.addDocumentForm.value.exhibitNumber < 4000){
      this.addingToList = false;
      this.addDocumentForm.enable();
      this.commonUtils.showError(
        'Exhibit numbers 3000-3999 are reserved for the Board only. Please choose another number and try again.',
        'Add to list failed'
      );
    }
    else if (
      this.addDocumentForm.value.docType.toLowerCase() ===
        CONSTANTS.DOC_TYPE.EXHIBIT &&
      (this.addedDocumentsList.find(
        (d) => d.exhibitNumber == this.addDocumentForm.value.exhibitNumber
      ) ||
        this.modal.existingExhibitsList.find(
          (e) => e.exhibitNumber == this.addDocumentForm.value.exhibitNumber
        ))
    ) {
      this.addingToList = false;
      this.addDocumentForm.enable();
      this.commonUtils.showError(
        'Exhibit number is already used. Please choose another number and try again.',
        'Add to list failed'
      );
    }
    else {
      this.ifilingService
        .addToList(
          this.addDocumentForm.value.fileToUpload,
          this.addDocumentForm.value.docType,
          this.modal.proceedingIdentifier
        )
        .pipe(take(1))
        .subscribe(
          (fileAdded) => {
            // this.logger.info('Added to list', fileAdded);
            // this.selectedFilingParty = !this.selectedFilingParty
            //   ? this.addDocumentForm.value.filingParty
            //   : this.selectedFilingParty;
            // this.addDocumentForm
            //   .get('uploadedDate')
            //   .setValue(this.commonUtils.getCurrentDateString('time'));
            // // this.addDocumentForm
            // //   .get('artifactIdentifer')
            // //   .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
            // if (this.addDocumentForm.value.docType === 'exhibits') {
            //   this.minExhibitNumber++;
            // } else {
            //   this.addDocumentForm.get('exhibitNumber').setValue(null);
            // }
            // this.addDocumentForm.get('pageCount').setValue(fileAdded.pageCount);
            // this.addedDocumentsList.push(this.addDocumentForm.value);
            // this.clearForm();
            this.addDocumentForm.enable();
            console.log('form', this.addDocumentForm);
            this.showPaperErrorMessage = !this.paperDocumentExists();
            let petitionDocument = null;
            let filingParty =
              this.addDocumentForm.value.filingParty.partyType.toUpperCase();
            if (this.addDocumentForm.value.docType.toLowerCase() === 'paper') {
              const docId = this.addDocumentForm.value.paperType.documentTypeId
                ? this.addDocumentForm.value.paperType.documentTypeId
                : this.addDocumentForm.value.paperType.identifier;
              petitionDocument = new PetitionDocument(
                this.addDocumentForm.value.docType.toUpperCase(),
                this.addDocumentForm.value.documentName,
                this.addDocumentForm.value.fileName,
                filingParty,
                this.addDocumentForm.value.availability.code,
                docId,
                this.addDocumentForm.value.paperType.code,
                this.addDocumentForm.value.filingParty.code,
                this.addDocumentForm.value.fileToUpload.type,
                null,
                'Y',
                null
              );
            } else {
              petitionDocument = new PetitionDocument(
                this.addDocumentForm.value.docType.toUpperCase(),
                this.addDocumentForm.value.documentName,
                this.addDocumentForm.value.fileName,
                filingParty,
                this.addDocumentForm.value.availability.code,
                null,
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.addDocumentForm.value.filingParty.code,
                this.addDocumentForm.value.fileToUpload.type,
                this.addDocumentForm.value.exhibitNumber,
                'Y',
                null
              );
            }

            const documentToAdd = new DocumentToAdd(petitionDocument);
            documentToAdd.proceedingNumberText = this.modal.proceedingNo;
            this.addDocumentForm.get('pageCount').setValue(fileAdded.pageCount);
            this.addDocumentForm
              .get('filingDate')
              .setValue(fileAdded.filingDate);
            this.addDocumentForm
              .get('uploadedDate')
              .setValue(this.commonUtils.setEST(new Date().getTime()));
            this.logger.log('Document to add:', documentToAdd);
            this.addingToList = false;
            // this.saveDocumentToCMS(documentToAdd);
            this.addedDocumentsList.push(this.addDocumentForm.value);
            if (
              this.addDocumentForm.value.docType.toLowerCase() ===
              CONSTANTS.DOC_TYPE.EXHIBIT
            ) {
              // this.getNextExhibitNumber();
              // this.minExhibitNumber = this.commonUtils.getNextExhibitNumber({
              //   currentNumber: this.addDocumentForm.get('exhibitNumber').value,
              //   listOfNumbers: this.listOfExistingExhibitNumbers,
              // });
            }
            this.clearForm();
            this.showPaperErrorMessage = !this.paperDocumentExists();
            this.commonUtils.focusOnCloseModal('closeAddDocumentsModal');
            this.exhibitMessage = false;
          },
          (addToListFailure) => {
            this.addingToList = false;
            this.addDocumentForm.enable();
            this.commonUtils.showError(
              addToListFailure.statusText,
              `Add to list failed`
            );
            this.commonUtils.throwError(`Add to list failed`, addToListFailure);
            this.commonUtils.focusOnCloseModal('closeAddDocumentsModal');
          }
        );
    }
    // } else {
    //   this.showPaperErrorMessage = true;
    // }
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.docType.toLowerCase() === 'paper' &&
          this.addDocumentForm.value.docType === 'paper'
        ) {
          paperDocExists = true;
        }
      });
    }
    return paperDocExists;
  }

  // saveDocumentToCMS(documentToAdd) {
  //   this.addDocumentForm.disable();
  //   this.ifilingService
  //     .saveToCMS(documentToAdd)
  //     .pipe(take(1))
  //     .subscribe(
  //       (saveSuccessful) => {
  //         this.addDocumentForm.enable();
  //         this.logger.info('Saved document to CMS', saveSuccessful);
  //         this.selectedFilingParty = !this.selectedFilingParty
  //           ? this.addDocumentForm.value.filingParty
  //           : this.selectedFilingParty;
  //         // this.addDocumentForm
  //         //   .get('uploadedDate')
  //         //   .setValue(this.commonUtils.getCurrentDateString('time'));
  //         this.addDocumentForm
  //           .get('uploadedDate')
  //           .setValue(this.commonUtils.setEST(new Date().getTime()));
  //         this.addDocumentForm
  //           .get('artifactIdentifer')
  //           .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
  //         if (this.addDocumentForm.value.docType === 'exhibit') {
  //           // this.getNextExhibitNumber();
  //         } else {
  //           this.addDocumentForm.get('exhibitNumber').setValue(null);
  //         }
  //         this.addDocumentForm
  //           .get('contentManagementId')
  //           .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
  //         this.addedDocumentsList.push(this.addDocumentForm.value);
  //         this.clearForm();
  //         this.showPaperErrorMessage = !this.paperDocumentExists();
  //       },
  //       (documentSaveFailed) => {
  //         // this.logger.error(
  //         //   'Failed to save document to CMS',
  //         //   documentSaveFailed
  //         // );
  //         // this.commonUtils.showError(
  //         //   documentSaveFailed.error.message,
  //         //   'Add document'
  //         // );
  //         this.commonUtils.throwError(
  //           `Save document failed for Other document`,
  //           documentSaveFailed
  //         );
  //         this.addingToList = false;
  //         this.addDocumentForm.enable();
  //       }
  //     );
  // }

  submitDocuments() {
    this.saving = true;
    let petitionDocument = null;
    let documentObj = {
      partyRequestTypes: [],
      proceedingNumberText: this.modal.proceedingNo,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        createUserIdentifier: window.sessionStorage.getItem('email'),
      },
      petitionDocuments: [],
      joinderOrginalIndicator: null,
    };
    this.addedDocumentsList.forEach((doc) => {
      if (doc.docType.toLowerCase() === 'paper') {
        const docId = doc.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier;
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileToUpload.name,
          doc.filingParty.partyType,
          doc.availability.code,
          docId,
          doc.paperType.code,
          doc.filingParty.code,
          doc.fileToUpload.type,
          null,
          'Y',
          null
        );
      } else {
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileToUpload.name,
          doc.filingParty.partyType,
          doc.availability.code,
          null,
          CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
          doc.filingParty.code,
          doc.fileToUpload.type,
          doc.exhibitNumber,
          'Y',
          null
        );
      }
      documentObj.petitionDocuments.push(petitionDocument);

      console.log('DocumentObj: ', documentObj);
    });
    this.ifilingService
      .submitDocuments(documentObj)
      .pipe(take(1))
      .subscribe(
        (documentsResponse) => {
          this.commonUtils.showSuccess(
            'Document(s) uploaded successfully.',
            'Document upload'
          );
          this.saving = false;
          this.logger.info(documentsResponse);
          this.close(true);
        },
        (submitFailure) => {
          this.logger.error(submitFailure.error.message);
          this.commonUtils.showError(
            submitFailure.error.message,
            'Document upload'
          );
          this.saving = false;
        }
      );
  }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    if (this.addedDocumentsList[e].pageCount == undefined) {
      this.addedDocumentsList[e].pageCount = 1;
    }
    if (!this.addedDocumentsList[e]?.fileName) {
      this.addedDocumentsList[e].fileName =
        this.addedDocumentsList[e].documentName;
    }
    this.addDocumentForm.setValue(this.addedDocumentsList[e]);
    // this.selectedPaperType = this.addedDocumentsList[e].paperType.displayName
    //   ? this.addedDocumentsList[e].paperType.displayName
    //   : this.addedDocumentsList[e].paperType.descriptionText;
    this.selectedPaperType = this.addedDocumentsList[e].paperType;
    if (this.addedDocumentsList[e].docType === 'exhibit') {
      console.log("check");
      this.currentExhibitNumber =
        this.addDocumentForm.get('exhibitNumber').value;
      this.addDocumentForm.get('paperType').clearValidators();
      this.addDocumentForm.get('paperType').updateValueAndValidity();
      // this.addDocumentForm
      //   .get('exhibitNumber')
      //   .setValidators(Validators.required);
      this.addDocumentForm.controls['exhibitNumber'].setValidators([
        Validators.min(this.minExhibitNumber),
        Validators.max(this.maxExhibitNumber),
        Validators.required,
      ]);
      this.addDocumentForm.get('exhibitNumber').updateValueAndValidity();
    }
    this.addDocumentForm.updateValueAndValidity();
    // this.addDocumentForm.get('docType').disable();
    this.addDocumentForm.get('fileName').disable();
  }

  onMotionTypeSelect(e) {}

  getSpecificPaperType(e) {
    // this.addDocumentForm.get('paperType').setValue(e.item);
    // this.paperTypeDisplayName = e.value;
    this.addDocumentForm.get('paperType').setValue(e);
    this.paperTypeDisplayName = e.value;
  }

  update() {
    console.log(this.addedDocumentsList);
    console.log(this.modal.existingExhibitsList);
    this.addingToList = true;
    if(this.addDocumentForm.value.exhibitNumber && this.addDocumentForm.value.exhibitNumber > 2999 && this.addDocumentForm.value.exhibitNumber < 4000){
      this.addingToList = false;
      this.addDocumentForm.enable();
      this.commonUtils.showError(
        'Exhibit numbers 3000-3999 are reserved for the Board only. Please choose another number and try again.',
        'Add to list failed'
      );
    }
    else if (
      this.addDocumentForm.value.docType.toLowerCase() ===
        CONSTANTS.DOC_TYPE.EXHIBIT &&
      this.addDocumentForm.value.exhibitNumber != this.currentExhibitNumber &&
      (this.addedDocumentsList.find(
        (d) => d.exhibitNumber == this.addDocumentForm.value.exhibitNumber
      ) ||
        this.modal.existingExhibitsList.find(
          (e) => e.exhibitNumber == this.addDocumentForm.value.exhibitNumber
        ))
    ) {
      this.addingToList = false;
      this.addDocumentForm.enable();
      this.commonUtils.showError(
        'Exhibit number is already used. Please choose another number and try again.',
        'Update failed'
      );
    }
    else {
      // this.addDocumentForm
      //   .get('uploadedDate')
      //   .setValue(this.commonUtils.getCurrentDateString('time'));
      // this.addDocumentForm
      //   .get('uploadedDate')
      //   .setValue(this.commonUtils.setEST(new Date().getTime()));
      // this.addDocumentForm.get('docType').enable();
      // this.addDocumentForm.get('fileName').enable();
      // this.addedDocumentsList[this.editIndex] = this.addDocumentForm.value;

      // this.clearForm();
      // this.caseViewerService
      //   .updateDocument(
      //     this.addedDocumentsList[this.editIndex],
      //     this.addDocumentForm,
      //     this.noticeOfAppealModalInfo.proceedingNo
      //   )
      //   .pipe(take(1))
      //   .subscribe(
      //     (editSuccess) => {
      //       this.addDocumentForm
      //         .get('uploadedDate')
      //         .setValue(this.commonUtils.getCurrentDateString('time'));
      //       this.addedDocumentsList[this.editIndex] =
      //         this.addDocumentForm.value;
      //       this.getNextExhibitNumber();
      //       this.clearForm();
      //       this.addingToList = false;
      //     },
      //     (editFailure) => {
      //       this.addingToList = false;
      //     }
      //   );

      this.addDocumentForm
        .get('uploadedDate')
        .setValue(this.commonUtils.setEST(new Date().getTime()));
      this.addDocumentForm.get('fileName').enable();
      this.addedDocumentsList[this.editIndex] = this.addDocumentForm.value;

      this.currentExhibitNumber = null;
      this.clearForm();
      this.addingToList = false;

      if (
        this.addDocumentForm.value.docType.toLowerCase() ===
        CONSTANTS.DOC_TYPE.EXHIBIT
      ) {
        // this.getNextExhibitNumber();
      }
    }
  }

  // saveSubmitNoticeOfAppeal() {
  //   this.saving = true;
  //   const currentTime = new Date().getTime();
  //   this.logger.info('Notice of appeal form:', this.addDocumentForm);
  //   let noticeOfAppealObj = {
  //     proceedingNumberText: this.modal.proceedingNo,
  //     filingParty: this.selectedFilingParty
  //       ? this.selectedFilingParty
  //       : 'Petitioner',
  //     motionStatusDate: null,
  //     submittedDate: currentTime,
  //     audit: {
  //       lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
  //       lastModifiedTimestamp: currentTime,
  //       createTimestamp: currentTime,
  //     },
  //     noticeOfAppealDocuments: null,
  //   };
  //   let noticeOfAppealDocuments = [];
  //   this.addedDocumentsList.forEach((doc) => {
  //     const noticeOfAppealDoc = {
  //       category: doc.docType.toUpperCase(),
  //       exhibitNumber: doc.docType === 'exhibit' ? doc.exhibitNumber : null,
  //       sequenceNumber: null,
  //       name: doc.documentName,
  //       fileName: doc.fileToUpload.name,
  //       filingParty: this.selectedFilingParty
  //         ? this.selectedFilingParty
  //         : 'Petitioner',
  //       availability: doc.availability.code,
  //       documentTypeIdentifier: doc.paperType.documentTypeId
  //         ? doc.paperType.documentTypeId
  //         : doc.paperType.identifier,
  //       documentTypeCode: doc.paperType.code,
  //       mimeType: doc.fileToUpload.type,
  //     };
  //     noticeOfAppealDocuments.push(noticeOfAppealDoc);
  //   });
  //   noticeOfAppealObj.noticeOfAppealDocuments = noticeOfAppealDocuments;

  //   this.caseViewerService
  //     .saveSubmitMotion(noticeOfAppealDocuments)
  //     .pipe(take(1))
  //     .subscribe(
  //       (saveMotionResponse) => {
  //         this.logger.info('Motion saved successfully', saveMotionResponse);
  //         // this.setSuccessToastr(motionStatus);
  //         this.commonUtils.showSuccess(
  //           'Successfully submitted notice of appeal',
  //           'Notice of appeal'
  //         );
  //         this.close(false);
  //       },
  //       (motionSaveError) => {
  //         this.logger.error('Motion failed to save', motionSaveError);
  //         this.commonUtils.showError(
  //           motionSaveError.error.message,
  //           'Notice of appeal'
  //         );
  //         this.saving = false;
  //       }
  //     );
  // }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
  }

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.showWarningMessage = e;
  }

  close(selection) {
    // this.modalService.config.initialState.closeModal = selection;
    this.modal.closeModal = selection;
    this.modalService.hide();
  }

  checkForm() {
    this.logger.info('Motions form: ', this.addDocumentForm);
    this.logger.info('Warning message: ', this.showWarningMessage);
    this.logger.info('Saving: ', this.saving);
    this.logger.info('Adding to list: ', this.addingToList);
  }

  checkAvailability(action) {
    if (
      this.addDocumentForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: any = {
      modal: {
        keepPublic: false,
      },
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      {
        class: 'modal-lg second-modal',
        animated: true,
        ignoreBackdropClick: true,
        initialState,
      }
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.keepPublic) {
        action === 'add' ? this.addToList() : this.update();
      }
    });
  }

  getNextLowestExhibitNumber() {
    let listLength = this.addedDocumentsList.length;
    this.ifilingService.getNextExhibitNumber(this.modal.proceedingNo).subscribe((nextNo: any) => {
      if (this.addedDocumentsList.length > 0) {
        for (var i = listLength - 1; i >= 0; i--) {
          if (this.addedDocumentsList[i]?.exhibitNumber) {
            let nextnum = this.addedDocumentsList[i].exhibitNumber;
            this.checkNextValFromList(nextnum);
            this.addDocumentForm.get('exhibitNumber').setValue((parseInt(this.nextNewVal)).toString());
            break;
          }
          else {
            this.addDocumentForm.get('exhibitNumber').setValue(nextNo.intf);
          }

        }
      }
      else {
        this.addDocumentForm.get('exhibitNumber').setValue(nextNo.intf);
      }
    })
  }

  checkNextValFromList(nextnum) {
    this.nextNewVal = '';
    if (this.addedDocumentsList.find(
      (d) => d.exhibitNumber == nextnum
    ) ||
      this.modal.existingExhibitsList.find(
        (e) => e.exhibitNumber == nextnum
      )) {
      nextnum = parseInt(nextnum) + 1;
      this.checkNextValFromList(nextnum);
    }
    else if (nextnum == 3000) {
      nextnum = parseInt(nextnum) + 1000;
      this.checkNextValFromList(nextnum);
    }
    else {
      this.nextNewVal = nextnum;
    }
  }

}
