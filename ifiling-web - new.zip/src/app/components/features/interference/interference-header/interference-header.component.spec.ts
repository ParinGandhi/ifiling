import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterferenceHeaderComponent } from './interference-header.component';

describe('InterferenceHeaderComponent', () => {
  let component: InterferenceHeaderComponent;
  let fixture: ComponentFixture<InterferenceHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterferenceHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterferenceHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
