import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PublicSearchRoutingModule } from './public-search-routing.module';
import { AgGridModule } from 'ag-grid-angular';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AgGridModule.withComponents([]), 
    PublicSearchRoutingModule
  ]
})
export class PublicSearchModule { }
