import { TestBed } from '@angular/core/testing';

import { PublicSearchService } from './public-search.service';

describe('PublicSearchService', () => {
  let service: PublicSearchService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PublicSearchService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
