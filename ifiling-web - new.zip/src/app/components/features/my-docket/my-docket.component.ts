import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import {
  getUserDetails,
  setUserDetails,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';

@Component({
  selector: 'app-my-docket',
  templateUrl: './my-docket.component.html',
  styleUrls: ['./my-docket.component.scss'],
})
export class MyDocketComponent implements OnInit {
  constructor(
    private router: Router,
    public oktaAuth: OktaAuthService,
    private store: Store<PtactsState>
  ) {}

  async ngOnInit() {
    document.title = 'My docket';
    const isAuthenticated = await this.oktaAuth.isAuthenticated();
    this.oktaAuth.$authenticationState.subscribe(
      (isAuthenticated: boolean) => (isAuthenticated = isAuthenticated)
    );

    if (isAuthenticated) {
      const accessToken = this.oktaAuth.getAccessToken();
      const userInfo = await this.oktaAuth.token.getUserInfo();
      console.log('User info from OIDC: ', userInfo);
      this.store
        .select(PtactsSelectors.getUserDetailsState)
        .subscribe((obj) => {
          console.log('**** USER STATE:', obj);
        });
      this.setUserInState(userInfo);
    }
  }

  setUserInState(userInfo) {
    const userDetails = {
      lastName: userInfo.lastName,
      patronId: userInfo.patronId,
      displayName: userInfo.displayName,
      roles: userInfo.groups,
      userId: userInfo.userLogin,
      employeeNumber: null,
      firstName: userInfo.firstName,
      emailAddress: userInfo.emailAddress,
      ptabDefaultRefreshTime: null,
      employeeType: userInfo.accountType,
      ptabReadOnlyUser: null,
      clientIP: null,
      middleName: userInfo.middleName,
      passwordExpired: null,
      authLevel: null,
    };
    this.store.dispatch(setUserDetails({ payload: userDetails }));
  }
}
