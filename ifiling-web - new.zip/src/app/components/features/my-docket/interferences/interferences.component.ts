import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { MyDocketService } from '../my-docket.services';

import { select, Store } from '@ngrx/store';
import { setUserDetails } from 'src/app/store/ptacts/ptacts.actions';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { OpenCaseViewerComponent } from 'src/app/components/common/open-case-viewer/open-case-viewer.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { OktaAuthService } from '@okta/okta-angular';

@Component({
  selector: 'app-interferences',
  templateUrl: './interferences.component.html',
  styleUrls: ['./interferences.component.scss'],
})
export class InterferencesComponent implements OnInit {
  // loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  resizeGrid = () => {
    this.gridParams.gridApi.sizeColumnsToFit();
  };
  gridParams = new GridParamsModel();
  applications = [];
  loggedInUser = null;
  isAuthenticated: boolean = false;
  groups: string[] = [];

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
  };

  colWidth = '15%';

  columnDefs = [
    {
      field: 'proceedingNo',
      headerName: 'Interference #',
      width: this.colWidth,
      resizable: true,
      sort: 'desc',
      cellRendererFramework: OpenCaseViewerComponent,
      cellRendererParams: { fromComponent: 'myDocket' },
    },
    {
      field: 'applicationId',
      headerName: 'Application #',
      width: this.colWidth,
      resizable: true,
    },
    {
      field: 'patentNo',
      headerName: 'Patent #',
      width: this.colWidth,
      resizable: true,
    },
    {
      field: 'inventorName',
      headerName: 'Invention title',
      resizable: true,
      // comparator: this.gridHelper.dateComparator,
    },
    {
      field: 'patryName',
      headerName: 'Party name',
      width: '35%',
      resizable: true,
    },
  ];

  constructor(
    private gridHelper: GridHelperService,
    private myDocketService: MyDocketService,
    private store: Store<PtactsState>,
    private commonUtils: CommonUtilitiesService,
    public oktaAuth: OktaAuthService
  ) {}

  async ngOnInit() {
    // this.store
    //   .select(PtactsSelectors.getUserDetailsState)
    //   .subscribe((userDetails) => {
    //     this.loggedInUser = userDetails;
    //     // this.getMyDocketCases(this.loggedInUser.emailAddress);
    //     this.getMyDocketCases('parin.a.gandhi@gmail.com');
    //   });
    this.isAuthenticated = await this.oktaAuth.isAuthenticated();
    // Subscribe to authentication state changes
    this.oktaAuth.$authenticationState.subscribe(
      (isAuthenticated: boolean) => (this.isAuthenticated = isAuthenticated)
    );

    // Get user information
    if (this.isAuthenticated) {
      // get okta access token info and the user info if we're authenticated
      const accessToken = this.oktaAuth.getAccessToken();
      const userInfo = await this.oktaAuth.token.getUserInfo();
      console.log('User info from OIDC: ', userInfo);
      window.sessionStorage.setItem('user-name', userInfo.emailAddress);
      this.groups = userInfo.groups;
      console.log(this.groups);
      this.setUserInState(userInfo);
      this.store
        .select(PtactsSelectors.getUserDetailsState)
        .subscribe((obj) => {
          console.log('**** USER STATE IN CASE VIEWER:', obj);
        });
      this.getMyDocketCases(userInfo.emailAddress);
    }
  }

  ngOnDestroy() {
    window.removeEventListener('resize', this.resizeGrid);
  }

  setUserInState(userInfo) {
    const userDetails = {
      lastName: userInfo.lastName,
      patronId: userInfo.patronId,
      displayName: userInfo.displayName,
      roles: userInfo.groups,
      userId: userInfo.userLogin,
      employeeNumber: null,
      firstName: userInfo.firstName,
      emailAddress: userInfo.emailAddress,
      ptabDefaultRefreshTime: null,
      employeeType: userInfo.accountType,
      ptabReadOnlyUser: null,
      clientIP: null,
      middleName: userInfo.middleName,
      passwordExpired: null,
      authLevel: null,
    };
    this.store.dispatch(setUserDetails({ payload: userDetails }));
  }

  getMyDocketCases(loggedInUserEmail) {
    this.myDocketService
      .getMyInterferences(loggedInUserEmail)
      .pipe(take(1))
      .subscribe((myDcoketResponse) => {
        this.applications = myDcoketResponse;
      });
  }

  onGridReady(params) {
    this.gridParams = this.gridHelper.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'myDocket';
    params.api.sizeColumnsToFit();
    window.addEventListener('resize', this.resizeGrid);
  }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colId === 'proceedingNo') {
      this.commonUtils.openCaseViewerFromMyDocket(e.data.proceedingNo);
    }
  }
}
