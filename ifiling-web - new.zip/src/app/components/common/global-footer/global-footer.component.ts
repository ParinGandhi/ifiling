import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-global-footer',
  templateUrl: './global-footer.component.html',
  styleUrls: ['./global-footer.component.scss'],
})
export class GlobalFooterComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));

  constructor(private store: Store<PtactsState>) {}

  ngOnInit(): void {}
}
