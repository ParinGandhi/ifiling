import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { CommonService } from 'src/app/services/common.service';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-open-document',
  templateUrl: './open-document.component.html',
  styleUrls: ['./open-document.component.less'],
})
export class OpenDocumentComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  docTitle: any;
  params: any;
  public: boolean = false;
  board: boolean = false;

  constructor(
    private store: Store<CaseViewerState>,
    private commonService: CommonService
  ) {}

  agInit(params) {
    this.params = params;
    this.public = this.params?.data?.availability.toLowerCase() === 'public';
    this.board = this.params?.data?.availability.toLowerCase() === 'board';
  }

  ngOnInit(): void {}

  openDocument() {
    this.commonService.openPdf(
      this.params.data.petitionIdentifier,
      this.params.data.artifactIdentifer
    );
  }
}
