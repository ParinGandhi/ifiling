import { Component, OnInit } from '@angular/core';
// import { take } from 'rxjs/operators';
// import { Urls } from 'src/app/constants/urls';
// import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
// import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-open-case-viewer',
  templateUrl: './open-case-viewer.component.html',
  styleUrls: ['./open-case-viewer.component.scss'],
})
export class OpenCaseViewerComponent implements OnInit {
  proceedingNo: any;
  srText: string;
  params: any;
  checkForUser: boolean = false;
  fromNotifications: boolean = false;
  // documentsModalRef: BsModalRef = null;

  constructor(
    private commonUtils: CommonUtilitiesService
  ) // private caseViewerService: CaseViewerService,
  // private modalService: BsModalService
  {}

  agInit(params) {
    this.params = params;
    this.proceedingNo = params.value;
    if (
      this.params.fromComponent &&
      this.params.fromComponent === 'searchDocuments'
    ) {
      this.checkForUser = true;
    }
    if (this.params.data.applicationId) {
      this.srText =
        'Open Interference ' +
        this.proceedingNo +
        'with Application Number ' +
        this.params.data.applicationId;
    }
  }

  ngOnInit(): void {}

  openCaseViewer() {
    // if (this.params.fromComponent && this.params.fromComponent === 'myDocket') {
    this.commonUtils.openCaseViewerFromMyDocket(this.proceedingNo);
    // } else {
    //   this.commonUtils.openCaseViewerForPublic(this.proceedingNo);
    // }
  }
}
