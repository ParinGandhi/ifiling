import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-session-timer',
  templateUrl: './session-timer.component.html',
  styleUrls: ['./session-timer.component.scss'],
})
export class SessionTimerComponent implements OnInit {
  modal: any;
  counter: any = null;

  constructor(public modalRef: BsModalRef) {}

  ngOnInit(): void {}

  closeModal(toContinue) {
    this.modal.continue = toContinue;
    this.modalRef.hide();
  }
}
