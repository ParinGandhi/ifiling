# FFE API Dashboard UI

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Deployment configuration
* The `public-dev` directory has files for the `public` directory that are only useful for local development.
* The `public-deploy` directory has files for the `public` directory that are only useful for AWS deployment. Some files may be template files that will be used to overwrite files in the `dist` directory after building and before publishing.

### Deploy to S3
```
FAD_S3_BUCKET=mybucket \
    FAD_API_GATEWAY_DOMAIN=0000000000.execute-api.us-east-1.amazonaws.com \
    FAD_API_GATEWAY_STAGE=/Prod \
    ./deploy.sh
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
