<template>
  <div class="fad-request-editor">
    <div class="fad-service-config fad-panel">
      <div class="heading">Service Config
        <button type="button" v-on:click="resetServiceConfig">Reset to default</button>
      </div>
      <AceXmlEditor
        ref="ace-service-config"
        v-bind:key="serviceResetCount"
        class="vertical"
        v-model="serviceText"
        v-bind:options="editorOptions"
        lang="json"/>
    </div>
    <div class="vertical">
      <div class="fad-modeled-form fad-panel">
        <div class="heading">Modeled Form
          <button type="button" v-on:click="resetModeledForm">Reset to default values</button>
        </div>
        <ModeledForm
          v-bind:key="formResetCount"
          v-bind:schema="formSchema"
          v-model="formModel"/>
      </div>
      <div class="fad-displayed-form-schema fad-panel">
        <div class="heading">Displayed Form Schema</div>
        <div class="fad-pre">{{ JSON.stringify(formSchema, null, 2) }}</div>
      </div>
    </div>
    <div class="vertical">
      <div class="fad-form-model fad-panel">
        <div class="heading">Form Model</div>
        <div class="fad-pre">{{ JSON.stringify(formModel, null, 2) }}</div>
      </div>
      <div class="fad-ace-template-output fad-panel">
        <div class="heading">Template Output</div>
        <div v-if="!templateReady">
          <div class="fad-template-not-ready-message">Template is not ready.</div>
          <div class="fad-pre">{{ JSON.stringify(templateError, null, 2) }}</div>
        </div>
        <AceXmlEditor
          ref="ace-template"
          class="vertical"
          v-if="templateReady"
          v-bind:value="templatedRequest"
          v-bind:options="editorOptions"
          lang="json"/>
      </div>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';
  import ModeledForm from "../../dashboard/components/modeledform/ModeledForm";
  import AceXmlEditor from "../../dashboard/components/AceXmlEditor";

  import brace from 'brace';

  var CDN = 'https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.6'; // TODO switch to ace-builds webpack to avoid CDN!
  // Now we tell ace to use the CDN locations to look for files
  brace.config.set('basePath', CDN);
  brace.config.set('modePath', CDN);
  brace.config.set('themePath', CDN);
  brace.config.set('workerPath', CDN);

  var initialServiceText = JSON.stringify({
      "name": "Example Form",
      "path": "/v1/dmi/information",
      "body": "{\"people\":<%= JSON.stringify(people) %>, \"useLegacyDetermination\":<%= useLegacyDetermination %>,\"key\":<%= JSON.stringify(key) %>}",
      "formSchema": [
        {
          "id": "key",
          "title": "Hidden Key",
          "type": "password",
          "required": true,
          "default": "hunter2"
        },
        {
          "id": "sourceSystemName",
          "title": "Source-System-Name",
          "type": "select",
          "required": true,
          "default": "",
          "items": [
            "EE",
            "SES",
            "MCR"
          ]
        },
        {
          "id": "userId",
          "title": "User ID",
          "type": "number",
          "required": true,
          "default": "5"
        },
        {
          "id": "useLegacyDetermination",
          "title": "Use Legacy Determination",
          "type": "boolean",
          "required": true,
          "default": true
        },
        {
          "id": "correlationId",
          "title": "Correlation ID",
          "type": "string",
          "required": true,
          "default": "@uuid"
        },
        {
          "id": "zipCodes",
          "title": "Zip Codes",
          "type": "array",
          "required": true,
          "item": {
            "title": "Zip Code",
            "type": "string",
            "required": true
          }
        },
        {
          "id": "people",
          "title": "People",
          "type": "array",
          "required": true,
          "item": {
            "title": "Person",
            "type": "object",
            "required": true,
            "items": [
              {
                "id": "first",
                "type": "string",
                "title": "First"
              },
              {
                "id": "last",
                "type": "string",
                "title": "Last"
              }
            ]
          }
        }
      ],
      "headers": [
        "user-id: <%= userId %>",
        "x-correlation-id: <%= correlationId %>"
      ]
    }
    , null, 4);


  export default {
    name: 'Editor',
    components: {
      ModeledForm,
      AceXmlEditor,
    },
    data: function () {
      return {
        service: {},
        serviceText: '',
        serviceResetCount: 0,
        formSchema: [],
        formModel: {},
        formResetCount: 0,
        // templatedRequest: '',
        editorOptions: {
          mode: 'ace/mode/json',
          wrap: true,
          autoScrollEditorIntoView: true,
        }
      }
    },
    mounted: function () {
      let sessionServiceText = sessionStorage.getItem('serviceText');
      if (sessionServiceText) {
        this.serviceText = sessionServiceText;
      } else {
        this.serviceText = initialServiceText;
      }
      this.$nextTick(() => {
        this.$refs['ace-service-config'].resize();
        if (this.$refs['ace-template']) {
          this.$refs['ace-template'].resize();
        }
      })
    },
    watch: {
      serviceText: function (value) {
        var newServiceConfig;
        try {
          newServiceConfig = JSON.parse(value);
          if (_.isObject(newServiceConfig) && _.isArray(newServiceConfig.formSchema)) {
            this.service = newServiceConfig;
            this.formSchema = newServiceConfig.formSchema;
            sessionStorage.setItem('serviceText', value)
          }
        } catch (e) {
          // do nothing
        }
      },
      formSchemaText: function () {
        var newFormSchema;
        try {
          newFormSchema = JSON.parse(this.formSchemaText);
          if (_.isArray(newFormSchema)) {
            this.formSchema = newFormSchema;
          }
        } catch (e) {
          // do nothing
        }
      },
    },
    computed: {
      templateError: function () {
        return {
          path: this.templatePathError.toString(),
          headers: this.templateHeadersError.toString(),
          body: this.templateBodyError.toString(),
        }
      },
      templatedRequest: function () {
        if (!this.templateReady) {
          return '';
        }
        return JSON.stringify({
          path: this.templatePath,
          headers: this.templateHeaders,
          body: this.templateBody,
        }, null, 2)
      },
      templateReady: function () {
        return this.bodyReady && this.headersReady && this.pathReady;
      },
      bodyReady: function () {
        return !this.service.body || !this.templateBodyError;
      },
      templateBodyError: function () {
        if (!this.service.body) {
          return false;
        }
        try {
          _.template(this.service.body)(this.formModel);
          return false;
        } catch (err) {
          return err;
        }
      },
      templateBody: function () {
        if (!this.service.body) {
          return '';
        }
        try {
          return _.template(this.service.body)(this.formModel);
        } catch (err) {
          return '';
        }
      },
      headersReady: function () {
        return !this.service.headers || !this.templateHeadersError;
      },
      templateHeadersError: function () {
        if (!this.service.headers) {
          return false;
        }
        try {
          _.map(this.service.headers, (header) => {
            return _.template(header)(this.formModel)
          });
          return false;
        } catch (err) {
          return err;
        }
      },
      templateHeaders: function () {
        if (!this.service.headers) {
          return [];
        }
        try {
          return _.map(this.service.headers, (header) => {
            return _.template(header)(this.formModel)
          });
        } catch (err) {
          return [];
        }
      },
      pathReady: function () {
        return !this.templatePathError;
      },
      templatePathError: function () {
        try {
          _.template(this.service.path)(this.formModel);
          return false;
        } catch (err) {
          return err;
        }
      },
      templatePath: function () {
        try {
          return _.template(this.service.path)(this.formModel);
        } catch (err) {
          return '';
        }
      },
    },
    methods: {
      resetServiceConfig: function () {
        this.serviceText = initialServiceText;
        this.serviceResetCount += 1;
      },
      resetModeledForm: function () {
        this.formResetCount += 1;
      },
    }
  }
</script>

<style scoped>
  .fad-request-editor {
    display: flex;
    flex-direction: row;
    height: 100%;
    width: 100%;
  }

  .fad-request-editor > * {
    flex: 1;
    display: flex;
    flex-direction: column;
  }

  .fad-panel {
    margin: 2px;
    border: 1px solid black;
  }

  .vertical {
    flex: 1;
    flex-direction: column;
  }

  .heading {
    background-color: #eee;
    height: 30px;
    min-height: 30px;
    line-height: 30px;
    overflow: hidden;
    padding: 0 5px;
  }

  .heading > * {
    line-height: normal;
  }

  .fad-pre {
    white-space: pre-wrap;
    font-family: "Fira Mono", monospace;
    padding: 15px;
  }

  .fad-ace-template-output {
    display: flex;
    flex-direction: column;
    flex: 1;
  }

  .fad-modeled-form form {
    padding: 5px;
  }

  .fad-template-not-ready-message {
    background-color: #ffa5a0;
  }
</style>
