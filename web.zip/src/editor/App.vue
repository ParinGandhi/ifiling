<template>
  <div id="app">
    <Editor/>
  </div>
</template>

<script>
  import 'bootstrap/dist/css/bootstrap.css'
  import 'bootstrap/dist/css/bootstrap-theme.css'
  import Editor from './components/Editor.vue'

  export default {
    name: 'app',
    components: {
      Editor
    }
  }
</script>

<style>
  @import url('https://fonts.googleapis.com/css?family=Fira+Mono|Fira+Sans&display=swap');

  html, body, #app {
    width: 100%;
    height: 100%;
    display: flex;
    flex: 1;
    flex-direction: column;
  }

  body {
    font-family: "Fira Sans", sans-serif;
  }
</style>
