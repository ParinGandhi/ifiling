import 'bootstrap/dist/css/bootstrap.css'

import { createApp } from 'vue'
import jQuery from 'jquery'
window.$ = window.jQuery = jQuery

import App from './App.vue'
import { createVuetify } from 'vuetify'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { VSkeletonLoader } from 'vuetify/labs/VSkeletonLoader'

// const app = createApp({
//   render: ()=>h(App)
// })

const vuetify = createVuetify({
  ssr: true,
  components: {
    components,
    VSkeletonLoader
  },
  directives,
  // defaults: {},
  opts: {
      theme: { dark: false },
      icons: {
       iconfont: 'mdi'
      }
    }
})

createApp(App).use(vuetify).mount('#app')
