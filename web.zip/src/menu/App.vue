<template>
  <v-app>
    <div id="app">
      <Menu v-if="resourceUrls"
            v-bind:resourceUrls="resourceUrls"/>
    </div>
  </v-app>
</template>

<script>
import 'promise-polyfill/src/polyfill'
import 'abortcontroller-polyfill'
import 'whatwg-fetch'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/css/bootstrap-theme.css'
import Menu from './components/Menu'
import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "../utils/RedirectToIndex";

export default {
  name: 'app',
  data: function () {
    return {
      resourceUrls: null,
    }
  },
  components: {
    Menu
  },
  async created() {
    redirectToIndexIfNoAccessToken();
    const self = this;
    await fetch('/resourceUrls.json')
      .then(response => response.json())
      .then(json => {
        self.resourceUrls = json;
        return fetch(json.services, {
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
        })
          .then(response => {
            redirectToIndexIfUnauthenticated(response);
            return response;
          })
          .catch(redirectToIndexIfNoAccessToken)
      })
      .then(response => response.json())
      .catch(redirectToIndexIfNoAccessToken)
  },
}
</script>

<style>

@import url('https://fonts.googleapis.com/css?family=Fira+Mono|Fira+Sans&display=swap');

html, body, #app {
  width: 100%;
  height: 100%;
  display: flex;
  flex: 1;
  flex-direction: column;
}

body {
  font-family: "Fira Sans", sans-serif;
}
</style>
