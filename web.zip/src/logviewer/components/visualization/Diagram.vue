<template>
  <div id="svg-container">
    <svg
      :viewBox="viewBoxDiagram"
      preserveAspectRatio="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="smallGrid"
          width="10"
          height="10"
          patternUnits="userSpaceOnUse"
        >
          <path
            d="M 10 0 L 0 0 0 10"
            fill="none"
            stroke="gray"
            stroke-width="0.5"
          />
        </pattern>
        <pattern
          id="grid"
          width="100"
          height="100"
          patternUnits="userSpaceOnUse"
        >
          <rect width="100" height="100" fill="url(#smallGrid)" />
          <path
            d="M 100 0 L 0 0 0 100"
            fill="none"
            stroke="gray"
            stroke-width="1"
          />
        </pattern>
      </defs>
      <g :transform="scaleStr">
        <rect
          x="0"
          y="0"
          :width="width"
          :height="height"
          :fill="showGrid ? 'url(#grid)' : background"
          @click="reset"
        />
        <Node
          :node="item"
          v-for="item in nodes"
          :key="item.id"
          :rWidth="rect().rWidth"
          :rHeight="rect().rHeight"
          :scale="scale"
          
        />
        <Node 
          :node="item"
          v-for="item in nodeNum"
          :key="item.id"
          :rWidth="rect().rWidth"
          :rHeight="rect().rHeight"
          :scale="scale"
        />
        <a xlink:href="#" class="btn-cta" >
        <Node
        class="button"
          :node="item"
          v-for="item in nodesPayload"
          :key="item.id"
          :rWidth="rect().rWidth"
          :rHeight="rect().rHeight"
          :scale="scale"
          @click="clickNode"
        />
        </a>
        <Link
          :link="item"
          v-for="item in links"
          :selected="true"
          :key="item.id"
          :source="findNode(item.source)"
          :destination="findNode(item.destination)"
          :editable="false"
          :labels="{endpoint: item.path, status_code: item.statuscode}"
          :rWidth="rect().rWidth"
          :rHeight="rect().rHeight"
          :scale="scale"
        />
      </g>
    </svg>
  </div>
</template>
<script>
import Node from "./CustomizedNode";
import Link from "./CustomizedLink";
export default {
  name: "Diagram",
  props: {
    width: Number,
    height: Number,
    scale: {
      type: String,
      default: "1"
    },
    background: String,
    showGrid: Boolean,
    nodes: Array,
    nodeNum: Array,
    nodesPayload: Array,
    links: Array,
    editable: Boolean,
    labels: Object,
    fluid: {
      type: Boolean,
      default: false
    }
  },
  components: {
    Node,
    Link
  },
  computed: {
    viewBoxDiagram() {
      return this.fluid
        ? `0 0 ${this.width / this.scale} ${this.height / this.scale}`
        : `0 0 ${this.width} ${this.height}`;
    },
    scaleStr() {
      return (
        "scale(" +
        (this.fluid ? 1.0 : this.scale || 1.0) +
        ")" +
        "translate(" +
        0 +
        "," +
        0 +
        ")"
      );
    },
  },

  methods: {
     reset() {
      this.$emit("reset");
     },
    findNode(id) {
      return this.nodes.find(x => x.id === id);
    },

    rect() {
      if (this.fluid) {
        const rect = this.$refs.field.getBoundingClientRect();
        return {
          rWidth: rect.width / this.width,
          rHeight: rect.height / this.height
        };
      } else {
        return {
          rWidth: 1,
          rHeight: 1
        };
      }
    },

    clickNode(id) {
      this.$emit("nodeClicked", id);
    },
  }
};
</script>
<style>
svg, #container{
    height: 100%;
    width: 100%;
    display: flex;
    position: relative;
    align-items: center;
}

.svg-container {
    display: flex;
    position: relative;
    width: 100%;
    padding-bottom: 100%;
    vertical-align: top;
    overflow: hidden;
    margin: auto;
}
.svg-content {
    display: inline-block;
    position: absolute;
    margin: auto;
    top: 0;
    left: 0;
}
.button {
  cursor: pointer;
}
.grab {
  cursor: grab;
}

.btn-cta {
  width: 120px;
  display: block;
  margin: 0 auto;
  text-align: center;
  text-transform: uppercase;
  font-size: 20px;
  padding: 10px;
  background: #ccc;
  color: #555;
  text-decoration: none;
  transition: all 0.2s ease-in-out;
}
</style>
