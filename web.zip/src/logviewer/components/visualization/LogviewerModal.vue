 
<template >
<div class="show-modal">
  <v-dialog v-model="show" scrollable width="100%" height="100%">
    <v-card >

     <v-card-title>
        <h2>Request</h2>
      </v-card-title>
            <v-card-subtitle>
      <div class="fad-log-entry-tags badge">
            <span >name:</span>
            <span >{{payload.request.name}}</span>
             </div> 
             <div class="fad-log-entry-tags badge">
            <span > span.kind:</span>
            <span >{{payload.request.tags['span.kind']}}</span>
            </div>  
      </v-card-subtitle>
       <v-card-text>
         <LogEntry
              v-bind:logEntry="payload.request"
              v-bind:isCollapsed="false"
              />
           
        </v-card-text>
      <v-card-actions>
        <v-btn color="primary"  @click="show=false">Close</v-btn>
      </v-card-actions>
        </v-card>
      <v-card>
     <v-card-title>       
        <h2>Response</h2>
      </v-card-title>
        <v-card-subtitle>
        <div class="fad-log-entry-tags badge">
            <span >name:</span>
            <span >{{payload.response.name}}</span>
             </div>  
             <div class="fad-log-entry-tags badge">
            <span > span.kind:</span>
            <span >{{payload.response.tags['span.kind']}}</span>
            </div>     
        </v-card-subtitle>
        <v-card-text>
         <LogEntry 
              v-bind:logEntry="payload.response"
              v-bind:isCollapsed="false"
              />
         </v-card-text>

    </v-card>
 


   </v-dialog>
</div>
</template>
  
<script>
import LogEntry from "../LogEntry"; 
export default {
  name:'LogviewerModal',
  props: {
    value: Boolean,
    payload: Object,
    selected: Boolean  
  },
  components: {
       LogEntry,
      },

  computed: {
    show: {
      get () {
       if(this.value)
         return this.selected
       return this.value
      },
      set (value) {
         this.$emit('input', value)
      }
    }
  }
}
</script>

