<template>
  <div class="fad-log-viewer-output">
    <div class="fad-log-viewer-output-filters" v-if="tags.length > 0">
      <h2>Tag Filters</h2>
      <div>
        <span
          v-for="tag in tags"
          v-bind:key="tag"
          class="fad-log-viewer-filter-tag badge"
          v-on:click="toggleTagFilter(tag)"
          v-on:keyup.enter="toggleTagFilter(tag)"
          v-bind:class="{'fad-log-viewer-filter-tag-active':activeTags[tag]}"
          tabindex="0"
        >{{tag}}</span>
      </div>
    </div>
    <div class="fad-log-viewer-output-heading">
      <h2>
        Records
      </h2>
    </div>
    <div class="fad-log-viewer-entries">
      <LogEntry
        v-for="(entry, index) in logs"
        v-bind:key="index"
        v-bind:tags="logTags[index]"
        v-bind:activeTags="activeTags"
        v-bind:logEntry="entry"
        v-bind:isCollapsed="true"
        v-show="shouldShowThisLog(index)"
        v-on:toggleTag="toggleTagFilter($event)"
      />
      <div v-if="logs.length > 0 && filteredLogs.length === 0">All results filtered out</div>
    </div>
  </div>
</template>

<script>
  import LogEntry from "./LogEntry";
  import _ from 'lodash';

  export default {
    name: 'LogviewerOutput',

    data: function () {
      return {
        filterMode: 'AND', // 'OR'
        activeTags: {}, // key: tag; value: true if tag is active.
        ignoreTags: ['request.id', 'thread.id', 'thread.name'], // tags in JSON that won't get a badge
      };
    },

    props: {
      logs: Array,
    },

    components: {
      LogEntry,
    },

    computed: {
      // Array of all tags of all LogEntries
      tags: function () {
        return _(this.logTags).flatten().sort().sortedUniq().value();
      },

      // Array of objects. Array index = LogEntry index.
      // Object keys: tags of the entry. Object values: true (to enable quick set-like check for existence)
      logTagsMap: function () {
        return this.logs.map(logEntry => {
          return this.getTags(logEntry).reduce((accum, current) => {
            if (!_.includes(this.ignoreTags, current.substring(0, current.indexOf(':')))) {
              accum[current] = true;
            }
            return accum;
          }, {});
        });
      },
      // Array of arrays. Array index = LogEntry index. Inner array = tags of the entry.
      logTags: function () {
        return this.logTagsMap.map(x => _.keys(x))
      },

      filteredLogs: function() {
        return this.logs.filter((log, index) => this.shouldShowThisLog(index))
      },

    },

    methods: {
      shouldShowThisLog: function (index) {
        if (_.isEmpty(this.activeTags)) {
          return true;
        }
        let trues = [];
        _.forEach(this.activeTags, (value, key) => {
          if (value) {
            trues.push(key);
          }
        })
        if (_.isEmpty(trues)) {
          return true;
        }
        for (const tag of trues) {
          if (this.filterMode === 'AND') {
            if (!this.logTagsMap[index][tag]) {
              return false;
            }
          } else if (this.filterMode === 'OR') {
            if (this.logTagsMap[index][tag]) {
              return true;
            }
          }
        }
        // Not optimizing to a single return statement for the sake of readability
        if (this.filterMode === 'AND') {
          return true;
        }
        if (this.filterMode === 'OR') {
          return false;
        }
      },

      toggleTagFilter: function (tag) {
        // this.activeTags[tag] = !this.activeTags[tag]; // Use $set to fix reactivity!
        this.$set(this.activeTags, tag, !this.activeTags[tag]);
      },

      // Generate a list of String tags to be associated with a log entry
      getTags: function (logEntry) {
        let firstTags = [];
        let secondTags = [];
        let otherTags = [];
        if (logEntry.name) {
          firstTags.push('name:' + logEntry.name);
        }
        if (logEntry.request) {
          firstTags.push('type:request');
          if (logEntry.request.method && logEntry.request.path) {
            secondTags.push('request.resource:' + logEntry.request.method + ' ' + logEntry.request.path)
          }
          if (logEntry.request.method) {
            secondTags.push('request.method:' + logEntry.request.method);
          }
          if (logEntry.request.path) {
            secondTags.push('request.path:' + logEntry.request.path);
          }
        }
        if (logEntry.response) {
          firstTags.push('type:response');
          if (logEntry.response.status_code) {
            secondTags.push('status.code:' + logEntry.response.status_code);
          }
        }
        if (_.get(logEntry, 'logs', []).some(item => item.event === 'error')) {
          firstTags.push('event:error');
        }
        if (logEntry.tags) {
          let firstKeys = ['span.kind'];
          let secondKeys = ['role.id', 'user.id'];
          _.forEach(_.omit(logEntry.tags, 'correlation.id'), (value, key) => {
            let tag = key + ':' + value;
            if (_.includes(firstKeys, key)) {
              firstTags.push(tag)
            } else if (_.includes(secondKeys, key)) {
              secondTags.push(tag);
            } else {
              otherTags.push(tag);
            }
          });
        }
        otherTags.sort();
        let allTags = firstTags.concat(secondTags).concat(otherTags);
        allTags.forEach(tag => this.$emit('registerTag', tag));
        return allTags;
      },
    },

    watch: {
      logs: function () {
        this.activeTags = {};
      }
    },
  }
</script>

<style scoped>
  .fad-log-viewer-output {

  }

  .fad-log-viewer-filter-tag:focus {
    outline-offset: 1px;
    outline: 1px dotted #1d1a65;
  }
  .fad-log-viewer-filter-tag-active {
    background-color: #0594ea;
  }

  .fad-log-viewer-output-filters {
    padding: 5px;
  }
  .fad-log-viewer-output-filters h2 {
    font-size: 20px;
  }
  .fad-log-viewer-output-heading {
    padding: 5px;
  }

  .badge {
    cursor: pointer;
    margin: 1px;
  }

  .fad-log-viewer-entries > *:nth-child(2n) {
    background: #eef2f9;
  }
  .fad-log-viewer-entries > * {
    background: #dee5ee;
    /*box-shadow: inset 0px 0px 120px -39px rgba(0,0,0,0.75);*/
  }
</style>
