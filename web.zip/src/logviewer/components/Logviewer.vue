<template>
  <div class="fad-log-viewer">
    <Header v-bind:username="username"
            v-bind:environment="environment"
            v-bind:resourceUrls="resourceUrls"/>
    <main class="fad-log-viewer-main" role="main">
      <div class="fad-log-viewer-header">
        <h1>Transaction Log Search</h1>
      </div>
      <div class="fad-log-viewer-body">
        <LogviewerSearch
          v-bind:requestUrl="resourceUrls"
          v-bind:decryptable="decrypt"
        />
      </div>
    </main>
  </div>
</template>

<script>
  import LogviewerSearch from "./LogviewerSearch";
  import Header from "../../dashboard/components/Header";
  import jwtDecode from "jwt-decode";
  import {redirectToIndexIfNoAccessToken} from "../../utils/RedirectToIndex";

  export default {
    name: "Logviewer",
    data: function() {
      return {
        environment: {},
        userDropdownOpen: false,
      };
    },
    components: {
      LogviewerSearch,
      Header,
    },

    props: {
      resourceUrls: Object,
      decrypt: Boolean
    },
    computed: {
      username: function () {
        try {
          return jwtDecode(sessionStorage.getItem('idToken'))['custom:uid'];
        } catch (err) {
          return 'User';
        }
      },
    },
    mounted: function() {
      fetch(this.resourceUrls.environment, {
        headers: {
          "access-token": sessionStorage.getItem("accessToken")
        }
      })
        .then(response => response.json())
        .then(json => (this.environment = json))
        .catch(redirectToIndexIfNoAccessToken)
    }
  };
</script>

<style scoped>
  .fad-log-viewer-header {
    color: #cfe2ea;
    background-color: #055072;
  }
  .fad-log-viewer-header h1 {
    text-align: center;
  }
  .fad-log-viewer-main {
    display: flex;
    flex-direction: column;
    height: 100%;
  }
  .fad-log-viewer {
    display: flex;
    flex-direction: column;
    height: 100%;
  }
  .fad-log-viewer-body {
    height: 100%;
  }
</style>

<style>
  html {
    overflow-y: scroll;
  }
</style>
