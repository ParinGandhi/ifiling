import 'bootstrap/dist/css/bootstrap.css'

import { createApp, h } from 'vue'
// import Vue from 'vue'
import App from './App.vue'
import { createVuetify } from 'vuetify/lib/framework.mjs'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

// const app = createApp({
//     // render: ()=>h(App)
// })

const app = createApp(App);

const vuetify = createVuetify({
    ssr: true,
    components,
    directives,
    defaults: {},
    opts: {
        theme: { dark: false },
        icons: {
         iconfont: 'mdi'
        }
      }
  })

if (process.env.NODE_ENV !== 'production') {
  app.use(require('vue-axe').default);
}
app.config.productionTip = false


app.use(vuetify)
app.mount('#app')