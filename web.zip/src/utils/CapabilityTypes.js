const API_REQUEST_CAPABILITY = {
    name: "api_request_capability"
}
const REF_DATA_BROWSING_CAPABILITY = {
    name: "ref_data_browsing_capability"
}
const TRANSACTION_LOG_SEARCH_CAPABILITY = {
    name: "transaction_log_search_capability"
}
const APP_CONFIG_MANAGEMENT_CAPABILITY = {
  name: "app_config_management_capability"
}
module.exports = {
    api_request_capability: API_REQUEST_CAPABILITY,
    ref_data_browsing_capability:REF_DATA_BROWSING_CAPABILITY,
    transaction_log_search_capability:TRANSACTION_LOG_SEARCH_CAPABILITY,
    app_config_management_capability:APP_CONFIG_MANAGEMENT_CAPABILITY,
    capabilities: [
        API_REQUEST_CAPABILITY,
        REF_DATA_BROWSING_CAPABILITY,
        TRANSACTION_LOG_SEARCH_CAPABILITY,
        APP_CONFIG_MANAGEMENT_CAPABILITY
    ]
}
