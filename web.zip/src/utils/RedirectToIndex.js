import jwtDecode from 'jwt-decode';

function redirectToIndexIfNoAccessToken() {
  const accessToken = sessionStorage.getItem('accessToken');
  if (!accessToken) {
    // redirectToIndex();
  }
  try {
    const decoded = jwtDecode(accessToken);
    const now = (new Date()).getTime() / 1000;
    if (now >= decoded.exp) {
      // redirectToIndex();
    }
    if (!/^https:\/\/cognito-idp\.us-[^.]*\.amazonaws\.com\//.test(decoded.iss)) {
      // redirectToIndex();
    }
    // If the token validation reaches this point with an invalid token, fine.
    // If the token is invalid, the REST requests won't work anyway.
  } catch (e) {
    // redirectToIndex();
  }
}

function redirectToIndex() {
  sessionStorage.removeItem('accessToken');
  fetch('/resourceUrls.json')
    .then(response => response.json())
    .then(env => {
      let logoutUrl = env.cognitoLogout + '&logout_uri=' + env.idpLogoutUri
      window.location.href = logoutUrl
    })
  throw new Error('Redirecting to index');
}

function redirectToIndexIfUnauthenticated(fetchResponse) {
  let isAuthenticated = ![401, 403].includes(fetchResponse.status); // TODO only redirect on 401; 403 means authenticated but not authorized
  if (!isAuthenticated) {
    // redirectToIndex();
  }
}

export {redirectToIndex, redirectToIndexIfUnauthenticated, redirectToIndexIfNoAccessToken}
