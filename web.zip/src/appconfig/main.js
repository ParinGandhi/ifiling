import 'bootstrap/dist/css/bootstrap.css'

import { createApp } from 'vue'
import App from './App.vue'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { defaults as vuetifyDefaults } from 'vuetify'
import store from './store'

const vuetify = createVuetify({
    components,
    directives,
    defaults: vuetifyDefaults
})

createApp(App).use(store).use(vuetify).mount('#app')