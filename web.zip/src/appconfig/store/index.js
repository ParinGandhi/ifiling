import { createApp } from 'vue'
import App from '../App.vue'
import Vuex from 'vuex'
import applicationData from './module/applicationData'
import directoryData from './module/directoryData'

const debug = process.env.NODE_ENV !== 'production'

const app = createApp(App)
app.use(Vuex)
app.mount('#app')

export default new Vuex.Store({
  modules: {
    applicationData,
    directoryData
  },
  // strict: debug,
})
