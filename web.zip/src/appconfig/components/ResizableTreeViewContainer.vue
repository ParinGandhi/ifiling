<template>
  <div v-resize="onResize">
    <div ref="resizableDiv">
      <slot name="table" :table-height="tableHeight"/>
    </div>
  </div>
</template>

<script>
export default {
  name: "resizable-tree-view-container",
  data() {
    return {
      tableHeight: {
        height: '620px'
      },
    };
  },
  props: {
  },
  methods: {
    onResize() {
      let tHeight =
        window.innerHeight -
        this.$refs.resizableDiv.getBoundingClientRect().y - 20;
      this.tableHeight = {
        height: `${tHeight}px`
      }
    },
  },
};
</script>
