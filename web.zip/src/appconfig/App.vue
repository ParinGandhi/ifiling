<template>
  <v-app>
    <div id="app" style="background-color: #055072">
      <AppConfigViewer v-if="resourceUrls"
                       v-bind:applications="applications"
                       v-bind:resourceUrls="resourceUrls"/>
    </div>
  </v-app>
</template>

<script>
import 'promise-polyfill/src/polyfill'
import 'abortcontroller-polyfill'
import 'whatwg-fetch'
import AppConfigViewer from './components/AppConfigViewer'
import capabilities from '../utils/CapabilityTypes'
import _ from 'lodash';
import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "../utils/RedirectToIndex";

export default {
  name: 'app',
  data: function () {
    return {
      applications: null,
      resourceUrls: null,
    }
  },
  components: {
    AppConfigViewer
  },
  async created() {
    redirectToIndexIfNoAccessToken();
    const self = this;
    await fetch('/resourceUrls.json')
      .then(response => response.json())
      .then(async (json) => {
        this.$store.dispatch('applicationData/setNewResourceUrls', json)
        self.resourceUrls = json;

        await fetch(this.resourceUrls.capabilities, {
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          }
        })
          .then(response => response.json())
          .then(json => {
            if(!_.find(json.capabilityList, (o => {return o.name === capabilities.app_config_management_capability.name}))){
              window.location.href = '/menu.html';
            }
            json.capabilityList
          })
          .catch(redirectToIndexIfNoAccessToken)

        return fetch(json.appConfigServices, {
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
        })
          .then(response => {
            redirectToIndexIfUnauthenticated(response);
            return response;
          })
          .catch(redirectToIndexIfNoAccessToken)
      })
      .then(response => response.json())
      .then(json => {
        this.applications = json.applications
        this.$store.dispatch('applicationData/setNewApplications', json.applications)
      })
      .catch(redirectToIndexIfNoAccessToken)
  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900');

html, body, #app {
  width: 100%;
  height: 100%;
  display: flex;
  flex: 1;
  flex-direction: column;
}

body {
  font-family: "Fira Sans", sans-serif;
}

.badge {
  background-color: #6c6c6c;
}
</style>
