<template>
  <v-app>
    <app-selection
      v-if="resourceUrls"
      v-bind:applications="applications"
      v-bind:resourceUrls="resourceUrls"/>
  </v-app>
</template>

<script>
import 'promise-polyfill/src/polyfill'
import 'abortcontroller-polyfill'
import 'whatwg-fetch'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/css/bootstrap-theme.css'
import AppSelection from "./components/AppSelection";
import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "../utils/RedirectToIndex";
import _ from "lodash";
import capabilities from "@/utils/CapabilityTypes";


export default {
  name: 'app',
  data: function () {
    return {
      applications: null,
      resourceUrls: null,
    }
  },
  async created() {
    redirectToIndexIfNoAccessToken();
    const self = this;
    await fetch('/resourceUrls.json')
      .then(response => response.json())
      .then(async (json) => {
        self.resourceUrls = json;

        await fetch(this.resourceUrls.capabilities, {
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          }
        })
          .then(response => response.json())
          .then(json => {
            let test = _.find(json.capabilityList, (o => {
              return o.name === capabilities.api_request_capability.name
            }));
            if (!_.find(json.capabilityList, (o => {
              return o.name === capabilities.api_request_capability.name
            }))) {
              window.location.href = '/menu.html';
            }
            json.capabilityList
          })
          .catch(redirectToIndexIfNoAccessToken)

        return fetch(json.services, {
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
        })
          .then(response => {
            redirectToIndexIfUnauthenticated(response);
            return response;
          })
          .catch(redirectToIndexIfNoAccessToken)
      })
      .then(response => response.json())
      .then(json => {
        this.applications = json.applications
        this.$store.dispatch('applicationData/setNewApplications', json.applications)
      })
      .catch(redirectToIndexIfNoAccessToken)

  },
  components: {
    AppSelection
  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Fira+Mono|Fira+Sans&display=swap');

html, body {
  display: flex;
  flex-direction: column;
  flex: 1;
  -ms-flex: 1 1 auto;
}

html {
  height: 100%;
}

listing, plaintext, pre, xmp, code, kbd, samp, tt {
  font-family: "Fira Mono", monospace;
}

/**:not(listing, plaintext, pre, xmp, code, kbd, samp, tt) {*/
body {
  font-family: "Fira Sans", sans-serif;
}

/*.fad-ace-container .ace_editor .ace_gutter, .fad-ace-container .ace_editor .ace_scroller {*/
/*  font-family: "Fira Mono", monospace;*/ /* Fira Mono works fine on FF but bugs out on Chrome */
/*}*/

.btn {
  /*padding: 6px 12px 3px;*/
}

.btn-lg, .btn-group-lg > .btn {
  /*padding: 10px 16px 7px;*/
}

</style>
