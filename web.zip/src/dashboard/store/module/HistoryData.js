const state = () => ({
  historyItems: [],
})

const getters = {
  getHistoryItems: (state) => {
    return state.historyItems;
  }  
}

const mutations = {
  setHistoryItems(state, hItems) {
    state.historyItems = hItems;
  }
}

const actions = {
  setNewHistoryItems({commit}, hItems) {
    return new Promise((resolve, reject) => {
      commit('setHistoryItems', hItems)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
