const state = () => ({
  currentInput: 'formInput',
  rawInputPath: '',
  rawInputHeaders: '',
  rawInputBody: '',
  formModel: {},
  historyItemInputPathClicked: false,
  historyItemInputHeadersClicked: false,
  historyItemInputBodyClicked: false,
})

const getters = {
  // getCurrentInput: (state) => {
  //   return state.CurrentInput;
  // },
  // getRawInputPath: (state) => {
  //   return state.rawInputPath;
  // },
  // getRawInputHeaders: (state) => {
  //   return state.rawInputHeaders;
  // },
  // getRawInputBody: (state) => {
  //   return state.rawInputBody;
  // },
  // getHistoryItemClicked: (state) => {
  //   return state.historyItemClicked;
  // }
}

const mutations = {
  setCurrentInput(state, newInput) {
    state.currentInput = newInput;
  },
  setRawInputPath(state, newInputPath) {
    state.rawInputPath = newInputPath;
  },
  setRawInputHeaders(state, newInputHeaders) {
    state.rawInputHeaders = newInputHeaders;
  },
  setRawInputBody(state, newInputBody) {
    state.rawInputBody = newInputBody;
  },
  setFormModel(state, newFormModel) {
    state.formModel = newFormModel;
  },
  setHistoryItemInputPathClicked(state, newStatus) {
    state.historyItemInputPathClicked = newStatus;
  },
  setHistoryItemHeadersClicked(state, newStatus) {
    state.historyItemInputHeadersClicked = newStatus;
  },
  setHistoryItemInputBodyClicked(state, newStatus) {
    state.historyItemInputBodyClicked = newStatus;
  }
}

const actions = {
  setNewCurrentInput({commit}, newInput) {
    commit('setCurrentInput', newInput)
  },
  setNewRawInputPath({commit}, newInputPath) {
    commit('setRawInputPath', newInputPath)
  },
  setNewRawInputHeaders({commit}, newInputHeaders) {
    commit('setRawInputHeaders', newInputHeaders)
  },
  setNewRawInputBody({commit}, newInputBody) {
    commit('setRawInputBody', newInputBody);
  },
  setNewFormModel({commit}, newFormModel) {
    commit('setFormModel', newFormModel);
  },
  setNewHistoryItemInputPathClicked({commit}, newStatus) {
    commit('setHistoryItemInputPathClicked', newStatus);
  },
  setNewHistoryItemHeadersClicked({commit}, newStatus) {
    commit('setHistoryItemHeadersClicked', newStatus);
  },
  setNewHistoryItemInputBodyClicked({commit}, newStatus) {
    commit('setHistoryItemInputBodyClicked', newStatus);
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
