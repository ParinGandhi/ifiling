const state = () => ({
  selectedService: null,
  filteredServices: [],
  serviceRequestUrl:''
})

const getters = {
  getSelectedApplication: (state) => {
    return state.selectedService;
  },
  getFilteredServices: (state) => {
    return state.filteredServices;
  },
  getServiceRequestUrl: (state) => {
    return state.serviceRequestUrl;
  }
}

const mutations = {
  setSelectedService(state, svc) {
    state.selectedService = svc;
  },
  setFilteredServices(state, svc) {
    state.filteredServices = svc;
  },
  setServiceRequestUrl(state, svc) {
    state.serviceRequestUrl = svc;
  }
}

const actions = {
  setNewSelectedService({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setSelectedService', svc)
      resolve()
    })
  },
  setNewFilteredServices({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setFilteredServices', svc)
      resolve()
    })
  },
  setNewServiceRequestUrl({commit}, svc) {
    return new Promise((resolve, reject) => {
      commit('setServiceRequestUrl', svc)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
