import { createApp } from 'vue'
import App from '../App.vue'
// import Vuex from 'vuex'
import { createStore } from "vuex";
import applicationData from './module/applicationData'
import serviceData from './module/serviceData'
import modeledformData from './module/modeledformData'
import historyData from './module/HistoryData'

const debug = process.env.NODE_ENV !== 'production'



// export default new Vuex.Store({
//   modules: {
//     applicationData,
//     serviceData,
//     modeledformData,
//     historyData
//   },
//   // strict: debug,
// })

export default createStore({
  modules: {
    applicationData,
    serviceData,
    modeledformData,
    historyData
  },
  // strict: debug,
})

// const app = createApp(App)
// app.use(Vuex)
// app.mount('#app')

createApp(App).mount('#app')
