function prettyPathNotation(string) {
  let lodashTemplateVariable = /<%[-=]\s*(.*?)\s*%>/g;
  return string.toString().replace(lodashTemplateVariable, "{$1}");
}

function toPrecision (number, digits) {
  return number.toPrecision(digits);
}

export {prettyPathNotation, toPrecision}
