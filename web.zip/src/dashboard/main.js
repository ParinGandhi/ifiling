import { createApp, h } from 'vue'
import App from './App.vue'
import store from './store'
import { createVuetify } from 'vuetify'
import 'vuetify/styles'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
// import { defaults as vuetifyDefaults } from 'vuetify'
// import fs from ''

// const app = createApp({
//   // render: ()=>h(App)
// })

const vuetify = createVuetify({
  // ssr: true,
  components,
  directives,
  defaults: {
    global: {
      variant: 'outlined'
    }
  }
  // defaults: useDefaults(),
  // opts: {
  //     theme: { dark: false },
  //     icons: {
  //      iconfont: 'mdi'
  //     }
  //   }
})

// const string  = JSON.stringify(vuetify)
// fs.writeFileSync("./vuetifylog.txt", string)


// console.log("VUETIFY: ", vuetify);

createApp(App).use(vuetify).use(store).mount('#app')
