<template>
  <fieldset v-bind:aria-required="schema.required">
    <legend v-bind:class="{required: schema.required}">{{ schema.title }}</legend>
    <div
      v-for="item in schema.items"
      v-bind:key="item.id"
    >
      <component
        v-if="value != null"
        v-bind:is="getComponent(item.type)"

        v-bind:schema="item"
        v-bind:value="value[item.id]"
        v-on:input="update($event, item)"
      />
    </div>

  </fieldset>
</template>

<script>
  import {getComponent} from "./modeled-form-utils";
  import ModeledFormArray from "./ModeledFormArray";
  import ModeledFormObject from "./ModeledFormObject";
  import ModeledFormText from "./ModeledFormText";
  import ModeledFormPassword from "./ModeledFormPassword";
  import ModeledFormNumber from "./ModeledFormNumber";
  import ModeledFormCheckbox from "./ModeledFormCheckbox";
  import ModeledFormSelect from "./ModeledFormSelect";
  import ModeledFormUnknown from "./ModeledFormUnknown";
  import ModeledFormCorrelationId from "./ModeledFormCorrelationId";

  export default {
    name: "ModeledFormObject",
    props: {
      value: {
        type: Object,
        default: function () {
          const def = {};
          this.$emit('input', def);
          return def;
        },
      },
      schema: Object,
    },
    components: {
      ModeledFormArray,
      ModeledFormObject,
      ModeledFormText,
      ModeledFormPassword,
      ModeledFormNumber,
      ModeledFormCheckbox,
      ModeledFormSelect,
      ModeledFormUnknown,
      ModeledFormCorrelationId,
    },
    created() {
      if (this.value == null) {
        this.$emit('input', {});
      }
    },
    methods: {
      getComponent,
      update: function (newValue, item) {
        this.value[item.id] = newValue;
        this.$emit('input', Object.assign({}, this.value))
      },
    },
  }
</script>

<style scoped>

</style>
