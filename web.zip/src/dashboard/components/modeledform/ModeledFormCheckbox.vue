<template>
  <div>
    <label v-bind:class="{required: schema.required}">
      {{ schema.title }}
      <input type="checkbox" ref="box" class="checkbox"
             v-bind:checked="value"
             v-bind:aria-required="schema.required"
             v-on:input="updateValue()"
      />
    </label>
  </div>
</template>

<script>
  export default {
    name: "ModeledFormCheckbox",
    props: {
      value: Boolean,
      schema: Object
    },
    mounted: function() {
      if (this.schema.default) {
        this.$refs.box.checked = this.schema.default || false;
        this.$emit('input', this.schema.default || false)
      }else{}
    },
    methods: {
      updateValue: function () {
        this.$emit('input', this.$refs.box.checked)
      }
    }
  }
</script>

<style scoped>

</style>
