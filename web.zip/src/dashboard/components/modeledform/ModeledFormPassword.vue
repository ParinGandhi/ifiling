<template>
  <div>
    <label v-bind:class="{required: schema.required}">
      {{ schema.title }}
      <input type="password" ref="box"
             class="form-control"
             v-on:input="updateValue"
             v-bind:aria-required="schema.required"
      />
    </label>
  </div>
</template>

<script>
  export default {
    name: "ModeledFormPassword",
    props: {
      value: String,
      schema: Object
    },
    mounted: function() {
      if (this.schema.default) {
        this.$refs.box.value = this.schema.default;
        this.$emit('input', this.schema.default)
      }
    },
    methods: {
      updateValue: function () {
        this.$emit('input', this.$refs.box.value)
      }
    }
  }
</script>

<style scoped>

</style>
