<template>
  <div>
    <label v-bind:class="{required: schema.required}">
      {{ schema.title }}
      <input type="number"
             class="form-control"
             v-bind:schema="schema.value"
             v-bind:value="value"
             v-bind:aria-required="schema.required"
             v-on:input.prevent="updateValue"
             v-on:keypress="allowOnlyNumber"
      />
    </label>
  </div>
</template>

<script>
  export default {
    name: "ModeledFormNumber",
    props: {
      value: String, // Because string can represent more than doubles
      schema: Object
    },
    data: function() {
      return {
        oldValue: ''
      }
    },
    mounted: function() {
      if (this.schema.default) {

      } else {
        //this.$emit('input', undefined);
      }
    },
    methods: {
      allowOnlyNumber: function(evt) {
        if (evt.target.value === '' && evt.key === '-') {
          this.oldValue = evt.target.value + evt.key;
          return true;
        }
        if (/\d/.test(evt.key)) {
          this.oldValue = evt.target.value + evt.key;
          return true;
        }
        if (evt.target.value.indexOf('.') === -1 && evt.key === '.') {
          this.oldValue = evt.target.value + evt.key;
          return true;
        }
        evt.preventDefault();
        return false;
      },
      updateValue: function (evt) {
        if (evt.inputType === 'insertFromPaste') {
          if (isNaN(parseInt(evt.data)) || isNaN(parseFloat(evt.data))) {
            evt.target.value = this.oldValue;
            return;
          } else {
            // Replace whole field because pasting "-1.2" multiple
            // times creates "-1.2-1.2-1.2" which is not a number
            this.oldValue = evt.data;
            evt.target.value = evt.data;
          }
        }
        this.$emit('input', evt.target.value);
      }
    }
  }
</script>

<style scoped>

</style>
