<template>
  <div class="fad-history-panel">
    <h2>History</h2>
    <div class="row">
      <div class="fad-right-menu-services btn-group-vertical">
        <button v-for="historyItem in historyItems"
                v-bind:key="historyItem.id"
                v-on:click="repopulatePage(historyItem)"
                class="btn btn-default"
                type="button">

          <div class="fad-history-button">{{ historyItem.application }}-{{ historyItem.service }}</div>
          <span class="fad-history-path text-muted"> {{ dateFormatConverter(historyItem.creationDateTime) }}

          - <span :class="httpCodeColrClass(historyItem.response_status)">{{ historyItem.response_status }}</span>
          </span>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
//import {prettyPathNotation} from '../filters'
import moment from "moment";
import _ from 'lodash';
import {mapState} from 'vuex';
import {prettyPathNotation} from "../filters";

export default {
  name: 'HistoryView',
  components: {},
  data: function () {
    return {
      // historyItems: [],
    }
  },
  async created() {
    const self = this;
    await fetch(this.historyRequestUrl, {
      method: 'POST',
      headers: {
        'access-token': sessionStorage.getItem('accessToken')
      },
    })
      .then(response => response.json())
      .then(json => {
        if (json.userRequestHistory) {
          this.historyItems = json.userRequestHistory.sort((a, b) => moment(b.creationDateTime).diff(moment(a.creationDateTime)))
        } else {
          this.historyItems = []
        }
      })
      .catch(function (ex) {
        console.log('parsing failed', ex)
      }) //TODO: how to handle parsing error
  },
  methods: {
    repopulatePage: function (hItem) {
      try {
        const app = this.applications.find(application => application.name == hItem.application)
        const svc = app.services.find(service => service.name == hItem.service)
        const headersArray = Object.keys(hItem.request_headers).map(key => (key + hItem.request_headers[key]))
        const requestBody = hItem.request_body == null ? "" : hItem.request_body;
        const hEnv = hItem.request_environment

        var relUrl = hItem.url.replace((hItem.url.match(/https?:\/\/.+:\d{4}/g) || [""])[0], "")
        this.$store.dispatch('modeledformData/setNewRawInputPath', relUrl)
        this.$store.dispatch('applicationData/setNewSelectedApplication', app).then(() => {
          let envList = []
          let filteredList = []
          _.map(app.services, service => {
            if (service.environments)
              envList = _.concat(envList, service.environments)
          })
          envList = _.uniqBy(envList, env => env.env)
          let hisEnv = envList.find(envItem => envItem.env == hItem.request_environment)

          _.forEach(app.services, service => {
            if (hisEnv && _.find(service.environments, env => env.env == hisEnv.env)) {
              filteredList.push(service)
            }
          })
          if (!hisEnv && svc.environments && app.services) {//added for backward compatibility with history items lacking environments
            envList = svc.environments
            hisEnv = svc.environments[0]
            filteredList = app.services
          } else if (!hisEnv) {
            return
          }
          this.$store.dispatch('applicationData/setNewSelectedEnvironment', hisEnv).then(() => {
            this.$store.dispatch('applicationData/setNewEnvironments', envList)
            this.$store.dispatch('serviceData/setNewFilteredServices', filteredList).then(() => {
              this.$store.dispatch('modeledformData/setNewFormModel', {});
              this.$store.dispatch('serviceData/setNewSelectedService', svc).then(() => {
                if (hItem.request_formmodel != null) {
                  this.$store.dispatch('modeledformData/setNewRawInputBody', requestBody)
                  this.$store.dispatch('modeledformData/setNewCurrentInput', 'formInput')
                  this.$store.dispatch('modeledformData/setNewFormModel', _.cloneDeep(hItem.request_formmodel));
                } else {
                  this.$store.dispatch('modeledformData/setNewCurrentInput', 'rawInput')
                  this.$store.dispatch('modeledformData/setNewRawInputHeaders', headersArray.join('\n'))
                  this.$store.dispatch('modeledformData/setNewRawInputBody', requestBody)
                }
              })
            })
          })
        })
      } catch (e) {
        console.warn("Error repopulating from history item: " + e)
      }

    },
    dateFormatConverter: function (date) {
      return moment(date).format('YYYY-MM-DD HH:mm:ss')
    },
    httpCodeColrClass: function (code) {
      return {
        'http-code-color-1xx': _.inRange(code, 100, 200),
        'http-code-color-2xx': _.inRange(code, 200, 300),
        'http-code-color-3xx': _.inRange(code, 300, 400),
        'http-code-color-4xx': _.inRange(code, 400, 500),
        'http-code-color-5xx': _.inRange(code, 500, 600),
        'http-code-color-unknown': code < 100 || code > 600,
      }
    },
  },
  props: {
    historyRequestUrl: String,
  },
  filters: {
    prettyPathNotation,
  },
  computed: {
    applications: {
      get() {
        return this.$store.state.applicationData.applications
      },
      set(value) {
      }
    },
    historyItems: {
      get() {
        return this.$store.state.historyData.historyItems
      },
      set(value) {
        this.$store.dispatch('historyData/setNewHistoryItems', value)
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.fad-history-panel {
  width: 100%;
  height: 100%;
  padding-top: 20px;
  padding-left: 5px;
  align-content: stretch;
}

.fad-history-button {
  text-align: left;
}

.fad-right-menu-services {
  width: 100%;
  padding-left: -15px;
  padding-right: -15px;
}

.fad-history-path {
  display: block;
  font-size: 10px;
  letter-spacing: -.5px;
  font-family: "Fira Mono", monospace;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: left;
}

.fad-history-panel ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.fad-history-view h2 {
  font-size: 25px;
  margin-top: 5px;
  margin-bottom: 20px;
}

.fad-history-list {
  /* right: 0 !important;
  left: auto !important; */
  width: 280px;
  padding-right: 10px;
}

.list-group li {
  border: 0;
}

.list-group-item {
  font-size: 11px;
  padding: 10px 10px;
}

.http-code-color-1xx {
  color: #1969D0;
}

.http-code-color-2xx {
  color: #1C8222;
}

.http-code-color-3xx {
  color: #790779;
}

.http-code-color-4xx {
  color: #976d1e;
}

.http-code-color-5xx {
  color: #b90d0d;
}

.http-code-color-unknown {
  color: black;
}

</style>
