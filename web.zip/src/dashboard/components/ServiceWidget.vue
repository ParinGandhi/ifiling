<template>
  <div class="fad-service-widget">
    <div class="fad-input container-fluid vertical">
      <h2>Inputs</h2>
      <div class="btn-group horizontal" role="group">
        <button type="button" class="fad-btn-form-input btn btn-default btn-lg flex"
                v-bind:class="{active: currentInput === inputs.formInput}"
                v-on:click.prevent="currentInput = changeCurrentInput(inputs.formInput)">Form Input
        </button>
        <button type="button" class="fad-btn-raw-input btn btn-default btn-lg flex"
                v-bind:class="{active: currentInput === inputs.rawInput}"
                v-on:click.prevent="currentInput = changeCurrentInput(inputs.rawInput)">Raw Input
        </button>
      </div>
      <div class="fad-input-form vertical" v-show="currentInput === inputs.formInput">
        <div class="fad-no-inputs" v-if="!service.formSchema">No inputs defined.</div>
        <ModeledForm
          v-else
          v-bind:schema="service.formSchema"
          v-model="formModel"
          v-on:submit.prevent="submitTemplate()"/>
        <div class="fad-input-submit">
          <button type="submit" class="btn btn-lg btn-success"
                  role="button"
                  v-on:submit.prevent="submitTemplate()"
                  v-on:click.prevent="submitTemplate()"
                  v-bind:disabled="requestBusy || !templateReady"
          >Submit Request
          </button>
        </div>
      </div>
      <div class="fad-input-raw vertical" v-show="currentInput === inputs.rawInput">
        <form class="vertical">
          <label>
            <span class="fad-label">Path</span>
            <input type="text" class="form-control" v-model="rawInputPath"/>
          </label>
          <!--          <ModeledForm v-bind:schema="headerSchema"-->
          <!--                       v-model="templateHeaders"/>-->
          <label>
            <span class="fad-label">Headers</span>
            <textarea class="form-control fad-raw-headers" v-model="rawInputHeaders"/>
          </label>
          <label class="vertical">
            <span class="fad-label">Body</span>
            <textarea class="form-control fad-raw-body vertical" v-model="rawInputBody"/>
          </label>
          <div class="fad-input-submit">
            <button type="submit" class="btn btn-lg btn-success"
                    role="button"
                    v-on:submit.prevent="submitRawInput()"
                    v-on:click.prevent="submitRawInput()"
                    v-bind:disabled="requestBusy"
            >Submit Raw Input Request
            </button>
          </div>
        </form>
      </div>
    </div>
    <div class="fad-output">
      <div v-for="(response, index) in responses"
           v-bind:key="index"
           class="fad-response">
        <div class="fad-response-url">{{ response.url }}</div>
        <div class="fad-response-with-code">
          <h2>Response</h2>
          <div class="fad-response-code" v-bind:class="responseCodeClass(response)"
          >{{ response.status + ' ' + response.statusText }}<!-- strip whitespace to div close
        --></div>
          <div class="fad-response-duration" v-if="response.fadDuration != null"
          >{{ fadDurationToPrecision(response.fadDuration) }} ms<!--
        --></div>
          <div class="fad-correlation-id" v-if="response.requestCorrelationId != null">
            x-correlation-id: {{response.requestCorrelationId}}
          </div>
        </div>
        <response-view v-bind:response="response"
                       v-bind:requestUrl="requestUrl"
                       v-on:dereference="sendDereferenceRequest"/>
      </div>
      <template v-if="responses.length === 0">
        <h2>Response</h2>
        <div class="fad-no-outputs form-control"><!--
          -->{{ fetchStatus }}<!--
        --></div>
      </template>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash';
  import {getStatusText} from "http-status-codes";
  import {prettyPathNotation, toPrecision} from "../filters";

  import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "../../utils/RedirectToIndex";
  import ModeledForm from "./modeledform/ModeledForm";
  import ResponseView from "./ResponseView";

  export default {
    name: 'ServiceWidget',
    components: {
      ModeledForm,
      ResponseView,
    },
    props: {
      service: Object,
      application: String,
      requestUrl: String,
    },
    data: function () {
      return {
        inputs: {
          formInput: 'formInput',
          rawInput: 'rawInput',
        },
        responses: [],
        fetchStatus: 'Send a request to view the response.',
        requestBusy: false,
        fakeService: {},
        // requests: [
        //   ['https://httpbin.org/image', {headers: {accept: 'image/*'}}],
        //   ['https://httpbin.org/xml', {headers: {accept: 'application/xml'}}],
        //   ['https://httpbin.org/status/400'],
        //   ['https://httpbin.org/status/500'],
        //   ['http://localhost:8010/proxy/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'],
        //   ['https://httpbin.org/post', {
        //     method: 'POST',
        //     body: JSON.stringify({
        //       application: 'my app 1',
        //       service: 'my service 1',
        //       path: '/path/{var}/foo',
        //       headers: ['test headers'],
        //       body: '{"body": true}'
        //     })
        //   }],
        //   ['https://localhost:1025/'],
        //   ['https://httpbin.org/drip?duration=1&numbytes=3&code=200&delay=1'],
        // ],
        // requestCycle: 0,
      }
    },
    // mounted() {
    //   return this.$store.dispatch('modeledform/setNewRawInputHeaders', this.service.headers.join('\n'));
    // },
    computed: {
      templateReady: function () {
        return this.bodyReady && this.headersReady && this.pathReady;
      },
      bodyReady: function () {
        return this.service.body === '' || this.service.body == null || this.templateBody !== ''
      },
      templateBody: function () {
        if (!this.service.body) {
          return '';
        }
        try {
          const templated = _.template(this.service.body)(this.formModel);
          return templated;
        } catch (err) {
          return '';
        }
      },
      headersReady: function () {
        return !this.service.headers || this.service.headers.length === 0 || this.templateHeaders.length > 0;
      },
      templateHeaders: function () {
        let self = this;
        if (!this.service.headers) {
          return [];
        }
        try {
          return _.map(this.service.headers, (header) => {
            try {
              return _.template(header)(self.formModel)
            } catch (err) {
              return '';
            }
          });
        } catch (err) {
          return [];
        }
      },
      pathReady: function () {
        return this.templatePath != null;
      },
      templatePath: function () {
        try {
          return _.template(this.service.path)(this.formModel);
        } catch (err) {
          return null;
        }
      },
      currentInput: {
        get() {
          return this.$store.state.modeledformData.currentInput;
        },
        set(value) {

        }
      },
      formModel: {
        get() {
          return this.$store.state.modeledformData.formModel
        },
        set(value) {
          this.$store.dispatch('modeledformData/setNewFormModel', value);
        }
      },
      rawInputPath: {
        get() {
          //this.$store.dispatch('modeledformData/setNewRawInputPath', prettyPathNotation(this.service.path))
          return this.$store.state.modeledformData.rawInputPath;
        },
        set(value) {
          this.$store.dispatch('modeledformData/setNewRawInputPath', value)
        }

      },
      rawInputHeaders: {
        get() {
          return this.$store.state.modeledformData.rawInputHeaders;
        },
        set(value) {
          this.$store.dispatch('modeledformData/setNewRawInputHeaders', value)
        }

      },
      rawInputBody: {
        get() {
          return this.$store.state.modeledformData.rawInputBody;
        },
        set(value) {
          this.$store.dispatch('modeledformData/setNewRawInputBody', value)
        }
      },
      fadDurationToPrecision(faDuration) {
        return toPrecision(faDuration, 3)
      }
    },
    watch: {
      // TODO reset all raw inputs on input without destroying them on mount
      templatePath: function (newPath, oldPath) {
        if (!this.pathReady) {
          return;
        }
        this.rawInputPath = newPath;
        // this.rawInputHeaders = this.templateHeaders.join('\n');
        // this.rawInputBody = this.templateBody;
      },
      templateHeaders: function (newHeaders, oldHeaders) {
        if (!this.headersReady) {
          return;
        }
        // this.rawInputPath = this.templatePath;
        this.rawInputHeaders = newHeaders.join('\n');
        // this.rawInputBody = this.templateBody;
      },
      templateBody: function (newBody, oldBody) {
        if (!this.bodyReady) {
          return;
        }
        // this.rawInputPath = this.templatePath;
        // this.rawInputHeaders = this.templateHeaders.join('\n');
        this.rawInputBody = newBody;
      }
    },
    methods: {
      cleanHeaders: function (headersString) {
        return headersString.split('\n')
          .map(header => header.trim())
          .filter(header => header !== '');
      },
      submitTemplate: function () {
        var self = this;
        if (self.requestBusy || !self.templateReady) {
          return;
        }
        this.rawInputPath = this.templatePath;
        this.rawInputHeaders = this.templateHeaders.join('\n');
        this.rawInputBody = this.templateBody;
        this.submitRawInput();
      },
      submitRawInput: function () {
        var self = this;
        if (self.requestBusy) {
          return;
        }
        self.requestBusy = true;
        self.fetchStatus = '(waiting for response...)';
        self.responses = [];

        // self.requestCycle += 1;
        // var responsePromise = fetch.apply(window, self.requests[(self.requestCycle) % self.requests.length]);
        var requestObj = {
          application: self.application,
          service: self.service.name,
          serviceEnv: self.$store.state.applicationData.selectedEnvironment,
          path: self.rawInputPath,
          headers: this.cleanHeaders(self.rawInputHeaders),
          body: self.rawInputBody
        };
        if (self.currentInput == self.inputs.formInput) {
          requestObj.formmodel = self.formModel
        }
        var responsePromise = fetch(self.requestUrl, {
          method: 'POST',
          headers: {
            'access-token': sessionStorage.getItem('accessToken')
          },
          body: JSON.stringify(requestObj),
        });
        responsePromise
          .then(response => {
            redirectToIndexIfUnauthenticated(response);
            return response;
          })
          .then(async response => {
            response.fadRequestProxy = true;

            if (response.status === 200) {
              // Special handling for dashboard request URL
              const fadJson = await response.json();
              if (_.get(fadJson, 'body.documentUrl')) {
                // TODO remove WIP hardcoding
                self.sendDereferenceRequest(fadJson.body.documentUrl);
              }
              const newHeaders = new Headers(fadJson.headers);
              const newResponse = {
                status: fadJson.status,
                statusText: getFadStatusText(fadJson.status),
                requestCorrelationId: fadJson.requestCorrelationId,
                headers: newHeaders,
                json: function () {
                  return Promise.resolve(fadJson.body)
                },
                text: function () {
                  return this.json();
                },
              };
              if (fadJson.requestHistoryItem) {
                var hItems = this.$store.state.historyData.historyItems;
                if (hItems.length > 20) {
                  hItems.pop()
                }
                hItems.unshift(fadJson.requestHistoryItem);
                this.$store.dispatch('historyData/setNewHistoryItems', hItems)
              }
              if (_.get(fadJson, 'downstreamUrlPath')) {
                newResponse.url = fadJson.downstreamUrlPath;
              }
              if (_.get(fadJson, 'responseTime')) {
                newResponse.fadDuration = fadJson.responseTime;
              }
              response = newResponse;
            } else if (response.status === 500) {
              try {
                const fadJson = await response.json();
                if (fadJson && fadJson.requestHistoryItem) {
                  var hItems = this.$store.state.historyData.historyItems;
                  if (hItems.length > 20) {
                    hItems.pop()
                  }
                  hItems.unshift(fadJson.requestHistoryItem);
                  this.$store.dispatch('historyData/setNewHistoryItems', hItems)
                }
              } catch (e) {

              }
            }

            self.responses.push(response);
            self.fetchStatus = 'Send a request to view the response.';
            self.requestBusy = false;
          })
          .catch(reason => {
            redirectToIndexIfNoAccessToken();
            self.fetchStatus = reason.toString();
            self.requestBusy = false;
          })
      },
      sendDereferenceRequest: function (getUrl) {
        const start = performance.now();
        fetch(getUrl)
          .then(response => {
            const end = performance.now();
            response.fadDuration = end - start
            this.responses.push(response);
          })
          .catch(redirectToIndexIfNoAccessToken)
      },
      responseCodeClass: function (response) {
        return {
          'fad-response-code-good': 200 <= response.status && response.status < 300,
          'fad-response-code-bad-client': 400 <= response.status && response.status < 500,
          'fad-response-code-bad-server': 500 <= response.status && response.status < 600,
        }
      },
      changeCurrentInput: function (newInput) {
        this.$store.dispatch('modeledformData/setNewCurrentInput', newInput)
      },
    },
    filters: {
      toPrecision,
    },
  }

  function getFadStatusText(status) {
    return getStatusText(status).replace(/_/g, ' ');
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  @media (max-width: 1000px) {
    .fad-service-widget {
      flex-direction: column;
    }

    .fad-input, .fad-output {
      width: 100%;
    }
  }

  @media not all and (max-width: 1000px) {
    .fad-service-widget {
      flex-direction: row;
    }

    .fad-input {
      max-width: 300px;
    }
  }

  .fad-service-widget {
    display: flex;
    flex: 1;
    -ms-flex: 1 1 100%;

    background-color: #055072;
  }

  .fad-input, .fad-output {
    padding: 20px;
  }

  .fad-no-inputs {
    text-align: center;
  }

  .fad-output {
    flex: 1;
    -ms-flex: 1 1 auto;
  }

  .fad-input {
    box-shadow: inset 0 0 80px #133d68;
  }

  .fad-output {
    box-shadow: inset 0 0 280px #315d8a;
  }

  .fad-input {
    min-width: 375px;
  }

  .fad-btn-form-input {
    font-family: "Fira Sans", sans-serif;
    color:black !important;
  }

  .fad-btn-raw-input {
    font-family: "Fira Mono", monospace;
    color:black !important;
  }

  button.fad-btn-form-input.active, button.fad-btn-raw-input.active {
    background-color: #d8effb;
  }

  .fad-input-submit {
    margin: 30px 0 0;
    padding: 20px;
    text-align: center;
    border-top: 1px solid #e5e5e5;
  }

  .fad-service-widget input, .fad-service-widget select, .fad-service-widget textarea {
    color: #333;
  }

  .fad-output {
    display: flex;
    flex-direction: column;
  }

  .fad-no-outputs {
    cursor: text;
    white-space: pre-wrap;
    height: auto;
    min-height: 34px;
    border-radius: 0;
  }

  .fad-response {
    /*border-top: 5px solid rgb(207, 226, 234);*/
    margin-top: 60px;
    /*padding-top: 25px;*/
    /*padding: 10px 0 20px;*/
    /*border-left: 2px solid rgb(207, 226, 234);*/
    /*padding-left: 15px;*/
    /*margin-left: -5px;*/
    flex: 1;
    display: flex;
    flex-direction: column;
  }

  .fad-response:nth-child(1) {
    /*border-top: none;*/
    margin-top: 0;
    /*padding-top: 0;*/
  }

  .fad-response-url {
    margin-bottom: 10px;
    word-break: break-all;
  }

  .fad-response-with-code {
    display: flex;
    flex-direction: row;
    margin-bottom: 20px;
    flex-wrap: wrap;
  }

  .fad-response-with-code h2 {
    margin-bottom: 0;
  }

  .fad-response-with-code .fad-response-code,
  .fad-response-with-code .fad-response-duration,
  .fad-response-with-code .fad-correlation-id {
    border: 1px solid white;
    display: flex;
    justify-content: center;
    flex-direction: column;
    margin: 5px 10px;
    padding: 5px 10px;
    font-family: "Fira Mono", monospace;
    line-height: 1.1;
  }

  .fad-response-code-good {
    color: #70ec70;
    border-color: #70ec70 !important;
  }

  .fad-response-code-bad-client {
    color: #f4b2f0;
    border-color: #f4b2f0 !important;
  }

  .fad-response-code-bad-server {
    color: #fdb6b6;
    border-color: #fdb6b6 !important;
  }

  .fad-correlation-id {
    border-color: #f6f088 !important;
    color: #f6f088 !important;
  }

  .fad-input-raw {
    font-family: "Fira Mono", monospace;
    display: flex;
    flex-direction: column;

  }

  .fad-input-raw, .fad-input-form {
    margin-top: 20px;
  }

  .fad-input-raw label {
    width: auto;
    /*display: block;*/
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: bold;
  }

  .fad-input-raw label .fad-label {
    /*display: block;*/
    width: 100%;
    text-align: left;
  }

  .fad-input-raw label input, .fad-input-raw label textarea {
    width: 100%;
    max-width: 100%;
    min-width: 100%;
    font-size: 10px;
  }

  .fad-input-raw label textarea {
    resize: vertical;
  }

  .fad-input-raw textarea.fad-raw-headers {
    min-height: 150px;
    white-space: pre;
    overflow: auto;
  }

  .fad-input-raw textarea.fad-raw-body {
  }

  .horizontal {
    display: flex;
    flex-direction: row;
  }

  .flex {
    flex: 1;
  }

  .vertical {
    display: flex;
    flex-direction: column;
    flex: 1;
  }

</style>

<style>
  label, input.form-control {
    width: 100%;
  }

  .fad-service-widget, .fad-service-widget legend {
    color: #cfe2ea;
  }

  form fieldset {
    margin: 10px 0 !important;
  }

  form fieldset legend {
    margin-bottom: 10px;
    font-size: 18px;
  }

  form > div, form > fieldset {
    margin-bottom: 10px;
  }
</style>
