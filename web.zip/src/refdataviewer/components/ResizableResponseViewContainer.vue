<template>
  <div v-resize="onResize">
    <div ref="resizableDiv">
      <slot name="resizer" :style-prop="widgetStyle"/>
    </div>
  </div>
</template>

<script>
export default {
  name: "resizable-response-view-container",
  data() {
    return {
      widgetStyle: {
        overflow: 'auto',
        height: '120px'
      },
    };
  },
  props: {
  },
  methods: {
    onResize() {
      let tHeight = window.innerHeight - 130
      this.widgetStyle = {
        backgroundColor: '#055072',
        overflow: 'auto',
        height: `${tHeight}px`
      }
    },
  },
};
</script>
