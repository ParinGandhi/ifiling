<template>
  <v-container fluid :class="diffCls">
    <v-row style="height: 70px">
      <v-col cols="12">
        <v-switch v-model="switch1" v-show="!showStandardText"
                  :readonly="readOnly"
                  :label="`${schema.title}: ${switch1.toString()}`"
                  v-on:change="updateValue"
        ></v-switch>
      </v-col>
      <v-col cols="11" style="margin: -30px 0px 0px 0px">
        <v-text-field :class="diffCls" v-show="showStandardText" style="margin: 0px 0px 0px 0px"
                      label="Value"
                      v-model="textValParseFail"
                      v-bind:aria-required="schema.required"
                      :readonly="readOnly"
        ></v-text-field>
      </v-col>
      <v-col v-show="regexError" cols="1" style="padding: 0px 0px 0px 0px">
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-icon v-bind="attrs" color="red darken-3"
                    v-on="on">
              mdi-alert-outline
            </v-icon>
          </template>
          <span>{{localWidgetVal}} failed RegEx validation</span>
        </v-tooltip>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "RefDataModeledFormSwitch",
  props: {
    service: Object,
    value: String,
    schema: Object,
    filteredResults: Object,
    applyDiffCls: Boolean,
    readOnly: Boolean
  },
  data: () => ({
    switch1: true,
    diffCls: "",
    parseFailed: false,
    showStandardText: false,
    textValParseFail: '',
    regexError: false,
    localWidgetVal:''

  }),
  mounted: function () {
    if (!this.value && this.schema.default) {
      this.switch1 = JSON.parse(this.schema.default);
      this.$emit('input', this.schema.default)
    } else if (this.filteredResults != null && this.filteredResults['value']) {
      let regexStr = this.schema.switchParseInfo.matchSwitchPattern
      let regex = new RegExp(regexStr);
      let resultArr = regex.exec(this.filteredResults['value']);
      if (resultArr && resultArr.length > 0) {
        let val = resultArr[this.schema.switchParseInfo.matchGroup]
        this.switch1 = JSON.parse(val)
        this.$emit('input', this.filteredResults['value']);
      } else {
        this.$emit('input', this.filteredResults['value'])
      }
    } else {
      if (this.value != null) {
        try {
          this.switch1 = JSON.parse(this.value);
        } catch (e) {
         // this.parseFailed = true
        }
        if(!new RegExp(this.schema.switchParseInfo.matchSwitchPattern).test(this.value)) this.parseFailed = true
        this.$emit('input', this.value);
      }
    }
    if (this.service) {
      let updatedVal = this.service.formModel[this.schema.id]
      let originalVal = this.service.formModelOriginal[this.schema.id]
      if (this.applyDiffCls && updatedVal != null && updatedVal !== originalVal) {
        this.diffCls = "diffCls"
      }
      if (this.readOnly && this.parseFailed) {
        this.textValParseFail = this.value
        this.showStandardText = true
      }
    }
  },
  methods: {
    updateValue: function (newVal) {
      this.$emit('input', newVal.toString())
    }
  },
  computed: {}
}
</script>

<style scoped>
.diffCls {
  background-color: lightyellow !important;
}
</style>
