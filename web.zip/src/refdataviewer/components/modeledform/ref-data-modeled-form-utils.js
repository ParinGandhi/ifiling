import _ from "lodash";

function getComponent(type) {
  const typeMap = {
    string: 'RefDataModeledFormText',
    date: 'RefDataModeledFormDate',
    switch: 'RefDataModeledFormSwitch',
    select: 'RefDataModeledFormSelect'
  };
  return _.defaultTo(typeMap[type], 'ModeledFormUnknown');
}

function getDefaultValue(type) {
  const typeMap = {

  }
}

export {
  getComponent
}
