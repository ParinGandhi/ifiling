<template>
  <div>
    <v-row style="min-height: 70px">
      <v-col cols="12" style="max-height: 99px; overflow: auto">
        <v-select ref="box" :class="diffCls" v-show="!showStandardText" style="margin: 15px 0px 0px 0px"
                  :items="schema.items"
                  v-model="selectVal"
                  :multiple="multiSelect"
                  chips
                  dense
                  v-on:input="updateValue"
                  :label="schema.title"
                  :readonly="readOnly"
        ></v-select>
      </v-col>
      <v-col v-show="showStandardText">
        <v-text-field :class="diffCls"
                      label="Value"
                      v-model="textValParseFail"
                      v-bind:aria-required="schema.required"
                      :readonly="readOnly"
        ></v-text-field>
      </v-col>
    </v-row>
  </div>
</template>

<script>

import _ from "lodash";

export default {
  name: "RefDataModeledFormSelect",
  props: {
    service: Object,
    value: String,
    schema: Object,
    filteredResults: Object,
    applyDiffCls: Boolean,
    readOnly: Boolean
  },
  data: () => ({
    selectVal: null,
    diffCls: "",
    multiSelect: false,
    parseFailed: false,
    showStandardText: false,
    textValParseFail: ''
  }),
  mounted: function () {
    this.multiSelect = this.schema.multiSelect
    if (!this.value && this.schema.default) {
      if (new RegExp(this.schema.selectParseInfo.matchSelectPattern).test(this.schema.default)) {
        this.setSelectValue(this.schema.default)
      } else {
        this.selectVal = this.schema.default;
        this.$emit('input', this.schema.default)
      }
    } else if (this.filteredResults != null && this.filteredResults['value']) {
      if (new RegExp(this.schema.selectParseInfo.matchSelectPattern).test(this.filteredResults['value'])) {
        this.setSelectValue(this.filteredResults['value'])
      } else {
        this.$emit('input', this.filteredResults['value'])
      }
    } else {
      if (this.value != null) {
        try {
          if (this.schema.multiSelect) {
            this.selectVal = this.value.split("|");
          } else {
            this.selectVal = this.value
          }
        } catch (e) {
        }
        if (this.value == '' || this.value == null || this.value == 'dummyValue') {
          this.parseFailed = true
        }
        this.$emit('input', this.value);
      }
    }
    if (this.service) {
      let updatedVal = this.service.formModel[this.schema.id]
      let originalVal = this.service.formModelOriginal[this.schema.id]
      if (this.applyDiffCls && updatedVal != null && updatedVal !== originalVal) {
        this.diffCls = "diffCls"
      }
      if (this.readOnly && this.parseFailed) {
        this.textValParseFail = this.value
        this.showStandardText = true
      }
    }
  },
  methods: {
    updateValue: function () {
      if (this.schema.multiSelect) {
        this.$emit('input', this.selectVal.sort().join('|'))
      } else {
        this.$emit('input', this.selectVal)
      }
    },
    setSelectValue: function(selectValue){
      let regexStr = this.schema.selectParseInfo.matchSelectPattern
      let regex = new RegExp(regexStr, this.schema.selectParseInfo.regexModifiers);
      let resultArr = selectValue.matchAll(regex);
      let val = []
      for (let result of resultArr) {
        val.push(result[1])
      }
      if (val && val.length > 0) {
        if (this.schema.multiSelect) {
          this.selectVal = val
          this.$emit('input', val.sort().join('|'));
        } else {
          this.selectVal = val[0]
          this.$emit('input', val[0]);
        }
      }
    }
  }
}
</script>

<style scoped>

.diffCls {
  background-color: lightyellow !important;
}

.custom-select select {
  display: inline-block;
  max-width: 100%;
  padding: .375rem 1.75rem .375rem .75rem;
  line-height: 1.25;
  color: #464a4c;
  vertical-align: middle;
  background: #fff url(../../../../public/br_down.svg) no-repeat right .75rem center !important;
  background-size: auto;
  -webkit-background-size: 8px 10px;
  background-size: 8px 10px;
  border: 1px solid rgba(0, 0, 0, .15);
  border-radius: .25rem;
  -moz-appearance: none;
  -webkit-appearance: none;
}

/* Style the arrow inside the select element: */
.custom-select select:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 30px;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

</style>
