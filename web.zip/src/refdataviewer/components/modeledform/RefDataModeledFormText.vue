<template>
  <div>
    <v-row style="height: 70px">
      <v-col cols="12">
    <v-text-field ref="box" :class="diffCls" v-show="!showStandardText"
                  :label="schema.title"
                  v-model="textVal"
                  v-bind:aria-required="schema.required"
                  :readonly="readOnly"
                  v-on:input="updateValue"
    ></v-text-field>
      </v-col>
      <v-col cols="11">
    <v-text-field :class="diffCls" v-show="showStandardText"
                  label="Value"
                  v-model="textValParseFail"
                  v-bind:aria-required="schema.required"
                  :readonly="readOnly"
    ></v-text-field>
      </v-col>
    </v-row>
  </div>
</template>

<script>
export default {
  name: "RefDataModeledFormText",
  props: {
    service: Object,
    value: String,
    schema: Object,
    filteredResults: Object,
    applyDiffCls: Boolean,
    readOnly:Boolean
  },
  data: () => ({
    textVal: "",
    diffCls: "",
    parseFailed: false,
    showStandardText: false,
    textValParseFail:''
  }),
  mounted: function () {
    if (!this.value && this.schema.default) {
      this.textVal = this.schema.default;
      this.$emit('input', this.schema.default)
    } else if (this.filteredResults != null && this.filteredResults['value']) {
      let regexStr = this.schema.stringParseInfo.matchStringPattern
      let regex = new RegExp(regexStr);
      let resultArr = regex.exec(this.filteredResults['value']);
      if(resultArr) {
        let val = resultArr[this.schema.stringParseInfo.matchGroup]
        this.textVal = val
        this.$emit('input', val);
      }else{
        this.$emit('input', this.filteredResults['value'])
      }
    } else {
      if (this.value != null) {
        this.textVal = this.value;
        //if(!new RegExp(this.schema.stringParseInfo.matchStringPattern).test(this.value)) this.parseFailed = true
        this.$emit('input', this.textVal);
      }
    }
    if (this.service) {
      let updatedVal = this.service.formModel[this.schema.id]
      let originalVal = this.service.formModelOriginal[this.schema.id]
      if (this.applyDiffCls && updatedVal != null &&  updatedVal.localeCompare(originalVal, undefined, { sensitivity: 'accent' }) !== 0) {
        this.diffCls = "diffCls"
      }
      if (this.readOnly && this.parseFailed) {
        this.textValParseFail = this.value
        this.showStandardText = true
      }
    }
  },
  methods: {
    updateValue: function (newVal) {
      this.$emit('input', newVal)
    }
  }
}
</script>

<style scoped>
.diffCls {
  background-color: lightyellow !important;
}
</style>
