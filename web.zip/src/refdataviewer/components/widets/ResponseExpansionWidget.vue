<template>
  <v-list-item style="width: 100%; margin-left: 0px; margin-right: 0px; padding-bottom: 10px" ref="cardTitle">
    <v-card style="width: 100%; min-height: 70px; margin-left: 14px; margin-right: 18px; padding-bottom: 10px">
      <v-row v-if="response == null">
        <v-col cols="12">
          <v-progress-linear
            color="deep-purple accent-4"
            indeterminate
            rounded
            height="6"
          ></v-progress-linear>
        </v-col>
      </v-row>
      <v-row v-if="response != null">
        <v-col cols="4">
          <v-card-text style="padding-bottom: 0px">
            <v-row>
              <v-col cols="10">
                <div>
                  {{ service.name }}
                </div>
                <div>
                  {{ service.templatePath }}
                </div>
              </v-col>
              <v-col cols="2">
                <v-card-actions style="width: 50px; margin-left: auto" v-show="showError">
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon v-bind="attrs" color="red darken-3"
                              v-on="on">
                        mdi-alert-outline
                      </v-icon>
                    </template>
                    <span><strong>"{{ localWidgetVal }}"</strong> failed the regEx validation</span>
                  </v-tooltip>
                </v-card-actions>
              </v-col>
            </v-row>
            <v-list-item style="padding-bottom: 0px">
              <v-list-item-content style="padding-bottom: 0px">
                <v-list-item-title>{{ service.labell }}</v-list-item-title>
                <RefDataModeledForm ref="localForm" v-if="showForm"
                                    v-bind:service="service"
                                    v-bind:schema="service.refDataFormSchema"
                                    v-bind:filteredResults="service.filteredResults"
                                    v-model="service.formModel"
                                    v-on:formValidated="updateValidationIcon"/>
              </v-list-item-content>
            </v-list-item>
          </v-card-text>
        </v-col>
        <v-col cols="4">
          <h4>Legend</h4>
          <ul>
            <li v-for="(legend ,index) in service.legend" v-bind:key="index">
              <span v-html="legend"></span>
            </li>
          </ul>
        </v-col>
        <v-col cols="4">
          <h4>Notes</h4>
          <ul class="">
            <li v-for="(note ,index) in service.notes" v-bind:key="index">
              <span v-html="note"></span>
            </li>
          </ul>
        </v-col>
      </v-row>
      <v-card-actions v-if="response != null" style="padding-top: 0px; padding-bottom: 0px">
        <v-btn color="blue" text @click="removeService">
          <v-icon
            right
            dark
          >
            mdi-checkbox-marked-outline
          </v-icon>
          Uncheck
        </v-btn>
        <v-btn color="blue" text @click="resetFormModel">
          Reset
        </v-btn>
        <v-spacer></v-spacer>
        <v-btn icon @click="expandBtnClicked()">
          <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
        </v-btn>
      </v-card-actions>
      <v-expand-transition v-if="response != null">
        <div v-show="show" style="padding: 0px 0px 20px 0px">
          <v-divider></v-divider>
          <v-row style="margin-left: 20px; margin-right: 40px" eager>
            <textarea :id="expansionEditorId" style="height: auto;" ref="expansionEditor" value="">
            </textarea>
          </v-row>
        </div>
      </v-expand-transition>
    </v-card>
  </v-list-item>
</template>
<script>

import _ from "lodash";
import 'codemirror/lib/codemirror.css'
import 'codemirror/addon/fold/foldgutter.css'
import 'codemirror/addon/dialog/dialog.css'
import 'codemirror/addon/search/matchesonscrollbar.css'
import uuid from "uuid"
import RefDataModeledForm from "@/refdataviewer/components/modeledform/RefDataModeledForm";
import {redirectToIndexIfNoAccessToken, redirectToIndexIfUnauthenticated} from "@/utils/RedirectToIndex";
import {getStatusText} from "http-status-codes";

export default {
  name: 'responseExpansionWidget',
  components: {
    RefDataModeledForm
  },
  props: {
    service: Object,
    selectedServices: Array,
    serviceResetSwitch: Boolean,
    application: String,
    requestUrl: String
  },
  data: function () {
    return {
      expansionEditorId: null,
      editorInitialized: false,
      show: false,
      response: null,
      showForm: false,
      showError: false,
      localWidgetVal: ''
    }
  },
  computed: {
    templatePath: {
      get() {
        return this.service.templatePath
      },
      set(value) {
      }
    },
    filteredResults: {
      get() {
        return this.service.filteredResults
      },
      set(value) {
        this.service.filteredResults = value
      }
    }
  },
  async created() {

  },
  mounted: function () {
    let self = this;
    self.expansionEditorId = uuid();

    const el = this.$refs.cardTitle.$el;
    this.$emit('scrollChildIntoView', el);

    if (self.requestBusy) {
      return;
    }
    self.requestBusy = true;
    self.fetchStatus = '(waiting for response...)';
    self.responses = [];
    let urlPath = (_.template(this.service.root_url)(this.$store.state.applicationData.selectedEnvironment) + self.service.path);
    let requestObj = {
      application: self.application,
      service: self.service.name,
      serviceEnv: self.$store.state.applicationData.selectedEnvironment,
      path: self.templatePath,
      url: urlPath,
      method: this.service.method,
      headers: [],
      body: {}
    };
    let responsePromise = fetch(this.$store.state.applicationData.resourceUrls.refDataRequest, {
      method: 'POST',
      headers: {
        'access-token': sessionStorage.getItem('accessToken')
      },
      body: JSON.stringify(requestObj),
    });
    responsePromise
      .then(response => {
        redirectToIndexIfUnauthenticated(response);
        return response;
      })
      .then(async response => {
        response.fadRequestProxy = true;
        if (response.status === 200) {
          // Special handling for dashboard request URL
          const fadJson = await response.json();
          if (_.get(fadJson, 'body.documentUrl')) {
            // TODO remove WIP hardcoding
            self.sendDereferenceRequest(fadJson.body.documentUrl);
          }
          const newHeaders = new Headers(fadJson.headers);
          const newResponse = {
            status: fadJson.status,
            statusText: getFadStatusText(fadJson.status),
            requestCorrelationId: fadJson.requestCorrelationId,
            headers: newHeaders,
            json: function () {
              return Promise.resolve(fadJson.body)
            },
            text: function () {
              return this.json();
            },
          };
          if (_.get(fadJson, 'downstreamUrl')) {
            newResponse.url = fadJson.downstreamUrl;
          }
          if (_.get(fadJson, 'responseTime')) {
            newResponse.fadDuration = fadJson.responseTime;
          }
          response = newResponse;
        }

        self.response = response;
        self.response.json().then(json => {
          self.service.filteredResults = self.filterResponseOutput(json);
          self.showForm = true
        })
        self.responses.push(response);
        self.fetchStatus = 'Send a request to view the response.';
        self.requestBusy = false;
      })
      .catch(reason => {
        redirectToIndexIfNoAccessToken();
        self.fetchStatus = reason.toString();
        self.requestBusy = false;
      })

  },
  watch: {
    serviceResetSwitch: function () {
      this.resetFormModel()
    }
  },
  methods: {
    expandBtnClicked: function () {
      let self = this;
      self.show = !self.show;
      if (!self.editorInitialized) {
        self.editorInitialized = true;
        require([
          "codemirror", "codemirror/mode/htmlmixed/htmlmixed", "codemirror/mode/javascript/javascript", "codemirror/mode/xml/xml", "codemirror/mode/shell/shell",
          "codemirror/mode/properties/properties", "codemirror/mode/yaml/yaml",
          "codemirror/addon/fold/brace-fold", "codemirror/addon/fold/comment-fold", "codemirror/addon/fold/foldcode", "codemirror/addon/fold/foldgutter",
          "codemirror/addon/fold/indent-fold", "codemirror/addon/fold/markdown-fold", "codemirror/addon/fold/xml-fold", "codemirror/addon/dialog/dialog",
          "codemirror/addon/search/search", "codemirror/addon/search/jump-to-line", "codemirror/addon/search/match-highlighter", "codemirror/addon/search/matchesonscrollbar",
          "codemirror/addon/search/searchcursor", "codemirror/addon/scroll/annotatescrollbar", "codemirror/addon/edit/matchbrackets", "codemirror/addon/edit/closebrackets",
          "codemirror/addon/search/match-highlighter"
        ], function (CodeMirror) {
          self.codeMirrorEditor = CodeMirror.fromTextArea(document.getElementById(self.expansionEditorId), {
            lineNumbers: true,
            // mode: "htmlmixed",
            viewportMargin: Infinity,
            autoCloseBrackets: true,
            matchBrackets: true,
            foldGutter: true,
            gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
          });
          self.codeMirrorEditor.setSize("100%", 400);
          self.codeMirrorEditor.setOption("mode", {
            name: "javascript",
            jsonld: true,
            statementIndent: 2
          })
          self.response.json().then(json => {
            //self.codeMirrorEditor.setValue(JSON.stringify(self.testAreaValueJson, null, 2))
            self.codeMirrorEditor.setValue(JSON.stringify(json, null, 2))
            self.resetGutterCss();
          })
        }); /**/
      }
    },
    resetGutterCss: function () {//workaround to reset the gutter css when the language mode is changed
      let tmp = this.codeMirrorEditor.getValue()
      this.codeMirrorEditor.setValue("")
      this.codeMirrorEditor.setValue(tmp)
      this.codeMirrorEditor.refresh()
    },
    filterResponseOutput: function (output) {
      const fOutput = {}
      let self = this;
      if (_.isArray(output)) {
        _.forEach(output, function (outputItem) {
          _.forEach(self.service.filtered_values, function (value) {
            fOutput[value.substring(value.length, value.indexOf(".") + 1)] = _.get(outputItem, value, '');
          });
        })
      } else {
        _.forEach(self.service.filtered_values, function (value) {
          fOutput[value.substring(value.length, value.indexOf(".") + 1)] = _.get(output, value, '');
        });
      }
      return fOutput;
    },
    removeService: function () {
      this.$emit('removeService', true, this.service);
    },
    updateValidationIcon: function (val, result) {
      this.localWidgetVal = result
      this.showError = !val
    },
    resetFormModel: function () {
      let self = this
      let p = new Promise((resolve, reject) => {
        this.showForm = false
        resolve()
      }).then(() => {
        this.showForm = true
      })
    }
  }
}

function getFadStatusText(status) {
  return getStatusText(status).replace(/_/g, ' ');
}
</script>

<style>
.btn {
  /*padding: 6px 12px 3px;*/
}
</style>
