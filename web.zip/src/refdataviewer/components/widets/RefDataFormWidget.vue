<template>
  <ModeledForm v-bind:schema="service.formSchema"
               v-model="formModel"/>
</template>

<script>

import _ from "lodash";
import ModeledForm from "@/dashboard/components/modeledform/ModeledForm";

export default {
  name: 'refDataFormWidget',
  components: {
    ModeledForm
  },
  props: {
    service: Object,
  },
  data: function () {
    return {
      count: 5
    }
  },
  async created() {

  },
  mounted: function () {
  },
  updated() {
  },
  watch: {
  },
  computed: {
    formModel: {
      get() {
        return this.service.standardFormModel
      },
      set(value) {
        let self = this;
        try {
          this.$emit('templatePathChanged', _.template(self.service.path)(value));
          this.service.standardFormModel = value
        } catch (err) {
          console.log(err)
        }
      }
    }
  }
}
</script>

<style>
.btn {
  /*padding: 6px 12px 3px;*/
}
</style>
