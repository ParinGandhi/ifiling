<template>
  <v-row no-gutters align="start" align-self="start" style="height: 100%;">

    <v-col cols="12" style="height: 100%; width:100%">
      <v-row
        style="padding-bottom: 1px; padding-left: 11px; padding-right: 14px; background-color: #d5d5d5; height: 54px">
        <v-toolbar dense style="height: 52px;background-color: #d5d5d5;" flat>
          <v-toolbar-title>
          </v-toolbar-title>
          <v-spacer></v-spacer>
          <v-tooltip left>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                v-bind="attrs"
                :elevation="10"
                color="primary"
                fab
                x-small
                dark
                v-on="on"
                @click="resetAll"
              >
                <v-icon>mdi-backup-restore</v-icon>
              </v-btn>
            </template>
            <span>Reset All</span>
          </v-tooltip>
          <div style="width: 10px"></div>
          <v-tooltip left>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                v-bind="attrs"
                :elevation="10"
                color="primary"
                fab
                x-small
                dark
                v-on="on"
                @click.stop="showDiffDialog = true">
                <v-icon>mdi-download</v-icon>
              </v-btn>
            </template>
            <span>Download</span>
          </v-tooltip>
        </v-toolbar>
      </v-row>
      <v-row
        style="padding-bottom: 1px; padding-left: 0px; padding-right: 0px; background-color: #d5d5d5; height: 100%; width: 100%; margin-left: 0px; margin-right: 0px">
        <ResizableResponseViewContainer style="width: 100%">
          <template v-slot:resizer="styles">
            <v-list width="100%"
                    :style="styles.styleProp" ref="responseListRef">
              <template  v-for="(service) in selectedServices">
                  <ResponseExpansionWidget
                    v-if="service"
                    :key="service.name"
                    v-bind:serviceResetSwitch="serviceResetSwitch"
                    v-bind:selectedServices="selectedServices"
                    v-bind:service="service"
                    v-bind:application="application"
                    v-bind:requestUrl="requestUrl"
                    v-on:removeService="removeService"
                    v-on:scrollChildIntoView="scrollChildIntoView"/>
              </template>
            </v-list>
          </template>
        </ResizableResponseViewContainer>
        <DiffDialog v-if="showDiffDialog"
                    v-bind:selectedServices="selectedServices"
                    v-bind:application="application"
                    v-bind:requestUrl="requestUrl"/>
      </v-row>
    </v-col>
    <v-snackbar
      v-model="saveSnackBar"
      :timeout="saveSnackBarTimeout"
      top
      vertical
      width="340"
    >
      <div style="padding-bottom: 3px">
        <v-icon>{{ actionStatusIcon }}</v-icon>
        <span style="font-weight: bold !important;; padding-left: 5px !important;">{{ actionStatusTitle }}</span>
      </div>
      <div>
        <div>
          {{ actionStatusMsg }}
        </div>
      </div>
      <template v-slot:action="{ attrs }">
        <v-btn
          v-bind="attrs"
          color="blue"
          text
          @click="saveSnackBar = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>
    <v-dialog
      v-model="actionStatusDialog"
      hide-overlay
      persistent
      width="300"
      content-class="statusDialogCls"
    >
      <v-card
        color="primary"
        dark
      >
        <v-card-text>
          {{ actionStatusMsg }}
          <v-progress-linear
            indeterminate
            color="white"
            class="mb-0"
          ></v-progress-linear>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>

import _ from "lodash";
import ResizableResponseViewContainer from "@/refdataviewer/components/ResizableResponseViewContainer";
import ResponseExpansionWidget from "@/refdataviewer/components/widets/ResponseExpansionWidget";
import DiffDialog from "@/refdataviewer/components/widets/DiffDialogWidget"

export default {
  name: 'responseWidget',
  components: {
    ResponseExpansionWidget,
    ResizableResponseViewContainer,
    DiffDialog
  },
  props: {
    selectedServices: Array,
    application: String,
    requestUrl: String
  },
  data: function () {
    return {
      show: false,
      applications: null,
      resourceUrls: null,
      actionStatusMsg:"Retrieving RefData Queries",
      saveSnackBar: false,
      saveSnackBarTimeout: 3000,
      actionStatusIcon:'',
      actionStatusTitle:'Action Title'
    }
  },
  async created() {
  },
  mounted: function () {

  },
  computed: {
    showDiffDialog: {
      get() {
        return this.$store.state.applicationData.showDiffDialog
      },
      set(value) {
        this.$store.dispatch('applicationData/setNewShowDiffDialog', value)
      }
    },
    serviceResetSwitch: {
      get() {
        return this.$store.state.serviceData.serviceResetSwitch
      },
      set(value) {
        this.$store.dispatch('serviceData/setNewServiceResetSwitch', value)
      }
    },
    actionStatusDialog: {
      get() {
        return this.$store.state.applicationData.actionStatusDialog
      },
      set(value) {
        this.$store.dispatch('applicationData/setNewActionStatusDialog', value)
      }
    }
  },
  methods: {
    removeService: function (val, service) {
      this.$emit('removeService', val, service);
    },
    scrollChildIntoView: function (child) {
      try{
        const parentEl = this.$refs.responseListRef.$el;
        let topPos = child.offsetTop;
        let parentOffsetPlusChildHeight = (topPos - parentEl.offsetTop) - 100;
        parentOffsetPlusChildHeight = (parentOffsetPlusChildHeight < 0) ? 0 : parentOffsetPlusChildHeight
        parentEl.scrollTo({
          top: parentOffsetPlusChildHeight,
          left: 0,
          behavior: 'smooth'
        });
      }catch (e) {
        console.log('ScrollTo Error: '+e)
      }
    },
    resetAll: function () {
      this.serviceResetSwitch = !this.serviceResetSwitch
    }
  }
}
</script>

<style>
.btn {
  /*padding: 6px 12px 3px;*/
}
.statusDialogCls {
  margin-left: 10px !important;
}
</style>
