<template>
  <div v-resize="onResize">
    <div ref="resizableDiv">
      <slot name="resizer" :style-prop="widgetStyle"/>
    </div>
  </div>
</template>

<script>
export default {
  name: "resizable-service-selection-container",
  data() {
    return {
      widgetStyle: {
        overflow: 'auto',
        height: '120px'
      },
    };
  },
  props: {
  },
  methods: {
    onResize() {
      let tHeight = window.innerHeight - 125
      this.widgetStyle = {
        backgroundColor: '#ECEFF1',
        overflowY: 'auto',
        overflowX: 'hidden',
        padding: '2px 0px 0px 0px',
        height: `${tHeight}px`
      }
    },
  },
};
</script>
