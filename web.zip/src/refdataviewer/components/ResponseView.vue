<template>
  <ResponseWidget v-bind:selectedServices="selectedServices"
                  v-bind:application="application"
                  v-bind:requestUrl="requestUrl"
                  v-on:removeService="removeService"/>
</template>

<script>
import jQuery from 'jquery'
import _ from 'lodash';
import ResponseWidget from "@/refdataviewer/components/widets/ResponseWidget"

export default {
  name: 'ResponseView',
  components: {
    ResponseWidget
  },
  props: {
    selectedServices: Array,
    application: String,
    requestUrl: String
  },
  data: function () {
    return {};
  },
  mounted: async function () {
  },
  methods: {
    removeService: function (val, service) {
      this.$emit('removeService', val, service);
    }
  }
}


</script>

<style scoped>
</style>

<style>
</style>
