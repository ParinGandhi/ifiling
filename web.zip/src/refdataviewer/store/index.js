import { createApp, h } from 'vue'
import App from '../App.vue'
import Vuex from 'vuex'
import applicationData from './module/applicationData'
import serviceData from './module/serviceData'
import modeledformData from './module/modeledformData'

const debug = process.env.NODE_ENV !== 'production'

const app = createApp(App)
app.use(Vuex)
app.mount('#app')

export default new Vuex.Store({
  render() {
    return h(App)
  },
  modules: {
    applicationData,
    serviceData,
    modeledformData
  },
})
