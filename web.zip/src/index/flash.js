
const INDEX_FLASH_KEY = 'indexFlashMessage';

function setFlash(message) {
  sessionStorage.setItem(INDEX_FLASH_KEY, message);
}

function getFlash() {
  try {
    const message = sessionStorage.getItem(INDEX_FLASH_KEY);
    sessionStorage.removeItem(INDEX_FLASH_KEY);
    return message || '';
  } catch (e) {
    return '';
  }
}

export {setFlash, getFlash};

