<template>
  <div id="app">
    <login/>
  </div>
</template>

<script>
  import 'bootstrap/dist/css/bootstrap.css'
  import 'bootstrap/dist/css/bootstrap-theme.css'
  import 'promise-polyfill/src/polyfill'
  import 'abortcontroller-polyfill'
  import 'whatwg-fetch'
  import Login from './components/Login.vue'

  export default {
    name: 'app',
    components: {
      Login
    }
  }
</script>

<style>
  @import url('https://fonts.googleapis.com/css?family=Fira+Mono|Fira+Sans&display=swap');

  html, body, #app {
    width: 100%;
    height: 100%;
    display: flex;
    flex: 1;
    flex-direction: column;
  }

  body {
    font-family: "Fira Sans", sans-serif;
  }
</style>
