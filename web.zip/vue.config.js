const { VuetifyPlugin } = require('webpack-plugin-vuetify')
module.exports = {
  chainWebpack: (config) => {
    config.resolve.alias.set('vue', '@vue/compat')

    config.module
      .rule('vue')
      .use('vue-loader')
      .tap((options) => {
        return {
          ...options,
          compilerOptions: {
            compatConfig: {
              MODE: 2,
              WATCH_ARRAY: false
            }
          }
        }
      })
  },
  pages: {
    index: 'src/index/main.js',
    dashboard: 'src/dashboard/main.js',
    editor: 'src/editor/main.js',
    menu: 'src/menu/main.js',
    logviewer: 'src/logviewer/main.js',
    refdataviewer: 'src/refdataviewer/main.js',
    appconfig: 'src/appconfig/main.js'
  },
  configureWebpack: {
    devtool: 'source-map',
    plugins: [
      new VuetifyPlugin({ autoImport: true }), // Enabled by default
    ]
  },
  devServer: {
    proxy: {
      '/api/*': {
        target: 'http://localhost:8082/',
        changeOrigin: true,
        pathRewrite: {
          '^/api': ''
        }
      }
    }
  },
};