/**
 * ! Constant file for handling all URLS
 * ! Try to follow this naming convention:
 *
 * ! API_FUNCTION_DESCRIPTION: {
 * !    GET:
 * !    POST:
 * !    PUT:
 * !    DELETE:
 * ! }
 */
export const Urls = {
  /** This can be removed */
  IFILING_SERVICES: '/ifiling',
  COMMON_SERVICES: '/PTABE2ECommonServices',
  TRIAL_SERVICES: '/PTABTrialsServices',
  CASEVIEWER_SERVICES: '/PTABCaseViewer',
  EXTERNAL_SERVICES: '/ptacts',
  ENVIRONMENTS: {
    // SIT: 'https://ptab-q121-trial-services-wildfly-0.sit.uspto.gov:8443',
    SIT: 'https://ptacts-q321-intservices-wildfly-1.sit.uspto.gov:8443',
    // PVT: 'https://ptacts-intservices.pvt.uspto.gov',
    // PVT: 'https://ptacts-pvt.etc.uspto.gov',
    PVT: 'https://ptacts-extservices.pvt.uspto.gov',
  },
  PUBLIC_CASESEARCH: '/public-informations/case-search-intf?',
  CASESEARCH: '/prcdng-invention-disclosure/case-search-intf?',
  REFERENCE_TYPES: '/references?typeCode=',
  COUNTRIES: '/geo-region/get-countriesinfo/TRAILS',
  CLAIMS_UPLOAD: '/pcdng-claims',
  CLAIMS_GET: '/petition-claims',
  OPSG_GENERAL: '/opsg-application-general-information/v1',
  OPSG_GENERAL_NEW: '/opsg-application-general-information',
  PAPER_TYPES: '/references/proceeding-number/interference?typeCode=INTF',
  DECISION_OUTCOME: 'decisionOutcomeTypes',
  PARTY_REPRESENTING: '/external-user/prcdingparty-group-type?proceedingNo=',
  USERS: {
    GET: 'http://localhost:3000/login',
  },
  PETITIONS: '/petitions?proceedingNumberText=',
  DOCUMENTS: {
    GET: '/proceeding-artifacts?proceedingNumber=',
    PUBLIC_GET: '/public-informations/proceeding-artifacts?proceedingNumber=',
    SAVE_TO_CMS: '/proceeding-artifacts/external-documents',
    EDIT: '/proceeding-artifacts/',
    DELETE: '/proceeding-artifacts/external-documents/',
    NEXT_EXHIBIT_NO: '/proceeding-artifacts/sequences?proceedingNumber=',
    ALL_EXHIBIT_NOS:
      '/proceeding-party-details/exhibit-sequences?proceedingNumber=',
    PAPER_TYPES: '/references/document-type?documentTypeCd=',
    DOWNLOAD_EXCEL:
      '/proceeding-artifacts/exportpaperexhibits-excel?proceedingNumber=',
    DOWNLOAD_EWF: '/artifacts/downloadMergedPdfFile',
    UNSUBMITTEDGET:
      '/proceeding-artifacts/initiate-petitions?proceedingNumber=',
    submitDocuments: '/trials/proceeding/submitproceeding',
    PAPER_TYPE_BY_ID: '/references?typeCode=documentTypes&identifiers=',
    OTHER_DOCUMENTS:
      '/references/proceeding-number?typeCode=documentTypes&proceedingNumber=',
  },
  CREATE_PETITION: '/petitions',
  REAL_PARTY: {
    ADD: '/proceeding-party-details',
    GET: '/proceeding-party-details?proceedingNumber=',
    DELETE: '/proceeding-party-details?proceedingNumber=',
  },
  COUNSEL: {
    ADD: '/proceeding-party-details?partyRepresentIndicator=',
    GET: '/proceeding-party-details?proceedingNumber=',
    UPDATE: '/proceeding-party-details',
    DELETE: '/proceeding-party-details?proceedingNumber=',
    SWAP: '/proceeding-party-details/switch-counsels?isLeadCounsel=',
    GET_STAFF: '/proceeding-staff-details?proceedingNumber=',
    ADD_STAFF: '/proceeding-staff-details',
    UPDATE_STAFF: '/proceeding-staff-details',
    DELETE_STAFF: '/proceeding-staff-details?proceedingNumber=',
  },
  CASEVIEWER: {
    HEADER: '/case-viewer/details?proceedingNo=',
    PUBLIC_HEADER: '/public-informations/details?proceedingNo=',
    CASE_STATUS: '/ptab-state-role?caseNumber=',
    SEARCH: '/case-viewer/caseNumber-search?caseNumber=',
    PUBLIC_SEARCH: '/public-informations/caseNumber-search?caseNumber=',
    APPLICATIONS: '/proceeding-party-details/intf/realparties?proceedingNumber=',
    PUBLIC_APPLICATIONS: '/public-informations/intf/realparties?proceedingNumber='
  },
  ATTORNEY: {
    GET: '/proceeding-party-details/counsels/TRAILS?registrationNumber=',
    ADD: '/proceeding-party-details',
  },
  MOTIONS: {
    SAVE_SUBMIT: '/trials/motions/create-motion',
    MOTIONS_ON_CASE: '/case-viewer/proceeding-number/motions?proceedingNumber=',
    UPDATE: '/trials/motions/updatepartymotion/',
  },
  REHEARINGS: {
    PER_CASE: '/case-viewer/proceeding-number/rehearings?proceedingNumber=',
    SAVE_SUBMIT: '/trials/rehearing-info/create-rehearing',
    UPDATE: '/trials/rehearing-info/updatepartyrehearing/',
  },
  NOTIFICATIONS: {
    EMAIL_CONTENT: '/notificationemail/',
  },
  NEXT_PAPER_NUM_URL: '/proceeding-artifacts/sequences?proceedingNumber=',
  //PAYMENTS: '/reviewInfo?postingReferenceText=',
  PAYMENTS: '/payments?proceedingNumber=',
  MANDATORY_NOTICE: {
    VERIFICATION: '/case-search',
  },
  ECFR_URL: '/reference-data/code-reference-types?typeCode=OPEN_ECFR',
  AHD_URL: '/reference-data/code-reference-types?typeCode=OPEN_AHD',
  HELP_LINK: '/code-reference-types?typeCode=HELP_LINKS',
  OKTA_LINK: '/code-reference-types?typeCode=OKTA_LINKS',
  PTACTS_VERSIONS: '/code-reference-types?typeCode=PTACTS_VERSIONS',
  MYUSPTO_LINK: '/code-reference-types?typeCode=MYUSPTO_LINK',
  // MYUSPTO: 'https://my-pvt.etc.uspto.gov/?vcRBWiUGf5XwO55FLcajp7Xgzymkn4yR=',
  FEE_CALCULATION: '/feeCalculations?proceedingNumber=',
  APPEALS: {
    SUBMIT: '/proceeding-appeal',
  },
  PUBLIC: '/public-informations',
};
