export const CONSTANTS = {
  /** This can be removed */
  APPLICATION_NUMBER: 'applicationNumber',
  PATENT_NUMBER: 'patentNumber',
  CSV: '.csv',
  PAPER_FILE_TYPES: 'application/pdf',
  EXHIBIT_FILE_TYPES: 'application/pdf,video/mp4,video/x-m4v,video/*',
  MANDATORY_COUNTRIES: ['US', 'CA', 'GB'],
  TRIAL_TYPES: ['IPR', 'PGR', 'CBM', 'DER'],
  DUPLICATE_DOCUMENT_ID: 201,
  MOTIONS: {
    MOTION: 'File a motion',
    OPPOSITION: 'File an opposition',
    REPLY: 'File a reply',
  },
  MOTION_TYPES: {
    MOTION: 'MOTION',
    OPPOSITION: 'OPPOSITION',
    REPLY: 'REPLY',
  },
  DOWNLOAD_TYPE: {
    PDF: '.pdf',
    EXCEL: '.xlsx',
  },
  AVAILABILITY_CODE: {
    PUBLIC: 'public',
  },
  TYPE_CODES: {
    DOCUMENT_TYPES: 'documentTypes',
    REHEARING_TYPES: 'rehearingTypes',
  },
  PARTIES: {
    PATENT_OWNER: 'PATENT OWNER',
    PETITIONER: 'PETITIONER',
  },
  DOCUMENT_TYPES: {
    MOTION: 'MOTION',
    REHEARING: 'REHEARING',
  },
  PAGINATION: {
    SIZES: ['25', '50', '75', '100', 'All'],
    DEFAULT: '25',
  },
  VALIDATIONS: {
    PHONE_FAX: '^!*([0-9-.()]!*){10,}$',
    EMAIL: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z0-9]{2,100}$',
  },
  NOTICE_OF_APPEAL_PAPER_TYPE_ID: 252,
  KEY_DATES: {
    FINAL_DECISION_DUE_DATE: {
      DESC: 'Final Decision Due Date',
      KEY: 'finalDecisionDueDate',
    },
    PRELIMINARY_RESPONSE: {
      DESC: 'Preliminary Response',
      KEY: 'preliminaryResponseDate',
    },
    PRELIMINARY_RESPONSE_DUE_DATE: {
      DESC: 'Preliminary Response Due Date',
      KEY: 'preliminaryResponseDueDate',
    },
    TERMINATION_DECISION: {
      DESC: 'Termination Decision',
      KEY: 'terminationDecisionDate',
    },
    DECISION_TO_INSTITUE: {
      DESC: 'Decision to Institute',
      KEY: 'decisionToInstituteDate',
    },
    DECISION_TO_INSTITUTE_DUE_DATE: {
      DESC: 'Decision to Institute Due Date',
      KEY: 'decisionToInstituteDueDate',
    },
    ACCORD_FILING_DATE: {
      DESC: 'Accorded Filing Date',
      KEY: 'accordFilingDate',
    },
    NOTICE_OF_ACCORD_FILING_DATE: {
      DESC: 'Notice of Accorded Filing Date',
      KEY: 'noticeOfAccordFilingDate',
    },
    FILING_DATE: {
      DESC: 'Filing Date',
      KEY: 'filingDate',
    },
  },
  EXPORT_NAMES: {
    ADVANCED_SEARCH: 'AIA Search Results',
  },
  ANONYMOUS_USER: 'anonymous',
  DOC_TYPE: {
    PAPER: 'paper',
    EXHIBIT: 'exhibit',
  },
  EXHIBIT_DOC_TYPE_CODE: 'EXBT',
  SESSION_TIMER: {
    WARN_AFTER: 1500000,
    WARNING_TIME: 300000,
  },
};
