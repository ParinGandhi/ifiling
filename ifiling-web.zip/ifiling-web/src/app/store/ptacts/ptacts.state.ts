/**
 * !The interface can be modified bu adding properties/objects to it.
 * !The same structure has to be present in the initializeState function below it.
 */

// import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';

export interface PtactsState {
  userDetails: {
    lastName: string;
    patronId: string;
    displayName: string;
    roles: any;
    userId: string;
    employeeNumber: any;
    firstName: string;
    emailAddress: string;
    ptabDefaultRefreshTime: number;
    employeeType: any;
    ptabReadOnlyUser: boolean;
    clientIP: any;
    middleName: any;
    passwordExpired: boolean;
    authLevel: any;
  };
  userId: string;
}

export const initializeState = (): PtactsState => {
  const savedState = JSON.parse(window.sessionStorage.getItem('state'));
  if (savedState) {
    const userDetails = savedState;
    return userDetails;
  } else {
    return {
      userDetails: {
        lastName: null,
        patronId: null,
        displayName: null,
        roles: null,
        userId: null,
        employeeNumber: null,
        firstName: null,
        emailAddress: null,
        ptabDefaultRefreshTime: null,
        employeeType: null,
        ptabReadOnlyUser: null,
        clientIP: null,
        middleName: null,
        passwordExpired: null,
        authLevel: null,
      },
      userId: null,
    };
  }
};
