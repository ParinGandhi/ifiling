import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs';
import { concatMap, map } from 'rxjs/operators';
// import { CaseViewerService } from 'src/app/components/features/case-viewer/case-viewer.service';
import { HomeService } from 'src/app/components/features/home/home.service';
// import { InitiatePetitionService } from 'src/app/components/features/initiate-petition/initiate-petition.service';
import { LoginService } from 'src/app/components/features/login/login.service';
import * as PtactsActions from 'src/app/store/ptacts/ptacts.actions';
declare let $: any;

@Injectable()
export class PtactsEffects {
  constructor(
    private actions: Actions,
    private homeService: HomeService,
    private loginService: LoginService,
    // private caseViewerService: CaseViewerService,
    // private initiatePetitionService: InitiatePetitionService,
    private router: Router
  ) {}

  getUserDetails$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getUserDetails),
      concatMap((_action) => {
        console.log("***** Inside", _action)
        return this.homeService.getLoggedInUserDetails().pipe(
          map((data: any) => {
            // $.sessionTimeoutWidget.staySignedIn();
            window.sessionStorage.setItem('userDetails', JSON.stringify(data));
            window.sessionStorage.setItem('userInfo', JSON.stringify(data));
            if (!location.href.includes('localhost')) {
              window.sessionStorage.setItem('email', data.emailAddress);
            }
            console.log("***** User data: ", data);
            return PtactsActions.setUserDetails({ payload: data });
          })
        );
      })
    );
  });

  getNonOKTAUserDetails$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getLoginDetailsForNonOKTA),
      concatMap((_action) => {
        const userName = window.sessionStorage.getItem('email');
        // const userName = _action.userName;
        return this.loginService.getUserInfo(userName).pipe(
          map((data: any) => {
            const userDetails = {
              lastName: data.lastName,
              patronId: null,
              displayName: null,
              roles: data.roles,
              userId: data.emailId,
              employeeNumber: null,
              firstName: data.firstName,
              emailAddress: data.emailId,
              ptabDefaultRefreshTime: data.ptabDefaultRefreshTime,
              employeeType: null,
              ptabReadOnlyUser: data.ptabReadOnlyUser,
              clientIP: null,
              middleName: null,
              passwordExpired: null,
              authLevel: null,
            };
            this.router.navigate(['/ui/my-docket']);
            window.sessionStorage.setItem('state', JSON.stringify(userDetails));
            window.sessionStorage.setItem(
              'userInfo',
              JSON.stringify(userDetails)
            );
            window.sessionStorage.setItem(
              'userDetails',
              JSON.stringify(userDetails)
            );
            return PtactsActions.setUserDetails({ payload: userDetails });
          })
        );
      })
    );
  });

  // getPartyRepresenting$: Observable<Action> = createEffect(() => {
  //   return this.actions.pipe(
  //     ofType(PtactsActions.getPartyRepresenting),
  //     concatMap((_action) => {
  //       return this.caseViewerService
  //         .getPartyRepresenting(_action.proceedingNo)
  //         .pipe(
  //           map((partyRepresenting: string) => {
  //             let pr = partyRepresenting;
  //             if (partyRepresenting.toLowerCase() === 'patentowner') {
  //               pr = 'PATENT OWNER';
  //             }
  //             window.sessionStorage.setItem('partyRepresenting', pr);
  //             return PtactsActions.setPartyRepresenting({
  //               partyRepresenting: pr,
  //             });
  //           })
  //         );
  //     })
  //   );
  // });

  // getPetitionIdentifier$: Observable<Action> = createEffect(() => {
  //   return this.actions.pipe(
  //     ofType(PtactsActions.getPetitionIdentifier),
  //     concatMap((_action) => {
  //       return this.initiatePetitionService
  //         .getCaseInfoByProceedingNo(_action.proceedingNo)
  //         .pipe(
  //           map((caseInfoByProceedingResponse) => {
  //             const petitionIdentifier =
  //               caseInfoByProceedingResponse.petitionIdentifier;
  //             return PtactsActions.setPetitionIdentifier({
  //               petitionIdentifier: petitionIdentifier,
  //             });
  //           })
  //         );
  //     })
  //   );
  // });

  // setStateInfo$ = createEffect(() => {
  //     this.actions$.pipe(
  //         ofType(PtactsActions.setUserIdAction),
  //         concatMap(_action => {
  //             window.sessionStorage.setItem('state', JSON.stringify(_action))
  //             return void;
  //         })
  //     )
  // })
}
