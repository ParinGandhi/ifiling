export class columnDetails {
    name: string;
    displayName: string;
    field: string;
    headerTooltip?: string;
    cellTooltip?: true;
    width: number;
    type: string;
    allowCellFocus?: false;
    searchText?: string;
}
export class tableOptions {

    columnDefs: Array<columnDetails>;
    data: any;
    tableId: string;
    tableHeaderClass: string;
    tableBodyClass: string;
    isCellfilterNeeded:boolean;
}