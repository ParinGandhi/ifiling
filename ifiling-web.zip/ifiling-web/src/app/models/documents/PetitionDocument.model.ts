export class PetitionDocument {
  category: string = null;
  exhibitNumber: any = null;
  sequenceNumber: any = null;
  name: string = null;
  fileName: string = null;
  filingParty: string = null;
  availability: string = null;
  documentTypeIdentifier: number = null;
  documentTypeCode: string = null;
  docUploadedByText: string = null;
  mimeType: string = null;
  submitDocumentIndicator?: string = null;
  documentTypeCustomAttributes?: any = null;

  constructor(
    category,
    name,
    fileName,
    filingParty,
    availability,
    documentTypeIdentifier,
    documentTypeCode,
    docUploadedByText,
    mimeType,
    exhibitNumber,
    submitDocumentIndicator,
    documentTypeCustomAttributes
  ) {
    this.category = category;
    this.name = name;
    this.fileName = fileName;
    this.filingParty = filingParty;
    this.availability = availability;
    this.documentTypeIdentifier = documentTypeIdentifier;
    this.documentTypeCode = documentTypeCode;
    this.docUploadedByText = docUploadedByText;
    this.mimeType = mimeType;
    this.exhibitNumber = exhibitNumber;
    this.submitDocumentIndicator = submitDocumentIndicator;
    this.documentTypeCustomAttributes = documentTypeCustomAttributes;
  }
}
