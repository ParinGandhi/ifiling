import { Audit } from '../common/Audit.model';

export class EditDocument {
  artifactIdentifer: number = null;
  audit: Audit = new Audit();
  availability: string = null;
  category: string = null;
  contentManagementId: string = null;
  documentTypeIdentifier: number = null;
  fileSize: number = null;
  filingDate: number = null;
  filingParty: string = null;
  name: string = null;
  proceedingNumberText: string = null;
  ptabDefaultRefreshTime: number = null;
  ptabReadOnlyUser: boolean = false;
  textExtractionIndicator: string = null;
  exhibitNumber: string = null;

  constructor(docToEdit) {
   
    this.artifactIdentifer = docToEdit.artifactIdentifer;
    this.availability = docToEdit.availability;
    this.category = docToEdit.category;
    this.contentManagementId = docToEdit.contentManagementId;
    this.documentTypeIdentifier = docToEdit.documentTypeIdentifier;
    this.exhibitNumber = docToEdit.exhibitNumber;
    this.fileSize = docToEdit.fileSize;
    this.filingDate = docToEdit.filingDate;
    this.filingParty = docToEdit.filingParty;
    this.name = docToEdit.documentName;
    this.proceedingNumberText = docToEdit.proceedingNumberText;
  }

  //   constructor(artifactIdentifier,
  //     availability,
  //     category,
  //     contentManagementId,
  //     documentTypeIdentifier,
  //     fileSize,
  //     filingDate,
  //     filingParty,
  //     name,
  //     proceedingNumberText
  //     ) {
  //    
  //     this.availability = documentToEdit.selectedAvailability.code;
  //     this.category = documentToEdit.docType.toUpperCase();
  //   }
}
