import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import jpViewModel from '../models/jpview.model';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import UserInfoModel from '../models/UserInfo.model';
import CaseHeaderModel from '../models/cases/CaseHeader.model';
// import { claimUpload } from '../models/claims.model';
// import claimsListModal from '../models/cases/claimsDetails.model';




@Injectable({
  providedIn: 'root'
})
export class JpViewService {

  getHeaders(addResponseType) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': userName.loginId,
        // 'Access-Control-Allow-Credentials':  'true'
        // 'user-loginid': userName.loginId
      }),
      withCredentials: true,
      crossDomain: true
    };
    if (addResponseType) {
      httpOptions.headers.set('responseType', 'arraybuffer')
    }
    return httpOptions;
  }


  getDownloadHeaders(docsToDownload) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': userName.loginId
      }),
      withCredentials: true,
      crossDomain: true,
      body: docsToDownload,
      responseType: 'arraybuffer'
    };
    return httpOptions;
  }



  getTrialsHeaders(addResponseType) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-loginid': userName.loginId
      }),
      withCredentials: true,
      crossDomain: true
    };
    if (addResponseType) {
      httpOptions.headers.set('responseType', 'arraybuffer')
    }
    return httpOptions;
  }

  // private APPEALS_BASE: string = window.location.hostname === 'localhost' ? 'http://localhost:8082' : 'https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices';
  private APPEALS_BASE: string = 'https://ptabe2eint-fqt.etc.uspto.gov';

  // private COMMON_SERVICES_BASE_DEV;
  private COMMON_SERVICES_BASE_PVT = "https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABE2ECommonServices";


  // private hostname: string = window.location.hostname === 'localhost' ? 'ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443' : window.location.host;

  private ApiURL: string = "https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443/PTABCaseViewer";
  private TrialsApiURL: string = "https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443/PTABTrialsServices"
  // "https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABTrialsServices";

  private protocol: string = window.location.hostname === 'localhost' ? 'https:' : window.location.protocol + '//';
  // private hostname: string = window.location.hostname === 'localhost' ? 'ptab-trial-services.pvt.uspto.gov' : window.location.host;
  private hostname: string = window.location.hostname === 'localhost' ? 'ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443' : window.location.host;
  private uiUrl: string = window.location.hostname === 'localhost' ? 'ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443' : window.location.host;


  //! Change this for local
  // private BASE_API_URL: string = `${this.protocol}//${this.hostname}`;
  // private BASE_API_URL: string = `https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443`;
  private BASE_API_URL: string = `https://ptab-trial-services.pvt.uspto.gov`;
  private BASE_UI_URL: string = `${this.protocol}//${this.uiUrl}`

  /** TEMPORARY - REMOVE WHEN DEPLOYED TO PVT */
  private PARTIES_API: string = `https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443`;

  // private ApiURL: string = this.protocol + this.hostname;
  constructor(private httpclient: HttpClient) { }

//! Not used anywhere in code
  // getPdf(url: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.COMMON_SERVICES_URL}`+ url );
  // }

  // getJpView(urlSuffix: string): Observable<jpViewModel> {
  //   return this.httpclient.get<jpViewModel>('./assets/jpview.json');
  // }

  // getExhibits(url: string): Observable<any> {
  //   return this.httpclient.get<any>('./assets/exhibits.json');
  // }

  // getPapers(url: string): Observable<any> {
  //   return this.httpclient.get<any>('./assets/papers.json');
  // }

  //! Moved to Trials Service
  // getClaims(url: string): Observable<any> {
  //   return this.httpclient.get<any>(this.TrialsApiURL + url);
  // }

  //! Moved to Caseviewer Service
  // TODO - Create caseViewer service and environment files
  // getPayments(url: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.BASE_URL}` + url);
  // }

  //! Moved to Trials Service
  // getCounselInfo(url: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url);
  //   // return this.httpclient.get<any>("http://localhost:8081" + url);
  // }

  // getOpenCases(url: string): Observable<jpViewModel> {
  //   return this.httpclient.get<jpViewModel>(this.ApiURL + url)
  // };

  // getClosedCases(url: string): Observable<jpViewModel> {
  //   return this.httpclient.get<jpViewModel>(this.ApiURL + url)
  // };

  //! Moved to CaseViewer Service
    // TODO - Create caseViewer service and environment files
  // getUserInfo(url: string): Observable<UserInfoModel> {
  //   // return this.httpclient.get<UserInfoModel>(this.ApiURL + url);
  //   return this.httpclient.get<UserInfoModel>(`${this.BASE_API_URL}` + url);
  // }

  //! Moved to CaseViewer Service
  // TODO - Create caseViewer service and environment files
  // whoAmI(): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.CASE_VIEWER_URL}${PtabTrialConstants.WHO_AM_I}`);
  // }

  //! Moved to CaseViewer Service
  // TODO - Create caseViewer service and environment files
  // getOpenPalm(): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.CASE_VIEWER_URL}${PtabTrialConstants.PALM_URL}`);
  // }

  //! Moved to Trial Services
  //! Moved to CaseViewer Service and renamed to caseSearch
  // TODO - Create caseViewer service and environment files
  // getDocuments(url: string): Observable<any> {
  //   // return this.httpclient.get<any>('./assets/' + url + '.json');
  //   // return this.httpclient.get<any>(this.ApiURL + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  //   // return this.httpclient.get<any>(url);
  // }

  // getCaseDetails(url: string): Observable<any> {
  //   // return this.httpclient.get<any>('./assets/' + url + '.json');
  //   return this.httpclient.get<any>(this.ApiURL + url);
  // }

 getCaseHeader(url: string): Observable<CaseHeaderModel> {
    return this.httpclient.get<CaseHeaderModel>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url);
  }

  // downloadDocuments(url: string, docsToDownload: any): Observable<any> {
  //   return this.httpclient.post<any>(this.ApiURL + url, docsToDownload)
  // }
  // uploadDocuments(url:string,uploadObjectList:Array<DocumentUpload>){
  //   return this.httpclient.post<any>('http://localhost:8083' + url, uploadObjectList)
  // }


//! Moved to Common Service
  // uploadDocuments(url: string, fileToUpload: any) {
  //   console.log(fileToUpload);
  //   const formData: FormData = new FormData();
  //   // formData.append('file', new Blob([fileToUpload]))
  //   formData.append('file', fileToUpload)
  //   return this.httpclient.post<any>(this.BASE_API_URL + url, formData);
  // }





  // getReferenceData(url: string): Observable<any> {
  //   return this.httpclient.get<any>(this.ApiURL + url);
  // }

  // TODO - Need to create appeals service and environment files
  getAppealsCaseData(url: string): Observable<any> {
    // return this.httpclient.get<any>("http://localhost:8082" + url, this.getHeaders(false));
    // return this.httpclient.get<any>("https://ptabe2eint-fqt.etc.uspto.gov" + url);
    return this.httpclient.get<any>(this.APPEALS_BASE + url);
  }

  // TODO - Need to create appeals service and environment files
  getBibData(url: string): Observable<any> {
    // return this.httpclient.get<any>("http://localhost:8082" + url, this.getHeaders(false));
    // return this.httpclient.get<any>("https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices" + url);
    return this.httpclient.get<any>(this.APPEALS_BASE + url);
  }

  // TODO - Need to create appeals service and environment files
  getCaseNotes(url: string): Observable<any> {
    // return this.httpclient.get<any>("http://localhost:8082" + url, this.getHeaders(false));
    // return this.httpclient.get<any>("https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices" + url);
    return this.httpclient.get<any>(this.APPEALS_BASE + url);
  }

  // TODO - Need to create appeals service and environment files
  getCaseComments(url: string): Observable<any> {
    // return this.httpclient.get<any>("http://localhost:8082" + url, this.getHeaders(false));
    // return this.httpclient.get<any>("https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices" + url);
    return this.httpclient.get<any>(this.APPEALS_BASE + url);
  }

  //! Already in Trial Services
  // getMilestoneData(url: string): Observable<any> {
  //   // return this.httpclient.get<any>("http://localhost:8082" + url, this.getHeaders(false));
  //   // return this.httpclient.get<any>("https://ptabe2eint-fqt.etc.uspto.gov/PTABAppealsServices" + url);
  //   return this.httpclient.get<any>(this.APPEALS_BASE + url);
  // }

  // TODO - Need to create appeals service and environment files
  getAppeals(url: string): Observable<any> {
    return this.httpclient.get<any>(this.APPEALS_BASE + url);
  }

  //! Moved to Common Service as getPaperTypes
  // getDropDownList(url: string): Observable<any> {
  //   // return this.httpclient.get<any>(this.BASE_API_URL + url);
  //   // return this.httpclient.get<any>("https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443" + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }

//! Moved to Common Service
  // getCaseInfoByProceedingNo(url: string): Observable<any> {
  //   // return this.httpclient.get<any>(this.COMMON_SERVICES_BASE_PVT + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }

  // deleteDocument(url: string, docToDelete: any): Observable<any> {
  //   const options = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json'
  //     }),
  //     body: docToDelete
  //   }
  //   return this.httpclient.delete<any>(this.BASE_API_URL + url, options);
  // }

  // getPDF(url: string): Observable<any> {
  //   // return this.httpclient.get<any>(this.COMMON_SERVICES_BASE_PVT + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }

  //! Moved to Trials
  // getTrialsInfo(url: string): Observable<any> {
  //   // return this.httpclient.get<any>('https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443' + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }

  //! Moved to Common Services as getFromCodeReference
  // getMimeTypes(url: string): Observable<any> {
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }

  //! Moved to Trials Services
  // saveToDocket(url: string, docsToSave: any): Observable<any> {
  //   return this.httpclient.post<any>(this.BASE_API_URL + url, docsToSave, this.getTrialsHeaders(false));
  //   // return this.httpclient.post<any>('https://ptab-q121-trial-services-wildfly-0.dev.uspto.gov:8443' + url, docsToSave, this.getTrialsHeaders(false));
  //   // return this.httpclient.post<any>(url, docsToSave)
  // }

  // TODO - Need to create appeals service and environment files
  downloadZip(url: string, docsToDownload: any): Observable<any> {
    // return this.httpclient.post<any>(this.APPEALS_BASE + url, docsToDownload, this.getHeaders(true));
    let header = {'Content-Type': 'application/json', 'user-name': 'sbartlett'}
    return this.httpclient.post<any>(this.APPEALS_BASE + url, docsToDownload, {headers: header, responseType: 'arraybuffer' as 'json', withCredentials: true});
  }

  // getDocumentsForUpdate(url: string): Observable<any> {
  //   // return this.httpclient.get<any>(`http://localhost:8081` + url);
  //   return this.httpclient.get<any>(this.BASE_API_URL + url);
  // }


  // expungeDocument(url: string, docToExpunge: any): Observable<any> {
  //   // return this.httpclient.put<any>(`http://localhost:8081` + url, docToExpunge, this.getHeaders(false));
  //   return this.httpclient.put<any>(this.BASE_API_URL + url, docToExpunge, this.getHeaders(false));
  // }

  /**
   * Add counsel
   */

  //! Moved to Trial Services
  // findCounsel(url: string): Observable<any> {
  //   return this.httpclient.get(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url);
  //   // return this.httpclient.get("http://localhost:8081" + url);
  // }

  //! Moved to Trial Services
  // getStates(url: string): Observable<any> {
  //   return this.httpclient.get(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url);
  //   // return this.httpclient.get(`http://localhost:8081` + url);
  // }

//! Moved to Trial Services
  // getCountries(url: string): Observable<any> {
  //   return this.httpclient.get(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url);
  //   // return this.httpclient.get(`http://localhost:8081` + url);
  // }

  //! Moved to Trial Services
  // getGround(url: string): Observable<any> {
  //   return this.httpclient.get(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, this.getHeaders(false));
  // }

  //! Moved to Trial Services
  // uploadClaims(url: string, claimUpload:any ): Observable<any> {
  //   return this.httpclient.post<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, claimUpload, this.getHeaders(false));
  // }

  //! Moved to Trial Services
  // editClaims(url: string, claimUpload:any ): Observable<any> {
  //   return this.httpclient.put<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, claimUpload, this.getHeaders(false));
  // }

  //! Moved to Trial Services
  // uploadRealParty(url: string, realPartyUpload:any): Observable<any> {
  //   return this.httpclient.post<any>(this.BASE_API_URL + url, realPartyUpload, this.getHeaders(false));
  //   // return this.httpclient.post<any>("http://localhost:8081" + url, realPartyUpload, this.getHeaders(false));
  // }

  //! Moved to Trial Services
  // deleteClaim(url: string) {
  //   return this.httpclient.delete<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, this.getHeaders(false));
  // }

  //! Not used anywhere in code
  // deleteParty(url: string) {
  //   // return this.httpclient.delete<any>("http://localhost:8081"+ url, this.getHeaders(false));
  //   return this.httpclient.delete<any>(this.BASE_API_URL + url, this.getHeaders(false));
  // }

  //! Moved to Trial Service as updateRealParty
  // updatePartyInfo(url:string,updateParty:any): Observable<any> {
  //   // return this.httpclient.put<any>("http://localhost:8081"+ url, updateParty, this.getHeaders(false));
  //   return this.httpclient.put<any>(this.BASE_API_URL + url, updateParty, this.getHeaders(false));
  // }

  //! Moved to Trial Service
  // // Adding
  // addCounsel(url: string, counselToAdd: any): Observable<any> {
  //   // return this.httpclient.post<any>(url, counselToAdd, this.getHeaders(false));
  //   return this.httpclient.post<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, counselToAdd, this.getHeaders(false));
  //   // return this.httpclient.post<any>(`http://localhost:8081` + url, counselToAdd, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // updateCounsel(url: string, counselToUpdate: any): Observable<any> {
  //   return this.httpclient.put<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, counselToUpdate, this.getHeaders(false));
  //   // return this.httpclient.put<any>(`http://localhost:8081` + url, counselToUpdate, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // deleteCounsel(url: string): Observable<any> {
  //   return this.httpclient.delete<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, this.getHeaders(false));
  //   // return this.httpclient.delete<any>("http://localhost:8081" + url, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // switchCounsel(url: string, counseltoSwitch: any): Observable<any> {
  //   return this.httpclient.put<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, counseltoSwitch, this.getHeaders(false));
  //   // return this.httpclient.put<any>(`http://localhost:8081` + url, counseltoSwitch, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // getWorkQueue(url: string, filterData: any): Observable<any> {
  //   // return this.httpclient.post<any>(`${this.BASE_API_URL}`+`/PTABE2EServices` + url, filterData, this.getHeaders(false))

  //   // return this.httpclient.get<any>('./assets/test_data/workqueue.json');
  //   return this.httpclient.post<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, filterData, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // markCompleteWorkQueue(url: string, dataObj: any): Observable<any> {
  //   return this.httpclient.put<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` + url, dataObj, this.getHeaders(false));
  // }

  //! Not used anywhere in code
// openCV(url: string){
//  window.open(`${this.BASE_API_URL}${PtabTrialConstants.CASE_VIEWER_URL}` + url);
//   }

  //! Moved to Trials Service
  // getAssignToList(url: string): Observable<any> {
  //   return this.httpclient.get<any>(`${this.BASE_API_URL}${PtabTrialConstants.TRIAL_SERVICES_URL}` +url, this.getHeaders(false));
  // }

  //! Moved to Trials Service
  // reassignTasks(url: string, tasksToReassign: any): Observable<any> {
  //   return this.httpclient.put<any>(url, tasksToReassign, this.getHeaders(false));
  // }

}