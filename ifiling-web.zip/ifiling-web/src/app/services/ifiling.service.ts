import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Urls } from '../constants/urls';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import CaseHeaderModel from '../models/cases/CaseHeader.model';

@Injectable({
  providedIn: 'root',
})
export class IfilingService {
  private IFILING_BASE_URL = environment.IFILING_SERVICE_API;

  // getHeaders() {
  // let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
  // let httpOptions = null;
  // if (userName && userName.loginId) {
  //   httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'user-name': userName.loginId,
  //     }),
  //     withCredentials: true,
  //     crossDomain: true,
  //   };
  // } else {
  //   httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //     }),
  //     withCredentials: true,
  //     crossDomain: true,
  //   };
  // }
  // if (addResponseType) {
  //   httpOptions.headers.set('responseType', 'arraybuffer' as 'json');
  // }
  // return httpOptions;
  // }

  constructor(private httpclient: HttpClient) {}

  getCaseHeaderInfo(proceedingNo: string): Observable<any> {
    const userName = window.sessionStorage.getItem('email')
    const from = window.sessionStorage.getItem('from')
    let url = null;
    if (!userName || userName === 'anonymous' || from === 'public') {
      url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.PUBLIC_HEADER}${proceedingNo}`;
    } else {
    url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.HEADER}${proceedingNo}`;
    }

    return this.httpclient.get<any>(url);
  }

  getApplications(proceedingNo: string) {
    const userName = window.sessionStorage.getItem('email')
    const from = window.sessionStorage.getItem('from')
    let url = null;
    if (!userName || userName === 'anonymous' || from === 'public') {
      url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.PUBLIC_APPLICATIONS}${proceedingNo}`;
    } else {
    url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.APPLICATIONS}${proceedingNo}`;
    }

    return this.httpclient.get(url);
  }

  getDocumentsForUpdate(proceedingNo: string): Observable<any> {
    const userName = window.sessionStorage.getItem('email')
    const from = window.sessionStorage.getItem('from')
    let url = null;
    if (!userName || userName === 'anonymous' || from === 'public') {
      url = `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.PUBLIC_GET}${proceedingNo}`;
    } else {
    url = `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.GET}${proceedingNo}`;
    }

    return this.httpclient.get<any>(url);
  }

  addToList(fileToUpload: any, category: string, petitionIdentifier: string) {
    const formData: FormData = new FormData();
    formData.append('file', fileToUpload);
    formData.set('category', category);
    return this.httpclient
      .post<any>(
        `${this.IFILING_BASE_URL}/petitions/${petitionIdentifier}/documents`,
        formData
      )
      .pipe(
        map(
          (documentData) => {
            return documentData;
          }
        )
      );
  }

  deleteDocument(artifactID: number) {
    return this.httpclient
      .delete<any>(
        `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.DELETE}${artifactID}`
      )
      .pipe(
        map((deleteDocumentResponse) => {
          return deleteDocumentResponse;
        })
      );
  }

  // saveToCMS(petitionDocument: DocumentToAdd): Observable<any> {
  //   return this.httpclient
  //     .post<any>(
  //       `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.SAVE_TO_CMS}`,
  //       petitionDocument
  //     )
  //     .pipe(
  //       map((savedDocument) => {
  //         return savedDocument;
  //       })
  //     );
  // }

  submitDocuments(documentsToUpload: any): Observable<any> {
    return this.httpclient
      .post<any>(
        `${this.IFILING_BASE_URL}/proceeding-artifacts`,
        documentsToUpload
      )
      .pipe(
        map((documentsResponse) => {
          return documentsResponse;
        })
      );
  }

  getNextPaperNumber(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.NEXT_EXHIBIT_NO}${proceedingNo}`
    );
  }

  getAttorneyByNumber(registrationNumber: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.IFILING_BASE_URL}${Urls.ATTORNEY.GET}${registrationNumber}`
    );
  }

  addAttorney(attorney) {
    return this.httpclient.post<any>(
      `${this.IFILING_BASE_URL}${Urls.ATTORNEY.ADD}`,
      attorney
    );
  }

  getDocumentPaperTypes(): Observable<any> {
    return this.httpclient
    .get<any>(
      `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.PAPER_TYPES}INCOMING CORR`
    )
    .pipe(
      map((documentPaperTypesResponse) => {
        return documentPaperTypesResponse;
      })
    );
  }

  getAvailabilities(referenceType: string, isPublic: boolean) {
    return this.httpclient
      .get<any>(
        `${this.IFILING_BASE_URL}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((availabilities) => {
          return availabilities;
        })
      );
  }

  getNextExhibitNumber(proceedingNumber: string) {
    return this.httpclient
      .get<any>(
        `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.NEXT_EXHIBIT_NO}${proceedingNumber}`
      )
      .pipe(
        map((exhibitNumbers) => {
          return exhibitNumbers;
        })
      );
  }

  getAllExhibitNumbers(proceedingNumber) {
    return this.httpclient
      .get(
        `${this.IFILING_BASE_URL}${Urls.DOCUMENTS.ALL_EXHIBIT_NOS}${proceedingNumber}`
      )
      .pipe(
        map((allExhibitNumbers) => {
          return allExhibitNumbers;
        })
      );
  }

  getIfPartyOnCase(proceedingNumber) {
    return this.httpclient.get(`${this.IFILING_BASE_URL}/external-user/prcdingparty-group-type?proceedingNo=${proceedingNumber}`)
    .pipe(
      map((partyType) => {
        return partyType;
      })
    );
  }

}
