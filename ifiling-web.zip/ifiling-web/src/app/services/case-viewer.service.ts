import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';
import CaseHeaderModel from '../models/cases/CaseHeader.model';
import UserInfoModel from '../models/UserInfo.model';

@Injectable({
  providedIn: 'root',
})
export class CaseViewerService {
  private CASEVIEWER_BASE_URL = environment.CASEVIEWER_SERVICE_API;

  getHeaders(addResponseType) {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
        withCredentials: true,
        crossDomain: true,
      };
    }

    // if (userName && userName.loginId) {
    //   httpOptions.headers.set('user-name', userName.loginId);
    // }
    if (addResponseType) {
      httpOptions.headers.set('responseType', 'arraybuffer' as 'json');
    }
    return httpOptions;
  }

  constructor(private httpclient: HttpClient) {}

  getPayments(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.PAYMENTS}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  getUserInfo(userName: string): Observable<any> {
    return this.httpclient.get<UserInfoModel>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.USER_INFO}${userName}`,
      this.getHeaders(false)
    );
  }

  whoAmI(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.WHO_AM_I}`
    );
  }
  getCaseViewerUrl(typecode: string) {
    return this.httpclient.get<any>(
      this.CASEVIEWER_BASE_URL +
        '/reference-data/code-reference-types?typeCode=' +
        typecode,
      this.getHeaders(false)
    );
  }
  getOpenPalm(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.PALM_URL}`,
      this.getHeaders(false)
    );
  }

  getHelpUrl(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.HELP_URL}`,
      this.getHeaders(false)
    );
  }
  caseSearch(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.GENERAL.CASE_SEARCH}${proceedingNo}`,
      this.getHeaders(false)
    );
  }

  getAppealsUrl(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.APPEALS_URL}`
    );
  }

  getDocData(url): Observable<any> {
    return this.httpclient.get<any>(url);
  }

  getQuestionsList(url): Observable<any> {
    return this.httpclient.get<any>(url, this.getHeaders(false));
  }

  saveAnswers(url, data): Observable<any> {
    return this.httpclient.post<any>(url, data, this.getHeaders(false));
  }

  updateAnswers(url, data): Observable<any> {
    return this.httpclient.put<any>(url, data, this.getHeaders(false));
  }

  checkDocStatus(url): Observable<any> {
    return this.httpclient.get<any>(url, this.getHeaders(false));
  }

  getExternalUrls(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.EXTERNAL_URLS}`,
      this.getHeaders(false)
    );
  }

  getExternalUserDetails(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.CASEVIEWER_BASE_URL}${PtabTrialConstants.EXTERNAL_USER_DETAILS}`,
      this.getHeaders(false)
    );
  }
}
