import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PtabTrialConstants } from '../constants/ptab-trials.constants';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  /** Location variables */

  private port: string = '8081';

  /**
   * * LOCAL DEVELOPMENT
   * ? Uncomment below ONLY if you are running Common Services locally.
   * ? Otherwise use the appropriate environment commands
   * ? DEV - npm run start:dev
   * ? PVT - npm run start:pvt
   */
  // private COMMON_BASE_URL: string = `${PtabTrialConstants.ENVIRONMENTS.LOCAL}${port}`;
  private COMMON_BASE_URL: string = environment.COMMON_SERVICE_API;

  getFileUploadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          // 'Content-Type': "",
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          // 'Content-Type': "",
          // 'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
      };
    }

    return httpOptions;
  }

  constructor(private httpclient: HttpClient) {}

  /**
   * * CaseViewer - update documents modal */

  getReferenceData(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  openPdf(petitionerIdentifier, artifactIdentifer) {
    const userName = window.sessionStorage.getItem('email')
    let url = null;
    if (!userName || userName === 'anonymous') {
      url = `${environment.IFILING_SERVICE_API}/public-informations/petitions/${petitionerIdentifier}/download-documents?artifactId=${artifactIdentifer}`
    } else {
    url = `${environment.IFILING_SERVICE_API}/petitions/${petitionerIdentifier}/download-documents?artifactId=${artifactIdentifer}`
    }

    window.open(url);
  }

  openPdfFromMount(selectedFile, petitionerIdentifier) {
    // window.open(this.COMMON_BASE_URL + url);
    // window.open(
    //   `${this.COMMON_BASE_URL}/petitions/${petitionerIdentifier}/download-documents?artifactId=${artifactIdentifer}`
    // );
    return this.httpclient.get(
      `${environment.IFILING_SERVICE_API}/petitions/${petitionerIdentifier}/documents?fileName=${selectedFile.fileName}`,
      this.getDownloadHeaders()
    );
  }

  getDownloadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    let httpOptions = null;
    if (userName && userName.loginId) {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
        responseType: 'arraybuffer' as 'json',
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          // 'user-name': userName.loginId,
        }),
        withCredentials: true,
        crossDomain: true,
        responseType: 'arraybuffer' as 'json',
      };
    }
    return httpOptions;
  }

  getDecisionOutcomeTypes(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getNotificationsList(url: string): Observable<any> {
    // return this.httpclient.get<any>('https://ptab-q121-trial-intservices-wildfly-green-0.pvt.uspto.gov:8443/PTABE2ECommonServices'+ url);
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getDropDownList(refType: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.TYPE_CODE}${refType}`
    );
  }

  getAppealsStatuses(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getMotionStatusTypes(url: string): Observable<any> {
    return this.httpclient.get<any>(this.COMMON_BASE_URL + url);
  }

  getFromCodeReference(referenceType: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.TYPE_CODE}${referenceType}`
    );
  }

  getCaseInfoByProceedingNo(proceedingNo: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.PETITIONS}${proceedingNo}`
    );
  }

  getPaperTypes(proceedingNo: string, recipientType: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.PAPER_TYPE_BY_PROCEEDING_NO}${proceedingNo}${PtabTrialConstants.REFERENCE_TYPES.RECIPIENT_TYPE}${recipientType}`
    );
  }

  getInteferenceDocumentTypes(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.INTERFERENCE_DOCUMENT_TYPE}`
    );
  }

  uploadDocuments(url: string, fileToUpload: any) {
    // console.log(fileToUpload);
    const formData: FormData = new FormData();
    formData.append('file', fileToUpload);
    return this.httpclient.post<any>(
      `${this.COMMON_BASE_URL}${url}`,
      formData,
      this.getFileUploadHeaders()
    );
  }

  /** Notification preferences */
  getNotificationPreferences(userId: string): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.GET_NOTIFICATION_PREFERENCES}${userId}`
    );
  }

  saveNotificationPreferences(updatedNotifications: any): Observable<any> {
    return this.httpclient.post<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.SAVE_NOTIFICATION_PREFERENCES}`,
      updatedNotifications,
      this.getFileUploadHeaders()
    );
  }

  getAllMotionsList() {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}/references/documentTypes?isMotions=true`
    );
  }

  getAllRehearingsList() {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}/references/documentTypes?isRehearings=true`
    );
  }

  getInterferencePaperTypes(): Observable<any> {
    return this.httpclient.get<any>(
      `${this.COMMON_BASE_URL}${PtabTrialConstants.REFERENCE_TYPES.INTERFERENCE_PAPER_TYPES}`
    );
  }
}
