import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
// import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { take } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
// import { PublicAvailabilityModalComponent } from '../components/common/public-availability-modal/public-availability-modal.component';
// import { CaseViewerService } from '../components/features/case-viewer/case-viewer.service';
import { Urls } from '../constants/urls';
// import { AngularCsv } from 'angular-csv-ext/dist/Angular-csv';
// import { WarningModalComponent } from '../components/common/warning-modal/warning-modal.component';
// import jsPDF from 'jspdf';
// import html2canvas from 'html2canvas';
import { NGXLogger } from 'ngx-logger';
import { Validators } from '@angular/forms';
import { InterferenceService } from '../components/features/interference/interference.service';
// import { ViewDocumentsModalComponent } from '../components/features/advanced-search/view-documents-modal/view-documents-modal.component';
// import { EmailSubjectComponent } from '../components/features/my-docket/email-subject/email-subject.component';

@Injectable({
  providedIn: 'root',
})
export class CommonUtilitiesService {
  private EXTERNAL_SERVICE_BASE = environment.EXTERNAL_SERVICE_API;
  private IFILING_BASE_URL = environment.IFILING_SERVICE_API;
  confidentialityInfo: string;
  // private publicModalRef: BsModalRef;
  // private warningModalRef: BsModalRef;
  // private documentsModalRef: BsModalRef;
  // private emailModalRef: BsModalRef;

  constructor(
    private toastr: ToastrService,
    private datePipe: DatePipe,
    // private caseViewerService: CaseViewerService,
    // public modalService: BsModalService,
    private logger: NGXLogger,
    public interferenceService:InterferenceService
  ) {}

  generateRandomNumber() {
    return Math.floor(Math.random() * 100) + 1;
  }

  showError(message, title) {
    this.toastr.error(message, title, {
      timeOut: 9900,
      closeButton: true,
    });
  }

  showInfo(message, title) {
    this.toastr.info(message, title, {
      timeOut: 5500,
      closeButton: true,
    });
  }

  showWarning(message, title) {
    this.toastr.warning(message, title, {
      timeOut: 9500,
      closeButton: true,
    });
  }

  showSuccess(message, title) {
    this.toastr.success(message, title, {
      timeOut: 5500,
      closeButton: true,
    });
  }

  convertDateToString(epochDate) {
    if (!epochDate) {
      return '';
    }
    if (epochDate.toString().length > 10) {
      return this.datePipe.transform(
        parseInt(epochDate),
        'MM/dd/yyyy'
      );
    } else {
      return this.datePipe.transform(
        parseInt(epochDate) * 1000,
        'MM/dd/yyyy'
      );
    }
  }

  getCurrentDateString(dateType) {
    let dateFormat = dateType === 'date' ? 'MM/dd/yyyy' : 'MM/dd/yyyy hh:mm a';
    return this.datePipe.transform(new Date(), dateFormat);
  }

  convertStringToTitleCase(str) {
    if (!str) {
      return str;
    }
    return str
      .toLowerCase()
      .split(' ')
      .map((word) => {
        return word.charAt(0).toUpperCase() + word.slice(1);
      })
      .join(' ');
  }

  getLoggedInUser() {
    return window.sessionStorage.getItem('email');
  }

  openPdf(url: string) {
    window.open(this.EXTERNAL_SERVICE_BASE + url);
  }

  openInNewTab(url: string) {
    if(window.location.hostname === 'localhost'){
      window.open('/ui' +url,"_blank");
    }
    else{
      window.open(this.IFILING_BASE_URL + '/ui' +url,"_blank");
    }
  }

  openPdfNew(pdfResponse: ArrayBuffer) {
    //! Old
    //window.open(this.EXTERNAL_SERVICE_BASE + url);
    const blob = new Blob([pdfResponse], { type: 'application/pdf' });
    const link = window.URL.createObjectURL(blob);
    this.logger.info('Blob link: ', link);
    // window.open(link, '', 'height=650,width=840');
    const a = document.createElement('a');
    a.target = '_blank';
    a.href = link;
    a.click();

    //! New
    // //window.open(this.EXTERNAL_SERVICE_BASE + url);
    // const user = window.sessionStorage.getItem('email');
    // const blob = new Blob([pdfResponse], { type: 'application/pdf' });
    // const bloblink = window.URL.createObjectURL(blob);
    // const splitBlobLink = bloblink.split('/');
    // const blobLinkValue = splitBlobLink[splitBlobLink.length - 1];
    // // this.logger.info('Blob link: ', link);
    // // window.open(link, '', 'height=650,width=840');
    // let link = `blob:${window.location.protocol}//${window.location.host}${Urls.EXTERNAL_SERVICES}`;
    // if (user === 'anonymous' && !window.location.host.includes('localhost')) {
    //   link = `${link}${Urls.PUBLIC}/${blobLinkValue}`;
    //   const a = document.createElement('a');
    //   a.target = '_blank';
    //   a.href = link;
    //   a.click();
    // } else {
    //   const a = document.createElement('a');
    //   a.target = '_blank';
    //   a.href = bloblink;
    //   a.click();
    // }
  }

  openCaseViewerForPublic(proceedingNo, location = '_blank') {
    this.interferenceService
      .caseSearchPublic(proceedingNo)
      .pipe(take(1))
      .subscribe(
        (caseSearchInfo) => {
          if (caseSearchInfo.serialNumber && caseSearchInfo.serialNumber[0]) {
              let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
            newTabUrl +=
              window.location.port !== '' ? `:${window.location.port}` : '';
            newTabUrl +=
              window.location.hostname === 'localhost'
                ?
                  '/public-informations/case-viewer/' +
                  // caseSearchInfo.serialNumber[0].trim() +
                  // '/' +
                  caseSearchInfo.appealNumber[0].trim() 
                  // + tab
                : `${Urls.IFILING_SERVICES}` +
                  '/public-informations/case-viewer/' +
                  // caseSearchInfo.serialNumber[0].trim() +
                  // '/' +
                  caseSearchInfo.appealNumber[0].trim() 
                  // + tab;
                  window.sessionStorage.setItem('from', 'public');
            window.open(newTabUrl, location);
            window.sessionStorage.removeItem('from');
            
          } else {
            //this.showError('No serial number found for this case.', null);
          }
        },
        (caseViewerError) => {
          this.throwError(
            `Unable to open caseviewer for case# ${proceedingNo}`,
            caseViewerError
          );
        }
      );
  }

  openCaseViewerFromMyDocket(proceedingNo, location = '_blank') {
    this.interferenceService
      .caseSearch(proceedingNo)
      .pipe(take(1))
      .subscribe(
        (caseSearchInfo) => {
          if (caseSearchInfo.serialNumber && caseSearchInfo.serialNumber[0]) {
              let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
            newTabUrl +=
              window.location.port !== '' ? `:${window.location.port}` : '';
            newTabUrl +=
              window.location.hostname === 'localhost'
                ?
                  '/ui/case-viewer/' +
                  // caseSearchInfo.serialNumber[0].trim() +
                  // '/' +
                  caseSearchInfo.appealNumber[0].trim() 
                  // + tab
                : `${Urls.IFILING_SERVICES}` +
                  '/ui/case-viewer/' +
                  // caseSearchInfo.serialNumber[0].trim() +
                  // '/' +
                  caseSearchInfo.appealNumber[0].trim() 
                  // + tab;
            window.open(newTabUrl, location);
            
          } else {
            //this.showError('No serial number found for this case.', null);
          }
        },
        (caseViewerError) => {
          this.throwError(
            `Unable to open caseviewer for case# ${proceedingNo}`,
            caseViewerError
          );
        }
      );
  }

  setToastr(status, message) {
    this.toastr[status](`${message}`, '', {
      closeButton: true,
    });
  }

  copyToClipboard(stringToCopy, counselType) {
    let counsel = '';
    if (counselType) {
      counselType === 'petitionCounsel' ? 'Petitioner' : 'PO/Respondent';
    }
    if (stringToCopy) {
      const body = document.querySelector('body');
      const area = document.createElement('textarea');
      body.appendChild(area);
      area.value = stringToCopy;
      area.select();
      document.execCommand('copy');
      body.removeChild(area);
      //this.setToastr('success', `Copied all ${counsel} emails to clipboard`);
    } else {
      //this.setToastr('warning', 'No emails to copy');
    }
  }

  /** Set backdrop shadow for second modal */
  setSecondModalBackgroundColor() {
    let allElements = document.getElementsByClassName('second-modal');
    // let element = document.getElementsByClassName('second-modal')[0];
    // if (!element) {
    //   return;
    // }
    if (!allElements || allElements.length === 0) {
      return;
    }

    // document.getElementsByClassName(
    //   'second-modal'
    // )[0].parentElement.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    allElements[allElements.length - 1].parentElement.style.backgroundColor =
      'rgba(0, 0, 0, 0.5)';
  }

  // exportCSVFile(headers, dataToExport, fileName) {
  //   var options = {
  //     fieldSeparator: ',',
  //     quoteStrings: '"',
  //     decimalseparator: '.',
  //     showLabels: true,
  //     showTitle: false,
  //     title: 'Your title',
  //     useBom: true,
  //     noDownload: true,
  //     headers: headers,
  //     useHeader: false,
  //     nullToEmptyString: true,
  //   };
  //   const angcsv = new AngularCsv(dataToExport, fileName, options);

  //   const csv = angcsv.getCsvData();
  //   const exportedFilenmae = fileName + '.csv' || 'export.csv';
  //   const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  //   // if (navigator.msSaveBlob) { // IE 10+
  //   //     navigator.msSaveBlob(blob, exportedFilenmae);
  //   // } else {
  //   const link = document.createElement('a');
  //   if (link.download !== undefined) {
  //     // feature detection
  //     // Browsers that support HTML5 download attribute
  //     const url = URL.createObjectURL(blob);
  //     link.setAttribute('href', url);
  //     link.setAttribute('download', exportedFilenmae);
  //     link.style.visibility = 'hidden';
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //   }

  //   // if (headers) {
  //   //   dataToExport.unshift(headers);
  //   // }
  //   // const jsonObject = JSON.stringify(dataToExport);
  //   // const csv = this.convertToCSV(jsonObject);
  //   // const exportedFilenmae = fileName + '.csv' || 'export.csv';
  //   // const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  //   // // if (navigator.msSaveBlob) { // IE 10+
  //   // //     navigator.msSaveBlob(blob, exportedFilenmae);
  //   // // } else {
  //   // const link = document.createElement('a');
  //   // if (link.download !== undefined) {
  //   //   // feature detection
  //   //   // Browsers that support HTML5 download attribute
  //   //   const url = URL.createObjectURL(blob);
  //   //   link.setAttribute('href', url);
  //   //   link.setAttribute('download', exportedFilenmae);
  //   //   link.style.visibility = 'hidden';
  //   //   document.body.appendChild(link);
  //   //   link.click();
  //   //   document.body.removeChild(link);
  //   // }
  // }

  convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';
    for (var i = 0; i < array.length; i++) {
      var line = '';
      for (var index in array[i]) {
        if (line != '') line += ',';
        if (line.includes(',')) {
          let strLine = array[i][index];
          if (typeof strLine === 'string' && strLine.includes('"')) {
            line = `${line}'\"'${strLine}'\"'`;
          } else {
            line = `${line}"${strLine}"`;
          }
        } else {
          line += array[i][index];
        }
      }
      str += line + '\r\n';
    }
    return str;
  }

  sortAlphabetically(listToSort, propertyToSortBy) {
    listToSort.sort(function (a, b) {
      var nameA = a[propertyToSortBy].toUpperCase(); // ignore upper and lowercase
      var nameB = b[propertyToSortBy].toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }

      // names must be equal
      return 0;
    });
    return listToSort;
  }

  setTypeaheadOptions() {
    return {
      multiple: false,
      closeOnSelect: true,
      width: '100%',
      allowClear: true,
      theme: 'bootstrap',
      openOnEnter: true,
      // minimumResultsForSearch: Infinity - use to hide search box
    };
  }

  /**
   * Common function to return date string based on provided milestoneDate
   *
   * @param keyDates - milestoneDt string from service response
   * @param dateNeeded - name of date needed (names are in the constant file)
   * @returns - date string 'MM/dd/yyyy'
   */
  parseKeyDates(keyDates, dateNeeded) {
    let resp = null;
    if (keyDates) {
      const parsedKeyDates = JSON.parse(keyDates);
      if (parsedKeyDates && parsedKeyDates.proceedingMileStoneResponse) {
        const dateFound = parsedKeyDates.proceedingMileStoneResponse.find(
          (keyDate) => {
            return keyDate.mileStoneTypeName
              ? keyDate.mileStoneTypeName.toLowerCase() ===
                  dateNeeded.toLowerCase()
              : null;
          }
        );
        resp = dateFound
          ? this.datePipe.transform(
              new Date(dateFound.mileStoneDate).getTime() + 25200000,
              'MM/dd/yyyy'
            )
          : null;
        // if (dateFound) {
        //   const estDate = new Date(new Date(parseInt(dateFound.mileStoneDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
        //   resp = this.datePipe.transform(estDate, 'MM/dd/yyyy');
        // }
      } else if (parsedKeyDates && Array.isArray(parsedKeyDates)) {
        const dateFound = parsedKeyDates.find((keyDate) => {
          return keyDate.mileStoneTypeName
            ? keyDate.mileStoneTypeName.toLowerCase() ===
                dateNeeded.toLowerCase()
            : null;
        });
        // resp = dateFound ? this.datePipe.transform(new Date(dateFound.mileStoneDate).getTime(), 'MM/dd/yyyy hh:mm a') : null;
        resp = dateFound
          ? this.datePipe.transform(
              new Date(dateFound.mileStoneDate).getTime() + 25200000,
              'MM/dd/yyyy'
            )
          : null;
        // if (dateFound) {
        //   const estDate = new Date(new Date(parseInt(dateFound.mileStoneDate)).toLocaleString('en-US', { timeZone: 'America/New_York' })).getTime();
        //   resp = this.datePipe.transform(estDate, 'MM/dd/yyyy');
        // }
      }
    }
    return resp;
  }

  setDateOnDatePicker(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  convertDatePickerToDisplayDate(datePickerDate) {
    // const newDate = new Date(datePickerDate);
    return this.datePipe.transform(datePickerDate, 'MM/dd/yyyy');
  }
  /**
   * This will convert the date picker date from 'yyyy-MM-dd' format to 13 digit epoch time.
   * This will set the time to 00:00 to compensate for timezone differences.
   *
   * @param datePickerDate : string - in the form of 'yyyy-MM-dd'
   */
  convertDatePickerToEpoch(datePickerDate) {
    return Date.parse(`${datePickerDate}T00:00`);
  }

  parseAllPartiesInfo(allPartiesInfo) {
    // return allPartiesInfo ? JSON.parse(allPartiesInfo) : null;
    if (allPartiesInfo) {
      try {
        return JSON.parse(allPartiesInfo);
      } catch (e) {
        // console.error(e);
        return null;
      }
    } else {
      return null;
    }
  }

  findDecisionOutcome(decisionOutcome) {
    let resp = null;
    if (decisionOutcome) {
      let decisionOutcomeFound = null;
      const parsedDecisionOutcomes = JSON.parse(decisionOutcome);
      if (
        parsedDecisionOutcomes &&
        parsedDecisionOutcomes.latestOutcomeDetails
      ) {
        resp = parsedDecisionOutcomes.latestOutcomeDetails
          ? parsedDecisionOutcomes.latestOutcomeDetails.descriptionText
          : null;
        // parsedDecisionOutcomes.forEach((element) => {

        // });
        // for (let i = 0; i < parsedDecisionOutcomes.length; i++) {
        //   if (parsedDecisionOutcomes[i].decisionOutcomeDetails && parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText) {
        //     resp = parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText;
        //   }
        //   if (resp) {
        //     break;
        //   }
        // }
      } else if (
        parsedDecisionOutcomes &&
        Array.isArray(parsedDecisionOutcomes)
      ) {
        for (let i = 0; i < parsedDecisionOutcomes.length; i++) {
          if (
            parsedDecisionOutcomes[i].decisionOutcomeDetails &&
            parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText
          ) {
            resp = parsedDecisionOutcomes[i].decisionOutcomeDetails
              ? parsedDecisionOutcomes[i].decisionOutcomeDetails.descriptionText
              : null;
          }
          if (resp) {
            break;
          }
        }
      }
    }
    return resp;
  }

  validateNumber(event) {
    const keyCode = event.keyCode;

    const excludedKeys = [8, 9, 37, 39, 46, 109, 189];
    const specialChars = [
      '!',
      '@',
      '#',
      '$',
      '%',
      '^',
      '&',
      '*',
      '(',
      ')',
      '_',
    ];

    if (specialChars.includes(event.key)) {
      event.preventDefault();
    } else if (
      !(
        (keyCode >= 48 && keyCode <= 57) ||
        (keyCode >= 96 && keyCode <= 105) ||
        excludedKeys.includes(keyCode)
      )
    ) {
      event.preventDefault();
    }
  }

  validateClaims(event) {
    const keyCode = event.keyCode;

    const excludedKeys = [8, 9, 32, 37, 39, 46, 109, 188, 189];
    const specialChars = [
      '!',
      '@',
      '#',
      '$',
      '%',
      '^',
      '&',
      '*',
      '(',
      ')',
      '_',
    ];

    if (specialChars.includes(event.key)) {
      event.preventDefault();
    } else if (
      !(
        (keyCode >= 48 && keyCode <= 57) ||
        (keyCode >= 96 && keyCode <= 105) ||
        excludedKeys.includes(keyCode)
      )
    ) {
      event.preventDefault();
    }
  }

  ValidatePhoneFax(control) {
    if (control.value && control.value.split('-').join('').length < 10) {
      return { invalidLength: true };
    }
    return null;
  }

  enableCaseViewerLink(loggedInUser, allPartiesInfoParsed) {
    let foundUser = false;
    //
    //
    if (allPartiesInfoParsed && allPartiesInfoParsed.patentOwner) {
      if (
        allPartiesInfoParsed.patentOwner.realParty &&
        allPartiesInfoParsed.patentOwner.realParty
          .trim()
          .toLowerCase()
          .includes(loggedInUser.trim().toLowerCase())
      ) {
        foundUser = true;
      }
      if (allPartiesInfoParsed.patentOwner.additionalPartyList) {
        if (
          this.checkForUserInList(
            allPartiesInfoParsed.patentOwner.additionalPartyList,
            loggedInUser
          )
        ) {
          foundUser = true;
        }
      }
      // if (
      //   allPartiesInfoParsed.patentOwner.counselList &&
      //   allPartiesInfoParsed.patentOwner.counselList.includes(loggedInUser)
      // ) {
      //   foundUser = true;
      // }
      if (allPartiesInfoParsed.patentOwner.counselList) {
        if (
          this.checkForUserInList(
            allPartiesInfoParsed.patentOwner.counselList,
            loggedInUser
          )
        ) {
          foundUser = true;
        }
      }
    }
    if (allPartiesInfoParsed && allPartiesInfoParsed.petitioner) {
      if (
        allPartiesInfoParsed.petitioner.realParty &&
        allPartiesInfoParsed.petitioner.realParty
          .trim()
          .toLowerCase()
          .includes(loggedInUser.trim().toLowerCase())
      ) {
        foundUser = true;
      }
      if (allPartiesInfoParsed.petitioner.additionalPartyList) {
        if (
          this.checkForUserInList(
            allPartiesInfoParsed.petitioner.additionalPartyList,
            loggedInUser
          )
        ) {
          foundUser = true;
        }
      }
      if (allPartiesInfoParsed.petitioner.counselList) {
        if (
          this.checkForUserInList(
            allPartiesInfoParsed.petitioner.counselList,
            loggedInUser
          )
        ) {
          foundUser = true;
        }
      }
    }
    return foundUser;
  }

  checkForUserInList(partyList, loggedInUser) {
    let foundUser = false;
    partyList.forEach((party) => {
      if (
        party &&
        party.trim().toLowerCase() === loggedInUser.trim().toLowerCase()
      ) {
        foundUser = true;
      }
    });
    return foundUser;
  }

  // openWarningModal() {
  //   const initialState: ModalOptions = {
  //     initialState: {
  //       title: 'Warning',
  //       // message: [
  //       //   'You have document information that has not been saved to the docket. Your changes will be lost',
  //       //   'Are you sure you want to clear the changes?',
  //       // ],
  //       message: [
  //         'Performing this action will exit the current screen without saving your changes.',
  //         'Do you want to continue and clear changes?',
  //       ],
  //       leftBtnLabel: 'No, return to page',
  //       rightBtnLabel: 'Yes, abandon changes',
  //       selection: false,
  //     },
  //   };
  //   this.warningModalRef = this.modalService.show(
  //     WarningModalComponent,
  //     initialState
  //   );
  //   this.removeModalFadeClass();
  //   return this.warningModalRef;
  // }

  setEST(dateInEpoch) {
    let dateToConvert = dateInEpoch;
    if (dateInEpoch.toString().length === 10) {
      dateToConvert = dateInEpoch * 1000;
    }
    return this.datePipe.transform(
      parseInt(dateToConvert),
      'MM/dd/yyyy hh:mm a ',
      'EST'
    );
  }

  // generateReceiptPdf(elementId) {
  //   let DATA: any = document.getElementById(elementId);
  //   html2canvas(DATA).then((canvas) => {
  //     // let fileWidth = 208;
  //     let fileWidth = 11;
  //     let fileHeight = (canvas.height * fileWidth) / canvas.width;
  //     const FILEURI = canvas.toDataURL('image/png');
  //     // let PDF = new jsPDF('p', 'mm', 'letter', true);
  //     let PDF = new jsPDF('l', 'in', 'letter', true);
  //     let position = 0;
  //     PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
  //     // PDF.save('angular-demo.pdf');
  //     // PDF.output('dataurlnewwindow');
  //     const pdfBlob = PDF.output('blob');
  //     var url = window.URL.createObjectURL(pdfBlob);

  //     var element = document.getElementById(elementId);

  //     var a = document.createElement('a');
  //     // var linkText = document.createTextNode('View File');
  //     a.target = '_blank';
  //     // a.appendChild(linkText);
  //     a.href = url;
  //     element.appendChild(a);
  //     a.click();
  //   });
  // }

  convertToTitleCase(stringToConvert) {
    if (stringToConvert) {
      let stringList = stringToConvert.split(' ');
      for (let i = 0; i < stringList.length; i++) {
        stringList[i] =
          stringList[i][0].toUpperCase() + stringList[i].substr(1);
      }

      return stringList.join(' ');
    } else {
      return stringToConvert;
    }
  }

  clearTableFilter(filteredColums) {
    filteredColums.forEach((searchCriteria) => {
      searchCriteria.searchText = null;
    });
  }

  removeSpaceFromPaperTypes(documentsList) {
    documentsList.forEach((doc) => {
      const tempDisplayNameText = doc.displayNameText
        .split(':')
        .map((item) => item.trim());
      doc.displayNameText = tempDisplayNameText[0];
      if (tempDisplayNameText[1]) {
        doc.displayNameText = `${doc.displayNameText} : ${tempDisplayNameText[1]}`;
      }
    });
    return documentsList;
  }

  formatPartiesAddress(partiesAddressDetails) {
    let address: string = '';
    if (partiesAddressDetails.address1) {
      address += `${partiesAddressDetails.address1}, `;
    }
    if (partiesAddressDetails.address2) {
      address += `${partiesAddressDetails.address2}, `;
    }
    if (partiesAddressDetails.city) {
      address += `${partiesAddressDetails.city}, `;
    }
    if (partiesAddressDetails.state.value) {
      address += `${partiesAddressDetails.state.value}, `;
    }
    if (partiesAddressDetails.zip) {
      address += `${partiesAddressDetails.zip}, `;
    }
    if (partiesAddressDetails.country.value) {
      address += `${partiesAddressDetails.country.value}`;
    }
    return address;
  }

  formatIPPartiesAddress(partiesAddressDetails) {
    let address: string = '';
    if (
      partiesAddressDetails.streetLineOneText &&
      partiesAddressDetails.streetLineOneText.trim()
    ) {
      address += `${partiesAddressDetails.streetLineOneText.trim()}, `;
    }
    if (
      partiesAddressDetails.streetLineTwoText &&
      partiesAddressDetails.streetLineTwoText.trim()
    ) {
      address += `${partiesAddressDetails.streetLineTwoText.trim()}, `;
    }
    if (partiesAddressDetails.city && partiesAddressDetails.city.trim()) {
      address += `${partiesAddressDetails.city.trim()}, `;
    }
    if (partiesAddressDetails.state && partiesAddressDetails.state.trim()) {
      address += `${partiesAddressDetails.state.trim()}, `;
    }
    if (partiesAddressDetails.zipCode && partiesAddressDetails.zipCode.trim()) {
      address += `${partiesAddressDetails.zipCode.trim()}, `;
    }
    if (partiesAddressDetails.country && partiesAddressDetails.country.trim()) {
      address += `${partiesAddressDetails.country.trim()}`;
    }
    return address;
  }

  throwError(description, errorPayload) {
    this.logger.error(`${description}: `, errorPayload);
    //this.showError(errorPayload?.error?.message, 'Error');
  }

  removeModalFadeClass() {
    setTimeout(() => {
      let modalContainer = document.getElementsByTagName(
        'modal-container'
      ) as HTMLCollectionOf<HTMLDivElement>;

      for (const tag of Array.from(modalContainer)) {
        tag.classList.remove('fade');
      }
    }, 200);
  }

  // trimWhitespace(textToTrim) {
  //   return textToTrim.trim();
  // }

  trimWhitespace(e, textToTrim, currentForm, currentProp) {
    // if (e.code === 'Space') {
    //   if (e.key === ' ' && !textToTrim) {
    //     setTimeout(() => {
    //       const trimmedText = textToTrim.trim();
    //       currentForm
    //         .get(currentProp)
    //         .setValue(trimmedText, Validators.required);
    //     });
    //   }
    // } else {
    //   return;
    // }
    setTimeout(() => {
      // const trimmedText = textToTrim.trim();
      if (currentForm.get(currentProp).value) {
        const trimmedText = currentForm.get(currentProp).value.trim();
        if (!trimmedText) {
          currentForm
            .get(currentProp)
            .setValue(trimmedText, Validators.required);
        }
      }
    });
  }

  // openDocumentsModal(proceedingNo) {
  //   window.sessionStorage.setItem('proceedingNoForSearch', proceedingNo);
  //   //
  //   //
  //   const initialState: ModalOptions = {
  //     initialState: {
  //       proceedingNo: proceedingNo,
  //       closeModal: false,
  //     },
  //     class: 'modal-xl',
  //     animated: true,
  //     ignoreBackdropClick: true,
  //   };
  //   this.documentsModalRef = this.modalService.show(
  //     ViewDocumentsModalComponent,
  //     initialState
  //   );
  //   this.removeModalFadeClass();
  //   this.documentsModalRef.onHide.subscribe((reason: string | any) => {
  //     if (reason.initialState.closeModal) {
  //     }
  //   });
  // }

  // openEmailSubject(params) {
  //   const initialState = {
  //     modal: {
  //       isConfirm: false,
  //     },
  //     emailContent: params,
  //   };
  //   this.emailModalRef = this.modalService.show(EmailSubjectComponent, {
  //     animated: true,
  //     backdrop: true,
  //     ignoreBackdropClick: true,
  //     class: 'add-doc-modal-content',
  //     initialState,
  //   });
  //   this.removeModalFadeClass();
  //   this.emailModalRef.onHide.subscribe((reason: string | any) => {
  //     if (reason.initialState.continueWithPetition) {
  //     }
  //   });
  // }

  getNextExhibitNumber(numbers) {
    numbers.listOfNumbers.sort();
    const currentNumberIndex = numbers.listOfNumbers.indexOf(
      numbers.currentNumber
    );
    if (currentNumberIndex < 0) {
      numbers.listOfNumbers.push(numbers.currentNumber);
      numbers.listOfNumbers.sort();
    }
    let nextNumber = numbers.currentNumber;
    let nextNumberIndex = null;
    do {
      nextNumber++;
      nextNumberIndex = numbers.listOfNumbers.indexOf(nextNumber);
    } while (nextNumberIndex >= 0);
    return nextNumber;
  }

  focusOnCloseModal(idName) {
    setTimeout(() => {
      document.getElementById(idName).focus();
    }, 200);
  }
}
