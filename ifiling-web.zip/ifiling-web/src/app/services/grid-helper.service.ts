import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { CONSTANTS } from '../constants/constants';
import { GridParamsModel } from '../models/common/GridParams.model';

@Injectable({
  providedIn: 'root'
})
export class GridHelperService {
  constructor(private datePipe: DatePipe) {}

  onGridReady(params) {
    const gridParams = new GridParamsModel();
    gridParams.gridApi = params.api;
    gridParams.gridColumnApi = params.columnApi;
    gridParams.gridApi.sizeColumnsToFit();
    return gridParams;
  }

  onFilterChanged(params, recordCountInfo, paginationInfo) {
    const filterModel = params.gridApi.getFilterModel();
    if (filterModel) {
      params.numberOfFilters = Object.keys(filterModel).length;
    } else {
      params.numberOfFilters = 0;
    }
    if (recordCountInfo) {
      recordCountInfo.dataLength = params.gridApi.getModel().getRowCount();
      paginationInfo.totalPages = Math.ceil(
        recordCountInfo.dataLength / paginationInfo.pageSize
      );
      if (paginationInfo.currentPage > paginationInfo.totalPages) {
        paginationInfo.currentPage = paginationInfo.totalPages;
        recordCountInfo.currentPage = paginationInfo.totalPages;
      } else if (
        recordCountInfo.currentPage === 0 &&
        recordCountInfo.dataLength > 0
      ) {
        paginationInfo.currentPage = 1;
        recordCountInfo.currentPage = 1;
      }
    }
  }

  clearFilters(params) {
    if (params.gridApi) {
      params.gridApi.setFilterModel(null);
    }
    params.numberOfFilters = 0;
  }

  exportGrid(params) {
    const fileName = `${params.fileName} - ${this.datePipe.transform(
      new Date().getTime(),
      'MM/dd/yyyy hh:mm a'
    )}${CONSTANTS.CSV}`;
    const columnsList = this.modifyColumns(params);

    params.gridApi.exportDataAsCsv(
      this.customizeCsvExport(fileName, columnsList)
    );
    // params.gridApi.exportDataAsCsv({ fileName: fileName });
  }

  customizeCsvExport(fileName, columnsList) {
    return {
      fileName: `${fileName}`,
      columnKeys: columnsList,
      allColumns: true,
      processCellCallback: this.convertToTitleCase,
      // processHeaderCallback: this.recipientsHeaderCallback,
    };
  }

  convertToTitleCase(params) {
    if (params.column.colId === 'allRecipientList') {
      let allRecipients = null;
      if (params.node.data.tolist && params.node.data.tolist.length > 0) {
        allRecipients = `TO: ${params.node.data.tolist.join(', ')}`;
      }
      if (params.node.data.ccList && params.node.data.ccList.length > 0) {
        allRecipients = `${allRecipients} CC: ${params.node.data.ccList.join(
          ', '
        )}`;
      }
      return allRecipients;
    } else {
      return params.value;
    }
  }

  modifyColumns(params) {
    let columns = params.gridColumnApi.getAllColumns();
    // remove documents column for advanced search
    if (params.fileName === CONSTANTS.EXPORT_NAMES.ADVANCED_SEARCH) {
      columns = columns.filter((col) => {
        return col.colId !== 'searchDocuments';
      });

      // columns.forEach((col) => {
      //   if (col.colId !== 'searchDocuments') {
      //     cols.push
      //   }
      // })
    }
    return columns;
  }

  convertDateToString(epochDate) {
    if (!epochDate) {
      return '';
    }
    return this.datePipe.transform(parseInt(epochDate), 'MM/dd/yyyy');
  }

  // convertDateTime(epochDate) {
  //   if (!epochDate) {
  //     return '';
  //   }
  //   return this.datePipe.transform(parseInt(epochDate), 'MM/dd/yyyy hh:mm:ss a');
  // }
  convertDateTime(epochDate) {
    if (!epochDate) {
      return '';
    }
    const estDate = new Date(
      new Date(parseInt(epochDate)).toLocaleString('en-US', {
        timeZone: 'America/New_York',
      })
    ).getTime();
    return this.datePipe.transform(estDate, 'MM/dd/yyyy hh:mm:ss a') + ' ET';
  }

  convertRegularDateTime(regularDate) {
    if (!regularDate) {
      return '';
    }
    return (
      this.datePipe.transform(regularDate, 'MM/dd/yyyy hh:mm:ss a') + ' ET'
    );
  }

  convertRegularDate(regularDate) {
    if (!regularDate) {
      return '';
    }
    return this.datePipe.transform(regularDate, 'MM/dd/yyyy');
  }

  dateComparator(date1, date2) {
    date1 = date1.trim() === '' ? null : date1;
    date2 = date2.trim() === '' ? null : date2;
    if (date1 && date2) {
      if (typeof date1 === 'string' && date1.trim().substr(-2) === 'ET') {
        date1 = date1.trim().substr(0, date1.length - 3);
      }
      if (typeof date2 === 'string' && date2.trim().substr(-2) === 'ET') {
        date2 = date2.trim().substr(0, date2.length - 3);
      }
      const date1Number = new Date(date1).getTime();
      const date2Number = new Date(date2).getTime();

      if (date1Number === null && date2Number === null) {
        return 0;
      }
      if (date1Number === null) {
        return -1;
      }
      if (date2Number === null) {
        return 1;
      }
      return date1Number - date2Number;
    } else {
      // return '';
      if (date1 === null) {
        return -1;
      }
      if (date2 === null) {
        return 1;
      }
    }
  }

  convertFilingDate(filingDate) {
    if (!filingDate) {
      return '';
    }
    return this.datePipe.transform(
      new Date(filingDate).getTime(),
      'MM/dd/yyyy'
    );
  }

  gridPaginationAction(event, gridApi) {
    switch (event.pageAction) {
      case 'first':
        gridApi.paginationGoToFirstPage();
        break;
      case 'previous':
        gridApi.paginationGoToPreviousPage();
        break;
      case 'next':
        gridApi.paginationGoToNextPage();
        break;
      case 'last':
        gridApi.paginationGoToLastPage();
        break;
      case 'specificPage':
        gridApi.paginationGoToPage(parseInt(event.pageNo));
        break;
      default:
        break;
    }
  }

  caseInsensitiveSort(valueA, valueB) {
    return valueA.toLowerCase().localeCompare(valueB.toLowerCase());
  }
}
