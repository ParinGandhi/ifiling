import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { PublicSearchService } from './public-search.service';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { CONSTANTS } from 'src/app/constants/constants';
import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { OpenCaseViewerComponent } from '../../common/open-case-viewer/open-case-viewer.component';

@Component({
  selector: 'app-public-search',
  templateUrl: './public-search.component.html',
  styleUrls: ['./public-search.component.scss']
})
export class PublicSearchComponent implements OnInit {
  selectedSearchType: string = 'Application No.';
  invalidSearch: string = null;
  searchText: string = null;
  noResults: boolean = false;

  columnDefs = {
    searchResults: [
      {
        field: 'interferenceNum',
        headerName: 'Interference No.',
        width: '7%',
        sort: 'desc',
        sortIndex: 2,
        cellRendererFramework: OpenCaseViewerComponent,
        // cellRendererParams: { fromComponent: 'searchDocuments' },
      },
      {
        field: 'applicationId',
        headerName: 'Application No.',
        width: '7%',
      },
      {
        field: 'patentNo',
        headerName: 'Patent No.',
        width: '7%',
      },
      { field: 'inventorLastName',
        headerName: 'Party Name',
        width: '7%' },      
    ],
  };

  rowData = {
    searchResults: [],
  };
  resultsEmpty: boolean;
  loading: boolean;
  resultsFound: boolean;
  searching: boolean;
  verifiedCaseList: any[];
  searchResultsFinal: Array<any> = [];
  recordCountInfo: RecordCountModel = new RecordCountModel();
  gridOptions = new GridOptionsModel();
  gridParams = new GridParamsModel();
  searchInfo: any;

  constructor(
    public gridHelperService: GridHelperService,
    private commonUtils: CommonUtilitiesService,
    private searchService: PublicSearchService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.searchInfo = JSON.parse(
      window.sessionStorage.getItem('searchInfo')
    );
    if(this.searchInfo)
    {
      this.selectedSearchType = this.searchInfo.searchType;
      this.searchText = this.searchInfo.text;
      this.search(this.searchInfo.text);
    }
  }

  search(text) {
    this.noResults = true;
    this.invalidSearch = null;
    if (this.selectedSearchType == 'Application No.') {
      if (!text || !text.match('^[0-9]{8}$')) {
        this.invalidSearch = 'application number';
        this.noResults = false;
      }
      else{
        this.getCaseSearchResults(text,'applicationId');
        this.noResults = false;
      }
    } else if (this.selectedSearchType == 'Interference No.') {
      if (!text || !text.match('^[0-9]{6}$')) {
        this.invalidSearch = 'interference number';
        this.noResults = false;
      }
      else{
        this.getCaseSearchResults(text,'interferenceNum');
        this.noResults = false;
      }
    } else if (this.selectedSearchType == 'Patent No.') {
      if (!text || !text.match('^[0-9]{7,8}$')) {
        this.invalidSearch = 'patent number';
        this.noResults = false;
      }
      else{
        this.getCaseSearchResults(text,'patentNo');
        this.noResults = false;
      }
    } else if (this.selectedSearchType == 'Party Name') {
      if (!text|| !text.match('^[a-zA-Z0-9_]+$')) {
        this.invalidSearch = 'party name';
        this.noResults = false;
      }
      else{
        this.getCaseSearchResults(text,'inventorLastName');
        this.noResults = false;
      }
    }
  }

  selectSearchType(e) {
    this.selectedSearchType = e;
  }

  getCaseSearchResults(text,type) {
    this.verifiedCaseList = [];
    this.searching = true;
    this.loading = true;
    this.resultsFound = false;
    this.searchService
      .getSearchResult(text,type)
      .pipe(take(1))
      .subscribe(
        (verificationResponse) => {
           if (verificationResponse.length >= 0) {
            this.loading = true;
            this.rowData.searchResults = verificationResponse;
            this.searchResultsFinal = [...verificationResponse];
            this.resultsFound = true;
            this.recordCountInfo.dataLength = this.rowData.searchResults.length;
            this.recordCountInfo.paginationPageSize = 25;
            this.loading = false;
            this.searching = false;
            this.resultsEmpty = false;
          } else {
            this.resultsEmpty = true;
            this.resultsFound = false;
            this.loading = false;
            this.searching = false;
          }
          sessionStorage.removeItem('searchInfo');
        },
        (searchFailure) => {
          //this.commonUtils.showInfo('No results found', 'Search');
          this.loading = false;
          this.searching = false;
          this.resultsEmpty = true;
        }
      );
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = CONSTANTS.EXPORT_NAMES.ADVANCED_SEARCH;
    // this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    // this.paginationInfo.totalPages = this.totalPages;
  }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colId === 'interferenceNum') {
      this.commonUtils.openCaseViewerForPublic(e.data.interferenceNum);
    }
  }

}
