import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Urls } from 'src/app/constants/urls';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Injectable({
  providedIn: 'root'
})
export class PublicSearchService {
  private IFILING_BASE_URL = environment.IFILING_SERVICE_API;

  constructor(
    private http: HttpClient,
    private commonUtils: CommonUtilitiesService
  ) { }

  getHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': emailId,
      }),
      withCredentials: true,
      crossDomain: true,
    };

    return httpOptions;
  }

  getSearchResult(searchNumber: string,searchType: string): Observable<any> {
    console.log(searchType);
    const userName = window.sessionStorage.getItem('email')
    let url = null;
    if (!userName || userName === 'anonymous') {
      url = `${this.IFILING_BASE_URL}${Urls.PUBLIC_CASESEARCH}`+searchType+"="+searchNumber;
    } else {
    url = `${this.IFILING_BASE_URL}${Urls.CASESEARCH}`+searchType+"="+searchNumber;
    }
    return this.http.get<any>(url).pipe(
      map((searchResult) => {
        return searchResult;
      })
    );
  }
}
