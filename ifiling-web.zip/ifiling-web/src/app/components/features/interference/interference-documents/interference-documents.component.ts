import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
// import { Store } from '@ngrx/store';
// import { State } from '../../../../store';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import PaperCasesModel from 'src/app/models/cases/PaperCases.model';
import ExhibitCasesModel from 'src/app/models/cases/ExhibitCases.model';
import CaseDetailsModel from 'src/app/models/cases/CaseDetails.model';
import { ActivatedRoute } from '@angular/router';
// import { tableOptions } from 'src/app/models/table-options.model';
import { AddDocumentsModalComponent } from './add-documents-modal/add-documents-modal.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
// import { TrialsService } from 'src/app/services/trials.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { CommonService } from 'src/app/services/common.service';
import { Store, select } from '@ngrx/store';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
// import { GetCasePhaseAction } from 'src/app/store/case-viewer/case-viewer.actions';
// import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
// import { JpViewService } from 'src/app/services/jpview.service';
import { OpenDocumentComponent } from '../../../common/open-document/open-document.component';
import { TrialsService } from 'src/app/services/trials.service';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-interference-documents',
  templateUrl: './interference-documents.component.html',
  styleUrls: ['./interference-documents.component.less'],
})
export class InterferenceDocumentsComponent implements OnInit {
  @Input() applications;
  resizePaperGrid = () => {
    this.paperGridParams.gridApi.sizeColumnsToFit();
  };
  resizeExhibitGrid = () => {
    this.exhibitGridParams.gridApi.sizeColumnsToFit();
  };

  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  modalRef: BsModalRef;
  paperGridParams = new GridParamsModel();
  exhibitGridParams = new GridParamsModel();
  allPaperCases: any;
  originalAllPaperCases: PaperCasesModel;
  allExhibitCases: any;
  originalAllExhibitCases: ExhibitCasesModel;
  papers: any = [];
  exhibits: any = [];
  orderByField: any[] = [];
  orderByExhibitField: any[] = [];
  caseDetails: CaseDetailsModel;
  caseInfo: CaseInfoModel = {
    // serialNo: null,
    proceedingNo: null,
  };
  selectedCases: Array<any> = [];
  filterObj: any = {};
  papersCount = {
    all: 0,
    board: 0,
    po: 0,
    petitioner: 0,
  };
  exhibitsCount = {
    all: 0,
    thousand: 0,
    twoThousand: 0,
    threeThousand: 0,
  };
  // documentTable: tableOptions;
  selectedParty: string;
  selectedExhibit: string;
  proceedingIdentifier: any;
  pdfData: any;
  pdfContent: any;
  contentsPreview: string;
  nextPaperNumber: string;
  papersToDownload: Array<string> = [];
  exhibitsToDownload: Array<string> = [];
  documentSelected = false;
  downloading = false;
  lastRefresh = new Date();
  isPartyOnCase: boolean = false;
  isPublic: boolean = false;

  rowData = {
    paperData: [],
    exhibitsData: [],
    attorneysData: [],
  };

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
  };

  columnDefs = {
    papers: [
      {
        field: 'documentNumber',
        headerName: 'Paper #',
        width: '8%',
        sort: 'desc',
        resizable: true,
      },
      {
        field: 'filingDateString',
        headerName: 'Filing date (mm/dd/yyyy)',
        width: '12%',
        resizable: true,
        comparator: this.gridHelperService.dateComparator,
        type: 'date',
      },
      {
        field: 'documentTypeDescription',
        headerName: 'Paper type #',
        width: '20%',
        resizable: true,
      },
      {
        field: 'name',
        headerName: 'Document name',
        width: '32%',
        resizable: true,
        comparator: this.gridHelperService.caseInsensitiveSort,
        cellRendererFramework: OpenDocumentComponent,
      },
      {
        field: 'pageCount',
        headerName: 'Pages',
        width: '2%',
        resizable: true,
      },
      {
        field: 'docUploadedByText',
        headerName: 'Filing party',
        width: '14%',
        resizable: true,
      },
      {
        field: 'availability',
        headerName: 'Availability',
        width: '12%',
        resizable: true,
      },
    ],
    exhibits: [
      {
        field: 'exhibitNumber',
        headerName: 'Exhibit #',
        width: '10%',
        sort: 'desc',
        resizable: true,
      },
      {
        field: 'filingDateString',
        headerName: 'Filing date (mm/dd/yyyy)',
        width: '15%',
        resizable: true,
        comparator: this.gridHelperService.dateComparator,
        type: 'date',
      },
      {
        field: 'name',
        headerName: 'Document name',
        width: '35%',
        resizable: true,
        comparator: this.gridHelperService.caseInsensitiveSort,
        cellRendererFramework: OpenDocumentComponent,
      },
      {
        field: 'pageCount',
        headerName: 'Pages',
        width: '10%',
        resizable: true,
      },
      {
        field: 'docUploadedByText',
        headerName: 'Filing party',
        width: '15%',
        resizable: true,
      },
      {
        field: 'availability',
        headerName: 'Availability',
        width: '15%',
        resizable: true,
      },
    ],
    attorneys: [
      {
        field: 'applicationNo',
        headerName: 'Application #',
        sort: 'desc',
        resizable: true,
      },
      {
        field: 'attorneyNo',
        headerName: 'Attorney #',
        resizable: true,
      },
      {
        field: 'attorneyName',
        headerName: 'Attorney name',
        resizable: true,
      },
      {
        field: 'attorneyType',
        headerName: 'Attorney type',
        resizable: true,
      },
    ],
  };

  // To refresh header - delete when integrated into header call
  // store: Store<CaseViewerState>;

  constructor(
    // private jpViewService: JpViewService,
    private activatedRoute: ActivatedRoute,
    private modalService: BsModalService,
    private trialsService: TrialsService,
    private ifilingService: IfilingService,
    private commonService: CommonService,
    private commonUtils: CommonUtilitiesService,
    private store: Store,
    public gridHelperService: GridHelperService
  ) {}

  ngOnInit(): void {
    this.caseInfo = {
      // serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };

    // this.store.dispatch(
    //   GetCasePhaseAction({ url: this.caseInfo.proceedingNo })
    // );
    this.orderByField = [];
    this.orderByExhibitField = [];
    const from = window.sessionStorage.getItem('from');
    this.isPublic = from === 'public';
    this.getIfPartyOnCase();
    this.getDocuments();
    this.getProceedingIdentifier();
    // setInterval(()=>{
    //   this.refresh();
    // },300000)
    // this.getApplications();
  }

  ngOnDestroy() {
    window.removeEventListener('resize', this.resizePaperGrid);
    window.removeEventListener('resize', this.resizeExhibitGrid);
  }

  refresh() {
    this.orderByField = [];
    this.orderByExhibitField = [];
    this.getDocuments();
    this.lastRefresh = new Date();
  }

  onPaperGridReady(params) {
    this.paperGridParams = this.gridHelperService.onGridReady(params);
    //this.gridParams.gridApi.setDomLayout('autoHeight');
    this.paperGridParams.fileName = 'Interference Papers';
    this.paperGridParams.gridApi.sizeColumnsToFit();
    window.addEventListener('resize', this.resizePaperGrid);
    // this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    // this.paginationInfo.totalPages = this.totalPages;
  }

  onExhibitGridReady(params) {
    this.exhibitGridParams = this.gridHelperService.onGridReady(params);
    this.exhibitGridParams.fileName = 'Interference Exhibits';
    this.exhibitGridParams.gridApi.sizeColumnsToFit();
    window.addEventListener('resize', this.resizeExhibitGrid);
  }

  setPapersCount() {
    this.papersCount = {
      all: this.allPaperCases.allPapersCount,
      board: this.allPaperCases.boardPapersCount,
      po: this.allPaperCases.patentOwnerPapersCount,
      petitioner: this.allPaperCases.petitionerPapersCount,
    };
  }

  getDocuments() {
    this.ifilingService
      .getDocumentsForUpdate(this.caseInfo.proceedingNo)
      .subscribe((documentSuccess) => {
        let paperDocs = [];
        let exhibitDocs = [];
        this.papersCount = {
          all: 0,
          board: 0,
          po: 0,
          petitioner: 0,
        };
        this.allPaperCases = {
          allPapersBag: [],
          boardPapersBag: [],
          petitionerPapersBag: [],
          patentOwnerPapersBag: [],
        };
        this.exhibitsCount = {
          all: 0,
          thousand: 0,
          twoThousand: 0,
          threeThousand: 0,
        };
        this.allExhibitCases = {
          allExhibitsBag: [],
          thousandsExhibitsBag: [],
          twoThousandsExhibitsBag: [],
          threeThousandsExhibitsBag: [],
        };
        let milestonePopr = {
          poprWaivedResponse: null,
          poprFileResponse: null,
        };
        documentSuccess.forEach((doc) => {
          // for milestone page
          doc.checked = false;
          if (
            doc?.documentTypeIdentifier == '18' ||
            doc?.documentTypeIdentifier == '203'
          ) {
            milestonePopr.poprWaivedResponse = 'No';
          } else if (
            doc?.documentTypeIdentifier == '38' ||
            doc?.documentTypeIdentifier == '204'
          ) {
            milestonePopr.poprWaivedResponse = 'Yes';
          }

          if (doc.filingDate && doc.filingDate.toString().length <= 10) {
            doc.filingDate = parseInt(doc.filingDate.toString() + '000');
          }
          if (doc.category && doc.category.toLowerCase() === 'paper') {
            this.papersCount.all++;
            this.allPaperCases.allPapersBag.push(doc);
            switch (doc.filingParty.toLowerCase()) {
              case 'board':
                this.papersCount.board++;
                this.allPaperCases.boardPapersBag.push(doc);
                break;
              case 'petitioner':
                this.papersCount.petitioner++;
                this.allPaperCases.petitionerPapersBag.push(doc);
                break;
              case 'patent owner':
                this.papersCount.po++;
                this.allPaperCases.patentOwnerPapersBag.push(doc);
            }
          } else if (doc.category && doc.category.toLowerCase() === 'exhibit') {
            this.exhibitsCount.all++;
            this.allExhibitCases.allExhibitsBag.push(doc);
            if (doc.exhibitNumber.toString().startsWith('1')) {
              this.exhibitsCount.thousand++;
              this.allExhibitCases.thousandsExhibitsBag.push(doc);
            } else if (doc.exhibitNumber.toString().startsWith('2')) {
              this.exhibitsCount.twoThousand++;
              this.allExhibitCases.twoThousandsExhibitsBag.push(doc);
            } else if (doc.exhibitNumber.toString().startsWith('3')) {
              this.exhibitsCount.threeThousand++;
              this.allExhibitCases.threeThousandsExhibitsBag.push(doc);
            }
          }
        });

        documentSuccess.forEach((poprElement, index, arr) => {
          if (
            poprElement?.documentTypeIdentifier == '38' ||
            poprElement?.documentTypeIdentifier == '204' ||
            poprElement?.documentTypeIdentifier == '18' ||
            poprElement?.documentTypeIdentifier == '203'
          ) {
            milestonePopr.poprFileResponse = 'Yes';
            arr.length = index + 1;
          } else {
            milestonePopr.poprFileResponse = 'No';
          }
        });

        // this.milestonePoprEmitter.emit(milestonePopr);
        // this.getPaperDocuments();
        // this.getExhibitDocuments();
        this.rowData.paperData = this.allPaperCases.allPapersBag;
        this.rowData.exhibitsData = this.allExhibitCases.allExhibitsBag;
      });
  }

  getProceedingIdentifier() {
    this.ifilingService
      .getCaseHeaderInfo(this.caseInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.proceedingIdentifier =
          caseInfoByProceedingResponse.proceedingIdentifier;
      });
  }

  openAddDocumentModal() {
    const initialState: any = {
      modal: {
        proceedingNo: this.caseInfo.proceedingNo,
        closeModal: false,
        applications: this.applications,
        proceedingIdentifier: this.proceedingIdentifier,
        existingExhibitsList: this.allExhibitCases?.allExhibitsBag
          ? this.allExhibitCases.allExhibitsBag
          : [],
      },
    };
    this.modalRef = this.modalService.show(AddDocumentsModalComponent, {
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    // this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.closeModal) {
        this.refresh();
      }
    });
  }

  setExhibitsCount() {
    this.exhibitsCount = {
      all: this.allExhibitCases.allExhibitsCount,
      thousand: this.allExhibitCases.thousandsExhibitsCount,
      twoThousand: this.allExhibitCases.twoThousandsExhibitsCount,
      threeThousand: this.allExhibitCases.threeThousandsExhibitsCount,
    };
  }

  // changeParty(partyType) {
  //   this.selectedParty = partyType;
  //   this.orderByField = [];
  //   this.papers.data = JSON.parse(
  //     JSON.stringify(this.allPaperCases[partyType])
  //   );
  //   this.sortColumns('-documentNumber', 'p');
  // }

  // changeExhibits(exhibitNumber) {
  //   this.selectedExhibit = exhibitNumber;
  //   this.orderByExhibitField = [];
  //   this.exhibits.data = JSON.parse(
  //     JSON.stringify(this.allExhibitCases[exhibitNumber])
  //   );
  //   this.sortColumns('-exhibitNumber', 'e');
  // }

  // sortColumns(field, sortType) {
  //   if (sortType === 'p') {
  //     !this.orderByField.includes(field)
  //       ? this.correctOrder(field, sortType)
  //       : this.correctOrder('-' + field, sortType);
  //     this.orderByField = !this.orderByField.includes(field)
  //       ? [field]
  //       : ['-' + field];
  //   } else if (sortType === 'e') {
  //     !this.orderByExhibitField.includes(field)
  //       ? this.correctOrder(field, sortType)
  //       : this.correctOrder('-' + field, sortType);
  //     this.orderByExhibitField = !this.orderByExhibitField.includes(field)
  //       ? [field]
  //       : ['-' + field];
  //   }
  // }

  // correctOrder(field, sortType) {
  //   let tempData;
  //   if (sortType === 'p') {
  //     tempData = [...this.papers.data];
  //     this.papers.data = [];
  //     let order = field.charAt(0) === '-' ? 'desc' : 'asc';
  //     tempData.sort(this.compareValues(field, order, sortType));
  //     this.papers.data = [...tempData];
  //   } else if (sortType === 'e') {
  //     tempData = [...this.exhibits.data];
  //     this.exhibits.data = [];
  //     let order = field.charAt(0) === '-' ? 'desc' : 'asc';
  //     tempData.sort(this.compareValues(field, order, sortType));
  //     this.exhibits.data = [...tempData];
  //   }
  // }

  // compareValues(key, order = 'asc', sortType) {
  //   if (key.charAt(0) === '-') {
  //     key = key.substring(1);
  //   }

  //   return function innerSort(a, b) {
  //     if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
  //       // property doesn't exist on either object
  //       return 0;
  //     }

  //     const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
  //     const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

  //     let comparison = 0;
  //     if (varA > varB) {
  //       comparison = 1;
  //     } else if (varA < varB) {
  //       comparison = -1;
  //     } else {
  //       let numberA = sortType === 'p' ? a.docNo : a.exhibitNumber;
  //       let numberB = sortType === 'p' ? b.docNo : b.exhibitNumber;

  //       if (numberA > numberB) {
  //         comparison = 1;
  //       } else if (numberA < numberB) {
  //         comparison = -1;
  //       } else {
  //         return 0;
  //       }
  //     }
  //     return order === 'desc' ? comparison * -1 : comparison;
  //   };
  // }

  // rowSelectionForPapers(selectedDocs) {
  //   if (typeof selectedDocs?.valueToEmit === 'string') {
  //     if (selectedDocs?.valueToEmit === 'all') {
  //       // this.papersToDownload = [];
  //       // this.papersToDownload = [...this.allPaperCases.allPapersBag];
  //       // this.allPaperCases.allPapersBag.forEach((paper) => {
  //       //   this.papersToDownload.push(paper.contentManagementId);
  //       // });
  //       this.papers.data.forEach((exhibit) => {
  //         exhibit.checked = true;
  //       });
  //     } else if (selectedDocs?.valueToEmit === 'none') {
  //       // this.papersToDownload = [];
  //       this.papers.data.forEach((exhibit) => {
  //         exhibit.checked = false;
  //       });
  //     }
  //   } else {
  //     const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
  //     if (selectedDocs?.row?.target?.checked) {
  //       // this.papersToDownload.push(contentManagementId);
  //       // this.papersToDownload.push(selectedDocs.valueToEmit);
  //       const indexToAdd = this.papers.data.indexOf(selectedDocs.valueToEmit);
  //       this.papers.data[indexToAdd].checked = true;
  //     } else {
  //       // const indexToRemove = this.papersToDownload.indexOf(contentManagementId);
  //       // const indexToRemove = this.papersToDownload.indexOf(
  //       //   selectedDocs.valueToEmit
  //       // );
  //       // this.papersToDownload.splice(indexToRemove, 1);
  //       const iToRemove = this.papers.data.indexOf(selectedDocs.valueToEmit);
  //       this.papers.data[iToRemove].checked = false;
  //     }
  //   }
  //   this.checkIfDocumentIsSelected();
  //   console.log('Papers to download:', this.papersToDownload);
  // }

  // rowSelectionForExhibits(selectedDocs) {
  //   console.log('selectedDocs: ', selectedDocs);
  //   const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
  //   if (typeof selectedDocs?.valueToEmit === 'string') {
  //     if (selectedDocs?.valueToEmit === 'all') {
  //       // this.exhibitsToDownload = [];
  //       // this.exhibitsToDownload = [...this.allExhibitCases.allExhibitsBag];
  //       // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
  //       //   this.exhibitsToDownload.push(exhibit.contentManagementId);
  //       // });
  //       this.exhibits.data.forEach((exhibit) => {
  //         exhibit.checked = true;
  //       });
  //     } else if (selectedDocs?.valueToEmit === 'none') {
  //       // this.exhibitsToDownload = [];
  //       this.exhibits.data.forEach((exhibit) => {
  //         exhibit.checked = false;
  //       });
  //     }
  //   } else {
  //     const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
  //     if (selectedDocs?.row?.target?.checked) {
  //       // this.exhibitsToDownload.push(contentManagementId);
  //       const indexToAdd = this.exhibits.data.indexOf(selectedDocs.valueToEmit);
  //       this.exhibits.data[indexToAdd].checked = true;
  //       // this.exhibitsToDownload.push(selectedDocs.valueToEmit);
  //     } else {
  //       // const indexToRemove = this.exhibitsToDownload.indexOf(contentManagementId);
  //       // const indexToRemove = this.exhibitsToDownload.indexOf(
  //       //   selectedDocs.valueToEmit
  //       // );
  //       // this.exhibitsToDownload.splice(indexToRemove, 1);
  //       const iToRemove = this.exhibits.data.indexOf(selectedDocs.valueToEmit);
  //       this.exhibits.data[iToRemove].checked = false;
  //     }
  //   }
  //   this.checkIfDocumentIsSelected();
  //   console.log('Exhibits to download:', this.exhibitsToDownload);
  // }

  // checkIfDocumentIsSelected() {
  //   // this.documentSelected =
  //   //   this.papersToDownload.length > 0 || this.exhibitsToDownload.length > 0;
  //   this.documentSelected = false;
  //   this.exhibits.data.forEach((exhibit) => {
  //     if (exhibit.checked) {
  //       this.documentSelected = true;
  //     }
  //   });
  //   this.papers.data.forEach((paper) => {
  //     if (paper.checked) {
  //       this.documentSelected = true;
  //     }
  //   });
  // }

  // sortPapers(papersToSort) {
  //   let docsToUpload = [];
  //   papersToSort.sort((a, b) => {
  //     let docNoA = a.documentNumber;
  //     let docNoB = b.documentNumber;
  //     if (docNoA < docNoB) {
  //       return -1;
  //     }
  //     if (docNoA > docNoB) {
  //       return 1;
  //     }

  //     // names must be equal
  //     return 0;
  //   });
  //   papersToSort.forEach((paper) => {
  //     docsToUpload.push(paper.contentManagementId);
  //   });
  //   return docsToUpload;
  // }

  // sortExhibits(exhibitsToSort) {
  //   let docsToUpload = [];
  //   exhibitsToSort.sort((a, b) => {
  //     let docNoA = a.exhibitNumber;
  //     let docNoB = b.exhibitNumber;
  //     if (docNoA < docNoB) {
  //       return -1;
  //     }
  //     if (docNoA > docNoB) {
  //       return 1;
  //     }

  //     // names must be equal
  //     return 0;
  //   });
  //   exhibitsToSort.forEach((paper) => {
  //     docsToUpload.push(paper.contentManagementId);
  //   });
  //   return docsToUpload;
  // }

  // getApplications() {
  //   this.ifilingService.getApplications(this.caseInfo.proceedingNo).subscribe(
  //     (applicationsResponse) => {
  //       console.log(applicationsResponse);
  //       let attorneysList: any;
  //       let attorneysListData = [];
  //       attorneysList = applicationsResponse;
  //       attorneysList.forEach(element => {
  //         element.proceedingPartyMaps.forEach(party =>{
  //           if(party?.juniorParty){
  //             party.juniorParty?.parties.forEach(ele => {
  //               let obj = {
  //                 applicationNo:'',
  //                 attorneyNo:'',
  //                 attorneyName:'',
  //                 attorneyType:''
  //               }
  //               obj.applicationNo = element.applicationId;
  //               obj.attorneyNo = ele?.registrationNo;
  //               obj.attorneyType = ele?.partySubType;
  //               obj.attorneyName = ele?.personType[0]?.lastName + " " + ele?.personType[0]?.firstName;
  //               attorneysListData.push(obj);
  //             });
  //           }
  //           else if(party?.seniorParty){
  //             party.seniorParty?.parties.forEach(ele => {
  //               let obj = {
  //                 applicationNo:'',
  //                 attorneyNo:'',
  //                 attorneyName:'',
  //                 attorneyType:''
  //               }
  //               obj.applicationNo = element.applicationId;
  //               obj.attorneyNo = ele?.registrationNo;
  //               obj.attorneyType = ele?.partySubType;
  //               obj.attorneyName = ele?.personType[0]?.lastName + " " + ele?.personType[0]?.firstName;
  //               attorneysListData.push(obj);
  //             });
  //           }
  //         })
  //       });
  //       this.rowData.attorneysData = attorneysListData;
  //     },
  //     (applicationsFailure) => {
  //       console.log(applicationsFailure);
  //     }
  //   );
  // }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colId === 'name') {
      this.commonService.openPdf(
        e.data?.petitionIdentifier,
        e.data?.artifactIdentifer
      );
    }
  }

  getIfPartyOnCase() {
    this.ifilingService.getIfPartyOnCase(this.caseInfo.proceedingNo).subscribe(
      (partyType: any) => {
        if (
          partyType.toLowerCase() === 'jr.party' ||
          partyType.toLowerCase() === 'sr.party'
        ) {
          this.isPartyOnCase = true;
        }
      },
      (partyTypeError) => {
        console.log(partyTypeError);
        if (
          partyTypeError?.error?.text?.toLowerCase() === 'jr.party' ||
          partyTypeError?.error?.text?.toLowerCase() === 'sr.party'
        ) {
          this.isPartyOnCase = true;
        }
      }
    );
  }
}
