import { Component, OnInit } from '@angular/core';
// import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { ActivatedRoute } from '@angular/router';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { TrialsService } from 'src/app/services/trials.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { DatePipe } from '@angular/common';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-interference',
  templateUrl: './interference.component.html',
  styleUrls: ['./interference.component.less'],
})
export class InterferenceComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  caseInfo: CaseInfoModel = {
    // serialNo: null,
    proceedingNo: null,
    scrollToId: null,
  };
  isTrialsCase: boolean = true;
  unsavedChanges: boolean = true;
  applications = null;
  expanded = false;
  isPartyOnCase: boolean = false;

  constructor(
    private store: Store<CaseViewerState>,
    private activatedRoute: ActivatedRoute,
    private trialsService: TrialsService,
    private ifilingService: IfilingService,
    private datePipe: DatePipe,
  ) {}

  ngOnInit(): void {
    this.caseInfo = {
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };
    window.sessionStorage.setItem('caseInfo', JSON.stringify(this.caseInfo));
    // this.store.dispatch(
    //   CaseViewerActions.setCaseInfoAction({ payload: this.caseInfo })
    // );
    document.title = `${this.caseInfo.proceedingNo} - Case viewer`
    this.getIfPartyOnCase();
    this.getApplications();
  }

  displayApplications(){
    this.expanded = !this.expanded;
  }

  getApplications() {
    this.ifilingService.getApplications(this.caseInfo.proceedingNo).subscribe(
      (applicationsResponse) => {
        this.applications = applicationsResponse;
        this.applications.forEach(application => {
          if(application.filingDate) {
            application.filingDate = this.datePipe.transform( application.filingDate,'MM/dd/yyyy');
          }
        });   
      },
      (applicationsFailure) => {
        console.log(applicationsFailure);
      }
    );
  }

  getIfPartyOnCase() {
    this.ifilingService.getIfPartyOnCase(this.caseInfo.proceedingNo).subscribe((partyType: any) => {
       if (partyType.toLowerCase() === 'jr.party' || partyType.toLowerCase() === 'sr.party') {
        this.isPartyOnCase = true;
       } 
    })
  }
}
