import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Urls } from 'src/app/constants/urls';
import { DatePipe } from '@angular/common';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class InterferenceService {

  private IFILING_BASE_URL = environment.IFILING_SERVICE_API;

  constructor(private http: HttpClient, private datePipe: DatePipe) { }

  caseSearch(proceedingNumber: string): Observable<any> {
    const userName = window.sessionStorage.getItem('email')
    let url = null;
    if (!userName || userName === 'anonymous') {
      url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.PUBLIC_SEARCH}${proceedingNumber}`;
    } else {
    url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.SEARCH}${proceedingNumber}`;
    }

    return this.http
      .get<any>(url)
      .pipe(
        map((caseSearchResponse) => {
          return caseSearchResponse;
        })
      );
  }

  caseSearchPublic(proceedingNumber: string): Observable<any> {
    let url = `${this.IFILING_BASE_URL}${Urls.CASEVIEWER.PUBLIC_SEARCH}${proceedingNumber}`;

    return this.http
      .get<any>(url)
      .pipe(
        map((caseSearchResponse) => {
          return caseSearchResponse;
        })
      );
  }
}
