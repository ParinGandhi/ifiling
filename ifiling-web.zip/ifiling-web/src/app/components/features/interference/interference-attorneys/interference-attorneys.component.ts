import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import CaseDetailsModel from 'src/app/models/cases/CaseDetails.model';
import { ActivatedRoute } from '@angular/router';
import { IfilingService } from 'src/app/services/ifiling.service';
import { CommonService } from 'src/app/services/common.service';
import { Store, select } from '@ngrx/store';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { TrialsService } from 'src/app/services/trials.service';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { AddAttorneysModalComponent } from './add-attorneys-modal/add-attorneys-modal.component';

@Component({
  selector: 'app-interference-attorneys',
  templateUrl: './interference-attorneys.component.html',
  styleUrls: ['./interference-attorneys.component.scss'],
})
export class InterferenceAttorneysComponent implements OnInit {
  resizeGrid = () => {
    this.gridParams.gridApi.sizeColumnsToFit();
  };
  
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  addAttorneyModelRef: BsModalRef;
  gridParams = new GridParamsModel();
  isPartyOnCase: boolean = false;

  orderByField: any[] = [];

  caseDetails: CaseDetailsModel;
  caseInfo: CaseInfoModel = {
    // serialNo: null,
    proceedingNo: null,
  };
  filterObj: any = {};

  lastRefresh = new Date();

  attorneysList;
  rowData = {
    attorneysData: [],
  };

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
  };

  columnDefs = {
    attorneys: [
      {
        field: 'applicationNo',
        headerName: 'Application #',
        sort: 'desc',
        sortIndex: 1,
        resizable: true,
      },
      {
        field: 'attorneyNo',
        headerName: 'Attorney #',
        resizable: true,
      },
      {
        field: 'attorneyName',
        headerName: 'Attorney name',
        resizable: true,
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'attorneyType',
        headerName: 'Attorney type',
        resizable: true,
        sort: 'desc',
        sortIndex: 2,
      },
    ],
  };
  isPublic: boolean = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private ifilingService: IfilingService,
    private commonService: CommonService,
    private store: Store,
    public gridHelperService: GridHelperService,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {
    this.caseInfo = {
      // serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };

    // this.store.dispatch(
    //   GetCasePhaseAction({ url: this.caseInfo.proceedingNo })
    // );
    this.orderByField = [];
    const from = window.sessionStorage.getItem('from');
    this.isPublic = from === 'public';
    this.getIfPartyOnCase();
    this.getAttorneys();
  }

  ngOnDestroy() {
    window.removeEventListener('resize', this.resizeGrid);
  }

  refresh() {
    this.orderByField = [];
    this.lastRefresh = new Date();
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'Attorneys';
    this.gridParams.gridApi.sizeColumnsToFit();
    window.addEventListener('resize', this.resizeGrid);
  }

  getAttorneys() {
    this.ifilingService.getApplications(this.caseInfo.proceedingNo).subscribe(
      (applicationsResponse) => {
        // console.log(applicationsResponse);
        let attorneysListData = [];
        this.attorneysList = applicationsResponse;
        this.attorneysList.forEach((element) => {
          if (element.proceedingPartyMaps && element.proceedingPartyMaps.length > 0) {
            element.proceedingPartyMaps.forEach((party) => {
              if (party?.juniorParty) {
                party.juniorParty?.parties.forEach((ele) => {
                  let obj = {
                    applicationNo: '',
                    attorneyNo: '',
                    attorneyName: '',
                    attorneyType: '',
                  };
                  obj.applicationNo = element.applicationId;
                  obj.attorneyNo = ele?.registrationNo;
                  obj.attorneyType = ele?.partySubType;
                  obj.attorneyName =
                    ele?.personType[0]?.firstName +
                    ' ' +
                    ele?.personType[0]?.lastName;
                  attorneysListData.push(obj);
                });
              } else if (party?.seniorParty) {
                party.seniorParty?.parties.forEach((ele) => {
                  let obj = {
                    applicationNo: '',
                    attorneyNo: '',
                    attorneyName: '',
                    attorneyType: '',
                  };
                  obj.applicationNo = element.applicationId;
                  obj.attorneyNo = ele?.registrationNo;
                  obj.attorneyType = ele?.partySubType;
                  obj.attorneyName =
                    ele?.personType[0]?.firstName +
                    ' ' +
                    ele?.personType[0]?.lastName;
                  attorneysListData.push(obj);
                });
              }
            });
          }
        });
        this.rowData.attorneysData = attorneysListData;
      },
      (applicationsFailure) => {
        console.log(applicationsFailure);
      }
    );
  }

  openAddAttorneyModal() {
    const initialState: any = {
      modal: {
        caseNo: this.caseInfo.proceedingNo,
        attorneys: this.attorneysList,
        isConfirm: false,
      },
    };
    this.addAttorneyModelRef = this.modalService.show(
      AddAttorneysModalComponent,
      {
        animated: true,
        backdrop: true,
        ignoreBackdropClick: true,
        class: 'modal-md',
        initialState,
      }
    );
    this.addAttorneyModelRef.onHide.subscribe((reason: string | any) => {
      // console.log('reason: ', reason);
      if (reason.initialState.modal.isConfirm) {
        this.getAttorneys();
      }
    });
  }

  getIfPartyOnCase() {
    this.ifilingService.getIfPartyOnCase(this.caseInfo.proceedingNo).subscribe((partyType: any) => {
       if (partyType.toLowerCase() === 'jr.party' || partyType.toLowerCase() === 'sr.party') {
        this.isPartyOnCase = true;
       } 
    }, (partyTypeError) => {
      console.log(partyTypeError);
      if (partyTypeError?.error?.text?.toLowerCase() === 'jr.party' || partyTypeError?.error?.text?.toLowerCase() === 'sr.party') {
        this.isPartyOnCase = true;
       } 
    })
  }
}
