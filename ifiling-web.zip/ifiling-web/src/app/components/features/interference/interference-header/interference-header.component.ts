import { Component, OnInit } from '@angular/core';
import CaseHeaderModel from 'src/app/models/cases/CaseHeader.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { TrialsService } from 'src/app/services/trials.service';
import { IfilingService } from 'src/app/services/ifiling.service';
import { Store, select } from '@ngrx/store';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';
import CaseInfoModel from 'src/app/models/CaseInfo.model';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { Observable } from 'rxjs';
import { CaseViewerService } from 'src/app/services/case-viewer.service';
import { ActivatedRoute } from '@angular/router';
// import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
// import { PanelingComponent } from '../../workspace/modals/paneling/paneling.component';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
import { DatePipe } from '@angular/common';
// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-interference-header',
  templateUrl: './interference-header.component.html',
  styleUrls: ['./interference-header.component.less'],
})
export class InterferenceHeaderComponent implements OnInit {
  // loggedInUser$ = this.store.pipe(select(CaseViewerSelectors.userInfoData));
  caseInfo: CaseInfoModel;
  expanded: boolean = true;
  petitionerPatentNumber: any;
  caseHeaderInfo: CaseHeaderModel;
  getCaseHeader$: Observable<any>;
  getCasePhase$ = this.store.pipe(select(CaseViewerSelectors.casePhaseData));
  panelOnCase: Array<any> = [];
  parties: string = null;
  palmUrls: any;
  // updatePanelModalRef: BsModalRef;
  loggedInUser = null;
  canEdit: boolean = false;
  editMode: boolean = false;
  derivationAvailabilityList: Array<any> = [];
  referenceMileStoneDateString:any;
  declarationEditMode: boolean = false;

  constructor(
    private store: Store<CaseViewerState>,
    private activatedRoute: ActivatedRoute,
    private trialsService: TrialsService,
    private ifilingService: IfilingService,
    private commonUtils: CommonUtilitiesService,
    private caseViewerService: CaseViewerService,
    // private modalService: BsModalService,
    // private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.caseInfo = {
      // serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };
    // this.store
    //   .pipe(select(CaseViewerSelectors.userInfoData))
    //   .subscribe((data) => {
    //     this.loggedInUser = data.caseDetailsData[0];
    //     if (!this.loggedInUser) {
    //       this.loggedInUser = JSON.parse(
    //         window.sessionStorage.getItem('userInfo')
    //       );
    //     }
    //     this.canEdit =
    //       this.loggedInUser.roleDescription ===
    //         PtabTrialConstants.ROLES.ADMIN ||
    //       this.loggedInUser.roleDescription === PtabTrialConstants.ROLES.SPL;
    //   });
    this.getCaseHeaderInfo(this.caseInfo);
    // this.getPanelInfo();
    // this.getPartiesInfo(this.caseInfo);
    // this.getPalmUrls();
    // this.derivationAvailabilityList = [];
    // this.derivationAvailabilityList.push('Public');
    // this.derivationAvailabilityList.push('Not Public');
  }

  getCaseHeaderInfo(caseInfo) {
    this.ifilingService
      .getCaseHeaderInfo(caseInfo.proceedingNo)
      .subscribe((caseHeaderInfoResponse) => {
        this.caseHeaderInfo = caseHeaderInfoResponse;
        window.sessionStorage.setItem(
          'caseInfo',
          JSON.stringify(caseHeaderInfoResponse[0])
        );
        if (this.caseHeaderInfo.judgementDate) {
          this.caseHeaderInfo.judgementDate = this.commonUtils.convertDateToString(this.caseHeaderInfo.judgementDate)
        }
        if (this.caseHeaderInfo.declarationDate) {
          this.caseHeaderInfo.declarationDate = this.commonUtils.convertDateToString(this.caseHeaderInfo.declarationDate)
        }
        // let confidentiality: any;
        // confidentiality = this.caseHeaderInfo
        //   ? this.caseHeaderInfo.derproceedingTypeDetails
        //   : null;
        // this.commonUtils.confidentialityInfo =
        //   confidentiality?.poConfidentialityIn;
      });
  }

  // getPanelInfo() {
  //   this.trialsService
  //     .getPaneledJudges(this.caseInfo.proceedingNo, false)
  //     .subscribe(
  //       (paneledJudgesResponse) => {
  //         this.panelOnCase = paneledJudgesResponse.listofJudges;
  //       },
  //       (paneledJudgesFailure) => {
  //         this.panelOnCase = [];
  //       }
  //     );
  // }

  // getPartiesInfo(caseInfo) {
  //   this.trialsService
  //     .getCaseHeaderInfo(caseInfo.proceedingNo)
  //     .subscribe((partiesResponse) => {
  //       this.parties = null;
  //       if (partiesResponse && partiesResponse[0]) {
  //         this.parties = partiesResponse[0].parties;
  //       }
  //     });
  // }

  // getPalmUrls() {
  //   this.caseViewerService.getOpenPalm().subscribe((response) => {
  //     this.palmUrls = response;
  //     console.log(this.palmUrls);
  //   });
  // }

  // getMilestoneDate(dateString: string) {
  //   let dateValue = Date.parse(dateString + 'T00:00');
  //   return dateValue;
  // }

  getDateString(pipeValue) {
    let currentDate:any = new Date();
    const datepipe: DatePipe = new DatePipe('en-US');
    let aDate = new Date(0); // The 0 there is the key, which sets the date to the epoch
    aDate.setUTCSeconds(currentDate/1000);
    return datepipe.transform(aDate, pipeValue);
  }

}
