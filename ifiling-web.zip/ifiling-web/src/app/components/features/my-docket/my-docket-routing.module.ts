import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InterferencesComponent } from './interferences/interferences.component';
import { MyDocketComponent } from './my-docket.component';

const myDocketRoutes: Routes = [
  {
    path: '',
    component: MyDocketComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'interferences',
      },
      {
        path: 'interferences',
        component: InterferencesComponent,
        // canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(myDocketRoutes)],
  exports: [RouterModule],
})
export class MyDocketRoutingModule {}
