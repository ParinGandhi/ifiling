import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { MyDocketService } from '../my-docket.services';

import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { OpenCaseViewerComponent } from 'src/app/components/common/open-case-viewer/open-case-viewer.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-interferences',
  templateUrl: './interferences.component.html',
  styleUrls: ['./interferences.component.scss'],
})
export class InterferencesComponent implements OnInit {
  // loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  resizeGrid = () => {
    this.gridParams.gridApi.sizeColumnsToFit();
  };
  gridParams = new GridParamsModel();
  applications = [];
  loggedInUser = null;

  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
  };

  colWidth = '15%';

  columnDefs = [
    {
      field: 'proceedingNo',
      headerName: 'Interference #',
      width: this.colWidth,
      resizable: true,
      sort: 'desc',
      cellRendererFramework: OpenCaseViewerComponent,
      cellRendererParams: { fromComponent: 'myDocket' },
    },
    {
      field: 'applicationId',
      headerName: 'Application #',
      width: this.colWidth,
      resizable: true,
    },
    {
      field: 'patentNo',
      headerName: 'Patent #',
      width: this.colWidth,
      resizable: true,
    },
    {
      field: 'inventorName',
      headerName: 'Invention title',
      resizable: true,
      // comparator: this.gridHelper.dateComparator,
    },
    {
      field: 'patryName',
      headerName: 'Party name',
      width: '35%',
      resizable: true,
    },
  ];

  constructor(
    private gridHelper: GridHelperService,
    private myDocketService: MyDocketService,
    private store: Store<PtactsState>,
    private commonUtils: CommonUtilitiesService
  ) {}

  ngOnInit(): void {
    this.store
      .select(PtactsSelectors.getUserDetailsState)
      .subscribe((userDetails) => {
        this.loggedInUser = userDetails;
        this.getMyDocketCases(this.loggedInUser.emailAddress);
      });
  }

  ngOnDestroy() {
    window.removeEventListener('resize', this.resizeGrid);
  }

  getMyDocketCases(loggedInUserEmail) {
    this.myDocketService
      .getMyInterferences(loggedInUserEmail)
      .pipe(take(1))
      .subscribe((myDcoketResponse) => {
        this.applications = myDcoketResponse;
      });
  }

  onGridReady(params) {
    this.gridParams = this.gridHelper.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'myDocket';
    params.api.sizeColumnsToFit();
    window.addEventListener('resize', this.resizeGrid);
  }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colId === 'proceedingNo') {
      this.commonUtils.openCaseViewerFromMyDocket(e.data.proceedingNo);
    }
  }
}
