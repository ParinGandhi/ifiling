import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterferencesComponent } from './interferences.component';

describe('InterferencesComponent', () => {
  let component: InterferencesComponent;
  let fixture: ComponentFixture<InterferencesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterferencesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
