/**
 * ! Example service for the user component. Business logic should be performed to the response
 * ! before returning it to the component.
 * ! Common functionality can still be in a separate service file that can be injected into
 * ! each service.
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Urls } from 'src/app/constants/urls';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { environment } from 'src/environments/environment';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class MyDocketService {
  private EXTERNAL_SERVICE_BASE = environment.EXTERNAL_SERVICE_API;
  private IFILING_SERVICE_BASE: string = environment.IFILING_SERVICE_API;

  constructor(private http: HttpClient) {}

  //    getHeaders() {
  //      const emailId = window.sessionStorage.getItem('email');
  //      const httpOptions = {
  //        headers: new HttpHeaders({
  //          'Content-Type': 'application/json',
  //          'user-name': emailId,
  //        }),
  //        withCredentials: true,
  //        crossDomain: true,
  //      };

  //      return httpOptions;
  //    }

  /** Add pending reviews calls and logic here  */
  getMyInterferences(emailId): Observable<any> {
    return (
      this.http
        .get<any>(
          `${this.IFILING_SERVICE_BASE}/docket?userId=${emailId}`
        )

        // .get<any>(
        //   `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?username=${emailId}&proceedingState=ext-pending-aia-reviews`,
        //   this.getHeaders()
        // )
        .pipe(
          map((myDocketInterferences) => {
            return myDocketInterferences;
          })
        )
    );
  }
}
