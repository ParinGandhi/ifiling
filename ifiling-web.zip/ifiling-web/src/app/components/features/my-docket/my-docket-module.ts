import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyDocketComponent } from './my-docket.component';
import { MyDocketRoutingModule } from './my-docket-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [MyDocketComponent],
  imports: [CommonModule, MyDocketRoutingModule, SharedModule],
})
export class MyDocketModule {}
