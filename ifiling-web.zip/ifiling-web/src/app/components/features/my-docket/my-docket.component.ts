import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-docket',
  templateUrl: './my-docket.component.html',
  styleUrls: ['./my-docket.component.scss']
})
export class MyDocketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    document.title = 'My docket';
  }

}
