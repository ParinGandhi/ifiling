import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Urls } from 'src/app/constants/urls';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class HomeService {
  private EXTERNAL_SERVICE_BASE: string = environment.EXTERNAL_SERVICE_API;
  private IFILING_SERVICE_BASE: string = environment.IFILING_SERVICE_API;
  constructor(private http: HttpClient) {}

  getUsers(loginInfo): Observable<any> {
    return this.http.post<any>(Urls.USERS.GET, loginInfo).pipe(
      map((userResponse) => {
        return userResponse;
      })
    );
  }

  // TODO Change to external service
  getUserInfo(emailAddress: string) {
    return this.http
      .get<any>(
        // `${this.COMMON_BASE_URL}/login-external-user-details?emailAddressText=${emailAddress}`
        `${this.IFILING_SERVICE_BASE}/login-external-user-details?emailAddressText=${emailAddress}`
      )
      .pipe(
        map((userInfo) => {
          return userInfo;
        })
      );
  }

  getLoggedInUserDetails() {
    return this.http.get(`${this.IFILING_SERVICE_BASE}/who-am-i`).pipe(
    // return this.http.get(`https://ptacts-extservices.pvt.uspto.gov/ifiling/who-am-i`).pipe(
      map((loggedInUserDetails) => {
        return loggedInUserDetails;
      })
    );
  }

  signOut(signoutLandingUrl) {
    // const currentHeader = this.headerService.getCurrentHeaderValues();
    // const appProps = currentHeader.appConfig.appProps;
    // const logoutUrl = appProps.MY_URL + '/home';
    // https://rbac-services-fqt.etc.uspto.gov/rbac/services - any non-prod
    //https://rbac-services.uspto.gov/rbac/services - pord
    this.http
      // .get(environment.ENV_SERVICES + '/authentication/logout/urls', {
      .get(signoutLandingUrl.rbacServicesUrl + '/authentication/logout/urls', {
        withCredentials: true,
      })
      .subscribe((urls: Array<String>) => {
        urls.forEach((url) => {
          if (url.indexOf('TAB') != -1) {
            var new_Window = window.open(url.split('::')[1], '_blank');
            setTimeout(() => {
              new_Window.close();
            }, 2000);
          } else if (url.indexOf('LANDING') != -1) {
            setTimeout(() => {
              // window.location.href = url.split('::')[1];
              // window.location.href =
              //   'https://rbac-services-fqt.etc.uspto.gov/rbac/pages/logout-landing-return.html?appUrl=https://ptacts-pvt.etc.uspto.gov/ptacts/ui/home';
              window.location.href = `${signoutLandingUrl.signoutLandingUrl}${this.IFILING_SERVICE_BASE}/ui/home`;
            }, 3000);
          } else {
            this.http
              .get('' + url, { withCredentials: true, responseType: 'text' })
              .subscribe((data) => {});
          }
        });
      });

    window.localStorage.clear();
  }
}
