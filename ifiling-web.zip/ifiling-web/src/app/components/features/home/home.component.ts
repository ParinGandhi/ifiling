import { Component, OnInit } from '@angular/core';
// import { Store } from '@ngrx/store';
// import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
// import { setAnonymousSearch } from 'src/app/store/ptacts/ptacts.actions';
// import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { Router } from '@angular/router';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  selectedSearchType: string = 'Application No.';
  invalidSearch: string = null;
  searchText: string = null;
  noResults: boolean = false;
  // caseSearch: CaseSearchModel = new CaseSearchModel();

  // constructor(private store: Store<PtactsState>, private router: Router) {}
  constructor(private router: Router,private commonUtils: CommonUtilitiesService) {}

  ngOnInit(): void {
    // const userName = window.sessionStorage.getItem('email');
    // if (userName && userName !== 'anonymous') {
    //   this.router.navigate(['ui/my-docket']);
    // }
  }

  selectSearchType(e) {
    this.selectedSearchType = e;
  }

  search(text) {
    this.noResults = true;
    this.invalidSearch = null;
    if (this.selectedSearchType == 'Application No.') {
      if (!text || !text.match('^[0-9]{8}$')) {
        this.invalidSearch = 'application number';
        this.noResults = false;
      }
      else{
        this.redirectToSearch(text,this.selectedSearchType);
      }
    } else if (this.selectedSearchType == 'Interference No.') {
      if (!text || !text.match('^[0-9]{6}$')) {
        this.invalidSearch = 'interference number';
        this.noResults = false;
      }
      else{
        this.redirectToSearch(text,this.selectedSearchType);
      }
    } else if (this.selectedSearchType == 'Patent No.') {
      if (!text || !text.match('^[0-9]{7,8}$')) {
        this.invalidSearch = 'patent number';
        this.noResults = false;
      }
      else{
        this.redirectToSearch(text,this.selectedSearchType);
      }
    } else if (this.selectedSearchType == 'Party Name') {
      if (!text|| !text.match('^[a-zA-Z0-9_]+$')) {
        this.invalidSearch = 'party name';
        this.noResults = false;
      }
      else{
        this.redirectToSearch(text,this.selectedSearchType);
      }
    }

    // window.sessionStorage.setItem('email', 'anonymous');
    // this.caseSearch.trailTypes = [];
    // this.trialTypes.forEach((trialType) => {
    //   if (trialType.checked) {
    //     this.caseSearch.trailTypes.push(trialType.name);
    //   }
    // });

    // this.store.dispatch(
    //   setAnonymousSearch({
    //     anonymousSearch: JSON.parse(JSON.stringify(this.caseSearch)),
    //   })
    // );

    // this.router.navigate(['/ui/public-search']);
  }

  redirectToSearch(textValue,type){
    let searchInfo = {
      text:textValue,
      searchType:type
    };
    window.sessionStorage.setItem(
      'searchInfo',
      JSON.stringify(searchInfo)
    );
    // this.router.navigate(['/ui/public-search']);
    //window.open('/public-search', "_blank");
    this.commonUtils.openInNewTab('/public-search');
    this.noResults = false;
  }
}
