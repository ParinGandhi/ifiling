import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-document-section',
  templateUrl: './document-section.component.html',
  styleUrls: ['./document-section.component.scss'],
})
export class DocumentSectionComponent implements OnInit {
  @Input() motionsForm: FormGroup;

  constructor() {}

  ngOnInit(): void {}
}
