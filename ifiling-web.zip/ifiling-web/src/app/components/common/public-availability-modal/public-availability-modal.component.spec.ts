import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicAvailabilityModalComponent } from './public-availability-modal.component';

describe('PublicAvailabilityModalComponent', () => {
  let component: PublicAvailabilityModalComponent;
  let fixture: ComponentFixture<PublicAvailabilityModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PublicAvailabilityModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicAvailabilityModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
