import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PtabTrialConstants } from 'src/app/constants/ptab-trials.constants';
// import * as CaseViewerActions from 'src/app/store/case-viewer/case-viewer.actions';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';

import { Store, select } from '@ngrx/store';
import { JpViewService } from 'src/app/services/jpview.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.less']
})
export class DataTableComponent {
  @Output() sortColumnEmitter: EventEmitter<any> = new EventEmitter();
  @Output() pdfEmitter: EventEmitter<any> = new EventEmitter();
  @Output() rowSelection: EventEmitter<any> = new EventEmitter();
  @Output() caseInfoEmitter: EventEmitter<any> = new EventEmitter();

  @Input() tableOptions: any;
  @Input() orderByField?: any;
  @Input() enableCheckbox?: boolean;
  show=true;
  constructor(
    private store: Store<CaseViewerState>,
    private jpViewService: JpViewService,
    private commonUtils: CommonUtilitiesService) { }
  keys: string[];


  getNumberOfFilters() {
    let count = 0;
    if (this.tableOptions && this.tableOptions.columnDefs && this.tableOptions.columnDefs.length > 0) {
      this.tableOptions.columnDefs.forEach(column => {
        if (column.searchText && column.searchText !== "" && column.searchText !== null) {
          count++;
        }
      });
    }
    return count;
  }

  clearAll() {
    this.tableOptions.columnDefs.forEach(column => {
      column.searchText = null;
    });
  }

  sortColumn(columnToSort) {
    this.sortColumnEmitter.emit(columnToSort);
  }

  openPdf(data, colName) {
    if (colName) {
      const dataToEmit = {
        colName: colName,
        data: data
      };
      this.pdfEmitter.emit(dataToEmit);
    } else {
      this.pdfEmitter.emit(data);
    }
  }

  openCaseViewer = function (data) {
    this.commonUtils.openInCaseViewer(data.relatedProceedingNo);
  // this.jpViewService.getDocuments(`${PtabTrialConstants.CASE_VIEWER_URL}/case-viewer/caseNumber-search?caseNumber=${data.relatedProceedingNo}`).subscribe((searchDetails) => {
  //   console.log(searchDetails);
  //   this.workspace = false;
  //   let caseInfo = {
  //     "serialNo": searchDetails.serialNumber[0].trim(),
  //     "proceedingNo": searchDetails.appealNumber[0],
  //     "scrollToId": 'documents'
  //   }
  //   this.store.dispatch(CaseViewerActions.setCaseInfoAction({ payload: caseInfo }));
  //   window.sessionStorage.setItem('caseInfo', JSON.stringify(caseInfo));
  //   let currentUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
  //   this.caseNumberSearch = null;
  //   let newTabUrl = `${window.location.protocol}//${window.location.hostname}`;
  //   newTabUrl += window.location.port !== "" ? `:${window.location.port}` : "";
  //   newTabUrl += window.location.hostname === 'localhost' ? `/#/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents` :
  //    `${PtabTrialConstants.BASE_URL}/#` +`/case-viewer/${caseInfo.serialNo}/${caseInfo.proceedingNo}/documents`;

  //   let prefix = "fromJudgePortal"
  //     window.open(newTabUrl, prefix + JSON.stringify({
  //             "caseInfo": caseInfo,
  //             "currentUser": currentUser
  //     }));
  // }, (caseSearchError) => {
  //   console.log('caseSearchError: ', caseSearchError);
  //   this.toastr.error(`Case number ${this.caseNumberSearch} not found. Please check the number and try again.`, "", {
  //     closeButton: true
  //   } );
  // })
  };

  onSelection(row, qty, record) {
    let rowData = {
      row: row,
      valueToEmit: null
    }
    if (qty === 'all') {
      let allCheckboxes: any = document.getElementsByClassName(this.tableOptions.checkboxClass);
      for (let i = 0; i < allCheckboxes.length; i++) {
        allCheckboxes[i].checked = row.target.checked;
      }
      rowData.valueToEmit = row.target.checked ? 'all' : 'none'
    } else {
      rowData.valueToEmit = record;
    }
    this.rowSelection.emit(rowData);
  }

}
