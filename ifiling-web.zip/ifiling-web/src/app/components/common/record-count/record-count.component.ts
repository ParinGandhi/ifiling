import { Component, Input, OnInit } from '@angular/core';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';

@Component({
  selector: 'app-record-count',
  templateUrl: './record-count.component.html',
  styleUrls: ['./record-count.component.scss']
})
export class RecordCountComponent implements OnInit {
  @Input() recordCountInfo: RecordCountModel;

  constructor() { }

  ngOnInit(): void {
  }

  calculateShowingFrom() {
    if (this.recordCountInfo.lastPage) {
      return (
        Math.floor(
          this.recordCountInfo.dataLength /
            this.recordCountInfo.paginationPageSize
        ) *
          this.recordCountInfo.paginationPageSize +
        1
      );
    } else {
      return (
        this.recordCountInfo.currentPage *
          this.recordCountInfo.paginationPageSize -
        (this.recordCountInfo.paginationPageSize - 1)
      );
    }
  }

  calculateShowingTo() {
    if (
      this.recordCountInfo.paginationPageSize *
        this.recordCountInfo.currentPage <
      this.recordCountInfo.dataLength
    ) {
      return (
        this.recordCountInfo.paginationPageSize *
        this.recordCountInfo.currentPage
      );
    } else {
      return this.recordCountInfo.dataLength;
    }
  }

}
