import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { MyDocketService } from 'src/app/components/features/my-docket/my-docket.services';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { DeleteModalComponent } from 'src/app/components/common/delete-modal/delete-modal.component';
import { take } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { IfilingService } from 'src/app/services/ifiling.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-list-of-documents',
  templateUrl: './list-of-documents.component.html',
  styleUrls: ['./list-of-documents.component.scss'],
})
export class ListOfDocumentsComponent implements OnInit {
  @Input() addedDocumentsList: any;
  @Input() editMode: boolean;
  @Input() loading: boolean;
  @Input() proceedingIdentifier: string;
  @Output() docToEditEmitter = new EventEmitter<any>();
  @Output() onePaperMin = new EventEmitter<boolean>();
  @Output() paperTypeIsNeeded = new EventEmitter<boolean>();
  caseInfo: any;
  // petitionIdentifier: any;

  constructor(
    private modalService: BsModalService,
    private modalRef: BsModalRef,
    private commonUtils: CommonUtilitiesService,
    private ifilingService: IfilingService,
    private commonService: CommonService,
    private logger: NGXLogger
  ) {}

  ngOnInit(): void {
    if (window.sessionStorage.getItem('caseInfo')) {
      this.caseInfo = window.sessionStorage.getItem('caseInfo');
    }
    this.loading;
    // this.getPetitionIdentifier();
  }

  edit(docToEdit, index) {
    this.docToEditEmitter.emit(index);
  }

  verifyDelete(index) {
    const initialState: any = {
      modal: {
        deleteDocument: false,
      },
    };
    this.modalRef = this.modalService.show(DeleteModalComponent, {
      id: 2,
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.deleteDocument) {
        this.deleteDocument(index);
      }
    });
  }

  deleteDocument(index) {
    const artifactID = this.addedDocumentsList[index].artifactIdentifer;
    if (artifactID) {
      this.ifilingService
        .deleteDocument(artifactID)
        .pipe(take(1))
        .subscribe(
          (deleteDocumentSuccess) => {
            this.addedDocumentsList.splice(index, 1);
            this.logger.info(
              'Document deleted successfully',
              deleteDocumentSuccess
            );
            this.commonUtils.showSuccess(
              'Document deleted successfully',
              'Delete document'
            );
            this.checkForMEssages();
          },
          (deleteDocumentFailure) => {
            this.logger.error(
              'Failed to delete document',
              deleteDocumentFailure
            );
            this.commonUtils.showError(
              deleteDocumentFailure.error.message,
              'Delete document'
            );
          }
        );
    } else {
      this.addedDocumentsList.splice(index, 1);
      this.logger.info('Document deleted successfully');
      this.checkForMEssages();
      this.commonUtils.showSuccess(
        'Document deleted successfully',
        'Delete document'
      );
    }
  }

  checkForMEssages() {
    if (this.addedDocumentsList.length <= 0) {
      this.onePaperMin.emit(true);
    }
    if (this.addedDocumentsList.length > 0) {
      let paperNeeded = true;
      this.addedDocumentsList.forEach((doc) => {
        if (doc.docType.toLowerCase() === 'paper') {
          paperNeeded = false;
        }
      });
      // this.paperTypeIsNeeded.emit(paperNeeded);
      this.onePaperMin.emit(paperNeeded);
    }
  }

  openPdf(data) {
  this.commonService
    .openPdfFromMount(data, this.proceedingIdentifier)
    .subscribe((pdfResponse) => {
      console.log(pdfResponse);
      var file = new Blob([pdfResponse], { type: 'application/pdf' });
      var fileURL = URL.createObjectURL(file);
      window.open(fileURL);
    });
  }

  // if (data.artifactIdentifer) {
  // this.commonService.openPdf(
  //   this.proceedingIdentifier,
  //   data.artifactIdentifer
  // )
  //   } else {
  //     this.initiatePetitionService
  //       .openPdfWithFileName(
  //         `/petitions/${this.proceedingIdentifier}/documents?fileName=${data.fileToUpload.name}`
  //       )
  //       .subscribe(
  //         (pdfResponse: any) => {
  //           console.log(pdfResponse);
  //           var file = new Blob([pdfResponse], { type: 'application/pdf' });
  //           var fileURL = URL.createObjectURL(file);
  //           window.open(fileURL);
  //         },
  //         (pdfFailure) => {
  //           console.log(pdfFailure);
  //         }
  //       );
  //   }
  // }
}
