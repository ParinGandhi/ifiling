import { ElectronicAddress } from './ElectronicAddress.model';
import { MailingAddress } from './MailingAddress.model';

export class PersonType {
  identifier: string = null;
  firstName: string = null;
  lastName: string = null;
  middleInitial?: string = null;
  prefferedName: string = null;
  mailingAddress: Array<MailingAddress> = [new MailingAddress()];
  electronicAddress: Array<ElectronicAddress> = [new ElectronicAddress()];
}
