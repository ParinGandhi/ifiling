export class ElectronicAddress {
  identifier: string = null;
  teleCommAddresType?: string = null;
  telephoneNumber?: string = null;
  email?: string = null;
  emailType?: string = null;
  extension: string = null;
  fax?: string = null;

  constructor() {}
}
