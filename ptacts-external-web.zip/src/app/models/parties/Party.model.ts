import { OrgType } from './OrgType.model';
import { PersonType } from './PersonType.model';

export class Party {
  identifier: string = null;
  rankNo: number = null;
  partyType: string = null;
  partySubType: string = null;
  partySubTypeDescription: string = null;
  registrationNo: string = null;
  submitterType: string = null;
  personType: Array<PersonType> = [new PersonType()];
  orgType: Array<OrgType> = [new OrgType()];
  proseIndicator: string = null;

  constructor() {}
}
