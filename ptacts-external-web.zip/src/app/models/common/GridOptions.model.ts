export class GridOptionsModel {
  columnDefs: Array<any> = [];
  rowData: Array<any> = [];
  headerHeight: number = 48;
  defaultColDef = {
    filter: true,
    sortable: true,
    floatingFilter: true,
    suppressMenu: true,
    suppressMovable: true,
    resizable: true,
    tooltipComponent: 'customTooltip',
  };

  constructor() {}
}
