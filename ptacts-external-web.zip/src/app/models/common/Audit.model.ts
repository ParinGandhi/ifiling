export class Audit {
  lastModifiedUserIdentifier: string;
  createUserIdentifier: string;

  constructor() {
    // this.lastModifiedUserIdentifier = 'sbartlett';
    // this.createUserIdentifier = 'sbartlett';
    this.lastModifiedUserIdentifier = window.sessionStorage.getItem('email');
    this.createUserIdentifier = window.sessionStorage.getItem('email');
  }
}
