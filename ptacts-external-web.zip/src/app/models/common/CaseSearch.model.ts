export class CaseSearchModel {
  proceedingNumber: string = null;
  patentNumber: string = null;
  applicationNumber: string = null;
  partyName: null;
  apj1Judge: null;
  apjXJudge: null;
  techCenterNum: null;
  trailTypes: Array<string> = ['IPR', 'PGR', 'CBM', 'DER'];
  inventionTitle: null;
  casePhase: null;
  artUnit: null;
  isMnNotice: boolean = false;

  constructor() {}
}

export class FilterValidations {
  partyNameHasError = false;
  partyNameMessage = null;
  institutionToHasError = false;
  institutionFromHasError = false;
  institutionMessage = null;
  filingToHasError = false;
  filingFromHasError = false;
  filingMessage = null;
  terminationToHasError = false;
  terminationFromHasError = false;
  terminationMessage = null;

  constructor() {}
}

export class FilterParams {
  partyName = null;
  additionalRealParty = true;
  counsel = true;
  institutionDateFrom = null;
  institutionDateTo = null;
  filingDateFrom = null;
  filingDateTo = null;
  terminationDateFrom = null;
  terminationDateTo = null;
  decisionOutcome = null;
  partyDescription = null;
  designPatent = false;
  reissueNumber = false;
  patentDescription = null;

  constructor() {}
}
