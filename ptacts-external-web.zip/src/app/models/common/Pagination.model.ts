export class PaginationModel {
  currentPage: any = 1;
  pageSize: any = 25;
  totalPages: any = null;

  constructor() {}
}
