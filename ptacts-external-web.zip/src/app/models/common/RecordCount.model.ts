import { CONSTANTS } from 'src/app/constants/constants';

export class RecordCountModel {
  currentPage: any = 1;
  paginationPageSize: any = CONSTANTS.PAGINATION.DEFAULT;
  dataLength: any = null;
  lastPage: boolean = false;

  constructor() {}
}
