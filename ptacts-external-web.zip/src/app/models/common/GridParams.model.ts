export class GridParamsModel {
  gridApi: any = null;
  gridColumnApi: any = null;
  numberOfFilters: number = 0;
  fileName: string = null;

  constructor() {}
}
