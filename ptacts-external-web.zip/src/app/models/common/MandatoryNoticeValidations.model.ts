// export interface MandatoryNoticeValidations {
//   validations: {
//     verification: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//     petitionInfo: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//     documents: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//     realParty: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//     additionalRealParty: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//     counsel: {
//       complete: boolean;
//       incomplete: boolean;
//     };
//   };
// }

export class MandatoryNoticeValidations {
  validations: {
    verified: boolean;
    verification: {
      complete: boolean;
      incomplete: boolean;
    };
    petitionInfo: {
      complete: boolean;
      incomplete: boolean;
    };
    documents: {
      complete: boolean;
      incomplete: boolean;
      mnExists: boolean;
    };
    realParty: {
      complete: boolean;
      incomplete: boolean;
      realPartyExists: boolean;
    };
    additionalRealParty: {
      complete: boolean;
      incomplete: boolean;
    };
    counsel: {
      complete: boolean;
      incomplete: boolean;
      leadExists: boolean;
    };
  };

  constructor() {}
}
