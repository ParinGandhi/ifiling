import { Audit } from '../common/Audit.model';
import { PetitionDocument } from '../documents/PetitionDocument.model';
import { InterestedParty } from '../parties/InterestedParty.model';

export class MandatoryNotice {
  partyGroupType: string = null;
  caseNumber: string = null;
  audit: Audit = new Audit();
  petitionDocuments: Array<PetitionDocument> = new Array<PetitionDocument>();
  proceedingParties = {
    audit: new Audit(),
    poRealParty: new InterestedParty(),
    poCounsel: new InterestedParty(),
    submitter: new InterestedParty(),
  };

  constructor() {}
}
