import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
  CanDeactivate,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { map } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { MandatoryNoticeService } from '../components/features/mandatory-notice/mandatory-notice.service';

@Injectable({
  providedIn: 'root',
})
export class ClearState implements CanDeactivate<any> {
  constructor(private mandatoryNoticeService: MandatoryNoticeService) {}

  canDeactivate(
    component: any,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): boolean {
    this.mandatoryNoticeService.clearValidations();
    return true;
  }

  //   canActivate(
  //     route: ActivatedRouteSnapshot,
  //     state: RouterStateSnapshot
  //   ): Observable<boolean | UrlTree> {
  //     return this.store.pipe(
  //       select(PtactsSelectors.ptactsStateData),
  //       map((stateData) => {
  //         if (!stateData.userId) {
  //           this.logger.info(
  //             'User ID from auth guard (false):',
  //             stateData.userId
  //           );
  //           // return this.router.parseUrl('/');
  //           return true;
  //         } else {
  //           this.logger.info('User ID from auth guard (true):', stateData.userId);
  //           return true;
  //         }
  //       })
  //     );
  //   }
}
