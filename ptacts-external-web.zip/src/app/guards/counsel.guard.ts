import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { map } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';

@Injectable({
  providedIn: 'root',
})
export class CounselGuard implements CanActivate {
  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> {
    return this.store.pipe(
      select(PtactsSelectors.getMandatoryNoticeShowCounsel),
      map((stateData) => {
        if (stateData) {
          return true;
        } else {
          //   this.logger.info('User ID from auth guard (true):', stateData.userId);
          this.router.navigate(['/ui/mandatory-notice/verification']);
          return false;
        }
      })
    );
  }
}
