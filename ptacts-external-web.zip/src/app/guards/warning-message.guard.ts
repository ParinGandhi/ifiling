import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
  CanDeactivate,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { map, take } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { CommonUtilitiesService } from '../services/common-utilities.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import {
  setMandatoryNoticeShowCounsel,
  setMandatoryNoticeValidations,
} from '../store/ptacts/ptacts.actions';
import { MandatoryNoticeValidations } from '../models/common/MandatoryNoticeValidations.model';

@Injectable({
  providedIn: 'root',
})
export class WarningMessage implements CanDeactivate<any> {
  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    private router: Router,
    private commonUtils: CommonUtilitiesService,
    private modalService: BsModalService
  ) {}

  canDeactivate(
    component: any,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): Observable<boolean | UrlTree> {
    return new Observable((observer) => {
      const deleteMn = window.sessionStorage.getItem('deleteMn');
      let isFormDirty = false;
      const tempValidations = JSON.parse(JSON.stringify(component.validations));
      component.validations = new MandatoryNoticeValidations();
      component.validations = JSON.parse(JSON.stringify(tempValidations));
      //   component.validations.validations.documents.complete = null;

      switch (component.componentName) {
        case 'documents':
          component.validations.validations.documents.incomplete = true;
          this.logger.info('Doc list', component.addedDocumentsList);
          component.validations.validations.documents.mnExists = false;
          component.addedDocumentsList.forEach((document) => {
            if (document.paperType.code === 'NOT:MN') {
              component.validations.validations.documents.mnExists = true;
            }
          });
          component.validations.validations.documents.complete =
            component.validations.validations.documents.mnExists;
          component.validations.validations.documents.incomplete =
            !component.validations.validations.documents.complete;
          this.store.dispatch(
            setMandatoryNoticeValidations({
              mnValidations: component.validations,
            })
          );
          isFormDirty =
            component.mandatoryNoticeDocumentForm.dirty ||
            component.editMode ||
            (component.mandatoryNoticeDocumentForm.value.selectedPaper &&
              component.mandatoryNoticeDocumentForm.invalid);
          break;
        case 'realParty':
          this.logger.info('Real party form:', component.realPartyForm);
          let realPartyExists = null;
          this.store
            .select(PtactsSelectors.getMandatoryNoticeRealParty)
            .pipe(take(1))
            .subscribe((mnRealParty) => {
              if (mnRealParty) {
                realPartyExists = Object.keys(mnRealParty).length !== 0;
              }
            });
          if (
            component.updateMode &&
            (component.realPartyForm.get('partyType').value.toLowerCase() ===
              'organization' ||
              component.realPartyForm.get('proSe').value.toLowerCase() === 'no')
          ) {
            component.store.dispatch(
              setMandatoryNoticeShowCounsel({ mnShowCounsel: true })
            );
          } else {
            component.store.dispatch(
              setMandatoryNoticeShowCounsel({ mnShowCounsel: false })
            );
          }
          // if (
          //   (component.updateMode &&
          //     component.realPartyForm.get('firstName').value &&
          //     component.realPartyForm.get('lastName').value) ||
          //   component.realPartyForm.get('organizationName').value
          // )
          if (component.updateMode && realPartyExists) {
            component.validations.validations.realParty.complete = true;
            component.validations.validations.realParty.incomplete = null;
          } else {
            component.validations.validations.realParty.incomplete = true;
            component.validations.validations.realParty.complete = null;
          }
          component.validations.validations.realParty.realPartyExists =
            component.validations.validations.realParty.complete;
          this.store.dispatch(
            setMandatoryNoticeValidations({
              mnValidations: component.validations,
            })
          );
          isFormDirty =
            (component.realPartyForm.dirty && !component.updateMode) ||
            (!component.realPartyForm.valid && component.updateMode) ||
            (component.realPartyForm.dirty && component.updateMode) ||
            component.realPartyForm.touched;
          break;
        case 'additionalRealParty':
          if (component.addedRealPartyList.length > 0) {
            component.validations.validations.additionalRealParty.complete =
              true;
          }
          this.store.dispatch(
            setMandatoryNoticeValidations({
              mnValidations: component.validations,
            })
          );
          isFormDirty = component.realPartyForm.dirty || component.editAction;
          break;
        case 'counsel':
          if (component.leadExists) {
            component.validations.validations.counsel.complete = true;
            component.validations.validations.counsel.incomplete = null;
          } else {
            component.validations.validations.counsel.incomplete = true;
            component.validations.validations.counsel.complete = null;
          }
          component.validations.validations.counsel.leadExists =
            component.leadExists;

          this.store.dispatch(
            setMandatoryNoticeValidations({
              mnValidations: component.validations,
            })
          );
          isFormDirty =
            component.counselForm.dirty ||
            component.editMode ||
            (component.counselForm.enabled && !component.counselForm.valid);
          break;
        default:
          break;
      }

      if (isFormDirty && !deleteMn) {
        let response = this.commonUtils.openWarningModal();

        response.onHide.subscribe((reason: string | any) => {
          if (reason.initialState.selection) {
            this.modalService.hide();
            observer.next(true);
          } else {
            observer.next(false);
          }
        });
      } else {
        window.sessionStorage.removeItem('deleteMn');
        observer.next(true);
      }
    });

    // return this.store.pipe(
    //   select(PtactsSelectors.ptactsStateData),
    //   map((stateData) => {
    //     if (!stateData.userId) {
    //       this.logger.info(
    //         'User ID from auth guard (false):',
    //         stateData.userId
    //       );
    //       // return this.router.parseUrl('/');
    //       return true;
    //     } else {
    //       this.logger.info('User ID from auth guard (true):', stateData.userId);
    //       return true;
    //     }
    //   })
    // );
  }
}
