import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
  CanDeactivate,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { take } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { CommonUtilitiesService } from '../services/common-utilities.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import {
  setMandatoryNoticeShowCounsel,
  setMandatoryNoticeValidations,
} from '../store/ptacts/ptacts.actions';
import { InitiatePetitionService } from '../components/features/initiate-petition/initiate-petition.service';
import { Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class IpStatusIndicator implements CanDeactivate<any> {
  public verificationFlag;
  validLeadCounsel: boolean = false;
  petitionInfo: any;

  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    private router: Router,
    private commonUtils: CommonUtilitiesService,
    private modalService: BsModalService,
    private initiatePetitionServices: InitiatePetitionService,
  ) {
    this.verificationFlag = initiatePetitionServices.getOption();
  }

  canDeactivate(
    component: any,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): Observable<boolean | UrlTree> {

    return new Observable((observer) => {
      let deletePetition = window.sessionStorage.getItem('withdrawPetition');
      let isFormDirty = false;
      this.petitionInfo = '';
      if (window.sessionStorage.getItem('petitionInfo')) {
        this.petitionInfo = JSON.parse(
          window.sessionStorage.getItem('petitionInfo')
        );
      }

      switch (component.componentName) {
        case 'claims':
          if (this.petitionInfo.proceedingNumberText) {
            this.initiatePetitionServices
              .getClaims(this.petitionInfo.proceedingNumberText)
              .pipe(take(1))
              .subscribe(
                (claimsInfo) => {
                  this.initiatePetitionServices.setOption('claimsComplete', true);
                  this.initiatePetitionServices.setOption('claimsInComplete', false);
                },
                (claimsFailure) => {
                  this.initiatePetitionServices.setOption('claimsComplete', false);
                  this.initiatePetitionServices.setOption('claimsInComplete', true);
                }
              );
          }
          isFormDirty = component.claimsChallengedForm.dirty;
          if (this.petitionInfo.trialType === 'PGR') {
            if((component.claimsChallengedForm.value.challengedGroupClaimList == null &&
              component.claimsChallengedForm.value.selectedStatutoryGround == null) && !component.claimsChallengedForm.valid){
                isFormDirty = false;
              }
            else if((component.claimsChallengedForm.value.challengedGroupClaimList != "" ||
              component.claimsChallengedForm.value.selectedStatutoryGround != "") && !component.claimsChallengedForm.valid){
                isFormDirty = true;
              }
            else if(component.priorArtRequired && component.claimsChallengedForm.valid){
              isFormDirty = true;
            } 
        }
          break;
        case 'documents':
          if (this.petitionInfo.proceedingNumberText) {
            this.initiatePetitionServices
              .getUnsubmittedDocuments(this.petitionInfo.proceedingNumberText)
              .pipe(take(1))
              .subscribe(
                (petitionDocumentList) => {
                  for (let i = 0; i < petitionDocumentList.length; i++) {
                    if (petitionDocumentList[i].documentTypeDescription == 'Petition: as filed') {
                      this.initiatePetitionServices.setOption('petitionPaperType', true);
                      this.initiatePetitionServices.setOption('noPetitionPaperType', false);
                      break;
                    } else {
                      this.initiatePetitionServices.setOption('noPetitionPaperType', true);
                      this.initiatePetitionServices.setOption('petitionPaperType', false);
                    }
                  }

                  for (let i = 0; i < petitionDocumentList.length; i++) {
                    if (petitionDocumentList[i].documentTypeDescription == 'Notice:  Power of Attorney' ) {
                      this.initiatePetitionServices.setOption('noNoticePaperType', false);
                      this.initiatePetitionServices.setOption('noticePaperType', true);
                      this.initiatePetitionServices.setOption('hasAttorneyPaperType', true);
                      break;
                    }
                    else if(this.verificationFlag.proseFlag){
                      this.initiatePetitionServices.setOption('noNoticePaperType', false);
                      this.initiatePetitionServices.setOption('noticePaperType', true);
                      this.initiatePetitionServices.setOption('hasAttorneyPaperType', false);
                    }
                    else {
                      this.initiatePetitionServices.setOption('noNoticePaperType', true);
                      this.initiatePetitionServices.setOption('noticePaperType', false);
                      this.initiatePetitionServices.setOption('hasAttorneyPaperType', false);
                    }
                  }
                },
                (failure) => {
                  this.initiatePetitionServices.setOption('petitionPaperType', false);
                  this.initiatePetitionServices.setOption('noticePaperType', false);
                  this.initiatePetitionServices.setOption('noPetitionPaperType', true);
                  this.initiatePetitionServices.setOption('noNoticePaperType', true);
                  this.initiatePetitionServices.setOption('hasAttorneyPaperType', false);
                }
              );
          }
          isFormDirty = component.petitionDocumentForm.dirty;
          if(component.selectedPaperType?.identifier != undefined && !component.petitionDocumentForm.valid){
            isFormDirty = true;
          }
          break;
        case 'realParty':
          if (this.petitionInfo.proceedingNumberText) {
            this.initiatePetitionServices
              .getRealParty(this.petitionInfo.proceedingNumberText)
              .pipe(take(1))
              .subscribe(
                (existingRealPartyResponse) => {
                  if (
                    existingRealPartyResponse.petitionRealParty &&
                    existingRealPartyResponse.petitionRealParty.parties.length > 0
                  ) {
                    for (
                      var i =
                        existingRealPartyResponse.petitionRealParty.parties.length - 1;
                      i >= 0;
                      i--
                    ) {
                      if (
                        existingRealPartyResponse.petitionRealParty.parties[i]
                          .partyType == 'REAL PARTY'
                      ) {
                        if (
                          existingRealPartyResponse.petitionRealParty.parties[i]
                            .personType.length > 0
                        ) {
                          this.initiatePetitionServices.setOption(
                            'realPartyInComplete',
                            false
                          );
                          this.initiatePetitionServices.setOption(
                            'realPartyComplete',
                            true
                          );
                          if (
                            existingRealPartyResponse.petitionRealParty.parties[i]
                              .proseIndicator == 'Y'
                          ) {
                            this.initiatePetitionServices.setOption('prose', true);
                            this.initiatePetitionServices.setOption('proseFlag', true);
                            this.initiatePetitionServices.setOption('noticePaperType', true);
                            this.initiatePetitionServices.setOption('noNoticePaperType', false);
                          }
                          else if (existingRealPartyResponse.petitionRealParty.parties[i]
                            .proseIndicator == 'N' && this.verificationFlag.hasAttorneyPaperType) {
                              this.initiatePetitionServices.setOption('prose', false);
                              this.initiatePetitionServices.setOption('proseFlag', false);
                              this.initiatePetitionServices.setOption('noticePaperType', true);
                              this.initiatePetitionServices.setOption('noNoticePaperType', false);
                          }
                          else if (existingRealPartyResponse.petitionRealParty.parties[i]
                            .proseIndicator == 'N') {
                              this.initiatePetitionServices.setOption('prose', false);
                              this.initiatePetitionServices.setOption('proseFlag', false);
                              this.initiatePetitionServices.setOption('noticePaperType', false);
                              this.initiatePetitionServices.setOption('noNoticePaperType', true);
                          }
                          break;
                        } else if (
                          existingRealPartyResponse.petitionRealParty.parties[i].orgType
                            .length > 0
                        ) {
                          this.initiatePetitionServices.setOption(
                            'realPartyInComplete',
                            false
                          );
                          this.initiatePetitionServices.setOption(
                            'realPartyComplete',
                            true
                          );
                          this.initiatePetitionServices.setOption('prose', false);
                          break;
                        } else {
                          this.initiatePetitionServices.setOption(
                            'realPartyInComplete',
                            true
                          );
                          this.initiatePetitionServices.setOption(
                            'realPartyComplete',
                            false
                          );
                          this.initiatePetitionServices.setOption('prose', true);
                        }
                      } else {
                        this.initiatePetitionServices.setOption(
                          'realPartyInComplete',
                          true
                        );
                        this.initiatePetitionServices.setOption(
                          'realPartyComplete',
                          false
                        );
                        this.initiatePetitionServices.setOption('prose', true);
                      }
                    }
                    for (
                      var i =
                        existingRealPartyResponse.petitionRealParty.parties.length - 1;
                      i >= 0;
                      i--
                    ) {
                      if (
                        existingRealPartyResponse.petitionRealParty.parties[i]
                          .partyType == 'ADD REAL PARTY'
                      ) {
                        if (
                          existingRealPartyResponse.petitionRealParty.parties[i]
                            .personType.length > 0
                        ) {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            true
                          );
                          break;
                        } else if (
                          existingRealPartyResponse.petitionRealParty.parties[i].orgType
                            .length > 0
                        ) {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            true
                          );
                          break;
                        } else {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            false
                          );
                        }
                      } else {
                        //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                        this.initiatePetitionServices.setOption(
                          'additionalRealPartyComplete',
                          false
                        );
                      }
                    }
                  } else {
                    this.initiatePetitionServices.setOption(
                      'realPartyInComplete',
                      true
                    );
                    this.initiatePetitionServices.setOption('realPartyComplete', false);
                    //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                    this.initiatePetitionServices.setOption(
                      'additionalRealPartyComplete',
                      false
                    );
                    this.initiatePetitionServices.setOption('prose', true);
                  }
                  this.verificationFlag = this.initiatePetitionServices.getOption();
                },
                (failure) => {
                  this.initiatePetitionServices.setOption('realPartyInComplete', true);
                  this.initiatePetitionServices.setOption('realPartyComplete', false);
                  //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                  this.initiatePetitionServices.setOption(
                    'additionalRealPartyComplete',
                    false
                  );
                  this.initiatePetitionServices.setOption('prose', true);
                }
              );
          }
            isFormDirty =
            component.realPartyForm.dirty && !component.realPartyForm.valid;
          isFormDirty = !isFormDirty ?
            component.realPartyForm.dirty && !component.realPartyForm.pristine:isFormDirty;
          let proseval = component.realPartyForm.controls.proSe.value == 'Yes' ? true:false;  
            if (component.realPartyForm.controls.partyType.touched 
              || (component.realPartyForm.touched && proseval && !component.realPartyForm.pristine) 
              || (component.updateMode && component.realPartyForm.controls.proSe.touched)
              || (component.realPartyForm.touched && proseval && !component.updateMode)
              || (!component.realPartyForm.dirty && !component.realPartyForm.touched && component.realPartyForm.pristine 
                && !component.updateMode && component.realPartyForm.value?.email?.length>1)){
                isFormDirty = true;
              }
          break;
        case 'additionalRealParty':
          if (this.petitionInfo.proceedingNumberText) {
            this.initiatePetitionServices
              .getRealParty(this.petitionInfo.proceedingNumberText)
              .pipe(take(1))
              .subscribe(
                (existingRealPartyResponse) => {
                  if (
                    existingRealPartyResponse.petitionRealParty &&
                    existingRealPartyResponse.petitionRealParty.parties.length > 0
                  ) {
                    for (
                      var i =
                        existingRealPartyResponse.petitionRealParty.parties.length - 1;
                      i >= 0;
                      i--
                    ) {
                      if (
                        existingRealPartyResponse.petitionRealParty.parties[i]
                          .partyType == 'ADD REAL PARTY'
                      ) {
                        if (
                          existingRealPartyResponse.petitionRealParty.parties[i]
                            .personType.length > 0
                        ) {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            true
                          );
                          break;
                        } else if (
                          existingRealPartyResponse.petitionRealParty.parties[i].orgType
                            .length > 0
                        ) {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            true
                          );
                          break;
                        } else {
                          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                          this.initiatePetitionServices.setOption(
                            'additionalRealPartyComplete',
                            false
                          );
                        }
                      } else {
                        //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                        this.initiatePetitionServices.setOption(
                          'additionalRealPartyComplete',
                          false
                        );
                      }
                    }
                  }
                });
          }
          isFormDirty = component.realPartyForm.dirty;
          if (component.realPartyForm.touched && !component.realPartyForm.pristine) {
            isFormDirty = true;
          }
          break;
        case 'counsel':
          if (this.petitionInfo.proceedingNumberText) {
            this.initiatePetitionServices
              .getCounsels(this.petitionInfo.proceedingNumberText)
              .pipe(take(1))
              .subscribe(
                (existingCounsels) => {
                  if (existingCounsels.length > 0) {
                    for(var i=0;i<existingCounsels.length;i++){
                      if (existingCounsels[i].counselType == 'Lead Counsel') {
                        this.validLeadCounsel = true;
                        break;
                      }
                      else{
                        this.validLeadCounsel = false;
                      }
                    }      
                    if (this.validLeadCounsel) {
                      this.initiatePetitionServices.setOption('counselComplete', true);
                      this.initiatePetitionServices.setOption(
                        'counselInComplete',
                        false
                      );
                    } else {
                      this.initiatePetitionServices.setOption('counselComplete', false);
                      this.initiatePetitionServices.setOption(
                        'counselInComplete',
                        true
                      );
                    }
                  } else {
                    this.initiatePetitionServices.setOption('counselComplete', false);
                    this.initiatePetitionServices.setOption('counselInComplete', true);
                  }
                },
                (failure) => {
                  this.initiatePetitionServices.setOption('counselComplete', false);
                  this.initiatePetitionServices.setOption('counselInComplete', true);
                }
              );
          }
          isFormDirty = component.counselForm.dirty;
          if (component.findCounsel != null && !component.counselForm.valid)
          {isFormDirty = true;}
          if (component.counselForm.status.toLowerCase() === 'invalid') {
            isFormDirty = true;
          }
          break;
        default:
          break;
      }

      if (isFormDirty && !deletePetition) {
        let response = this.commonUtils.openWarningModal();

        response.onHide.subscribe((reason: string | any) => {
          if (reason.initialState.selection) {
            this.modalService.hide();
            observer.next(true);
          } else {
            observer.next(false);
          }
        });
      } else {
        window.sessionStorage.removeItem('withdrawPetition');
        observer.next(true);
      }

      window.sessionStorage.setItem(
        'indicatorsInfo',
        JSON.stringify(this.initiatePetitionServices.getOption())
      );
      
    });

  }
}
