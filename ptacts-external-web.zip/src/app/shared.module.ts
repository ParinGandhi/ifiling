import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { GridActionsComponent } from './components/common/grid-actions/grid-actions.component';
// import { AddressComponent } from './components/common/address/address.component';
import { FilterPipe } from './utilities/table-filter-pipe';
import { OpenCaseViewerComponent } from './components/common/open-case-viewer/open-case-viewer.component';
import { AddressComponent } from './components/common/address/address.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { InfoModalComponent } from './components/common/info-modal/info-modal.component';
import { WarningModalComponent } from './components/common/warning-modal/warning-modal.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { PublicAvailabilityModalComponent } from './components/common/public-availability-modal/public-availability-modal.component';
import { RehearingsComponent } from './components/features/my-docket/rehearings/rehearings.component';
import { PhonePipe } from './utilities/phone-number-pipe';
import { GridPaginationComponent } from './components/common/grid-pagination/grid-pagination.component';
import { TablePaginationComponent } from './components/common/table-pagination/table-pagination.component';
import { RecordCountComponent } from './components/common/record-count/record-count.component';
import { ListOfDocumentsComponent } from './components/features/case-viewer/aia-review-info/documents/motions-modal/list-of-documents/list-of-documents.component';
import { DataTableComponent } from './components/common/data-table/data-table.component';
import { BasicTableComponent } from './components/common/basic-table/basic-table.component';
import { OpenPdfComponent } from './components/common/open-pdf/open-pdf.component';
import { TableActionsComponent } from './components/common/table-actions/table-actions.component';
import { LoadingSectionComponent } from './components/common/loading-section/loading-section.component';
import { LoadingButtonComponent } from './components/common/loading-button/loading-button.component';
import { LoadingIconComponent } from './components/common/loading-icon/loading-icon.component';
import { UnauthorizedComponent } from './components/common/unauthorized/unauthorized.component';

@NgModule({
  declarations: [
    GridActionsComponent,
    // AddressComponent,
    FilterPipe,
    PhonePipe,
    OpenCaseViewerComponent,
    AddressComponent,
    InfoModalComponent,
    WarningModalComponent,
    PublicAvailabilityModalComponent,
    RehearingsComponent,
    GridPaginationComponent,
    TablePaginationComponent,
    RecordCountComponent,
    ListOfDocumentsComponent,
    DataTableComponent,
    BasicTableComponent,
    OpenPdfComponent,
    TableActionsComponent,
    LoadingSectionComponent,
    LoadingButtonComponent,
    LoadingIconComponent,
    UnauthorizedComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AgGridModule.withComponents([]),
    BsDropdownModule.forRoot(),
    AccordionModule.forRoot(),
    TypeaheadModule.forRoot(),
    ModalModule.forRoot(),
    PopoverModule,
  ],
  exports: [
    GridActionsComponent,
    AgGridModule,
    FilterPipe,
    PhonePipe,
    FormsModule,
    ReactiveFormsModule,
    OpenCaseViewerComponent,
    AddressComponent,
    InfoModalComponent,
    BsDropdownModule,
    AccordionModule,
    TypeaheadModule,
    ModalModule,
    PopoverModule,
    PublicAvailabilityModalComponent,
    RehearingsComponent,
    GridPaginationComponent,
    TablePaginationComponent,
    RecordCountComponent,
    ListOfDocumentsComponent,
    DataTableComponent,
    BasicTableComponent,
    TableActionsComponent,
    LoadingSectionComponent,
    LoadingButtonComponent,
    LoadingIconComponent,
    UnauthorizedComponent,
  ],
  providers: [FilterPipe],
})
export class SharedModule {}
