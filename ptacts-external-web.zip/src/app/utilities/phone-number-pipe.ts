import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'phone',
})
export class PhonePipe implements PipeTransform {
  transform(unformattedNum: string): string {
    if (unformattedNum && unformattedNum.length === 10) {
      let arrNum = unformattedNum.split('');
      arrNum.splice(6, 0, '-');
      arrNum.splice(3, 0, '-');
      return arrNum.join('');
    } else {
      return unformattedNum;
    }
  }
}
