import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'filter',
  pure: false,
})
export class FilterPipe implements PipeTransform {
  constructor(private datePipe: DatePipe) {}

  filterNotApplicable = '~filterNotApplicable';

  //   transform(items: Array<any>, coldef: Array<columnDetails>): Array<any> {
  //     let results = items.filter(item => coldef.find(key => key.searchText ? this.getValueOnType(key, item) : undefined));
  //     return results;
  //     // return this.filterTable(items, coldef);
  //   }
  //    getValueOnType (key,item) {
  //       let dataType = {
  //         'string': () => {
  //           let temp = !item[key.field].toLowerCase().includes(key.searchText.toLowerCase());
  //
  //         },
  //         'date': () => !this.convertMilliSecondsToStringDate(item[key.field]).includes(key.searchText),
  //         'number': () => !item[key.field].includes(parseInt(key.searchText)),
  //       };
  //       return dataType[key.type]();
  //     }
  //   convertMilliSecondsToStringDate(dateInMilli){
  //       let date = new Date(dateInMilli);
  //       return  `${("0" + (date.getMonth() + 1)).slice(-2)}/${("0" + date.getDate()).slice(-2)}/${date.getFullYear()}`;
  // }

  transform(
    items: Array<any>,
    coldef: Array<any>,
    entireDataSet?: Array<any>
  ): Array<any> {
    //   let columnsWithFilters = this.getColumnsWithFilters(coldef);
    //   if (columnsWithFilters.length == 0) {
    //     return items;
    //   } else {
    //     let results = this.getFilteredData(items, columnsWithFilters);
    //     return results;
    //  }
    if (entireDataSet) {
      return this.filterGrid(entireDataSet, coldef);
    } else {
      return this.filterGrid(items, coldef);
    }
  }

  //   getColumnsWithFilters(coldef) {
  //     let columnsToFilter: Array<any> = [];
  //     coldef.forEach((column) => {
  //       if (column.searchText && column.searchText !== null && column.searchText !== "") {
  //         columnsToFilter.push(column);
  //       }
  //     });
  //     return columnsToFilter;
  //   }

  //   getFilteredData(items, columnsWithFilters) {
  //     let foundItems: Array<any> = [];
  //     items.forEach((item) => { // iterate over the row
  //       for (let i = 0; i < columnsWithFilters.length; i++) { // iterate over the columns with filters on each row
  //         if (columnsWithFilters[i].type === 'string') {
  //           let result = this.filterStringType(item, columnsWithFilters[i]);
  //           if (result) {
  //             foundItems.push(result);
  //             break;
  //           }
  //         }
  //       }
  //     });
  //
  //     return foundItems;
  //   }

  //   filterStringType(item, column) {
  //     if (item[column.field].toLowerCase().includes(column.searchText.toLowerCase())) {
  //       return item;
  //     } else {
  //       return null;
  //     }
  //   }

  //    getValueOnType (key,item) {
  //       let dataType = {
  //         'string': () => !item[key.field].toLowerCase().includes(key.searchText.toLowerCase()),
  //         'date': () => !this.convertMilliSecondsToStringDate(item[key.field]).includes(key.searchText),
  //         'number': () => !item[key.field].includes(parseInt(key.searchText)),
  //       };
  //      let result = dataType[key.type]();
  //
  //      return result;
  //     }
  //   convertMilliSecondsToStringDate(dateInMilli){
  //       let date = new Date(dateInMilli);
  //       return  `${("0" + (date.getMonth() + 1)).slice(-2)}/${("0" + date.getDate()).slice(-2)}/${date.getFullYear()}`;
  // }

  filterGrid(currentData, columns) {
    if (this.getNumberOfFilters(columns) === 0) {
      return currentData;
    }
    return this.filterTable(currentData, columns);
  }

  filterGridImportManager(grid, currentData) {
    if (this.getNumberOfFilters(grid.columns) === 0) {
      return currentData;
    }
    return this.filterTableForImportManager(currentData, grid.columns);
  }

  getNumberOfFilters(columns) {
    var numberOfFilters = 0;
    if (columns && columns.length > 0) {
      columns.forEach((column) => {
        numberOfFilters += this.hasTerm(columns, column.field);
      });
    }

    return numberOfFilters;
  }

  hasTerm(columns, field) {
    var term = '';
    columns.forEach((column) => {
      if (
        column.searchText &&
        column.searchText !== null &&
        column.searchText.trim() !== ''
      ) {
        column.searchText = column.searchText.trim();
        term = column.searchText;
      }
    });
    return term ? 1 : 0;
  }

  getColumnsWithTerms(columns) {
    if (this.isDefined(columns)) {
      var columnList = [];
      for (var i = 0; i < columns.length; i++) {
        var termAndColumn = {
          term: '',
          columnName: '',
          dataType: '',
        };
        if (
          columns[i].searchText &&
          columns[i].searchText !== null &&
          columns[i].searchText !== ''
        ) {
          termAndColumn.term = columns[i].searchText;
          termAndColumn.columnName = columns[i].field;
          if (this.isDefined(columns[i].type)) {
            termAndColumn.dataType = columns[i].type;
          }
          columnList.push(termAndColumn);
        }
      }
      return columnList;
    }
  }

  filterTable(unfilteredArray, columns) {
    var newList = [];
    var match, data, blankFound, currentRow, currentColumn;
    var columnList = this.getColumnsWithTerms(columns);
    // var data;
    var blankList = [];
    // var blankFound;
    // var currentRow;

    if (!unfilteredArray) {
      return null;
    } else if (this.isDefined(unfilteredArray.caseDetailsData)) {
      data = unfilteredArray.caseDetailsData;
    } else if (this.isDefined(unfilteredArray)) {
      data = unfilteredArray;
    }

    /** Will remove any column in the current row that contains blank cells if '?' is passed as the search criteria */
    for (currentRow = 0; currentRow < data.length; currentRow++) {
      blankFound = false;
      for (
        currentColumn = 0;
        currentColumn < columnList.length;
        currentColumn++
      ) {
        if (!blankFound) {
          if (
            columnList[currentColumn].term === '?' &&
            columnList[currentColumn].dataType !== 'date' &&
            data[currentRow][columnList[currentColumn].columnName]
          ) {
            if (
              columnList[currentColumn].columnName ===
              'ADDITIONAL_APJ_WORKER_ID_TX'
            ) {
              if (this.checkForBlanks(data[currentRow])) {
                blankList.push(data[currentRow]);
                blankFound = true;
                break;
              }
            }
            if (
              !data[currentRow][columnList[currentColumn].columnName]
                .toString()
                .trim()
            ) {
              blankList.push(data[currentRow]);
              blankFound = true;
              break;
            }
          } else {
            if (columnList[currentColumn].term === '/') {
            } else if (
              columnList[currentColumn].columnName ===
              'ADDITIONAL_APJ_WORKER_ID_TX'
            ) {
              if (this.checkForBlanks(data[currentRow])) {
                blankList.push(data[currentRow]);
                blankFound = true;
                break;
              }
            } else if (
              columnList[currentColumn].columnName.indexOf('alert') >= 0 ||
              columnList[currentColumn].columnName.indexOf(
                'APPEAL_SEQUENCE_NO'
              ) >= 0
            ) {
            } else if (
              !data[currentRow][columnList[currentColumn].columnName]
            ) {
              blankList.push(data[currentRow]);
              blankFound = true;
              break;
            }
          }
        }
      }
    }

    /** Will remove all rows containing blank calls from the dataset */
    data = data.filter((row) => {
      return blankList.indexOf(row) < 0;
    });

    blankList = [];

    /** Will keep any column in the current row that contains blank cells if '/' is passed as the search criteria */
    for (
      currentColumn = 0;
      currentColumn < columnList.length;
      currentColumn++
    ) {
      blankList = [];
      if (columnList[currentColumn].term === '/') {
        for (currentRow = 0; currentRow < data.length; currentRow++) {
          if (
            columnList[currentColumn].columnName ===
            'ADDITIONAL_APJ_WORKER_ID_TX'
          ) {
            if (this.checkForBlanks(data[currentRow])) {
              blankList.push(data[currentRow]);
            }
          } else if (
            data[currentRow][columnList[currentColumn].columnName] !== 0 &&
            (!data[currentRow][columnList[currentColumn].columnName] ||
              !data[currentRow][columnList[currentColumn].columnName]
                .toString()
                .trim())
          ) {
            blankList.push(data[currentRow]);
          }
        }
        /** Will remove all rows containing blank calls from the dataset */
        data = this.copy(blankList);
      }
    }

    data.forEach((currentRow) => {
      var firstRun = true;
      columnList.forEach((currentColumn) => {
        if (currentColumn.term !== '?' && currentColumn.term !== '/') {
          // Filter all APJ fields for Panel column in view case docket
          if (currentColumn.columnName === 'ADDITIONAL_APJ_WORKER_ID_TX') {
            if (firstRun) {
              match = this.compareConcatValue(currentColumn.term, currentRow);
            } else {
              match =
                match &&
                this.compareConcatValue(currentColumn.term, currentRow);
            }
          } else if (
            (this.isDefined(currentRow[currentColumn.columnName]) &&
              currentRow[currentColumn.columnName] !== null) ||
            currentColumn.columnName.indexOf('alert') === 0 ||
            currentColumn.columnName.indexOf('APPEAL_SEQUENCE_NO') >= 0
          ) {
            if (
              Array.isArray(currentRow[currentColumn.columnName]) &&
              currentColumn.columnName.indexOf('alert') < 0
            ) {
              for (var i = 0; i < 4; i++) {
                match = this.compareValue(
                  currentColumn.term,
                  currentRow[currentColumn.columnName][i],
                  currentColumn.dataType,
                  null,
                  currentColumn.columnName
                );
                if (match) {
                  break;
                }
              }
            } else {
              var data;

              if (
                currentColumn.columnName.indexOf('alert') >= 0 ||
                currentColumn.columnName.indexOf('APPEAL_SEQUENCE_NO') >= 0
              ) {
                data = currentRow['alerts'];
                if (!data) {
                  data = currentRow;
                }
              } else if (currentColumn.columnName === 'reviewDispositionCode') {
                data = currentRow['reviewDispositionCodeDescription'];
              } else {
                data = currentRow[currentColumn.columnName];
              }

              if (firstRun) {
                match = this.compareValue(
                  currentColumn.term,
                  data,
                  currentColumn.dataType,
                  null,
                  currentColumn.columnName
                );
              } else {
                match =
                  match &&
                  this.compareValue(
                    currentColumn.term,
                    data,
                    currentColumn.dataType,
                    null,
                    currentColumn.columnName
                  );
              }
              firstRun = false;
            }
          } else {
            if (firstRun) {
              match = false;
            } else {
              match = match && false;
              firstRun = false;
            }
          }
        } else {
          if (firstRun) {
            match = true;
            firstRun = false;
          } else {
            match = match && true;
          }
        }
      });

      if (match) {
        newList.push(currentRow);
      }
    });
    return newList;
  }

  // checkAlertValue(term, alerts) {
  //   var match = false;
  //   if (term === CONSTANTS.ALERTS.NEW.value && alerts[1].trim()) {
  //     match = true;
  //   } else if (term === CONSTANTS.ALERTS.CRITICAL.value && alerts[0].trim()) {
  //     match = true;
  //   } else if (term === CONSTANTS.ALERTS.DUE_TODAY.value && alerts[2].trim()) {
  //     match = true;
  //   } else if (term === CONSTANTS.ALERTS.PAST_DUE.value && alerts[3].trim()) {
  //     match = true;
  //   } else if (term === CONSTANTS.ALERTS.USER_INACTIVE.value && alerts[4].trim()) {
  //     match = true;
  //   } else if (term === CONSTANTS.ALERTS.NO_ALERTS.value && alerts[5].trim()) {
  //     match = containsAlertValue(alerts);
  //   }
  //   return match;
  // }

  // containsAlertValue(alerts) {
  //   var alertValues = "";
  //   alerts.forEach((value) => {
  //     alertValues += value.trim();
  //   });

  //   return alertValues === CONSTANTS.ALERTS.NO_ALERTS.value;
  // }

  filterTableForImportManager(unfilteredArray, columns) {
    var newList = [];
    var match;
    var columnList = this.getColumnsWithTerms(columns);

    unfilteredArray.caseDetailsData.forEach((currentRow) => {
      var firstRun = true;
      columnList.forEach((currentColumn) => {
        if (firstRun) {
          match = this.compareValue(
            currentColumn.term,
            currentRow.preAppealInfo[currentColumn.columnName],
            currentColumn.dataType,
            null,
            currentColumn.columnName
          );
        } else {
          match =
            match &&
            this.compareValue(
              currentColumn.term,
              currentRow.preAppealInfo[currentColumn.columnName],
              currentColumn.dataType,
              null,
              currentColumn.columnName
            );
        }
        firstRun = false;
      });

      if (match) {
        newList.push(currentRow.preAppealInfo);
      }
    });
    return newList;
  }

  compareConcatValue(filter, thisRow) {
    var upperCaseFilter = filter.toUpperCase();

    // Assignment docket docket judge objects
    if (
      thisRow.appealPanelJudgeOne &&
      thisRow.appealPanelJudgeOne.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return (
        thisRow.appealPanelJudgeOne.toUpperCase().indexOf(upperCaseFilter) >= 0
      );
    }
    if (
      thisRow.appealPanelJudgeTwo &&
      thisRow.appealPanelJudgeTwo.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return (
        thisRow.appealPanelJudgeTwo.toUpperCase().indexOf(upperCaseFilter) >= 0
      );
    }
    if (
      thisRow.appealPanelJudgeThree &&
      thisRow.appealPanelJudgeThree.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return (
        thisRow.appealPanelJudgeThree.toUpperCase().indexOf(upperCaseFilter) >=
        0
      );
    }

    // View case docket docket judge objects
    if (
      thisRow.APJ1_WORKER_ID &&
      thisRow.APJ1_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return thisRow.APJ1_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0;
    }
    if (
      thisRow.APJ2_WORKER_ID &&
      thisRow.APJ2_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return thisRow.APJ2_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0;
    }
    if (
      thisRow.APJ3_WORKER_ID &&
      thisRow.APJ3_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return thisRow.APJ3_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0;
    }

    if (
      thisRow.ATTORNEY_WORKER_ID &&
      thisRow.ATTORNEY_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0
    ) {
      return (
        thisRow.ATTORNEY_WORKER_ID.toUpperCase().indexOf(upperCaseFilter) >= 0
      );
    }

    return false;
  }

  // checkCaseAlertValue(row, filter) {

  //   if (row.PROCEEDING_TYPE_CT === 'TRIAL') {

  //     //Less than 90 days until a final decision is due
  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT !== null && row.PROCEEDING_STATUTORY_DT &&
  //       row.DECISION_DUE_DAYS < 90 &&
  //       row.DECISION_DUE_DAYS >= 30) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     //Less than 30 days until a Final Decision is due
  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT !== null &&
  //       row.DECISION_DUE_DAYS < 30 &&
  //       row.DECISION_DUE_DAYS >= 0) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT !== null && row.PROCEEDING_STATUTORY_DT !== null &&
  //       row.DECISION_DUE_DAYS < 0) {
  //       return filter === CONSTANTS.ALERTS.PAST_DUE.value;
  //     }

  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT === null && row.PROCEEDING_STATUTORY_DT !== null &&
  //       row.DECISION_DUE_DAYS < 60 &&
  //       row.DECISION_DUE_DAYS >= 30) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     //Less than 60 days until an Institution Decision is due
  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT === null && row.PROCEEDING_STATUTORY_DT !== null &&
  //       row.DECISION_DUE_DAYS < 30 &&
  //       row.DECISION_DUE_DAYS >= 0) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     if (row.DECISION_DUE_DAYS !== null && row.INSTITUTION_DECISION_DT === null && row.PROCEEDING_STATUTORY_DT !== null &&
  //       row.DECISION_DUE_DAYS < 0) {
  //       return filter === CONSTANTS.ALERTS.PAST_DUE.value;
  //     }

  //   } else {

  //     if (row.APPEAL_DECISION_DUE_DAYS !== null &&
  //       (row.PROCEEDING_STATE_NM !== 'Pending Disposal' && row.PROCEEDING_STATE_NM != 'Disposed') &&
  //       (row.APPEAL_DECISION_DUE_DAYS < 90 && row.APPEAL_DECISION_DUE_DAYS >= 45)) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     if (row.APPEAL_DECISION_DUE_DAYS !== null &&
  //       (row.PROCEEDING_STATE_NM !== 'Pending Disposal' && row.PROCEEDING_STATE_NM != 'Disposed') &&
  //       (row.APPEAL_DECISION_DUE_DAYS < 45 && row.APPEAL_DECISION_DUE_DAYS >= 0)) {
  //       return filter === CONSTANTS.ALERTS.UPCOMING.value;
  //     }

  //     if (row.APPEAL_DECISION_DUE_DAYS !== null &&
  //       (row.PROCEEDING_STATE_NM !== 'Pending Disposal' && row.PROCEEDING_STATE_NM != 'Disposed') &&
  //       row.APPEAL_DECISION_DUE_DAYS < 0) {
  //       return filter === CONSTANTS.ALERTS.PAST_DUE.value;
  //     }
  //   }

  //   return (filter === CONSTANTS.ALERTS.NO_ALERTS.value);
  // }

  checkForBlanks(thisRow) {
    // Assignment docket judge objects
    var panel = thisRow.appealPanelJudgeOne
      ? thisRow.appealPanelJudgeOne.toUpperCase().trim()
      : '';
    panel += thisRow.appealPanelJudgeTwo
      ? thisRow.appealPanelJudgeTwo.toUpperCase().trim()
      : '';
    panel += thisRow.appealPanelJudgeThree
      ? thisRow.appealPanelJudgeThree.toUpperCase().trim()
      : '';
    panel += thisRow.ATTORNEY_WORKER_ID
      ? thisRow.ATTORNEY_WORKER_ID.toUpperCase().trim()
      : '';

    // View case docket docket judge objects
    panel += thisRow.APJ1_WORKER_ID
      ? thisRow.APJ1_WORKER_ID.toUpperCase().trim()
      : '';
    panel += thisRow.APJ2_WORKER_ID
      ? thisRow.APJ2_WORKER_ID.toUpperCase().trim()
      : '';
    panel += thisRow.APJ3_WORKER_ID
      ? thisRow.APJ3_WORKER_ID.toUpperCase().trim()
      : '';
    panel += thisRow.ATTORNEY_WORKER_ID
      ? thisRow.ATTORNEY_WORKER_ID.toUpperCase().trim()
      : '';
    return !panel;
  }

  compareValue(filter, value, dateType, noSpecialCompare, columnName) {
    var filter1 = filter;
    var str = filter1;
    var result = /^(?!\[)\W*\d/.test(str);
    var result1 = /^[A-Za-z]/.test(str);
    var result2 = /(^[[A-Za-z]*]$)/.test(str);
    var result3 = /(^[[0-9]*\W[0-9]*]$)/.test(str);
    var result4 = /^(?!\[)\W*[A-Za-z0-9]/.test(str);
    var result5 = /^\W*\d/.test(str);
    var dateRangeFilter =
      /^(\[\s?[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}\s?[Tt][Oo]\s?([0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}|\*)\s?\])/.test(
        str
      );

    if (!filter) {
      return true;
    }

    if (columnName.indexOf('alert') >= 0) {
      // return checkAlertValue(filter, value);
      return null;
    } else if (columnName.indexOf('APPEAL_SEQUENCE_NO') >= 0) {
      // return checkCaseAlertValue(value, filter);
      return null;
    }

    if (dateType === 'date' || dateType === 'datetime') {
      if (filter.indexOf('[') === 0 && filter.indexOf(']') < 0) {
        return true;
      }
      if (dateRangeFilter) {
        var dateRange = filter
          .replace(' ', '')
          .replace('[', '')
          .replace(']', '')
          .toUpperCase()
          .replace('TO', '-');
        var rangedates = dateRange.split('-');
        var beginDate = rangedates[0];
        var endDate = rangedates[1];

        return this.compareDateRange(beginDate, endDate, value);
      } else if (result5) {
        return this.compareDateValue(filter, value, columnName, dateType);
      } else if (isNaN(parseInt(str))) {
        return false;
      } else {
        return true;
      }
    }

    if (
      (result && !isNaN(value)) ||
      (result1 && isNaN(value)) ||
      result2 ||
      result3 ||
      result4
    ) {
      return this.compareFilter(filter, value, noSpecialCompare);
    } else {
      return true;
    }
  }

  compareDateRange(beginDate, endDate, dateValue) {
    beginDate = new Date(beginDate).setHours(0, 0, 0, 0);
    var value = new Date(dateValue);
    if (endDate.indexOf('*') < 0) {
      endDate = new Date(endDate).setHours(23, 59, 59, 999);

      return beginDate <= value && value <= endDate;
    } else return beginDate <= value || dateValue === null;
  }

  compareLessThan(filter, value) {
    var filterValue = filter.substring(1);
    try {
      var intFilter = parseInt(filterValue);
      var intValue = parseInt(value);
      return intValue < intFilter;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareAngles(filter, value) {
    if (
      filter.indexOf('<') === 0 &&
      filter.indexOf('>') < 0 &&
      filter.indexOf('=') < 0
    ) {
      return this.compareLessThan(filter, value);
    }
    if (filter.indexOf('<') === 0 && filter.indexOf('=') === 1) {
      return this.compareLessThanEqual(filter, value);
    }

    return this.compareIsNotEquest(filter, value);
  }

  compareIsNotEquest(filter, value) {
    if (filter.indexOf('*') === 0) {
      return this.compareEndsWith(filter, value);
    }

    if (filter.indexOf('>') === 0 && filter.indexOf('=') < 0) {
      return this.compareGreaterThan(filter, value);
    }
    if (filter.indexOf('>') === 0 && filter.indexOf('=') === 1) {
      return this.compareGreaterThanEqual(filter, value);
    }

    return this.compareNotEqualValues(filter, value);
  }

  compareNotEqualValues(filter, value) {
    var hasTwoAngles = filter.indexOf('<') === 0 && filter.indexOf('>') === 1;
    if (
      filter.indexOf('*') < 0 &&
      (hasTwoAngles || (filter.indexOf('!') === 0 && filter.indexOf('=') === 1))
    ) {
      return this.compareNotEqual(filter, value);
    }

    if (filter.indexOf('!') === 0 && filter.length > 1) {
      return this.compareDoesNotContain(filter, value);
    }
    return this.filterNotApplicable;
  }

  compareDoesNotContain(filter, value) {
    if (!value) {
      return false;
    }
    var uppercaseValue = value;
    var substringVal = filter.substring(1);
    try {
      uppercaseValue = uppercaseValue.toUpperCase();
      substringVal = substringVal.toUpperCase();
    } catch (error) {
      // No issue. Value is a number
      return false;
    }
    var compare = uppercaseValue.indexOf(substringVal) >= 0;
    return !compare;
  }

  compareFilter(filter, value, noSpecialCompare) {
    if (!noSpecialCompare) {
      var compareValue = this.compareAngles(filter, value);
      if (compareValue !== this.filterNotApplicable) {
        return compareValue;
      }
      var oddEven = this.compareOddEven(filter, value);
      if (oddEven !== this.filterNotApplicable) {
        return oddEven;
      }
      if (filter.indexOf('=') === 0) {
        return this.compareEqual(filter, value);
      }
    }
    return this.compareOtherFilters(filter, value, noSpecialCompare);
  }

  compareOtherFilters(filter, value, noSpecialCompare) {
    if (!noSpecialCompare) {
      if (
        filter.indexOf('[') === 0 &&
        filter.indexOf('-') === 2 &&
        filter.indexOf(']') === 4
      ) {
        return this.compareLastDigitRange(filter, value);
      }
      if (
        filter.indexOf('[') === 0 &&
        filter.indexOf('-') === 3 &&
        filter.indexOf(']') === 6
      ) {
        return this.compareLastTwoDigitRange(filter, value);
      }
    }

    return this.compareFinalTypes(filter, value, noSpecialCompare);
  }

  compareFinalTypes(filter, value, noSpecialCompare) {
    if (!noSpecialCompare) {
      if (
        filter.indexOf('*') === filter.length - 1 &&
        filter.indexOf('!') === 0 &&
        filter.indexOf('=') === 1
      ) {
        return this.compareDoesNotStartsWith(filter, value);
      }
      if (filter.indexOf('*') === filter.length - 1) {
        return this.compareStartsWith(filter, value);
      }
    }
    return this.compareLikeText(filter, value);
  }

  compareOddEven(filter, value) {
    if (filter.toUpperCase() === '[ODD]') {
      return this.compareEndsOddNumber(value);
    }
    if (filter.toUpperCase() === '[EVEN]') {
      return this.compareEndsEvenNumber(value);
    }
    return this.filterNotApplicable;
  }

  compareEqualDateValue(filter, filterValue, value) {
    if (filter.indexOf('<=') === 0) {
      if (value <= filterValue) {
        return true;
      }
      return false;
    } else if (filter.indexOf('>=') === 0) {
      if (value >= filterValue) {
        return true;
      }
      return false;
    }

    return this.filterNotApplicable;
  }

  compareDateValue(filter, value1, columnName, dateType) {
    var date;
    // var value = new Date(parseInt(value1));
    let value = null;
    if (
      typeof value1 === 'string' &&
      (value1.includes('-') || value1.includes(':'))
    ) {
      value = new Date(value1);
    } else {
      value = new Date(parseInt(value1));
    }
    if (filter.indexOf('=') === 1) {
      return this.compareEqualDateValue(filter, value, value);
    }
    if (filter.indexOf('<') === 0) {
      date = new Date(filter.substring(1));
      return value < date;
    } else if (filter.indexOf('>') === 0) {
      date = new Date(filter.substring(1));
      return value > date;
    }

    var dateCompare = this.compareEqualDateValue(filter, value, value);

    if (dateCompare !== this.filterNotApplicable) {
      return dateCompare;
    }
    var strDate;
    if (dateType === 'date') {
      strDate = this.datePipe.transform(value, 'MM/dd/yyyy');
    } else {
      strDate = this.datePipe.transform(value, 'MM/dd/yyyy hh:mm:ss a');
    }
    // If the date is a last modified user then we display a time and we need to compare that
    // if (columnName !== 'LAST_MODIFIED_TS') {
    //   strDate = $filter('date')(value, "MM/dd/yyyy ");
    // } else {
    //   strDate = $filter('date')(value, "MM/dd/yyyy hh:mm:ss a");
    // }
    return this.compareFilter(filter, strDate, false);
  }

  compareLikeText(filter, value) {
    var upperCaseValue;
    var upperCaseFilter;
    if (!value && value !== 0) {
      return false;
    }
    if (Number.isInteger(value) && !Array.isArray(value)) {
      upperCaseValue = value.toString().toUpperCase();
    } else {
      if (this.isDefined(value) && value !== '' && !Array.isArray(value)) {
        upperCaseValue = value.toUpperCase();
      } else {
        upperCaseValue = value;
      }
    }
    if (Number.isInteger(filter)) {
      upperCaseFilter = filter.toString().toUpperCase();
    } else {
      upperCaseFilter = filter.toUpperCase();
    }
    if (Array.isArray(upperCaseValue)) {
      upperCaseValue.forEach((currentValue) => {
        if (currentValue.indexOf(upperCaseFilter) >= 0) {
          return upperCaseValue;
        }
      });
    } else {
      return upperCaseValue.indexOf(upperCaseFilter) >= 0;
    }
  }

  compareStartsWith(filter, value) {
    var upperCaseValue;
    var upperCaseFilter;
    if (!value && value !== 0) {
      return false;
    }
    if (Number.isInteger(value)) {
      upperCaseValue = value.toString().toUpperCase();
    } else {
      upperCaseValue = value.toUpperCase();
    }
    if (Number.isInteger(filter)) {
      upperCaseFilter = filter
        .toString()
        .toUpperCase()
        .substring(0, filter.length - 1);
    } else {
      upperCaseFilter = filter.toUpperCase().substring(0, filter.length - 1);
    }

    return upperCaseValue.indexOf(upperCaseFilter) === 0;
  }

  compareEndsWith(filter, value) {
    var upperCaseValue;
    var upperCaseFilter;
    if (!value && value !== 0) {
      return false;
    }
    if (Number.isInteger(value)) {
      upperCaseValue = value.toString().toUpperCase();
    } else {
      upperCaseValue = value.toUpperCase();
    }
    if (Number.isInteger(filter)) {
      upperCaseFilter = filter.toString().toUpperCase().substring(1);
    } else {
      upperCaseFilter = filter.toUpperCase().substring(1);
    }
    return (
      upperCaseValue.indexOf(
        upperCaseFilter,
        upperCaseValue.length - upperCaseFilter.length
      ) !== -1
    );
  }

  compareLessThanEqual(filter, value) {
    var filterValue = filter.substring(2);
    try {
      var intFilter = parseInt(filterValue);
      var intValue = parseInt(value);
      return intValue <= intFilter;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareGreaterThan(filter, value) {
    var filterValue = filter.substring(1);
    try {
      var intFilter = parseInt(filterValue);
      var intValue = parseInt(value);
      return intValue > intFilter;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareGreaterThanEqual(filter, value) {
    var filterValue = filter.substring(2);
    try {
      var intFilter = parseInt(filterValue);
      var intValue = parseInt(value);
      return intValue >= intFilter;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareNotEqual(filter, value) {
    var filterValue = filter.substring(2);
    var intFilter;
    var valueParse;
    try {
      intFilter = parseInt(filterValue);
      if (isNaN(intFilter)) {
        intFilter = filterValue.toUpperCase().trim();
      }
    } catch (error) {
      console.info('Not a number');
    }
    try {
      valueParse = parseInt(value);
      if (isNaN(valueParse)) {
        valueParse = value.toUpperCase().trim();
      }
    } catch (error) {
      console.info('Not a number');
      valueParse = value;
    }

    try {
      return intFilter !== valueParse;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareEqual(filter, value) {
    var filterValue = filter.substring(1);
    try {
      return filterValue == value;
    } catch (error) {
      console.info(
        'filter or Value does not contain integer to compare less than' + error
      );
      return false;
    }
  }

  compareDoesNotStartsWith(filter, value) {
    var upperCaseValue;
    var upperCaseFilter;
    if (!value && value !== 0) {
      return false;
    }
    if (Number.isInteger(value)) {
      upperCaseValue = value.toString().toUpperCase();
    } else {
      upperCaseValue = value.toUpperCase();
    }
    filter = filter.substring(2);
    if (Number.isInteger(filter)) {
      upperCaseFilter = filter
        .toString()
        .toUpperCase()
        .substring(0, filter.length - 1);
    } else {
      upperCaseFilter = filter.toUpperCase().substring(0, filter.length - 1);
    }

    return upperCaseValue.indexOf(upperCaseFilter) !== 0;
  }

  compareEndsOddNumber(value) {
    try {
      var intValue = parseInt(value);
      return intValue % 2 === 1;
    } catch (error) {
      console.info(
        'Value does not contain integer to compare odd numbers' + error
      );
      return false;
    }
  }

  compareEndsEvenNumber(value) {
    try {
      var intValue = parseInt(value);
      return intValue % 2 === 0;
    } catch (error) {
      console.info(
        'Value does not contain integer to compare even numbers' + error
      );
      return false;
    }
  }

  compareLastDigitRange(filter, value) {
    if (!value && value !== 0) {
      return false;
    }
    var lowerRange = filter.substring(1, filter.indexOf('-'));
    var upperRange = filter.substring(
      filter.indexOf('-') + 1,
      filter.length - 1
    );
    var valueString = value.toString().substring(value.toString().length - 1);
    try {
      var intValue = parseInt(valueString);
      var intLowerRange = parseInt(lowerRange);
      var intUpperRange = parseInt(upperRange);
      return intValue >= intLowerRange && intValue <= intUpperRange;
    } catch (error) {
      console.info(
        'Filter or Value does not contain integer to compare range' + error
      );
      return false;
    }
  }

  compareLastTwoDigitRange(filter, value) {
    if (!value && value !== 0) {
      return false;
    }
    var lowerRange = filter.substring(1, filter.indexOf('-'));
    var upperRange = filter.substring(
      filter.indexOf('-') + 1,
      filter.length - 1
    );
    var valueString = value.toString().substring(value.toString().length - 2);
    try {
      var intValue = parseInt(valueString);
      var intLowerRange = parseInt(lowerRange);
      var intUpperRange = parseInt(upperRange);
      return intValue >= intLowerRange && intValue <= intUpperRange;
    } catch (error) {
      console.info(
        'Value does not contain integer to compare even numbers' + error
      );
      return false;
    }
  }

  isDefined(item) {
    return item && item !== null && item !== '';
  }

  copy(item) {
    return JSON.parse(JSON.stringify(item));
  }
}
