/**
 * ! Example service for the user component. Business logic should be performed to the response
 * ! before returning it to the component.
 * ! Common functionality can still be in a separate service file that can be injected into
 * ! each service.
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Urls } from '../constants/urls';
import { map } from 'rxjs/operators';
import { CommonUtilitiesService } from './common-utilities.service';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  constructor(
    private http: HttpClient,
    private commonUtils: CommonUtilitiesService
  ) {}

  getUsers(): Observable<any> {
    return this.http.get<Array<any>>(Urls.USERS.GET).pipe(
      map((userResponse) => {
        const tempList = [];
        userResponse.forEach((element) => {
          let newUserObj = element;
          newUserObj.randomNumber = this.commonUtils.generateRandomNumber();
          tempList.push(newUserObj);
        });
        return tempList;
      })
    );
  }
}
