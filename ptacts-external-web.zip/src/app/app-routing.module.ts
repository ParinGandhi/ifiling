import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UnauthorizedComponent } from './components/common/unauthorized/unauthorized.component';

const routes: Routes = [
  {
    path: 'ui/home',
    loadChildren: () =>
      import('./components/features/home/home-routing.module').then(
        (m) => m.HomeRoutingModule
      ),
  },
  {
    path: 'ui/login',
    loadChildren: () =>
      import('./components/features/login/login-routing.module').then(
        (m) => m.LoginRoutingModule
      ),
  },
  {
    path: 'ui/my-docket',
    loadChildren: () =>
      import('./components/features/my-docket/my-docket-routing.module').then(
        (m) => m.MyDocketRoutingModule
      ),
  },
  {
    path: 'ui/initiate-petition',
    loadChildren: () =>
      import(
        './components/features/initiate-petition/initiate-petition-routing.module'
      ).then((m) => m.InitiatePetitionRoutingModule),
  },
  {
    path: 'ui/mandatory-notice',
    loadChildren: () =>
      import(
        './components/features/mandatory-notice/mandatory-notice-routing.module'
      ).then((m) => m.MandatoryNoticeRoutingModule),
  },
  {
    path: 'ui/case-viewer/:applicationNumber/:caseNumber',
    loadChildren: () =>
      import(
        './components/features/case-viewer/case-viewer-routing.module'
      ).then((m) => m.CaseViewerRoutingModule),
  },
  {
    path: 'ui/advanced-search',
    loadChildren: () =>
      import(
        './components/features/advanced-search/advanced-search.routing.module'
      ).then((m) => m.AdvancedSearchRoutingModule),
  },
  {
    path: 'ui/public-search',
    loadChildren: () =>
      import(
        './components/features/public-search/public-search.routing.module'
      ).then((m) => m.PublicSearchRoutingModule),
  },
  {
    path: 'ui/public-search/:caseNumber',
    loadChildren: () =>
      import(
        './components/features/public-search/public-search.routing.module'
      ).then((m) => m.PublicSearchRoutingModule),
  },
  {
    path: 'ui/external/petition/:petitionId/group/:groupId',
    loadChildren: () =>
      import('./components/features/external/external-routing.module').then(
        (m) => m.ExternalRoutingModule
      ),
  },
  {
    path: 'ui/external/petition/:petitionId/trialTypeCd/:typeId',
    loadChildren: () =>
      import('./components/features/external/external-routing.module').then(
        (m) => m.ExternalRoutingModule
      ),
  },
  {
    path: 'ui/unauthorized',
    component: UnauthorizedComponent,
  },
  {
    path: '',
    redirectTo: 'ui/home',
    pathMatch: 'full',
  },
  { path: '**', redirectTo: 'ui/home' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      onSameUrlNavigation: 'reload',
      // useHash: true,
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
