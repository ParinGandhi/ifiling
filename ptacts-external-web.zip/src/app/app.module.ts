import { environment } from 'src/environments/environment';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {
  LocationStrategy,
  Location,
  PathLocationStrategy,
} from '@angular/common';

import { LoggerModule } from 'ngx-logger';
import { TabsModule } from 'ngx-bootstrap/tabs';
// import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
// import { ModalModule } from 'ngx-bootstrap/modal';

import { StoreModule } from '@ngrx/store';
import { reducers } from './store/ptacts-app-store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { PtactsEffects } from './store/ptacts/ptacts.effects';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AuthInterceptorService } from './services/auth-interceptor.service';
import { NavbarComponent } from './components/common/navbar/navbar.component';
import { MyDocketModule } from './components/features/my-docket/my-docket.module';
import { SharedModule } from './shared.module';

import { InitiatePetitionModule } from './components/features/initiate-petition/initiate-petition.module';
import { MandatoryNoticeModule } from './components/features/mandatory-notice/mandatory-notice.module';
import { LoginModule } from './components/features/login/login.module';
import { ToastrModule } from 'ngx-toastr';
import { LoginService } from './components/features/login/login.service';
import { GridHelperService } from './services/grid-helper.service';
import { CaseViewerModule } from './components/features/case-viewer/case-viewer.module';
import { AdvancedSearchModule } from './components/features/advanced-search/advanced-search.module';
import { GlobalHeaderComponent } from './components/common/global-header/global-header.component';
import { GlobalFooterComponent } from './components/common/global-footer/global-footer.component';
import { HomeComponent } from './components/features/home/home.component';
import { ExternalModule } from './components/features/external/external.module';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    GlobalHeaderComponent,
    GlobalFooterComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ToastrModule.forRoot(),

    EffectsModule.forRoot([PtactsEffects]),
    StoreModule.forRoot(reducers, {
      runtimeChecks: {
        strictActionImmutability: true,
        strictActionSerializability: true,
        strictStateImmutability: true,
        strictStateSerializability: true,
      },
    }),
    StoreDevtoolsModule.instrument({ maxAge: 10 }),
    LoggerModule.forRoot({
      serverLoggingUrl: '/api/logs', //? Add path to server to write the logs
      level: environment.logLevel, //? Log level to show in browser console
      serverLogLevel: environment.serverLogLevel, //? Log level to show on the server
    }),
    BrowserAnimationsModule,
    TabsModule.forRoot(),
    // BsDropdownModule.forRoot(),
    // ModalModule.forRoot(),
    SharedModule,
    LoginModule,
    MyDocketModule,
    InitiatePetitionModule,
    CaseViewerModule,
    MandatoryNoticeModule,
    AdvancedSearchModule,
    ExternalModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true,
    },
    LoginService,
    GridHelperService,
    // Location,
    // { provide: LocationStrategy, useClass: PathLocationStrategy },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
