import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, concatMap, map } from 'rxjs/operators';
import { CaseViewerService } from 'src/app/components/features/case-viewer/case-viewer.service';
import { HomeService } from 'src/app/components/features/home/home.service';
import { InitiatePetitionService } from 'src/app/components/features/initiate-petition/initiate-petition.service';
import { LoginService } from 'src/app/components/features/login/login.service';
import * as PtactsActions from 'src/app/store/ptacts/ptacts.actions';
declare let $: any;

@Injectable()
export class PtactsEffects {
  constructor(
    private actions: Actions,
    private homeService: HomeService,
    private loginService: LoginService,
    private caseViewerService: CaseViewerService,
    private initiatePetitionService: InitiatePetitionService,
    private router: Router
  ) {}

  getUserDetails$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getUserDetails),
      concatMap((_action) => {
        return this.homeService.getLoggedInUserDetails().pipe(
          map((data: any) => {
            $.sessionTimeoutWidget.staySignedIn();
            window.sessionStorage.setItem('userDetails', JSON.stringify(data));
            if (!location.href.includes('localhost')) {
              window.sessionStorage.setItem('email', data.emailAddress);
            }
            return PtactsActions.setUserDetails({ payload: data });
          })
        );
      })
    );
  });

  getNonOKTAUserDetails$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getLoginDetailsForNonOKTA),
      concatMap((_action) => {
        const userName = window.sessionStorage.getItem('email');
        return this.loginService.getUserInfo(userName).pipe(
          map((data: any) => {
            const userDetails = {
              lastName: data.lastName,
              patronId: null,
              displayName: null,
              roles: data.roles,
              userId: data.emailId,
              employeeNumber: null,
              firstName: data.firstName,
              emailAddress: data.emailId,
              ptabDefaultRefreshTime: data.ptabDefaultRefreshTime,
              employeeType: null,
              ptabReadOnlyUser: data.ptabReadOnlyUser,
              clientIP: null,
              middleName: null,
              passwordExpired: null,
              authLevel: null,
            };
            const isCv = window.location.href.includes('case-viewer');
            // if (!isCv && userName !== 'anonymous') {
            //   this.router.navigate(['/ui/my-docket']);
            // }

            window.sessionStorage.setItem(
              'userDetails',
              JSON.stringify(userDetails)
            );
            return PtactsActions.setUserDetails({ payload: userDetails });
          })
        );
      })
    );
  });

  getPartyRepresenting$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getPartyRepresenting),
      concatMap((_action) => {
        return this.caseViewerService
          .getPartyRepresenting(_action.proceedingNo)
          .pipe(
            map((partyRepresenting: string) => {
              let pr = partyRepresenting;
              if (partyRepresenting.toLowerCase() === 'patentowner') {
                pr = 'PATENT OWNER';
              }
              window.sessionStorage.setItem('partyRepresenting', pr);
              return PtactsActions.setPartyRepresenting({
                partyRepresenting: pr,
              });
            })
          );
      })
    );
  });

  getPetitionIdentifier$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.getPetitionIdentifier),
      concatMap((_action) => {
        return this.initiatePetitionService
          .getCaseInfoByProceedingNo(_action.proceedingNo)
          .pipe(
            map((caseInfoByProceedingResponse) => {
              const petitionIdentifier =
                caseInfoByProceedingResponse.petitionIdentifier;
              return PtactsActions.setPetitionIdentifier({
                petitionIdentifier: petitionIdentifier,
              });
            })
          );
      })
    );
  });

  getCasePhase$: Observable<Action> = createEffect(() => {
    return this.actions.pipe(
      ofType(PtactsActions.GetCasePhaseAction),
      concatMap((_action) => {
        return this.caseViewerService.getCaseStatus(_action.url).pipe(
          map((data: any) => {
            console.log('data: ', data);
            return PtactsActions.SuccessGetCasePhaseAction({ payload: data });
          }),
          catchError((error: Error) => {
            // this.toastr.error(`Error retrieving case phase`,``, {
            //   closeButton: true
            // } );
            return of(PtactsActions.ErrorCasePhaseAction(error));
          })
        );
      })
    );
  });

  // getCasePhase$:Observable<Action> = createEffect(() =>
  //   this.actions.pipe(
  //     ofType(caseViewerActions.GetCasePhaseAction),
  //     concatMap(_action =>
  //         this.trialsServices.getCaseStatus(_action.url).pipe(
  //           map((data: CasePhaseModel) => {
  //             console.log('data: ', data);
  //             return caseViewerActions.SuccessGetCasePhaseAction({ payload: data });
  //           }),
  //           catchError((error: Error) => {
  //             // this.toastr.error(`Error retrieving case phase`,``, {
  //             //   closeButton: true
  //             // } );
  //             return of(caseViewerActions.ErrorUserInfoAction(error));
  //           })
  //         )
  //       )
  //   ));

  // setStateInfo$ = createEffect(() => {
  //     this.actions$.pipe(
  //         ofType(PtactsActions.setUserIdAction),
  //         concatMap(_action => {
  //             window.sessionStorage.setItem('state', JSON.stringify(_action))
  //             return void;
  //         })
  //     )
  // })
}
