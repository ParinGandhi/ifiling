/**
 * ! Create a new action based on needs
 */
import { createAction, props } from '@ngrx/store';

export const setUserIdAction = createAction(
  '[PtactsState] Set user ID',
  props<{ payload: any }>()
);

export const getUserIdAction = createAction(
  '[PtactsState] Get user ID',
  props<{ request: any }>()
);

export const setUserDetails = createAction(
  '[PtactsState] Set user details from RBAC',
  props<{ payload: any }>()
);

export const getUserDetails = createAction('[PtactsState] Get user details');

export const getLoginDetailsForNonOKTA = createAction(
  '[PtactsState] Get non-OKTA user details',
  props<{ userName: string }>()
);

export const changeLoading = createAction(
  '[PtactsState] Change loading',
  props<{ request: boolean }>()
);

export const setTrialInfo = createAction(
  '[PtactsState] Set trial info',
  props<{ request: any }>()
);

export const setNewPetitionInfo = createAction(
  '[PtactsState] Set new petition info',
  props<{ request: any }>()
);

export const setMandatoryNoticeInfo = createAction(
  '[PtactsState] Set mandatory notice info',
  props<{ mnNotice: any }>()
);

export const setMandatoryNoticeDocuments = createAction(
  '[PtactsState] Set mandatory notice documents',
  props<{ mnDocuments: any }>()
);

export const setMandatoryNoticeRealParty = createAction(
  '[PtactsState] Set mandatory notice real party info',
  props<{ mnRealParty: any }>()
);

export const setMandatoryNoticeAdditionalRealParty = createAction(
  '[PtactsState] Set mandatory notice additional real party info',
  props<{ mnAdditionalRealParty: any }>()
);

export const setMandatoryNoticeCounsel = createAction(
  '[PtactsState] Set mandatory notice counsel info',
  props<{ mnCounsel: any }>()
);

export const setMandatoryNoticeShowCounsel = createAction(
  '[PtactsState] Set flag to show counsel on sidenav',
  props<{ mnShowCounsel: boolean }>()
);

export const setMandatoryNoticeValidations = createAction(
  '[PtactsState] Set flag to show mandatory validations',
  props<{ mnValidations: any }>()
);

export const setAnonymousSearch = createAction(
  '[PtactsState] Set anonymous search',
  props<{ anonymousSearch: any }>()
);

export const setPartyRepresenting = createAction(
  '[PtactsState] Set party representing',
  props<{ partyRepresenting: any }>()
);

export const getPartyRepresenting = createAction(
  '[PtactsState] Get party representing',
  props<{ proceedingNo: string }>()
);

export const getPetitionIdentifier = createAction(
  '[PtactsState] Get petition identifier',
  props<{ proceedingNo: string }>()
);

export const setPetitionIdentifier = createAction(
  '[PtactsState] Set petition identifier',
  props<{ petitionIdentifier: any }>()
);

export const GetCasePhaseAction = createAction(
  '[CasePhase] Get Case Phase',
  props<{ url?: string }>()
)

export const SuccessGetCasePhaseAction = createAction(
  '[CasePhase] - Success Get case phase',
  props<{ payload: any }>()
);

export const ErrorCasePhaseAction = createAction(
  '[CasePhase] - Error', props<Error>());

// export const getAnonymousSearch = createAction(
//   '[PtactsState] Get anonymous search',
//   props<{ anonymousSearch: any }>()
// );
