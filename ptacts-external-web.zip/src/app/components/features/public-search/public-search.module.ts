import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared.module';
import { CheckboxDropdownComponent } from '../../common/checkbox-dropdown/checkbox-dropdown.component';
import { AdditionalFiltersComponent } from '../advanced-search/additional-filters/additional-filters.component';
import { AdvancedSearchComponent } from '../advanced-search/advanced-search.component';
import { DocumentsRendererComponent } from '../advanced-search/documents-renderer/documents-renderer.component';
import { ViewDocumentsModalComponent } from '../advanced-search/view-documents-modal/view-documents-modal.component';
import { PublicSearchRoutingModule } from './public-search.routing.module';

// import { PopoverModule } from 'ngx-bootstrap/popover';

@NgModule({
  declarations: [
    AdvancedSearchComponent,
    AdditionalFiltersComponent,
    CheckboxDropdownComponent,
    DocumentsRendererComponent,
    ViewDocumentsModalComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    PublicSearchRoutingModule,
    // PopoverModule.forRoot(),
  ],
  exports: [AdditionalFiltersComponent, CheckboxDropdownComponent],
})
export class PublicSearchModule {}
