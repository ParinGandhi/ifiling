import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-search',
  templateUrl: './public-search.component.html',
  styleUrls: ['./public-search.component.scss']
})
export class PublicSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
