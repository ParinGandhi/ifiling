import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Urls } from 'src/app/constants/urls';
import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Injectable({
  providedIn: 'root',
})
export class AdvancedSearchService {
  private EXTERNAL_SERVICE_BASE = environment.EXTERNAL_SERVICE_API;
  // private COMMON_SERVICE_BASE: string = environment.COMMON_SERVICE_API;

  constructor(
    private http: HttpClient,
    private gridService: GridHelperService,
    private commonUtils: CommonUtilitiesService
  ) {}

  getHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': emailId,
      }),
      withCredentials: true,
      crossDomain: true,
    };

    return httpOptions;
  }

  getSearchResults(verificationObj): Observable<any> {
    const userInfo = JSON.parse(window.sessionStorage.getItem('userDetails'));
    let fullName = 'anonymous';
    if (userInfo && (userInfo.lastName || userInfo.firstName)) {
      fullName = `${userInfo.lastName}, ${userInfo.firstName}`;
    }
    let url = `${this.EXTERNAL_SERVICE_BASE}${Urls.MANDATORY_NOTICE.VERIFICATION}`;
    if (fullName === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.MANDATORY_NOTICE.VERIFICATION}`;
    }
    return this.http.post(url, verificationObj).pipe(
      map((verificationResponse: Array<any>) => {
        let cases = [];
        verificationResponse.forEach((currentCase) => {
          currentCase.terminationDate = this.gridService.convertDateToString(
            currentCase.terminationDate
          );
          currentCase.institutionDecisionDate =
            this.gridService.convertDateToString(
              currentCase.institutionDecisionDate
            );
          currentCase.prcdCreatedTs = this.gridService.convertFilingDate(
            currentCase.prcdCreatedTs
          );

          currentCase.allPartiesInfoParsed =
            this.commonUtils.parseAllPartiesInfo(currentCase.allPartiesInfo);
          currentCase.enableCaseViewerLink =
            this.commonUtils.enableCaseViewerLink(
              fullName,
              currentCase.allPartiesInfoParsed
            );

          currentCase.enableCaseViewerLink = currentCase.extUserPrcdPartyGrpType
            ? true
            : false;

          // currentCase.decisionOutcome = this.commonUtils.findDecisionOutcome(
          //   currentCase.mileStoneDt
          // );
          currentCase.decisionOutcome = currentCase.terminationType;
          cases.push(currentCase);
        });

        return cases;
      })
    );
  }

  // TODO Change to external service
  getDecisionOutcomeTypes(): Observable<any> {
    const user = window.sessionStorage.getItem('email');
    let url = `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${Urls.DECISION_OUTCOME}`;
    if (user === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.REFERENCE_TYPES}${Urls.DECISION_OUTCOME}`;
    }
    return this.http
      .get<any>(
        // `${this.COMMON_SERVICE_BASE}${Urls.REFERENCE_TYPES}${Urls.DECISION_OUTCOME}`
        url
      )
      .pipe(
        map((decisionOutcomeTypes) => {
          return decisionOutcomeTypes[0].decisionOutcomeGroupTypes[0]
            .decisionOutComeTypes;
        })
      );
  }

  getDocumentsData(proceedingNumber: any): Observable<any> {
    const user = window.sessionStorage.getItem('email');
    let url = `${this.EXTERNAL_SERVICE_BASE}/proceeding-artifacts?proceedingNumber=${proceedingNumber}`;
    if (user === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}/proceeding-artifacts?proceedingNumber=${proceedingNumber}`;
    }
    return this.http.get(url).pipe(
      map((documentsData: []) => {
        documentsData.forEach((document: any) => {
          document.category = this.convertStringToTitleCase(document.category);
          document.filingParty = this.convertStringToTitleCase(
            document.filingParty
          );
          document.docNo = document.documentNumber
            ? document.documentNumber
            : document.exhibitNumber;
        });
        return documentsData;
      })
    );
  }

  convertStringToTitleCase(str) {
    if (!str) {
      return str;
    }
    return str
      .toLowerCase()
      .split(' ')
      .map((word) => {
        return word.charAt(0).toUpperCase() + word.slice(1);
      })
      .join(' ');
  }
}
