import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { AdditionalFiltersComponent } from './additional-filters/additional-filters.component';
import { CaseSearchModel } from '../../../models/common/CaseSearch.model';
import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { AiaToolTipComponent } from '../../common/aia-tool-tip/aia-tool-tip.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { OpenCaseViewerComponent } from '../../common/open-case-viewer/open-case-viewer.component';
import { AdvancedSearchService } from './advanced-search.service';
import { CheckboxDropdownComponent } from '../../common/checkbox-dropdown/checkbox-dropdown.component';
import { MandatoryNoticeService } from '../mandatory-notice/mandatory-notice.service';
import { filter, take } from 'rxjs/operators';
import { DocumentsRendererComponent } from './documents-renderer/documents-renderer.component';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { ActivatedRoute } from '@angular/router';

declare let $: any;

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  styleUrls: ['./advanced-search.component.scss'],
})
export class AdvancedSearchComponent implements OnInit {
  @ViewChild(AdditionalFiltersComponent)
  private readonly additionalFiltersComponent: AdditionalFiltersComponent;
  @ViewChild('searchCaseTypes')
  caseTypesDropdownComponent: CheckboxDropdownComponent;

  searching: boolean;
  caseTypes: Array<any> = [
    {
      val: false,
      description: 'IPR',
      code: 'IPR',
    },
    {
      val: false,
      description: 'PGR',
      code: 'PGR',
    },
    {
      val: false,
      description: 'CBM',
      code: 'CBM',
    },
    {
      val: false,
      description: 'DER',
      code: 'DER',
    },
  ];

  columnDefs = {
    searchResults: [
      {
        field: 'proceedingNumber',
        headerName: 'AIA review #',
        width: '7%',
        sort: 'desc',
        sortIndex: 2,
        cellRendererFramework: OpenCaseViewerComponent,
        cellRendererParams: { fromComponent: 'searchDocuments' },
      },
      {
        field: 'prcdCreatedTs',
        headerName: 'Filing date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '7%',
        sort: 'desc',
        sortIndex: 1,
        type: 'date',
      },
      {
        field: 'institutionDecisionDate',
        headerName: 'Institution decision date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '7%',
        type: 'date',
      },
      {
        field: 'terminationDate',
        headerName: 'Termination date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '7%',
        type: 'date',
      },
      {
        field: 'petiApplicationId',
        headerName: 'Petitioner application #',
        width: '7%',
      },
      {
        field: 'petiPatentNumber',
        headerName: 'Petitioner patent #',
        width: '7%',
      },
      { field: 'petiRealParty', headerName: 'Petitioner', width: '7%' },
      {
        field: 'petiTechCenterId',
        headerName: 'Petitioner tech center',
        width: '7%',
      },
      {
        field: 'poApplicationId',
        headerName: 'PO/Respondent application #',
        width: '7%',
      },
      {
        field: 'poPatentNumber',
        headerName: 'PO/Responsent patent #',
        width: '7%',
      },
      { field: 'poRealParty', headerName: 'PO/Respondent', width: '7%' },
      {
        field: 'poTechCenterId',
        headerName: 'PO/Respondent tech center',
        width: '7%',
      },
      { field: 'statusDisplay', headerName: 'Status', width: '7%' },
      {
        field: 'searchDocuments',
        headerName: 'Documents',
        cellRenderer: 'buttonRenderer',
        width: '12%',
        autoHeight: true,
        floatingFilter: false,
        cellRendererParams: {
          onClick: this.onActionClick.bind(this),
          label: 'Documents',
        },
      },
    ],
  };

  rowData = {
    searchResults: [],
  };
  searchResultsFinal: Array<any> = [];
  selectedCaseTypes: Array<string> = [];
  resultsFound: boolean;
  caseSearch: CaseSearchModel = new CaseSearchModel();
  message: string;

  gridOptions = new GridOptionsModel();
  gridParams = new GridParamsModel();
  userName: string;
  numberOfFilters: number;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;
  frameworkComponents: {
    customTooltip: typeof AiaToolTipComponent;
    buttonRenderer: typeof DocumentsRendererComponent;
  };
  btnComponents: any;
  loading: boolean;
  paginationPageSize = CONSTANTS.PAGINATION.DEFAULT;
  currentPage: number = 1;
  totalPages: number = null;
  recordCountInfo: RecordCountModel = new RecordCountModel();
  paginationInfo: PaginationModel = new PaginationModel();
  verifiedCaseList: any[];
  numberToSearch: string = null;
  resultsEmpty: boolean;
  rowDataClicked = {};
  filterType: string = null;

  constructor(
    private store: Store<PtactsState>,
    private readonly commonUtils: CommonUtilitiesService,
    private mandatoryNoticeService: MandatoryNoticeService,
    public changeDetector: ChangeDetectorRef,
    private modalService: BsModalService,
    public gridHelperService: GridHelperService,
    private advancedSearchService: AdvancedSearchService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const caseNumber = this.activatedRoute.snapshot.params['caseNumber'];
    if (caseNumber) {
      this.caseSearch.proceedingNumber = caseNumber;
      // const sessionEmail = window.sessionStorage.getItem('email');
      // if (!sessionEmail) {
      //   window.sessionStorage.setItem('email', 'anonymous');
      // }
      window.sessionStorage.setItem('email', 'anonymous');
      this.getCaseSearchResults();
    }
    this.gridOptions.headerHeight = 72;
    document.title = 'Search P-TACTS';
    const userId = window.sessionStorage.getItem('email');
    if (userId === 'anonymous') {
      this.store
        .select(PtactsSelectors.getAnonymousSearch)
        .pipe(take(1))
        .subscribe((anonymousSearch) => {
          this.caseSearch = JSON.parse(JSON.stringify(anonymousSearch));
          this.caseSearch.trailTypes.forEach((trailType) => {
            this.caseTypes.forEach((caseType) => {
              if (caseType.code === trailType) {
                caseType.val = true;
              }
            });
          });
          this.getCaseSearchResults();
        });
    } else {
      this.caseTypes.forEach((caseType) => {
        caseType.val = true;
      });
    }
    this.frameworkComponents = {
      customTooltip: AiaToolTipComponent,
      buttonRenderer: DocumentsRendererComponent,
    };
    this.popoverShow();
    this.loading = false;
    this.recordCountInfo.currentPage = this.currentPage;
    this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    this.paginationInfo.currentPage = this.currentPage;
  }

  popoverShow() {
    $(function () {
      $('.fa-info-circle').hover(function () {
        $('[data-toggle="popover"]').popover({ placement: 'top' }).popover();
      });
    });
  }

  onActionClick(e) {
    this.rowDataClicked = e.rowData;
  }

  setSelectedCaseTypes(e) {
    this.caseSearch.trailTypes = e;
  }

  getCaseSearchResults() {
    this.paginationInfo.currentPage = 1;
    this.recordCountInfo.currentPage = 1;
    this.verifiedCaseList = [];
    this.searching = true;
    this.loading = true;
    this.resultsFound = false;
    this.advancedSearchService
      .getSearchResults(this.caseSearch)
      .pipe(take(1))
      .subscribe(
        (verificationResponse) => {
          if (verificationResponse.length <= 0) {
            this.resultsEmpty = false;
            this.resultsFound = true;
            this.loading = false;
            this.searching = false;
          } else if (verificationResponse.length > 0) {
            this.numberOfFilters = 0;
            this.loading = true;
            this.rowData.searchResults = verificationResponse;
            this.searchResultsFinal = [...verificationResponse];
            this.resultsFound = true;
            this.recordCountInfo.dataLength = this.rowData.searchResults.length;
            this.recordCountInfo.paginationPageSize = 25;
            this.loading = false;
            this.searching = false;
            this.resultsEmpty = false;
          } else {
            this.resultsEmpty = true;
            this.resultsFound = false;
            this.loading = false;
            this.searching = false;
          }
        },
        (searchFailure) => {
          this.commonUtils.showInfo('No results found', 'Search');
          this.loading = false;
          this.searching = false;
          this.resultsEmpty = true;
        }
      );
  }

  clearCaseSearchResults() {
    this.resultsFound = false;
    this.resultsEmpty = false;
    this.loading = false;
    this.searching = false;
    this.caseSearch = new CaseSearchModel();
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = CONSTANTS.EXPORT_NAMES.ADVANCED_SEARCH;
    this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    this.paginationInfo.totalPages = this.totalPages;
  }

  ngOnDestroy(): void {}

  onPaginationChanged(e) {
    //
  }

  gridPaginationAction(e) {
    this.recordCountInfo.lastPage = false;
    this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    this.recordCountInfo.currentPage = this.currentPage;
    this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.rowData.searchResults.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.gridParams.gridApi.paginationSetPageSize(
        this.rowData.searchResults.length
      );
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.searchResults.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      this.gridParams.gridApi.paginationGoToPage(
        this.paginationInfo.currentPage
      );
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.searchResults.length / this.paginationInfo.pageSize
      );

      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.gridParams.gridApi.paginationGoToPage(
        this.recordCountInfo.currentPage - 1
      );
    }
  }

  setFilteredResults(filteredResults) {
    // if (this.filterType === 'case') {
    this.rowData.searchResults = filteredResults;
    this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    this.paginationInfo.totalPages = Math.ceil(
      filteredResults.length / this.paginationInfo.pageSize
    );
    this.recordCountInfo.dataLength = filteredResults.length;
    //     this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    // this.gridPagination.currentPage = 1;
    // this.setPaginationDetails();
    // }
    // else if (this.filterType === "document") {
    //   this.rowData.documentData = filteredResults;
    // }
    //   this.gridPagination.totalItems = filteredResults.length;

    //   setTimeout(() => {
    //     this.gridPagination.totalPages = this.gridApi.paginationGetTotalPages();
    //     this.gridPagination.currentPage = 1;
    //     this.setPaginationDetails();
    //     }, 200);
  }

  setFilterCount(filterCount) {
    // const filterModel = this.gridApi.getFilterModel();
    // const resp = this.gridHelper.onFilterChanged(this.gridApi);
    // this.numberOfFilters = resp.numberOfFilters + filterCount;
    // this.gridApi.setFilterModel(filterModel);
  }
}
