import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsRendererComponent } from './documents-renderer.component';

describe('DocumentsRendererComponent', () => {
  let component: DocumentsRendererComponent;
  let fixture: ComponentFixture<DocumentsRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentsRendererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
