import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ViewDocumentsModalComponent } from '../view-documents-modal/view-documents-modal.component';

@Component({
  selector: 'app-documents-renderer',
  templateUrl: './documents-renderer.component.html',
  styleUrls: ['./documents-renderer.component.scss'],
})
export class DocumentsRendererComponent implements OnInit {
  params;
  label: string;
  documentsModalRef: BsModalRef = null;
  srText: string;

  constructor(
    private modalService: BsModalService,
    private commonUtils: CommonUtilitiesService
  ) {}

  ngOnInit(): void {}

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
    this.srText = 'View documents for ' + this.params.data.proceedingNumber;
  }

  openDocumentsModal(e) {
    window.sessionStorage.setItem(
      'proceedingNoForSearch',
      this.params.data.proceedingNumber
    );
   
   
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.params.data.proceedingNumber,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.documentsModalRef = this.modalService.show(
      ViewDocumentsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.documentsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
       
      }
    });
  }
}
