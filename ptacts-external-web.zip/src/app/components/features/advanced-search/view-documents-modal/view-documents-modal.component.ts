import { Component, OnInit } from '@angular/core';
import { GridParams } from 'ag-grid-community';
import { BsModalService } from 'ngx-bootstrap/modal';
import { take } from 'rxjs/operators';
import { OpenPdfComponent } from 'src/app/components/common/open-pdf/open-pdf.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';
import { AdvancedSearchService } from '../advanced-search.service';

@Component({
  selector: 'app-view-documents-modal',
  templateUrl: './view-documents-modal.component.html',
  styleUrls: ['./view-documents-modal.component.scss'],
})
export class ViewDocumentsModalComponent implements OnInit {
  modalOptions: any = this.modalService.config.initialState;
  gridParams = new GridParamsModel();
  gridOptions = new GridOptionsModel();
  petitionIdentifier: string = null;
  documentsData = [];

  paginationPageSize = CONSTANTS.PAGINATION.DEFAULT;
  currentPage: number = 1;
  totalPages: number = null;
  recordCountInfo: RecordCountModel = new RecordCountModel();
  paginationInfo: PaginationModel = new PaginationModel();
  loading: boolean = false;

  columnDefs = [
    { valueGetter: 'node.rowIndex + 1', width: '12px' },
    {
      field: 'name',
      headerName: 'Document name',
      type: 'string',
      sort: 'asc',
      sortIndex: 2,
      cellRendererFramework: OpenPdfComponent,
    },
    {
      field: 'category',
      headerName: 'Document type',
      width: '40px',
      type: 'string',
    },
    {
      field: 'docNo',
      headerName: 'Exhibit/Paper number',
      width: '50px',
      sort: 'desc',
      sortIndex: 1,
      type: 'string',
    },
    {
      field: 'filingDateString',
      headerName: 'Filing date',
      comparator: this.gridHelperService.dateComparator,
      // sort: 'desc',
      sortIndex: 0,
      width: '40px',
      type: 'date',
    },
    {
      field: 'filingParty',
      headerName: 'Filing party',
      width: '50px',
      type: 'string',
    },
    {
      field: 'availability',
      headerName: 'Availability',
      width: '50px',
      type: 'string',
    },
  ];

  constructor(
    private modalService: BsModalService,
    public gridHelperService: GridHelperService,
    private advancedSearchService: AdvancedSearchService,
    private initiatePetitionService: InitiatePetitionService,
    private caseViewerService: CaseViewerService
  ) {}

  ngOnInit(): void {
    this.getDocumentsData();
    this.getPetitionIdentifier();
    this.recordCountInfo.currentPage = this.currentPage;
    this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    this.paginationInfo.currentPage = this.currentPage;
  }

  getDocumentsData() {
    this.loading = true;
    this.advancedSearchService
      .getDocumentsData(this.modalOptions.proceedingNo)
      .pipe(take(1))
      .subscribe(
        (documentsData) => {
          this.loading = false;
          this.documentsData = documentsData;
          this.recordCountInfo.dataLength = documentsData.length;
          this.totalPages = Math.ceil(
            documentsData.length / parseInt(this.paginationPageSize)
          );
          this.paginationInfo.totalPages = this.totalPages;
        },
        () => {
          this.loading = false;
        }
      );
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.modalOptions.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
        window.sessionStorage.setItem(
          'petitionIdentifier',
          this.petitionIdentifier
        );
      });
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = `${this.modalOptions.proceedingNo}`;
    // setTimeout(() => {
    //   this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    //   this.paginationInfo.totalPages = this.totalPages;
    // }, 1000);
  }

  openPdf(params) {
    this.caseViewerService
      .openPdf(this.petitionIdentifier, this.modalOptions.proceedingNo)
      // .pipe(take(1))
      // .subscribe((pdfResponse) => {
      //   this.commonUtils.openPdfNew(pdfResponse);
      // });
  }

  close(val) {
   
    this.modalService.hide();
  }

  onPaginationChanged(e) {
   
  }

  gridPaginationAction(e) {
    this.recordCountInfo.lastPage = false;
   

    this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    this.recordCountInfo.currentPage = this.currentPage;
    this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.documentsData.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.gridParams.gridApi.paginationSetPageSize(this.documentsData.length);
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.documentsData.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      this.gridParams.gridApi.paginationGoToPage(
        this.paginationInfo.currentPage
      );
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.documentsData.length / this.paginationInfo.pageSize
      );

      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.gridParams.gridApi.paginationGoToPage(
        this.recordCountInfo.currentPage - 1
      );
    }
  }
}
