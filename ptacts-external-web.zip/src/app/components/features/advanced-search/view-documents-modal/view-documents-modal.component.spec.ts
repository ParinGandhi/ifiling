import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDocumentsModalComponent } from './view-documents-modal.component';

describe('ViewDocumentsModalComponent', () => {
  let component: ViewDocumentsModalComponent;
  let fixture: ComponentFixture<ViewDocumentsModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewDocumentsModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewDocumentsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
