import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared.module';
import { AdvancedSearchComponent } from './advanced-search.component';
import { AdditionalFiltersComponent } from './additional-filters/additional-filters.component';
import { AiaToolTipComponent } from '../../common/aia-tool-tip/aia-tool-tip.component';
import { AdvancedSearchRoutingModule } from './advanced-search.routing.module';
import { CheckboxDropdownComponent } from '../../common/checkbox-dropdown/checkbox-dropdown.component';
import { DocumentsRendererComponent } from './documents-renderer/documents-renderer.component';
import { ViewDocumentsModalComponent } from './view-documents-modal/view-documents-modal.component';
// import { PopoverModule } from 'ngx-bootstrap/popover';

@NgModule({
  declarations: [
    AdvancedSearchComponent,
    AdditionalFiltersComponent,
    CheckboxDropdownComponent,
    DocumentsRendererComponent,
    ViewDocumentsModalComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    AdvancedSearchRoutingModule,
    // PopoverModule.forRoot(),
  ],
  exports: [AdditionalFiltersComponent, CheckboxDropdownComponent],
})
export class AdvancedSearchModule {}
