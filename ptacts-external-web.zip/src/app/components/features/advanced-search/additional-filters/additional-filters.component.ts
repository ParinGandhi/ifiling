import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FilterParams,
  FilterValidations,
} from 'src/app/models/common/CaseSearch.model';
import { CommonUtilitiesService } from '../../../../services/common-utilities.service';
import { CONSTANTS } from '../../../../constants/constants';
import { AdvancedSearchService } from '../advanced-search.service';
import { take } from 'rxjs/operators';
declare let $: any;

@Component({
  selector: 'app-additional-filters',
  templateUrl: './additional-filters.component.html',
  styleUrls: ['./additional-filters.component.scss'],
})
export class AdditionalFiltersComponent implements OnInit {
  @Input() searchResults: any;
  @Input() filterType: string;

  @Output() filteredResultsEmitter: EventEmitter<Array<any>> =
    new EventEmitter<any>();
  @Output() filterCountEmitter: EventEmitter<Number> =
    new EventEmitter<Number>();

  filterParams: FilterParams = new FilterParams();
  tags: Array<any> = [];
  enableSearch = true;
  dateRange = {
    institution: {
      min: null,
      max: null,
    },
    filing: {
      min: null,
      max: null,
    },
    termination: {
      min: null,
      max: null,
    },
  };
  validations: FilterValidations;
  showError = true;
  decisionOutcomeList: Array<any> = [];
  dropdownOptions: any;
  selectedDecisionOutcome: any;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;
  decisionOutcomeDisplayName: string = '';

  constructor(
    private readonly commonUtils: CommonUtilitiesService,
    private advancedSearchService: AdvancedSearchService
  ) {}

  ngOnInit(): void {
    this.dropdownOptions = this.commonUtils.setTypeaheadOptions();
    this.getDecisionOutcomeTypes();
    this.popoverInitiate();
  }

  popoverInitiate() {
    $(function () {
      $('.fa-info-circle').hover(function () {
        $('[data-toggle="popover"]').popover({ placement: 'top' }).popover();
      });
    });
  }

  getDecisionOutcomeTypes() {
    // this.commonUtils.getDecisionOutcomeTypes(`${CONSTANTS.REFERENCE_TYPES.TYPE_CODE}${CONSTANTS.REFERENCE_TYPES.DECISION_OUTCOME}`).subscribe((decisionOutcomeResponse) => {
    //   this.decisionOutcomeList = this.commonUtils.setTypeaheadList(decisionOutcomeResponse[0].decisionOutcomeGroupTypes[0].decisionOutComeTypes, 'identifier', 'descriptionText');
    // });
    this.advancedSearchService
      .getDecisionOutcomeTypes()
      .pipe(take(1))
      .subscribe(
        (decisionOutcomeTypes) => {
          this.decisionOutcomeList = decisionOutcomeTypes;
        },
        (decisionOutcomeFailure) => {}
      );
  }

  setDecisionOutcome(e) {
    const foundDecisionOutcome = this.decisionOutcomeList.find((decision) => {
      /** using == instead of === because decision could be number or string */
      // return decision.identifier == e.item.identifier;
      return decision.identifier == e.identifier;
    });

    this.filterParams.decisionOutcome = foundDecisionOutcome
      ? foundDecisionOutcome.descriptionText
      : null;
  }

  applyFilters(filtersDropdown) {
    if (this.validateFilters()) {
      // if (filtersDropdown) {
      //   filtersDropdown.close();
      // }
      let filteredResults = [];

      this.searchResults.forEach((item) => {
        let checkNextCondition = true;
        let keyDateEpoch = null;

        // Party name
        if (checkNextCondition && this.filterParams.partyName) {
          let foundParty = false;
          if (checkNextCondition && this.filterParams.additionalRealParty) {
            foundParty = this.findParty(
              item,
              'additionalPartyList',
              this.filterParams.partyName
            );
          }
          if (!foundParty && this.filterParams.counsel) {
            foundParty = this.findParty(
              item,
              'counselList',
              this.filterParams.partyName
            );
          }
          checkNextCondition = foundParty;
        }

        // Patent description
        if (checkNextCondition && this.filterParams.patentDescription) {
          if (item.poInventionTitleTx === undefined) {
            checkNextCondition = false;
          } else {
            checkNextCondition = item.poInventionTitleTx
              .toLowerCase()
              .includes(this.filterParams.patentDescription.toLowerCase());
          }
        }
        // Patent type
        // if (
        //   checkNextCondition &&
        //   this.filterParams.designPatent &&
        //   this.filterParams.reissueNumber
        // ) {
        //   if (item.poPatentNumber) {
        //     checkNextCondition =
        //       item.poPatentNumber.toLowerCase().includes('d') ||
        //       item.poPatentNumber.toLowerCase().includes('re');
        //   }
        // } else {
        //   if (
        //     checkNextCondition &&
        //     this.filterParams.designPatent &&
        //     item.poPatentNumber
        //   ) {
        //     checkNextCondition = item.poPatentNumber
        //       .toLowerCase()
        //       .includes('d');
        //   } else {
        //     checkNextCondition = false;
        //   }

        //   if (
        //     checkNextCondition &&
        //     this.filterParams.reissueNumber &&
        //     item.poPatentNumber
        //   ) {
        //     checkNextCondition = item.poPatentNumber
        //       .toLowerCase()
        //       .includes('re');
        //   } else {
        //     checkNextCondition = false;
        //   }
        // }
        if (checkNextCondition) {
          if (
            this.filterParams.designPatent &&
            this.filterParams.reissueNumber
          ) {
            if (item.poPatentNumber) {
              checkNextCondition =
                item.poPatentNumber.toLowerCase().includes('d') ||
                item.poPatentNumber.toLowerCase().includes('re');
            } else {
              checkNextCondition = false;
            }
          } else if (this.filterParams.designPatent) {
            if (item.poPatentNumber) {
              checkNextCondition = item.poPatentNumber
                .toLowerCase()
                .includes('d');
            } else {
              checkNextCondition = false;
            }
          } else if (this.filterParams.reissueNumber) {
            if (item.poPatentNumber) {
              checkNextCondition = item.poPatentNumber
                .toLowerCase()
                .includes('re');
            } else {
              checkNextCondition = false;
            }
          }
        }

        // Institution date range
        if (
          checkNextCondition &&
          (this.filterParams.institutionDateFrom ||
            this.filterParams.institutionDateTo)
        ) {
          if (item.institutionDecisionDate) {
            keyDateEpoch = new Date(item.institutionDecisionDate).getTime();
            checkNextCondition = this.checkDateRange(
              this.filterParams.institutionDateFrom,
              this.filterParams.institutionDateTo,
              keyDateEpoch
            );
          } else {
            checkNextCondition = false;
          }
        }

        // Filing date range
        if (
          checkNextCondition &&
          (this.filterParams.filingDateFrom || this.filterParams.filingDateTo)
        ) {
          if (item.prcdCreatedTs) {
            keyDateEpoch = new Date(item.prcdCreatedTs).getTime();
            checkNextCondition = this.checkDateRange(
              this.filterParams.filingDateFrom,
              this.filterParams.filingDateTo,
              keyDateEpoch
            );
          } else {
            checkNextCondition = false;
          }
        }

        // Termination date range
        if (
          checkNextCondition &&
          (this.filterParams.terminationDateFrom ||
            this.filterParams.terminationDateTo)
        ) {
          if (item.terminationDate) {
            keyDateEpoch = new Date(item.terminationDate).getTime();
            checkNextCondition = this.checkDateRange(
              this.filterParams.terminationDateFrom,
              this.filterParams.terminationDateTo,
              keyDateEpoch
            );
          } else {
            checkNextCondition = false;
          }
        }

        // Decision outcome
        if (checkNextCondition && this.filterParams.decisionOutcome) {
          if (
            item.decisionOutcome &&
            item.decisionOutcome.toLowerCase() ===
              this.filterParams.decisionOutcome.toLowerCase()
          ) {
            checkNextCondition = true;
          } else {
            checkNextCondition = false;
          }
        }
        if (checkNextCondition) {
          filteredResults.push(item);
        }
      });
      this.addTags();
      if (filtersDropdown) {
        this.cancel(filtersDropdown);
      }
      this.filteredResultsEmitter.emit(filteredResults);
    }
  }

  findParty(item, partyToFind, searchCriteria) {
    let foundParty = false;
    if (
      item.allPartiesInfoParsed &&
      item.allPartiesInfoParsed.petitioner &&
      item.allPartiesInfoParsed.petitioner[partyToFind] &&
      item.allPartiesInfoParsed.petitioner[partyToFind].length > 0
    ) {
      const petitionerPartyFound = item.allPartiesInfoParsed.petitioner[
        partyToFind
      ].find((info) => {
        return info
          ? info.toLowerCase().includes(searchCriteria.toLowerCase())
          : null;
      });
      if (petitionerPartyFound) {
        foundParty = true;
      }
    }
    if (
      !foundParty &&
      item.allPartiesInfoParsed &&
      item.allPartiesInfoParsed.patentOwner &&
      item.allPartiesInfoParsed.patentOwner[partyToFind] &&
      item.allPartiesInfoParsed.patentOwner[partyToFind].length > 0
    ) {
      const poPartyFound = item.allPartiesInfoParsed.patentOwner[
        partyToFind
      ].find((info) => {
        return info
          ? info.toLowerCase().includes(searchCriteria.toLowerCase())
          : null;
      });
      if (poPartyFound) {
        foundParty = true;
      }
    }
    return foundParty;
  }

  validateFilters() {
    this.validations = new FilterValidations();
    let formIsValid = true;

    if (this.filterParams.partyName) {
      if (
        !this.filterParams.additionalRealParty &&
        !this.filterParams.counsel
      ) {
        this.validations.partyNameHasError = true;
        this.validations.partyNameMessage =
          'Please select at least 1 party type';
        formIsValid = false;
      }
    }

    formIsValid = this.validateDateRanges(
      this.filterParams.institutionDateFrom,
      this.filterParams.institutionDateTo,
      'institution',
      formIsValid
    );
    formIsValid = this.validateDateRanges(
      this.filterParams.filingDateFrom,
      this.filterParams.filingDateTo,
      'filing',
      formIsValid
    );
    formIsValid = this.validateDateRanges(
      this.filterParams.terminationDateFrom,
      this.filterParams.terminationDateTo,
      'termination',
      formIsValid
    );
    return formIsValid;
  }

  validateDateRanges(fromDate, toDate, dateType, formIsValid) {
    if (fromDate && !toDate) {
      this.validations[`${dateType}ToHasError`] = true;
      this.validations[`${dateType}Message`] = "Please enter 'to' date";
      formIsValid = false;
    } else if (!fromDate && toDate) {
      this.validations[`${dateType}FromHasError`] = true;
      this.validations[`${dateType}Message`] = "Please enter 'from' date";
      formIsValid = false;
    }
    if (fromDate && toDate) {
      const fromDateEpoch = this.commonUtils.convertDatePickerToEpoch(fromDate);
      const toDateEpooch = this.commonUtils.convertDatePickerToEpoch(toDate);
      if (fromDateEpoch > toDateEpooch) {
        this.validations[`${dateType}ToHasError`] = true;
        this.validations[`${dateType}FromHasError`] = true;
        this.validations[
          `${dateType}Message`
        ] = `'To' ${dateType} date must be greater than 'from' ${dateType} date`;
        formIsValid = false;
      }
    }
    return formIsValid;
  }

  checkDateRange(dateFrom, dateTo, keyDateEpoch) {
    const fromDateInEpoch = this.commonUtils.convertDatePickerToEpoch(dateFrom);
    const toDateInEpoch = this.commonUtils.convertDatePickerToEpoch(dateTo);

    if (dateFrom && dateTo) {
      return keyDateEpoch >= fromDateInEpoch && keyDateEpoch <= toDateInEpoch;
    } else if (dateFrom && !dateTo) {
      return keyDateEpoch >= fromDateInEpoch;
    } else if (dateTo && !dateFrom) {
      return keyDateEpoch <= toDateInEpoch;
    } else {
      return false;
    }
  }

  addTags() {
    this.tags = [];
    if (
      this.filterParams.partyName &&
      (this.filterParams.additionalRealParty || this.filterParams.counsel)
    ) {
      const parties = [];
      if (this.filterParams.additionalRealParty) {
        parties.push('Additional real party');
      }
      if (this.filterParams.counsel) {
        parties.push('Counsel');
      }
      this.tags.push({
        description: `${parties.join('/')}: ${this.filterParams.partyName}`,
        tooltip: `${parties.join(' and ')}`,
        tagType: 'party',
      });
    }

    if (this.filterParams.patentDescription) {
      this.tags.push({
        description: `${this.filterParams.patentDescription}`,
        tooltip: `${this.filterParams.patentDescription}`,
        tagType: 'patentDescription',
      });
    }

    if (this.filterParams.designPatent) {
      this.tags.push({
        description: `Design patent`,
        tooltip: `Design patent`,
        tagType: 'designPatent',
      });
    }

    if (this.filterParams.reissueNumber) {
      this.tags.push({
        description: `Reissue number`,
        tooltip: `Reissue number`,
        tagType: 'reissueNumber',
      });
    }

    if (
      this.filterParams.institutionDateFrom &&
      this.filterParams.institutionDateTo
    ) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.institutionDateFrom
      );
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.institutionDateTo
      );
      this.tags.push({
        description: `Institution date range: ${fromDate} to ${toDate}`,
        tooltip: `Institution date range: ${fromDate} to ${toDate}`,
        tagType: 'institutionDate',
      });
    }

    if (this.filterParams.filingDateFrom && this.filterParams.filingDateTo) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.filingDateFrom
      );
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.filingDateTo
      );
      this.tags.push({
        description: `Filing date range: ${fromDate} to ${toDate}`,
        tooltip: `Filing date range: ${fromDate} to ${toDate}`,
        tagType: 'filingDate',
      });
    }

    if (
      this.filterParams.terminationDateFrom &&
      this.filterParams.terminationDateTo
    ) {
      const fromDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.terminationDateFrom
      );
      const toDate = this.commonUtils.convertDatePickerToDisplayDate(
        this.filterParams.terminationDateTo
      );
      this.tags.push({
        description: `Termination date range: ${fromDate} to ${toDate}`,
        tooltip: `Termination date range: ${fromDate} to ${toDate}`,
        tagType: 'terminationDate',
      });
    }

    if (this.filterParams.decisionOutcome) {
      this.tags.push({
        description: this.filterParams.decisionOutcome,
        tooltip: this.filterParams.decisionOutcome,
        tagType: 'decision',
      });
    }

    this.filterCountEmitter.emit(this.tags.length);
  }

  removeTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
    switch (tag.tagType) {
      case 'party':
        this.filterParams.partyName = null;
        break;
      case 'patentDescription':
        this.filterParams.patentDescription = null;
        break;
      case 'designPatent':
        this.filterParams.designPatent = null;
        break;
      case 'reissueNumber':
        this.filterParams.reissueNumber = null;
        break;
      case 'institutionDate':
        this.filterParams.institutionDateFrom = null;
        this.filterParams.institutionDateTo = null;
        break;
      case 'filingDate':
        this.filterParams.filingDateFrom = null;
        this.filterParams.filingDateTo = null;
        break;
      case 'terminationDate':
        this.filterParams.terminationDateFrom = null;
        this.filterParams.terminationDateTo = null;
        break;
      case 'decision':
        this.filterParams.decisionOutcome = null;
        this.decisionOutcomeDisplayName = '';
        break;
      default:
        break;
    }
    this.applyFilters(null);
  }

  clearFilters() {
    this.validations = new FilterValidations();
    this.dateRange = {
      institution: {
        min: null,
        max: null,
      },
      filing: {
        min: null,
        max: null,
      },
      termination: {
        min: null,
        max: null,
      },
    };
    this.filterParams = new FilterParams();
    this.tags = [];
    this.applyFilters(null);
    this.decisionOutcomeDisplayName = '';
  }

  cancel(dropdown) {
    dropdown.hide();
    // this.validations = new FilterValidations();
    // this.dateRange = {
    //   institution: {
    //     min: null,
    //     max: null,
    //   },
    //   filing: {
    //     min: null,
    //     max: null,
    //   },
    //   termination: {
    //     min: null,
    //     max: null,
    //   },
    // };
    // this.filterParams = new FilterParams();
    // this.tags = [];
  }

  setMinMaxDate(range, dateType, dateVal) {
    if (range === 'from') {
      this.dateRange[dateType].min =
        this.commonUtils.setDateOnDatePicker(dateVal);
    } else if (range === 'to') {
      this.dateRange[dateType].max =
        this.commonUtils.setDateOnDatePicker(dateVal);
    }
  }
}
