import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Urls } from 'src/app/constants/urls';
import { DatePipe } from '@angular/common';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class CaseViewerService {
  private EXTERNAL_SERVICE_BASE = environment.EXTERNAL_SERVICE_API;
  private TRIAL_SERVICE_BASE: string = environment.TRIAL_SERVICE_API;
  private COMMON_SERVICE_BASE: string = environment.COMMON_SERVICE_API;

  constructor(private http: HttpClient, private datePipe: DatePipe) {}
  private refreshSource = new BehaviorSubject(undefined);
  refreshHeader = this.refreshSource.asObservable();
  getCaseHeaderInfo(proceedingNumber: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CASEVIEWER.HEADER}${proceedingNumber}`
      )
      .pipe(
        map((caseHeaderResponse) => {
          return caseHeaderResponse;
        })
      );
  }
  initiateRefresh(message) {
    this.refreshSource.next(message);
  }
  getDownloadHeaders() {
    let userName = JSON.parse(window.sessionStorage.getItem('userInfo'));
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': userName.userId,
      }),
      withCredentials: true,
      crossDomain: true,
      responseType: 'arraybuffer' as 'json',
    };
    return httpOptions;
  }

  // TODO Change to external service
  getCaseStatus(proceedingNumber: string): Observable<any> {
    return this.http
      .get<any>(
        // `${this.TRIAL_SERVICE_BASE}${Urls.CASEVIEWER.CASE_STATUS}${proceedingNumber}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CASEVIEWER.CASE_STATUS}${proceedingNumber}`
      )
      .pipe(
        map((caseStatusResponse) => {
          return caseStatusResponse;
        })
      );
  }

  getPartyRepresenting(proceedingNumber: string): Observable<any> {
    return this.http
      .get(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.PARTY_REPRESENTING}${proceedingNumber}`,
        { responseType: 'text' }
      )
      .pipe(
        map((partyRepresenting) => {
          return partyRepresenting;
        })
      );
  }

  caseSearch(proceedingNumber: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CASEVIEWER.SEARCH}${proceedingNumber}`
      )
      .pipe(
        map((caseSearchResponse) => {
          return caseSearchResponse;
        })
      );
  }

  getAvailabilities(referenceType: string, isPublic: boolean) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((availabilities) => {
          return availabilities;
        })
      );
  }

  getMotionTypes(referenceType: string, isPublic: boolean): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((motionTypesResponse) => {
          return motionTypesResponse;
        })
      );
  }

  getSpecificMotionPaperType(motionType) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/references/documentTypes?motionTypeName=${motionType}`
      )
      .pipe(
        map((specificPaperType) => {
          return specificPaperType[0];
        })
      );
  }

  getSpecificRehearingPaperType(rehearingType) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/references/documentTypes?rehearingTypeName=${rehearingType}`
      )
      .pipe(
        map((specificPaperType) => {
          return specificPaperType;
        })
      );
  }

  getMotionPaperTypes(categoryType: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.MOTIONS_PAPER_TYPES}${categoryType}`
      )
      .pipe(
        map((motionsPaperTypesResponse) => {
          return motionsPaperTypesResponse;
        })
      );
  }

  getNoticeOfAppealPaperTypes(identifier: number): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.PAPER_TYPE_BY_ID}${identifier}`
      )
      .pipe(
        map((noticeOfAppealPaperTypesResponse) => {
          return noticeOfAppealPaperTypesResponse;
        })
      );
  }

  getRehearingTypes(categoryType: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${categoryType}`
      )
      .pipe(
        map((rehearingTypesResponse) => {
          return rehearingTypesResponse;
        })
      );
  }

  getPaperTypesByCategory(categoryType: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.MOTIONS_PAPER_TYPES}${categoryType}`
      )
      .pipe(
        map((paperTypesResponse) => {
          return paperTypesResponse;
        })
      );
  }

  saveSubmitMotion(motion): Observable<any> {
    return this.http
      .post<any>(
        // `${this.TRIAL_SERVICE_BASE}${Urls.MOTIONS.SAVE_SUBMIT}`,
        `${this.EXTERNAL_SERVICE_BASE}${Urls.MOTIONS.SAVE_SUBMIT}`,
        motion
      )
      .pipe(
        map((motionSaveResponse) => {
          return motionSaveResponse;
        })
      );
  }

  updateMotion(motion, motionId): Observable<any> {
    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.MOTIONS.UPDATE}${motionId}`,
        motion
      )
      .pipe(
        map((motionUpdateResponse) => {
          return motionUpdateResponse;
        })
      );
  }

  // TODO Change to external service
  getMotionsOnCase(
    proceedingNo: string,
    excludeArtifacts: boolean,
    actionType: string,
    partyRepresenting: string
  ): Observable<any> {
    return this.http
      .get<any>(
        // `${this.TRIAL_SERVICE_BASE}${Urls.MOTIONS.MOTIONS_ON_CASE}${proceedingNo}&motionStatus=ALL&excludeArtifacts=${excludeArtifacts}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.MOTIONS.MOTIONS_ON_CASE}${proceedingNo}&motionStatus=ALL&excludeArtifacts=${excludeArtifacts}`
      )
      .pipe(
        map((motionsOnCaseResponse) => {
          const motionsOnCase = [];
          let existingMotionsList = [];
          motionsOnCaseResponse.forEach((motion) => {
            if (motion.motionStatusName.toLowerCase().includes('pending')) {
              motionsOnCase.push(motion);
            }
          });
          motionsOnCase.forEach((motion) => {
            motion.filedDateString = this.convertDateToString(
              new Date(motion.filedDate).getTime()
            );
            switch (actionType) {
              case 'OPPOSITION':
                if (
                  motion.requestorTypeName.toLowerCase() !==
                  partyRepresenting.toLocaleLowerCase()
                ) {
                  existingMotionsList.push(motion);
                }
                break;
              case 'REPLY':
                if (
                  motion.requestorTypeName.toLowerCase() ===
                  partyRepresenting.toLocaleLowerCase()
                ) {
                  existingMotionsList.push(motion);
                }
                break;
              default:
                existingMotionsList = motionsOnCase;
                break;
            }
          });

          return existingMotionsList;
        })
      );
  }

  convertDateToString(epochDate) {
    if (!epochDate) {
      return '';
    }
    if (epochDate.toString().length > 10) {
      return this.datePipe.transform(
        parseInt(epochDate),
        'MM/dd/yyyy hh:mm a '
      );
    } else {
      return this.datePipe.transform(
        parseInt(epochDate) * 1000,
        'MM/dd/yyyy hh:mm a '
      );
    }
  }

  getAllMotionsOnCase(
    proceedingNo: string,
    excludeArtifacts: boolean
  ): Observable<any> {
    return this.http
      .get<any>(
        // `${this.TRIAL_SERVICE_BASE}${Urls.MOTIONS.MOTIONS_ON_CASE}${proceedingNo}&motionStatus=ALL&excludeArtifacts=${excludeArtifacts}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.MOTIONS.MOTIONS_ON_CASE}${proceedingNo}&motionStatus=ALL&excludeArtifacts=${excludeArtifacts}`
      )
      .pipe(
        map((motionsOnCaseResponse) => {
          return motionsOnCaseResponse;
        })
      );
  }

  getDocumentsForUpdate(url: string): Observable<any> {
    return this.http.get<any>(this.EXTERNAL_SERVICE_BASE + url);
  }

  getNextPaperNumber(proceedingNo: string): Observable<any> {
    return this.http.get<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.NEXT_PAPER_NUM_URL}${proceedingNo}`
    );
  }

  getCounselInfo(proceedingNumber: string): Observable<any> {
    return this.http.get<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.GET}${proceedingNumber}`
    );
  }

  getPayments(proceedingNo: string): Observable<any> {
    return this.http.get<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.PAYMENTS}${proceedingNo}`
    );
  }

  downloadExcel(proceedingNo: string): Observable<any> {
    return this.http.get<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.DOWNLOAD_EXCEL}${proceedingNo}`,
      this.getDownloadHeaders()
    );
  }

  downloadEwf(documentsToDownload: ArrayBuffer): Observable<any> {
    return this.http.post<ArrayBuffer>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.DOWNLOAD_EWF}`,
      documentsToDownload,
      this.getDownloadHeaders()
    );
  }

  getRehearingsOnProceeding(
    proceedingNumber: string,
    status: string
  ): Observable<any> {
    return this.http.get<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.REHEARINGS.PER_CASE}${proceedingNumber}&rehearingStatus=${status}`
    );
  }

  saveSubmitRehearing(rehearing): Observable<any> {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REHEARINGS.SAVE_SUBMIT}`,
        rehearing
      )
      .pipe(
        map((rehearingSaveResponse) => {
          return rehearingSaveResponse;
        })
      );
  }

  updateRehearing(rehearing, rehearingId): Observable<any> {
    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REHEARINGS.UPDATE}${rehearingId}`,
        rehearing
      )
      .pipe(
        map((rehearingUpdateResponse) => {
          return rehearingUpdateResponse;
        })
      );
  }

  openPdf(proceedingId: string, artifactId: string) {
    const email = window.sessionStorage.getItem('email');
    let url = `${this.EXTERNAL_SERVICE_BASE}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`;
    if (email === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`;
    }
    window.open(url, '_blank');
    // return this.http.get(url, { responseType: 'arraybuffer' as 'json' }).pipe(
    //   map((pdfResponse) => {
    //     return pdfResponse;
    //   })
    // );
  }

  getExistingRehearingDocuments(rehearingInfo): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/case-viewer/proceeding-number/rehearings?proceedingNumber=${rehearingInfo.proceedingNo}&rehearingId=${rehearingInfo.rehearingId}`
      )
      .pipe(
        map((existingRehearingResponse) => {
          return existingRehearingResponse;
        })
      );
  }

  getExistingMotionDocuments(motionInfo): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/case-viewer/proceeding-number/motions?proceedingNumber=${motionInfo.proceedingNo}&excludeArtifacts=false&motionId=${motionInfo.motionId}&motionStatus=ALL`
      )
      .pipe(
        map((existingMotionResponse) => {
          return existingMotionResponse;
        })
      );
  }

  getMotionsOnProceeding(proceedingNo, motionStatus): Observable<any> {
    let url = `${this.EXTERNAL_SERVICE_BASE}/case-viewer/proceeding-number/motions?proceedingNumber=${proceedingNo}`;
    if (motionStatus !== 'ALL') {
      url = `${url}&motionStatus=${motionStatus}`;
    }
    return this.http.get<any>(url).pipe(
      map((motionsResponse) => {
        return motionsResponse;
      })
    );
  }

  deleteMotion(motionId): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}/trials/motions/delete-motion/${motionId}`
      )
      .pipe(
        map((deleteMotionResponse) => {
          return deleteMotionResponse;
        })
      );
  }

  deleteRehearing(rehearingId): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}/trials/rehearing-info/delete-rehearing/${rehearingId}`
      )
      .pipe(
        map((deleteRehearingResponse) => {
          return deleteRehearingResponse;
        })
      );
  }

  getPrelimResponseTypes() {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/references?typeCode=documentTypes&categoryType=POPR`
      )
      .pipe(
        map((poprTypes) => {
          return poprTypes;
        })
      );
  }

  submitNoticeOfAppeal(noticeOfAppeal): Observable<any> {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.APPEALS.SUBMIT}`,
        noticeOfAppeal
      )
      .pipe(
        map((noticeOfAppealResponse) => {
          return noticeOfAppealResponse;
        })
      );
  }

  getAppealsOnProceeding(proceedingNo): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/case-viewer/proceeding-number/appeals?proceedingNumber=${proceedingNo}&appealStatus=ALL`
      )
      .pipe(
        map((appealsResponse) => {
          appealsResponse.forEach((notice) => {
            notice.appealNoticeDt = this.convertDate(notice.appealNoticeDt);
            notice.courtDecisionDt = this.convertDate(notice.courtDecisionDt);
            notice.courtMandateDt = this.convertDate(notice.courtMandateDt);
          });
          return appealsResponse;
        })
      );
  }

  // TODO Change to external service
  getOtherDocumentPaperTypes(proceedingNumber, recipientType): Observable<any> {
    return this.http
      .get<any>(
        // `${this.COMMON_SERVICE_BASE}${Urls.DOCUMENTS.OTHER_DOCUMENTS}${proceedingNumber}&recipientType=${recipientType}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.OTHER_DOCUMENTS}${proceedingNumber}&recipientType=${recipientType}&isOtherDocs=true`
      )
      .pipe(
        map((otherDocumentPaperTypesResponse) => {
          return otherDocumentPaperTypesResponse;
        })
      );
  }

  submitOtherDocuments(documentsToUpload: any): Observable<any> {
    return this.http
      .post<any>(
        // `${this.TRIAL_SERVICE_BASE}/proceeding-artifacts`,
        `${this.EXTERNAL_SERVICE_BASE}/proceeding-artifacts`,
        documentsToUpload
      )
      .pipe(
        map((otherDocumentsResponse) => {
          return otherDocumentsResponse;
        })
      );
  }

  convertDate(dateToConvert) {
    if (dateToConvert) {
      return this.datePipe.transform(dateToConvert, 'MM/dd/yyyy');
    } else {
      return '';
    }
  }

  getPaymentInfoByProceedingNo(proceedingNo: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.FEE_CALCULATION}${proceedingNo}&isMotionFeeCalculation=true`
      )
      .pipe(
        map((paymentInfo) => {
          return paymentInfo.feeCalculations[0];
        })
      );
  }

  redirectToFPNG(petitionIdentifier, data) {
    //
    return this.http
      .post<any>(
        // `https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/petitions/${petitionIdentifier}/payments`,
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionIdentifier}/payments`,
        data
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  redirectToFPNGForMotions(petitionIdentifier, data) {
    //
    return this.http
      .post<any>(
        // `https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/petitions/${petitionIdentifier}/adhoc-payments`,
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionIdentifier}/adhoc-payments`,
        data
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getMotionByMotionId(motionId) {
    return this.http
      .get(
        // `https://ptacts-intservices.pvt.uspto.gov/ptacts/motions/${motionId}`
        `${this.EXTERNAL_SERVICE_BASE}/motions/${motionId}`
      )
      .pipe(
        map((motionResponse) => {
          return motionResponse;
        })
      );
  }

  getSpecificMotionPaymentDetails(petitionId, receiptId) {
    return this.http
      .get(
        // `https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/petitions/${petitionId}/payments/${receiptId}/receipt`
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionId}/payments/${receiptId}/receipt`
      )
      .pipe(
        map((motionsPaymentDetails) => {
          return motionsPaymentDetails;
        })
      );
  }

  getJoinedCases(proceedingNumber) {
    return this.http.get(
      `${this.EXTERNAL_SERVICE_BASE}/joinder?caseNumber=${proceedingNumber}`
    );
  }

  getUsersRepresentation(proceedingNo) {
    return this.http.get(
      `${this.EXTERNAL_SERVICE_BASE}/external-user/prcdingparty-group-type?proceedingNo=${proceedingNo}`
    );
  }

  updateDocument(
    docToUpdate: any,
    updatedForm: FormGroup,
    proceedingNo: string
  ): Observable<any> {
    let updateDocObj = {
      artifactIdentifer: docToUpdate.artifactIdentifer,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        createUserIdentifier: window.sessionStorage.getItem('email'),
      },
      availability: updatedForm.value.availability.code,
      category: docToUpdate.docType.toUpperCase(),
      contentManagementId: docToUpdate.contentManagementId,
      documentTypeIdentifier: docToUpdate.paperType.identifier,
      fileSize: docToUpdate.fileToUpload.size,
      filingDate: docToUpdate.filingDate,
      filingParty: docToUpdate.filingParty.toUpperCase(),
      name: updatedForm.value.documentName,
      fileName: updatedForm.controls.fileName.value,
      proceedingNumberText: proceedingNo,
      ptabDefaultRefreshTime: null,
      ptabReadOnlyUser: false,
      textExtractionIndicator: null,
      exhibitNumber: updatedForm.value.exhibitNumber
        ? updatedForm.value.exhibitNumber
        : null,
    };

    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.EDIT}${docToUpdate.artifactIdentifer}`,
        updateDocObj
      )
      .pipe(
        map((editDocumentResponse) => {
          return editDocumentResponse;
        })
      );
  }

  getDropdownAccess(proceedingNumber: string) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/external-user/dropdownList?proceedingNo=${proceedingNumber}`
      )
      .pipe(
        map((dropdownAccessResponse) => {
          return dropdownAccessResponse;
        })
      );
  }

  addStaff(staff: any): Observable<any> {
    return this.http
      .post<any>(
        // `${this.TRIAL_BASE_URL}${Urls.staff.ADD}${partyRepresentIndicator}`,
        `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.ADD_STAFF}`,
        staff
      )
      .pipe(
        map((addStaffResponse) => {
          return addStaffResponse;
        })
      );
  }

  updateStaff(staffToUpdate: any): Observable<any> {
    return (
      this.http
        // .put<any>(`${this.TRIAL_BASE_URL}${Urls.COUNSEL.UPDATE}`, counselToUpdate)
        .put<any>(
          `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.UPDATE_STAFF}`,
          staffToUpdate
        )
        .pipe(
          map((updateStaffResponse) => {
            return updateStaffResponse;
          })
        )
    );
  }

  getAllExhibitNumbers(proceedingNumber, partyRepresenting) {
    let typeId = null;
    switch (partyRepresenting) {
      case 'PETITIONER':
        typeId = 1;
        break;
      case 'PATENT OWNER':
        typeId = 2;
        break;
      case 'BOARD':
        typeId = 3;
        break;
      default:
        break;
    }

    return this.http
      .get(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.ALL_EXHIBIT_NOS}${proceedingNumber}&typeId=${typeId}`
      )
      .pipe(
        map((allExhibitNumbers) => {
          return allExhibitNumbers;
        })
      );
  }

  deleteStaff(
    proceedingNumber: string,
    proceedingPartyIdentifier: number
  ): Observable<any> {
    return this.http
      .delete<any>(
        // `${this.TRIAL_BASE_URL}${Urls.COUNSEL.DELETE}${proceedingNumber}&proceedingPartyIdentifier=${proceedingPartyIdentifier}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.DELETE_STAFF}${proceedingNumber}&proceedingPartyIdentifier=${proceedingPartyIdentifier}`
      )
      .pipe(
        map((deleteCounselResponse) => {
          return deleteCounselResponse;
        })
      );
  }
}
