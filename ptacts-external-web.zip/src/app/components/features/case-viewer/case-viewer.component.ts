import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  getPartyRepresenting,
  getPetitionIdentifier,
  setNewPetitionInfo,
  setTrialInfo,
} from 'src/app/store/ptacts/ptacts.actions';
import { CaseViewerService } from './case-viewer.service';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-case-viewer',
  templateUrl: './case-viewer.component.html',
  styleUrls: ['./case-viewer.component.scss'],
})
export class CaseViewerComponent implements OnInit, OnDestroy {
  caseInfo = {
    serialNo: null,
    proceedingNo: null,
  };
  bc: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private store: Store<PtactsState>,
    private caseViewerService: CaseViewerService,
    private initiatePetitionService: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };
    let petitionInfo = {
      proceedingNumberText: this.caseInfo.proceedingNo,
      serialNo: this.caseInfo.serialNo,
      trialType: this.caseInfo.proceedingNo.substr(0, 3),
    };
    window.sessionStorage.setItem('petitionInfo', JSON.stringify(petitionInfo));

    this.store.dispatch(setNewPetitionInfo({ request: petitionInfo }));
    // this.setActiveTab(window.location.hash.split('/'));
    this.setActiveTab(window.location.href.split('/'));
    this.getPartyRepresenting();
    this.getPetitionIdentifier();
    document.title = `${this.caseInfo.proceedingNo} - Case Viewer`;
  }

  ngOnDestroy() {
    const globalHeader =
      document.querySelectorAll<HTMLElement>('.case-viewer-item');

    if (globalHeader.length > 0) {
      globalHeader[0].style.display = 'none';
    }
  }

  getPartyRepresenting() {
    this.store.dispatch(
      getPartyRepresenting({ proceedingNo: this.caseInfo.proceedingNo })
    );
    // this.caseViewerService
    //   .getPartyRepresenting(this.caseInfo.proceedingNo)
    //   .pipe(take(1))
    //   .subscribe(
    //     (partyRepresenting) => {
    //       if (partyRepresenting.toLowerCase() === 'patentowner') {
    //         partyRepresenting = 'PATENT OWNER';
    //       }
    //       window.sessionStorage.setItem('partyRepresenting', partyRepresenting);
    //     },
    //     (noPartyRepresentingFound) => {
    //
    //     }
    //   );
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.caseInfo.proceedingNo)
      .pipe(take(1))
      .subscribe(
        () => {
          this.store.dispatch(
            getPetitionIdentifier({ proceedingNo: this.caseInfo.proceedingNo })
          );
        },
        (petitionIdError) => {
          if (petitionIdError.status == 401) {
            this.router.navigate([`ui/unauthorized`]);
          }
        }
      );
  }

  setActiveTab(paramsList) {
    const el = document.getElementById(paramsList[paramsList.length - 1]);
    el.classList.add('active');
  }

  navigateTo(url) {
    this.router.navigate([
      `ui/case-viewer/${this.caseInfo.serialNo}/${this.caseInfo.proceedingNo}/${url}`,
    ]);
  }
}
