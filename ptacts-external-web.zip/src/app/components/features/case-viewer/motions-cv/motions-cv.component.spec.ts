import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotionsCvComponent } from './motions-cv.component';

describe('MotionsCvComponent', () => {
  let component: MotionsCvComponent;
  let fixture: ComponentFixture<MotionsCvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotionsCvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotionsCvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
