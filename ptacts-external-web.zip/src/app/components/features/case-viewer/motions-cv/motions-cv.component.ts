import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { DatePipe } from '@angular/common';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-motions-cv',
  templateUrl: './motions-cv.component.html',
  styleUrls: ['./motions-cv.component.scss'],
})
export class MotionsCvComponent implements OnInit {
  expanded: boolean = false;
  allClassActive: boolean = false;
  pendingClassActive: boolean = false;
  unsubmittedClassActive: boolean = false;
  tableOptions: any;
  dataList: any;
  motions = {
    ALL: [],
    INITIATED: [],
    PENDING_REVIEW: [],
  };
  orderByField: any[] = [];
  motionTypes = ['ALL', 'PENDING_REVIEW', 'INITIATED'];
  activeTab: string = 'Pending';
  petitionInfo: any = null;
  petitionIdentifier: any;
  documentsTableColSpan: number = 6;
  pendingColDef = [
    {
      name: 'Motion submitted date',
      displayName: 'Motion submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '215px',
      minWidth: '215px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Motion type',
      displayName: 'Motion type',
      field: 'motionTypeNm',
      width: '215px',
      minWidth: '215px',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Motion status',
      displayName: 'Motion status',
      field: 'motionStatusName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Motion',
      displayName: 'View motion',
      field: 'viewNotice',
      width: '150px',
      minWidth: '150px',
      type: 'string',
      searchText: null,
    },
  ];
  allColDef = [
    {
      name: 'Motion submitted date',
      displayName: 'Motion submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '215px',
      minWidth: '215px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Motion type',
      displayName: 'Motion type',
      field: 'motionTypeNm',
      width: '215px',
      minWidth: '215px',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Motion status',
      displayName: 'Motion status',
      field: 'motionStatusName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Motion',
      displayName: 'View motion',
      field: 'viewNotice',
      width: '150px',
      minWidth: '150px',
      type: 'string',
      searchText: null,
    },
  ];
  unsubmittedColDef = [
    {
      name: 'Motion initiated date',
      displayName: 'Motion initiated date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '215px',
      minWidth: '215px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Motion type',
      displayName: 'Motion type',
      field: 'motionTypeNm',
      width: '215px',
      minWidth: '215px',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Motion status',
      displayName: 'Motion status',
      field: 'motionStatusName',
      width: '160px',
      minWidth: '160px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Motion',
      displayName: 'View motion',
      field: 'viewNotice',
      width: '150px',
      minWidth: '150px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Action(s)',
      displayName: 'Action(s)',
      field: 'action',
      width: '200px',
      minWidth: '200px',
      type: 'string',
      searchText: null,
    },
  ];
  dataLoading = {
    ALL: false,
    INITIATED: false,
    PENDING_REVIEW: false,
  };

  constructor(
    public commonUtils: CommonUtilitiesService,
    private datePipe: DatePipe,
    private caseViewerService: CaseViewerService,
    private logger: NGXLogger,
    private initiatePetitionService: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.pendingClassActive = true;

    this.motionTypes.forEach((motionType) => {
      this.getMotions(motionType);
    });
    this.getPetitionIdentifier();
  }

  getMotions(motionType) {
    // const mtype =
    //   motionType === 'PENDING_REVIEW' ? 'PENDING REVIEW' : motionType;
    this.dataLoading[motionType] = true;
    this.caseViewerService
      .getMotionsOnProceeding(
        this.petitionInfo.proceedingNumberText,
        motionType
      )
      .pipe(take(1))
      .subscribe(
        (motionList) => {
          this.motions[motionType] = motionList;
          if (motionType === 'PENDING_REVIEW') {
            this.dataList = motionList;
          }
          this.dataLoading[motionType] = false;
          this.setMotionsTable('pendingColDef');
        },
        () => {
          this.dataLoading[motionType] = false;
        }
      );
    this.setMotionsTable('pendingColDef');
  }

  setMotionsTable(motionType) {
    this.tableOptions = {
      //btnId: this.REHEARINGS,
      tableId: 'rehearingTable',
      tableHeaderClass: 'rehearingTableHeader',
      tableBodyClass: 'rehearingTableBody',
      columnDefs: this[motionType],
      data: this.dataList ? JSON.parse(JSON.stringify(this.dataList)) : null,
    };
    this.commonUtils.clearTableFilter(this.tableOptions.columnDefs);
    this.orderByField.push('filedDate');
    this.sortColumn('filedDate', 'desc');
  }

  changeTab(tabName: any) {
    this.activeTab = tabName;
    //
    // this.tableOptions.columnDefs[0].displayName =
    //   'Motion submitted date (mm/dd/yyyy)';
    this.orderByField = [];
    if (tabName == 'All') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.ALL));
      this.setMotionsTable('allColDef');
      this.allClassActive = true;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Pending') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.PENDING_REVIEW));
      this.setMotionsTable('pendingColDef');
      this.allClassActive = false;
      this.pendingClassActive = true;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Unsubmitted') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.INITIATED));
      this.setMotionsTable('unsubmittedColDef');
      // this.tableOptions.columnDefs[0].displayName =
      //   'Motion initiated date (mm/dd/yyyy)';
      this.allClassActive = false;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = true;
    }
    this.documentsTableColSpan = this.tableOptions.columnDefs.length;
  }

  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    });
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field, sortType)
      : this.correctOrder('-' + field, sortType);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
  }

  correctOrder(field, sortType) {
    if (this.dataList && this.dataList.length > 0) {
      this.dataList.forEach((ele) => {
        if (ele.motionStatusDate === undefined) {
          ele.motionStatusDate = null;
        }
      });
      const tempData = [...this.dataList];
      this.dataList = [];
      const order = field.charAt(0) === '-' ? 'desc' : 'asc';
      tempData.sort(this.compareValues(field, order));
      this.dataList = [...tempData];
    }
  }

  exportCSVFile(fileTitle) {
    fileTitle = `${
      this.activeTab
    } ${fileTitle} ${this.commonUtils.getCurrentDateString(new Date())}`;
    const dataToExport = [];
    this.dataList.forEach((element) => {
      let row: any = {};
      row.filedDate = `${this.datePipe.transform(
        element.filedDate,
        'MM/dd/yyyy hh:mm a'
      )} ET`;
      row.requestorTypeName = this.commonUtils.convertStringToTitleCase(
        element.requestorTypeName
      );
      row.userPartyGroupType = this.commonUtils.convertStringToTitleCase(
        element.userPartyGroupType
      );
      row.motionTypeNm = element.motionTypeNm;
      row.motionStatusName = this.commonUtils.convertStringToTitleCase(
        element.motionStatusName
      );
      dataToExport.push(row);
    });
    let headers = [
      'Filing party',
      'Party representing',
      'Motion type',
      'Motion status',
    ];
    headers.unshift(
      this.unsubmittedClassActive
        ? 'Motion initiated date (mm/dd/yyyy)'
        : 'Motion submitted date (mm/dd/yyyy)'
    );
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  openPdf(data, proceedingId) {
    this.caseViewerService.openPdf(
      this.petitionIdentifier,
      data.artifactIdentifer
    );
    // .pipe(take(1))
    // .subscribe(
    //   (pdfResponse) => {
    //     this.commonUtils.openPdfNew(pdfResponse);
    //   },
    //   (pdfResponseError) => {
    //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   }
    // );
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  continueMotion(motion) {
    // this.router.navigate([
    //   `case-viewer/${this.petitionInfo.serialNo}/${this.petitionInfo.proceedingNumberText}`,
    // ]);
    const motionInfo = {
      proceedingNo: motion.proceedingNumber,
      motionId: motion.motionId,
    };
    window.sessionStorage.setItem('motionInfo', JSON.stringify(motionInfo));
    this.logger.info('motion: ', motion);
    document.getElementById('aia-review-info').click();
  }

  deleteMotion(motionToDelete) {
    this.caseViewerService
      .deleteMotion(motionToDelete.motionId)
      .pipe(take(1))
      .subscribe(
        (deleteMotionSuccess) => {
          this.logger.info('Delete rehearing success', deleteMotionSuccess);
          this.tableOptions.data = [];
          this.dataList = [];
          this.getMotions('ALL');
          this.getMotions('INITIATED');
          this.changeTab('Pending');
          this.commonUtils.showSuccess(
            'Successfully deleted motion request',
            'Delete motion request'
          );
        },
        (deleteMotionFailure) => {
          this.logger.error('Failed to delete motion', deleteMotionFailure);
          this.commonUtils.showError(
            'Failed to delete motion request',
            'Delete motion request'
          );
        }
      );
  }
}
