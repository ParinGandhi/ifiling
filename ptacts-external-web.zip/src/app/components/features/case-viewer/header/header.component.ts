import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { ViewDocumentsModalComponent } from '../../advanced-search/view-documents-modal/view-documents-modal.component';
import { CaseViewerService } from '../case-viewer.service';
import * as PtactsActions from 'src/app/store/ptacts/ptacts.actions';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  casePhase$ = this.store.pipe(select(PtactsSelectors.casePhaseData));
  isOpen: boolean = true;
  grayPanel = 'panel-primary';
  petitionInfo: any = null;
  caseInfo: any = null;
  caseType: string = 'OTHER';
  caseStatus: any = null;
  showJoinderDropdown: boolean = false;
  joinedCases = null;
  relatedCases = {
    originalCase: [],
    joinedCases: [],
  };
  isOriginalCase = false;
  documentsModalRef: BsModalRef = null;
  subscription: Subscription;
  constructor(
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService,
    private modalService: BsModalService,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getCaseHeaderInfo();
    // this.getCaseStatus();

    this.store.dispatch(
      PtactsActions.GetCasePhaseAction({
        url: this.petitionInfo.proceedingNumberText,
      })
    );

    this.subscription = this.caseViewerService.refreshHeader.subscribe(
      (message) => {
        if (message) {
          this.getCaseStatus();
        }
      }
    );
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getCaseHeaderInfo() {
    this.caseViewerService
      .getCaseHeaderInfo(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseHeaderResponse) => {
        this.caseInfo = caseHeaderResponse[0];
        this.caseType = this.caseInfo.proceedingNumber.substring(0, 3);
        this.checkForJoinedCases();
      });
  }

  getCaseStatus() {
    this.caseViewerService
      .getCaseStatus(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseStatus) => {
        this.caseStatus = caseStatus[caseStatus.length - 1];
      });
  }

  checkIsOpen(e) {
    this.isOpen = e;
  }

  checkForJoinedCases() {
    this.caseViewerService
      .getJoinedCases(this.caseInfo.proceedingNumber)
      .pipe(take(1))
      .subscribe(
        (joinedCasesSuccess: any) => {
          this.relatedCases.originalCase = [];
          this.relatedCases.joinedCases = [];
          this.showJoinderDropdown = false;
          this.isOriginalCase = false;

          if (joinedCasesSuccess.length >= 1) {
            this.showJoinderDropdown = true;

            for (let i = 0; i < joinedCasesSuccess.length; i++) {
              if (i == 0) {
                let tempOriginalCase = {
                  caseNo: joinedCasesSuccess[i].proceedingNo,
                  joinedDate: joinedCasesSuccess[i].beginEffectiveDate,
                };
                // this.relatedCases.originalCase.push(joinedCasesSuccess[i].proceedingNo);
                this.relatedCases.originalCase.push(tempOriginalCase);
                if (
                  this.caseInfo.proceedingNumber ===
                  joinedCasesSuccess[i].proceedingNo
                ) {
                  this.isOriginalCase = true;
                }
              }
              let tempJoinedCase = {
                caseNo: joinedCasesSuccess[i].relatedProceedingNo,
                joinedDate: joinedCasesSuccess[i].beginEffectiveDate,
              };
              this.relatedCases.joinedCases.push(tempJoinedCase);
            }
          }
        },
        (joinedCasesFailure) => {}
      );
  }

  openCase(proceedingNo) {
    this.caseViewerService
      .getPartyRepresenting(proceedingNo)
      .pipe(take(1))
      .subscribe(
        (partyResponse) => {
          // this.commonUtils.openCaseViewer(proceedingNo, '/aia-review-info');
          if (partyResponse !== '') {
            this.commonUtils.openCaseViewer(proceedingNo, '/aia-review-info');
          } else {
            this.openDocumentsModal(proceedingNo);
          }
        },
        (partyFailure) => {}
      );
  }

  openDocumentsModal(proceedingNo) {
    window.sessionStorage.setItem('proceedingNoForSearch', proceedingNo);
    //
    //
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: proceedingNo,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.documentsModalRef = this.modalService.show(
      ViewDocumentsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.documentsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
    });
  }

  copyToClipboard(itemToCopy) {
    let copyText: any = document.getElementById(itemToCopy).innerText;
    navigator.clipboard.writeText(copyText.trim());
    let numberType = null;
    if (itemToCopy == 'caseHeaderProceedingNumber') {
      numberType = 'Case';
    } else if (itemToCopy == 'caseHeaderPatentNumber') {
      numberType = 'Patent';
    }
    this.commonUtils.setToastr(
      'success',
      `${numberType} # copied to clipboard`
    );
  }
}
