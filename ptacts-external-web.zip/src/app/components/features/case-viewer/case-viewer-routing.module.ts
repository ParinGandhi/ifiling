import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { UnauthorizedComponent } from '../../common/unauthorized/unauthorized.component';
import { AiaReviewInfoComponent } from './aia-review-info/aia-review-info.component';
import { CaseViewerComponent } from './case-viewer.component';
import { MotionsCvComponent } from './motions-cv/motions-cv.component';
import { NoticeOfAppealsCvComponent } from './notice-of-appeals-cv/notice-of-appeals-cv.component';
import { RehearingRequestsCvComponent } from './rehearing-requests-cv/rehearing-requests-cv.component';

const routes: Routes = [
  {
    path: '',
    component: CaseViewerComponent,
    children: [
      {
        path: 'aia-review-info',
        component: AiaReviewInfoComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'motions',
        component: MotionsCvComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'rehearing-requests',
        component: RehearingRequestsCvComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'notice-of-appeal',
        component: NoticeOfAppealsCvComponent,
        canActivate: [AuthGuard],
      },
      // {
      //   path: 'unauthorized',
      //   component: UnauthorizedComponent,
      // },
      //   {
      //     path: '',
      //     pathMatch: 'full',
      //     redirectTo: 'pending-aia-reviews',
      //   },
      //   {
      //     path: 'pending-aia-reviews',
      //     component: PendingAiaReviewsComponent,
      //     canActivate: [AuthGuard],
      //   }
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CaseViewerRoutingModule {}
