import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { DatePipe } from '@angular/common';
import { NGXLogger } from 'ngx-logger';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-rehearing-requests-cv',
  templateUrl: './rehearing-requests-cv.component.html',
  styleUrls: ['./rehearing-requests-cv.component.scss'],
})
export class RehearingRequestsCvComponent implements OnInit {
  expanded: boolean = false;
  allClassActive: boolean = false;
  pendingClassActive: boolean = false;
  unsubmittedClassActive: boolean = false;
  tableOptions: any;
  dataList: any;
  orderByField: any[] = [];
  rehearings = {
    ALL: [],
    INITIATED: [],
    PENDING_REVIEW: [],
  };
  rehearingTypes = ['ALL', 'INITIATED', 'PENDING_REVIEW'];
  activeTab: string = 'Pending';
  petitionInfo: any = null;
  onCaseviewer: boolean = false;
  documentsTableColSpan: number = 6;
  pendingColDef = [
    {
      name: 'Rehearing submitted date',
      displayName: 'Rehearing submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '240px',
      minWidth: '240px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing type',
      displayName: 'Rehearing request type',
      field: 'rehearingTypeNm',
      width: '345px',
      minWidth: '345px',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Rehearing status',
      displayName: 'Rehearing request status',
      field: 'rehearingStatusDisplayName',
      width: '210px',
      minWidth: '210px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Rehearing',
      displayName: 'View rehearing request',
      field: 'viewNotice',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
  ];
  allColDef = [
    {
      name: 'Rehearing submitted date',
      displayName: 'Rehearing submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '240px',
      minWidth: '240px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing type',
      displayName: 'Rehearing request type',
      field: 'rehearingTypeNm',
      width: '345px',
      minWidth: '345px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing status',
      displayName: 'Rehearing request status',
      field: 'rehearingStatusDisplayName',
      width: '210px',
      minWidth: '210px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing decision date',
      displayName: 'Rehearing decision date',
      field: 'decisionDate',
      width: '140px',
      minWidth: '140px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'View Rehearing',
      displayName: 'View rehearing request',
      field: 'viewNotice',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
  ];
  unsubmittedColDef = [
    {
      name: 'Rehearing initiated date',
      displayName: 'Rehearing initiated date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '240px',
      minWidth: '240px',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      idth: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing type',
      displayName: 'Rehearing request type',
      field: 'rehearingTypeNm',
      width: '345px',
      minWidth: '345px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing status',
      displayName: 'Rehearing request status',
      field: 'rehearingStatusDisplayName',
      width: '210px',
      minWidth: '210px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Rehearing',
      displayName: 'View rehearing request',
      field: 'viewNotice',
      width: '175px',
      minWidth: '175px',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Action(s)',
      displayName: 'Action(s)',
      field: 'action',
      width: '200px',
      minWidth: '200px',
      type: 'string',
      searchText: null,
    },
  ];

  dataLoading = {
    ALL: false,
    INITIATED: false,
    PENDING_REVIEW: false,
  };

  constructor(
    public commonUtils: CommonUtilitiesService,
    private datePipe: DatePipe,
    private caseViewerService: CaseViewerService,
    private logger: NGXLogger,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.onCaseviewer = window.location.href.includes('case-viewer');
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.pendingClassActive = true;
    //this.setRehearingTable();

    this.rehearingTypes.forEach((rehearingType) => {
      this.getRehearing(rehearingType);
    });
  }

  getRehearing(rehearingType) {
    // let rtype = rehearingType;
    // rtype = rtype === 'PENDING_REVIEW' ? 'PENDING REVIEW' : rtype;
    this.dataLoading[rehearingType] = true;
    this.caseViewerService
      .getRehearingsOnProceeding(
        this.petitionInfo.proceedingNumberText,
        rehearingType
      )
      .pipe(take(1))
      .subscribe(
        (rehearingList) => {
          this.rehearings[rehearingType] = rehearingList;
          if (rehearingType === 'PENDING_REVIEW') {
            this.dataList = rehearingList;
          }
          this.setRehearingTable('pendingColDef');
          this.dataLoading[rehearingType] = false;
        },
        () => {
          this.dataLoading[rehearingType] = false;
        }
      );
  }

  setRehearingTable(rehearingType) {
    this.tableOptions = {
      //btnId: this.REHEARINGS,
      tableId: 'rehearingTable',
      tableHeaderClass: 'rehearingTableHeader',
      tableBodyClass: 'rehearingTableBody',
      columnDefs: this[rehearingType],
      data: this.dataList ? JSON.parse(JSON.stringify(this.dataList)) : null,
    };
    this.commonUtils.clearTableFilter(this.tableOptions.columnDefs);
    this.orderByField.push('filedDate');
    this.sortColumn('filedDate', 'desc');
  }

  changeTab(tabName: any) {
    // if (this.tableOptions.columnDefs.length > 6) {
    //   this.tableOptions.columnDefs.splice(6, 1);
    // }
    this.activeTab = tabName;
    this.orderByField = [];
    // this.tableOptions.columnDefs[0].displayName =
    //   'Rehearing submitted date (mm/dd/yyyy)';
    if (tabName == 'All') {
      this.dataList = JSON.parse(JSON.stringify(this.rehearings.ALL));
      this.setRehearingTable('allColDef');
      this.allClassActive = true;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Pending') {
      this.dataList = JSON.parse(
        JSON.stringify(this.rehearings.PENDING_REVIEW)
      );
      this.setRehearingTable('pendingColDef');
      this.allClassActive = false;
      this.pendingClassActive = true;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Unsubmitted') {
      this.dataList = JSON.parse(JSON.stringify(this.rehearings.INITIATED));
      this.setRehearingTable('unsubmittedColDef');
      // this.tableOptions.columnDefs[0].displayName =
      //   'Rehearing initiated date (mm/dd/yyyy)';
      this.tableOptions.columnDefs = this.unsubmittedColDef;
      this.allClassActive = false;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = true;
    }
    this.documentsTableColSpan = this.tableOptions.columnDefs.length;
  }

  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    });
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field, sortType)
      : this.correctOrder('-' + field, sortType);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
  }

  correctOrder(field, sortType) {
    if (this.dataList && this.dataList.length > 0) {
      this.dataList.forEach((ele) => {
        if (ele.motionStatusDate === undefined) {
          ele.motionStatusDate = null;
        }
      });
      const tempData = [...this.dataList];
      this.dataList = [];
      const order = field.charAt(0) === '-' ? 'desc' : 'asc';
      tempData.sort(this.compareValues(field, order));
      this.dataList = [...tempData];
    }
  }

  convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
      var line = '';
      for (var index in array[i]) {
        if (line != '') line += ',';

        line += array[i][index];
      }

      str += line + '\r\n';
    }

    return str;
  }

  exportCSVFile(fileTitle) {
    fileTitle = `${
      this.activeTab
    } ${fileTitle} ${this.commonUtils.getCurrentDateString(new Date())}`;
    const dataToExport = [];
    this.dataList.forEach((element) => {
      let row: any = {};
      row.filedDate = this.datePipe.transform(element.filedDate, 'MM/dd/yyyy');
      row.proceedingNumber = element.proceedingNumber;
      row.requestorTypeName = this.commonUtils.convertStringToTitleCase(
        element.requestorTypeName
      );
      row.userPartyGroupType = this.commonUtils.convertStringToTitleCase(
        element.userPartyGroupType
      );
      row.rehearingTypeNm = this.commonUtils.convertStringToTitleCase(
        element.rehearingTypeNm
      );
      row.rehearingStatusDisplayName = element.rehearingStatusDisplayName;
      if(this.activeTab == 'All'){
        row.decisionDate = this.datePipe.transform(element.decisionDate, 'MM/dd/yyyy');
      }
      dataToExport.push(row);
    });
    let headers = {};
    if (this.activeTab == 'All') {
      headers = {
        filedDate: this.unsubmittedClassActive
          ? 'Rehearing initiated date (mm/dd/yyyy)'
          : 'Rehearing submitted date (mm/dd/yyyy)',
        proceedingNumber: 'AIA review #',
        requestorTypeName: 'Filing party',
        userPartyGroupType: 'Party representing',
        rehearingTypeNm: 'Rehearing request type',
        rehearingStatusDisplayName: 'Rehearing status',
        decisionDate: 'Rehearing decision date'
      };
    }
    else {
      headers = {
        filedDate: this.unsubmittedClassActive
          ? 'Rehearing initiated date (mm/dd/yyyy)'
          : 'Rehearing submitted date (mm/dd/yyyy)',
        proceedingNumber: 'AIA review #',
        requestorTypeName: 'Filing party',
        userPartyGroupType: 'Party representing',
        rehearingTypeNm: 'Rehearing request type',
        rehearingStatusDisplayName: 'Rehearing status',
      };
    }

    if (headers) {
      dataToExport.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(dataToExport);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    // if (navigator.msSaveBlob) { // IE 10+
    //     navigator.msSaveBlob(blob, exportedFilenmae);
    // } else {
    var link = document.createElement('a');
    if (link.download !== undefined) {
      // feature detection
      // Browsers that support HTML5 download attribute
      var url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', exportedFilenmae);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    // }
  }

  openPdf(data, proceedingId) {
    this.caseViewerService
      .openPdf(proceedingId, data.artifactIdentifer)
      // .pipe(take(1))
      // .subscribe(
      //   (pdfResponse) => {
      //     this.commonUtils.openPdfNew(pdfResponse);
      //   },
      //   (pdfResponseError) => {
      //     this.logger.error('Failed to open PDF', pdfResponseError);
      //   }
      // );
  }

  continueRehearing(rehearing) {
    // this.router.navigate([
    //   `case-viewer/${this.petitionInfo.serialNo}/${this.petitionInfo.proceedingNumberText}`,
    // ]);
    const rehearingInfo = {
      proceedingNo: rehearing.proceedingNumber,
      rehearingId: rehearing.rehearingId,
    };
    window.sessionStorage.setItem(
      'rehearingInfo',
      JSON.stringify(rehearingInfo)
    );
    this.logger.info('Rehearing: ', rehearing);
    document.getElementById('aia-review-info').click();
  }

  deleteRehearing(rehearingToDelete) {
   
    this.caseViewerService
      .deleteRehearing(rehearingToDelete.rehearingId)
      .pipe(take(1))
      .subscribe(
        (deleteRehearingSuccess) => {
          this.logger.info('Delete rehearing success', deleteRehearingSuccess);
          this.tableOptions.data = [];
          this.dataList = [];
          this.getRehearing('INITIATED');
          this.changeTab('Pending');
          this.commonUtils.showSuccess(
            'Successfully deleted rehearing request',
            'Delete rehearing request'
          );
        },
        (deleteRehearingFailure) => {
          this.logger.error(
            'Failed to delete rehearing',
            deleteRehearingFailure
          );
          this.commonUtils.showError(
            'Failed to delete rehearing request',
            'Delete rehearing request'
          );
        }
      );
  }
}
