import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RehearingRequestsCvComponent } from './rehearing-requests-cv.component';

describe('RehearingRequestsCvComponent', () => {
  let component: RehearingRequestsCvComponent;
  let fixture: ComponentFixture<RehearingRequestsCvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RehearingRequestsCvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RehearingRequestsCvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
