import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticeOfAppealModalComponent } from './notice-of-appeal-modal.component';

describe('NoticeOfAppealModalComponent', () => {
  let component: NoticeOfAppealModalComponent;
  let fixture: ComponentFixture<NoticeOfAppealModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticeOfAppealModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NoticeOfAppealModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
