import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MotionsModalComponent } from './motions-modal/motions-modal.component';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { Urls } from 'src/app/constants/urls';
import { CaseViewerService } from '../../case-viewer.service';
import { take } from 'rxjs/operators';
import * as CaseViewerActions from 'src/app/store/ptacts/ptacts.actions';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CONSTANTS } from 'src/app/constants/constants';
import { RehearingsModalComponent } from './rehearings-modal/rehearings-modal.component';
import { PrelimResponseModalComponent } from './prelim-response-modal/prelim-response-modal.component';
import { NoticeOfAppealModalComponent } from './notice-of-appeal-modal/notice-of-appeal-modal.component';
import { OtherDocumentsModalComponent } from './other-documents-modal/other-documents-modal.component';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsActions from 'src/app/store/ptacts/ptacts.actions'
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss'],
})
export class DocumentsComponent implements OnInit {
  motionsModalRef: BsModalRef;
  rehearingsModalRef: BsModalRef;
  petitionInfo: any = null;
  motionsOnCase: number = 0;

  @Input() isOriginalJoinedCase;

  @Output() invokeJoinedCasesDropdownEmitter: EventEmitter<boolean> =
    new EventEmitter();
  @Output() milestonePoprEmitter: EventEmitter<any> = new EventEmitter();

  modalRef: BsModalRef;
  allPaperCases: any;
  allExhibitCases: any;
  papers: any = [];
  exhibits: any = [];
  orderByField: any[] = [];
  orderByExhibitField: any[] = [];
  selectedCases: Array<any> = [];
  filterObj: any = {};
  papersCount = {
    all: 0,
    board: 0,
    po: 0,
    petitioner: 0,
  };
  exhibitsCount = {
    all: 0,
    thousand: 0,
    twoThousand: 0,
    threeThousand: 0,
  };
  selectedParty: string;
  selectedExhibit: string;
  petitionerIdentifier: any;
  pdfData: any;
  pdfContent: any;
  contentsPreview: string;
  nextPaperNumber: string;
  papersToDownload: Array<string> = [];
  exhibitsToDownload: Array<string> = [];
  documentSelected = false;
  downloading = false;
  lastRefresh = new Date();
  partyRepresenting: string;
  isFWD: boolean = false;
  loading: boolean = false;
  dropdownAccess = {
    other: true,
    ptabDefaultRefreshTime: 300000,
    ptabReadOnlyUser: false,
    partyRepresenting: null,
    motions: true,
    prelim: false,
    appeal: false,
    rehearing: true,
  };

  constructor(
    public modalService: BsModalService,
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService,
    private store: Store<PtactsState> 
  ) {}

  ngOnInit(): void {
    setTimeout(() => {
      this.partyRepresenting =
        window.sessionStorage.getItem('partyRepresenting');
    }, 200);
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getMotions();
    this.getDocuments();
    this.getNextPaperNumber(this.petitionInfo.proceedingNumberText);

    this.getCaseStatus();
    this.getDropdownAccess();
  }

  getCaseStatus() {
    this.caseViewerService
      .getCaseStatus(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseStatus) => {
        const status = caseStatus[caseStatus.length - 1];
        this.isFWD =
          status.descriptionText.toLowerCase() === 'final written decision';
      });
  }

  getMotions() {
    this.caseViewerService
      .getAllMotionsOnCase(this.petitionInfo.proceedingNumberText, true)
      .pipe(take(1))
      .subscribe((motionsOnCase) => {
        this.motionsOnCase = motionsOnCase.length;
      });
  }

  openMotionsModal(actionType) {
    const initialState: ModalOptions = {
      initialState: {
        actionType: actionType,
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.motionsModalRef = this.modalService.show(
      MotionsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.motionsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
      this.updateCasePhase()
      this.orderByField = [];
      this.getMotions();
      this.refresh();
    });
  }

  openRehearingRequestModal() {
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.rehearingsModalRef = this.modalService.show(
      RehearingsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.rehearingsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
      this.updateCasePhase()
      this.orderByField = [];
      this.refresh();
    });
  }

  openPrelimResponseModal() {
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.rehearingsModalRef = this.modalService.show(
      PrelimResponseModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.rehearingsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
        
      }
      this.updateCasePhase()
      this.orderByField = [];
      this.refresh();
    });
  }

  openNoticeOfAppealModal() {
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.rehearingsModalRef = this.modalService.show(
      NoticeOfAppealModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.rehearingsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
      this.updateCasePhase()
      this.orderByField = [];
      this.refresh();
    });
  }

  openOtherDocumentsModal() {
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.rehearingsModalRef = this.modalService.show(
      OtherDocumentsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.rehearingsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
      this.updateCasePhase()
      this.orderByField = [];
      this.refresh();
    });
  }

  refresh() {
    this.orderByField = [];
    this.orderByExhibitField = [];
    this.getNextPaperNumber(this.petitionInfo.proceedingNumberText);
    this.getDocuments();
    this.lastRefresh = new Date();
    this.caseViewerService.initiateRefresh(true);
  }

  /**
   * Retrieve paper documents based on proceeding number
   *
   * @param proceedingNo
   */
  getPaperDocuments() {
    this.papers = {
      tableId: 'papersTable',
      tableHeaderClass: 'papersTableHeader',
      tableBodyClass: 'papersTableBody',
      checkboxClass: 'paperTableCheckbox',
      headerCheckboxId: 'paperHeaderCheckbox',
      cellCheckboxId: 'paperCheckbox',
      columnDefs: [
        {
          name: 'Paper #',
          displayName: 'Paper #',
          field: 'documentNumber',
          width: '6%',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Filing date',
          displayName: 'Filing date',
          field: 'filingDate',
          width: '8%',
          type: 'date',
          searchText: null,
        },
        {
          name: 'Paper type',
          displayName: 'Paper type',
          field: 'documentTypeDescription',
          width: '8%',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Title',
          displayName: 'Document name',
          field: 'name',
          width: '13%',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Pages',
          displayName: 'Pages',
          field: 'pageCount',
          width: '6%',
          type: 'string',
          searchText: '',
        },
        {
          name: 'Filing party',
          displayName: 'Filing party',
          field: 'filingParty',
          width: '9%',
          type: 'string',
          searchText: '',
        },
        {
          name: 'Availability',
          displayName: 'Availability',
          field: 'availability',
          width: '9%',
          type: 'string',
          searchText: '',
        },
      ],
      data: JSON.parse(JSON.stringify(this.allPaperCases.allPapersBag)),
    };
    this.sortColumns('-documentNumber', 'p');
    this.selectedParty = 'allPapersBag';
  }

  setPapersCount() {
    this.papersCount = {
      all: this.allPaperCases.allPapersCount,
      board: this.allPaperCases.boardPapersCount,
      po: this.allPaperCases.patentOwnerPapersCount,
      petitioner: this.allPaperCases.petitionerPapersCount,
    };
  }

  /** Retrieve new Paper number
   * @param proceedingNo
   */
  getNextPaperNumber(proceedingNo) {
    this.caseViewerService.getNextPaperNumber(proceedingNo).subscribe(
      (paperSequenceResponse) => {
        this.nextPaperNumber = paperSequenceResponse.paperSequence;
      },
      (paperNumberError) => {
        // Intentionally blank
      }
    );
  }

  /**
   * Retrieve exhibit documents based on proceeding number
   *
   * @param proceedingNo
   */
  getExhibitDocuments() {
    this.exhibits = {
      tableId: 'exhibitsTable',
      tableHeaderClass: 'exhibitsTableHeader',
      tableBodyClass: 'exhibitsTableBody',
      checkboxClass: 'exhibitsTableCheckbox',
      headerCheckboxId: 'exhibitsHeaderCheckbox',
      cellCheckboxId: 'exhibitsCheckbox',
      columnDefs: [
        {
          name: 'Exhibit #',
          displayName: 'Exhibit #',
          field: 'exhibitNumber',
          width: '5%',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Filing date',
          displayName: 'Filing date',
          field: 'filingDate',
          width: '6%',
          type: 'date',
          searchText: null,
        },
        {
          name: 'Document name',
          displayName: 'Document name',
          field: 'name',
          width: '13%',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Pages',
          displayName: 'Pages',
          field: 'pageCount',
          width: '4%',
          type: 'string',
          searchText: '',
        },
        {
          name: 'Filing party',
          displayName: 'Filing party',
          field: 'filingParty',
          width: '6%',
          type: 'string',
          searchText: '',
        },
        {
          name: 'Availability',
          displayName: 'Availability',
          field: 'availability',
          width: '6%',
          type: 'string',
          searchText: '',
        },
      ],
      data: JSON.parse(JSON.stringify(this.allExhibitCases.allExhibitsBag)),
    };
    this.sortColumns('-exhibitNumber', 'e');
    this.selectedExhibit = 'allExhibitsBag';
  }

  getDocuments() {
    this.loading = true;
    this.caseViewerService
      .getDocumentsForUpdate(
        `${Urls.DOCUMENTS.GET}${this.petitionInfo.proceedingNumberText}`
      )
      .subscribe(
        (documentSuccess) => {
          let paperDocs = [];
          let exhibitDocs = [];
          this.papersCount = {
            all: 0,
            board: 0,
            po: 0,
            petitioner: 0,
          };
          this.allPaperCases = {
            allPapersBag: [],
            boardPapersBag: [],
            petitionerPapersBag: [],
            patentOwnerPapersBag: [],
          };
          this.exhibitsCount = {
            all: 0,
            thousand: 0,
            twoThousand: 0,
            threeThousand: 0,
          };
          this.allExhibitCases = {
            allExhibitsBag: [],
            thousandsExhibitsBag: [],
            twoThousandsExhibitsBag: [],
            threeThousandsExhibitsBag: [],
          };
          let milestonePopr = {
            poprWaivedResponse: null,
            poprFileResponse: null,
          };
          documentSuccess.forEach((doc) => {
            doc.filingParty = doc.filingParty.toLowerCase();
            // for milestone page
            if (
              doc?.documentTypeIdentifier == '18' ||
              doc?.documentTypeIdentifier == '203'
            ) {
              milestonePopr.poprWaivedResponse = 'No';
            } else if (
              doc?.documentTypeIdentifier == '38' ||
              doc?.documentTypeIdentifier == '204'
            ) {
              milestonePopr.poprWaivedResponse = 'Yes';
            }

            if (doc.filingDate && doc.filingDate.toString().length <= 10) {
              doc.filingDate = parseInt(doc.filingDate.toString() + '000');
            }
            if (doc.category && doc.category.toLowerCase() === 'paper') {
              this.papersCount.all++;
              this.allPaperCases.allPapersBag.push(doc);
              switch (doc.filingParty.toLowerCase()) {
                case 'board':
                  this.papersCount.board++;
                  this.allPaperCases.boardPapersBag.push(doc);
                  break;
                case 'petitioner':
                  this.papersCount.petitioner++;
                  this.allPaperCases.petitionerPapersBag.push(doc);
                  break;
                case 'patent owner':
                  this.papersCount.po++;
                  this.allPaperCases.patentOwnerPapersBag.push(doc);
              }
            } else if (
              doc.category &&
              // doc.category.toLowerCase() === 'exhibits'
              doc.category.toLowerCase() === CONSTANTS.DOC_TYPE.EXHIBIT
            ) {
              this.exhibitsCount.all++;
              this.allExhibitCases.allExhibitsBag.push(doc);
              if (doc.exhibitNumber.toString().startsWith('1')) {
                this.exhibitsCount.thousand++;
                this.allExhibitCases.thousandsExhibitsBag.push(doc);
              } else if (doc.exhibitNumber.toString().startsWith('2')) {
                this.exhibitsCount.twoThousand++;
                this.allExhibitCases.twoThousandsExhibitsBag.push(doc);
              } else if (doc.exhibitNumber.toString().startsWith('3')) {
                this.exhibitsCount.threeThousand++;
                this.allExhibitCases.threeThousandsExhibitsBag.push(doc);
              }
            }
          });

          documentSuccess.forEach((poprElement, index, arr) => {
            if (
              poprElement?.documentTypeIdentifier == '38' ||
              poprElement?.documentTypeIdentifier == '204' ||
              poprElement?.documentTypeIdentifier == '18' ||
              poprElement?.documentTypeIdentifier == '203'
            ) {
              milestonePopr.poprFileResponse = 'Yes';
              arr.length = index + 1;
            } else {
              milestonePopr.poprFileResponse = 'No';
            }
          });

          this.milestonePoprEmitter.emit(milestonePopr);
          this.getPaperDocuments();
          this.getExhibitDocuments();
          this.loading = false;
        },
        (documentsError) => {
          console.log('Documents error: ', documentsError);
          this.loading = false;
        }
      );
  }

  setExhibitsCount() {
    this.exhibitsCount = {
      all: this.allExhibitCases.allExhibitsCount,
      thousand: this.allExhibitCases.thousandsExhibitsCount,
      twoThousand: this.allExhibitCases.twoThousandsExhibitsCount,
      threeThousand: this.allExhibitCases.threeThousandsExhibitsCount,
    };
  }

  changeParty(partyType) {
    this.selectedParty = partyType;
    this.orderByField = [];
    this.papers.data = JSON.parse(
      JSON.stringify(this.allPaperCases[partyType])
    );
    this.sortColumns('-documentNumber', 'p');
  }

  changeExhibits(exhibitNumber) {
    this.selectedExhibit = exhibitNumber;
    this.orderByExhibitField = [];
    this.exhibits.data = JSON.parse(
      JSON.stringify(this.allExhibitCases[exhibitNumber])
    );
    this.sortColumns('-exhibitNumber', 'e');
  }

  sortColumns(field, sortType) {
    if (sortType === 'p') {
      !this.orderByField.includes(field)
        ? this.correctOrder(field, sortType)
        : this.correctOrder('-' + field, sortType);
      this.orderByField = !this.orderByField.includes(field)
        ? [field]
        : ['-' + field];
    } else if (sortType === 'e') {
      !this.orderByExhibitField.includes(field)
        ? this.correctOrder(field, sortType)
        : this.correctOrder('-' + field, sortType);
      this.orderByExhibitField = !this.orderByExhibitField.includes(field)
        ? [field]
        : ['-' + field];
    }
  }

  correctOrder(field, sortType) {
    let tempData;
    if (sortType === 'p') {
      tempData = [...this.papers.data];
      this.papers.data = [];
      let order = field.charAt(0) === '-' ? 'desc' : 'asc';
      tempData.sort(this.compareValues(field, order, sortType));
      this.papers.data = [...tempData];
    } else if (sortType === 'e') {
      tempData = [...this.exhibits.data];
      this.exhibits.data = [];
      let order = field.charAt(0) === '-' ? 'desc' : 'asc';
      tempData.sort(this.compareValues(field, order, sortType));
      this.exhibits.data = [...tempData];
    }
  }

  compareValues(key, order = 'asc', sortType) {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }

    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      } else {
        let numberA = sortType === 'p' ? a.docNo : a.exhibitNumber;
        let numberB = sortType === 'p' ? b.docNo : b.exhibitNumber;

        if (numberA > numberB) {
          comparison = 1;
        } else if (numberA < numberB) {
          comparison = -1;
        } else {
          return 0;
        }
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  openPdfFile(data) {
    //this.commonService.openPdf(`/petitions/${this.petitionerIdentifier}/download-documents?contentManagementId=${data.contentManagementId}`);
  }

  rowSelectionForPapers(selectedDocs) {
    if (typeof selectedDocs?.valueToEmit === 'string') {
      if (selectedDocs?.valueToEmit === 'all') {
        this.papersToDownload = [];
        this.papersToDownload = [...this.allPaperCases.allPapersBag];
        // this.allPaperCases.allPapersBag.forEach((paper) => {
        //   this.papersToDownload.push(paper.contentManagementId);
        // });
      } else if (selectedDocs?.valueToEmit === 'none') {
        this.papersToDownload = [];
      }
    } else {
      const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
      if (selectedDocs?.row?.target?.checked) {
        // this.papersToDownload.push(contentManagementId);
        this.papersToDownload.push(selectedDocs.valueToEmit);
      } else {
        // const indexToRemove = this.papersToDownload.indexOf(contentManagementId);
        const indexToRemove = this.papersToDownload.indexOf(
          selectedDocs.valueToEmit
        );
        this.papersToDownload.splice(indexToRemove, 1);
      }
    }
    this.checkIfDocumentIsSelected();
  }

  rowSelectionForExhibits(selectedDocs) {
    //
    // const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
    if (typeof selectedDocs?.valueToEmit === 'string') {
      if (selectedDocs?.valueToEmit === 'all') {
        this.exhibitsToDownload = [];
        this.exhibitsToDownload = [...this.allExhibitCases.allExhibitsBag];
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   this.exhibitsToDownload.push(exhibit.contentManagementId);
        // });
      } else if (selectedDocs?.valueToEmit === 'none') {
        this.exhibitsToDownload = [];
      }
    } else {
      const contentManagementId = selectedDocs.valueToEmit.contentManagementId;
      if (selectedDocs?.row?.target?.checked) {
        // this.exhibitsToDownload.push(contentManagementId);
        this.exhibitsToDownload.push(selectedDocs.valueToEmit);
      } else {
        // const indexToRemove = this.exhibitsToDownload.indexOf(contentManagementId);
        const indexToRemove = this.exhibitsToDownload.indexOf(
          selectedDocs.valueToEmit
        );
        this.exhibitsToDownload.splice(indexToRemove, 1);
      }
    }
    this.checkIfDocumentIsSelected();
  }

  checkIfDocumentIsSelected() {
    this.documentSelected =
      this.papersToDownload.length > 0 || this.exhibitsToDownload.length > 0;
  }

  sortPapers(papersToSort) {
    let docsToUpload = [];
    papersToSort.sort((a, b) => {
      let docNoA = a.documentNumber ? a.documentNumber : 0;
      let docNoB = b.documentNumber ? b.documentNumber : 0;
      if (docNoA > docNoB) {
        return -1;
      }
      if (docNoA < docNoB) {
        return 1;
      }

      // names must be equal
      return 0;
    });
    papersToSort.forEach((paper) => {
      docsToUpload.push(paper.contentManagementId);
    });
    return docsToUpload;
  }

  sortExhibits(exhibitsToSort) {
    let docsToUpload = [];
    exhibitsToSort.sort((a, b) => {
      let docNoA = a.exhibitNumber ? a.exhibitNumber : 0;
      let docNoB = b.exhibitNumber ? b.exhibitNumber : 0;
      if (docNoA > docNoB) {
        return -1;
      }
      if (docNoA < docNoB) {
        return 1;
      }

      // names must be equal
      return 0;
    });
    exhibitsToSort.forEach((paper) => {
      docsToUpload.push(paper.contentManagementId);
    });
    return docsToUpload;
  }

  downloadEwf(downloadSelection: string) {
    this.downloading = true;
    let docsToUpload = null;
    let fileName = `${this.petitionInfo.proceedingNumberText}`;
    switch (downloadSelection) {
      case 'selected':
        fileName += ` - selected docs`;
        const sortedDocs = this.sortPapers(this.papersToDownload);
        // docsToUpload = this.papersToDownload.concat(this.exhibitsToDownload);
        const sortedExhibits = this.sortExhibits(this.exhibitsToDownload);
        // docsToUpload = sortedDocs.concat(this.exhibitsToDownload);
        docsToUpload = sortedDocs.concat(sortedExhibits);
        this.exportSelectedDocsAsExcel();
        break;
      case 'papers':
        fileName += ` - all papers`;
        docsToUpload = [];
        docsToUpload = this.sortPapers(this.allPaperCases.allPapersBag);
        this.exportAllPapersAsExcel();
        break;
      case 'exhibits':
        fileName += ` - all exhibits`;
        docsToUpload = [];
        docsToUpload = this.sortExhibits(this.allExhibitCases.allExhibitsBag);
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   docsToUpload.push(exhibit.contentManagementId);
        // });
        this.exportAllExhibitsAsExcel();
        break;
      case 'case':
        fileName += ` - entire case`;
        docsToUpload = [];
        docsToUpload = this.sortPapers(this.allPaperCases.allPapersBag);
        // this.allPaperCases.allPapersBag.forEach((paper) => {
        //   docsToUpload.push(paper.contentManagementId);
        // });
        const allSortedPapers = this.sortPapers(
          this.allPaperCases.allPapersBag
        );
        const allSortedExhibits = this.sortExhibits(
          this.allExhibitCases.allExhibitsBag
        );
        docsToUpload = allSortedPapers.concat(allSortedExhibits);
        // this.allExhibitCases.allExhibitsBag.forEach((exhibit) => {
        //   docsToUpload.push(exhibit.contentManagementId);
        // });
        this.exportEntireCaseAsExcel();
        break;
      default:
        break;
    }

    // this.caseViewerService.downloadEwf(docsToUpload).subscribe((downloadEwfSuccess) => {
    //   let blob = new Blob([downloadEwfSuccess], {
    //     type: "application/pdf"
    //   });
    //   let a = document.createElement('a');
    //   a.href = URL.createObjectURL(blob);
    //   a.download = `${fileName}${CONSTANTS.DOWNLOAD_TYPE.EXCEL}`;
    //   a.click();
    //   this.downloading = false;
    // }, (downloadEwfFailure) => {
    //
    //   let blob = new Blob([downloadEwfFailure.error.text], {
    //     type: "application/pdf"
    //   });
    //   let a = document.createElement('a');
    //   a.href = URL.createObjectURL(blob);
    //   a.download = `${fileName}${CONSTANTS.DOWNLOAD_TYPE.EXCEL}`;
    //   a.click();
    //   this.downloading = false;
    // });
  }

  exportAsExcel() {
    this.downloading = true;
    this.caseViewerService
      .downloadExcel(this.petitionInfo.proceedingNumberText)
      .subscribe(
        (excelResponse) => {
          let blob = new Blob([excelResponse], {
            type: 'application/pdf',
          });
          let a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = `${this.petitionInfo.proceedingNumberText} - all document list${CONSTANTS.DOWNLOAD_TYPE.EXCEL}`;
          a.click();
          this.downloading = false;
        },
        (csvFailure) => {
          //this.commonUtils.setToastr('error', 'Failed to generate report');
          this.downloading = false;
        }
      );
  }

  exportAllExhibitsAsExcel() {
    var fileTitle = `${this.petitionInfo.proceedingNumberText} - all exhibits`;
    const dataToExport = [];
    this.allExhibitCases.allExhibitsBag.forEach((element) => {
      let row: any = {};
      row.documentNumber = element.exhibitNumber ? element.exhibitNumber : ' ';
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    // let headers = {
    //   documentNumber: 'Exhibit #',
    //   filingDateString: 'Filing date',
    //   name: 'Document name',
    //   pageCount: 'Pages',
    //   filingParty: 'Filing party',
    //   availability: 'Availability',
    // };
    let headers = [
      'Exhibit #',
      'Filing date',
      'Document name',
      'Pages',
      'Filing party',
      'Availability',
    ];
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  exportAllPapersAsExcel() {
    var fileTitle = `${this.petitionInfo.proceedingNumberText} - all papers`;
    const dataToExport = [];
    this.allPaperCases.allPapersBag.forEach((element) => {
      let row: any = {};
      row.documentNumber = element.documentNumber
        ? element.documentNumber
        : ' ';
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.documentTypeDescription = element.documentTypeDescription
        ? element.documentTypeDescription
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    // let headers = {
    //   documentNumber: 'Paper #',
    //   filingDateString: 'Filing date',
    //   documentTypeDescription: 'Paper type',
    //   name: 'Document name',
    //   pageCount: 'Pages',
    //   filingParty: 'Filing party',
    //   availability: 'Availability',
    // };
    let headers = [
      'Paper #',
      'Filing date',
      'Paper type',
      'Document name',
      'Pages',
      'Filing party',
      'Availability',
    ];
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  exportEntireCaseAsExcel() {
    var fileTitle = `${this.petitionInfo.proceedingNumberText} - entire case`;
    const dataToExport = [];
    this.allPaperCases.allPapersBag.forEach((element) => {
      let row: any = {};
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.documentTypeDescription = element.category ? element.category : ' ';
      row.documentNumber = element.documentNumber
        ? element.documentNumber
        : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    this.allExhibitCases.allExhibitsBag.forEach((element) => {
      let row: any = {};
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.documentTypeDescription = element.category ? element.category : ' ';
      row.documentNumber = element.exhibitNumber ? element.exhibitNumber : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    // let headers = {
    //   filingDateString: 'Filing date',
    //   name: 'Document name',
    //   documentTypeDescription: 'Type',
    //   documentNumber: 'Number',
    //   pageCount: 'Pages',
    //   filingParty: 'Filing party',
    //   availability: 'Availability',
    // };
    let headers = [
      'Filing date',
      'Document name',
      'Type',
      'Number',
      'Pages',
      'Filing party',
      'Availability',
    ];
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  exportSelectedDocsAsExcel() {
    var fileTitle = `${this.petitionInfo.proceedingNumberText} - selected docs`;
    const dataToExport = [];
    this.papersToDownload.forEach((element: any) => {
      let row: any = {};
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.documentTypeDescription = element.category ? element.category : ' ';
      row.documentNumber = element.documentNumber
        ? element.documentNumber
        : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    this.exhibitsToDownload.forEach((element: any) => {
      let row: any = {};
      row.filingDateString = element.filingDateString
        ? element.filingDateString
        : ' ';
      row.name = element.name ? element.name : ' ';
      row.documentTypeDescription = element.category ? element.category : ' ';
      row.documentNumber = element.exhibitNumber ? element.exhibitNumber : ' ';
      row.pageCount = element.pageCount ? element.pageCount : ' ';
      row.filingParty = element.filingParty ? element.filingParty : ' ';
      row.availability = element.availability ? element.availability : ' ';
      dataToExport.push(row);
    });
    // let headers = {
    //   filingDateString: 'Filing date',
    //   name: 'Document name',
    //   documentTypeDescription: 'Type',
    //   documentNumber: 'Number',
    //   pageCount: 'Pages',
    //   filingParty: 'Filing party',
    //   availability: 'Availability',
    // };
    let headers = [
      'Filing date',
      'Document name',
      'Type',
      'Number',
      'Pages',
      'Filing party',
      'Availability',
    ];
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  getDropdownAccess() {
    this.caseViewerService
      .getDropdownAccess(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (dropdownAccessResponse) => {
          this.dropdownAccess = dropdownAccessResponse;
        },
        (dropdownAccessFailure) => {}
      );
  }

  updateCasePhase() {
    this.store.dispatch(
      PtactsActions.GetCasePhaseAction({
        url: this.petitionInfo.proceedingNumberText,
      })
    );
  }
}
