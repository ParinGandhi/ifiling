import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { InitiatePetitionService } from 'src/app/components/features/initiate-petition/initiate-petition.service';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../../case-viewer.service';

@Component({
  selector: 'app-rehearings-modal',
  templateUrl: './rehearings-modal.component.html',
  styleUrls: ['./rehearings-modal.component.scss'],
})
export class RehearingsModalComponent implements OnInit {
  rehearingsModalInfo: any = this.modalService.config.initialState;

  publicModalRef: BsModalRef;
  rehearingChangeModalRef: BsModalRef;
  rehearingsForm: FormGroup;
  partyRepresenting: string;
  rehearingFilingPartyDisplayName: string = null;
  rehearingTypeDisplayName: string = '';
  paperTypeDisplayName: string = null;
  petitionIdentifier: string = null;
  rehearingStatus: string = null;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;

  editMode: boolean = false;
  saving: boolean = false;
  addingToList: boolean = false;
  showWarningMessage: boolean = false;
  onePaperMin: boolean = false;
  showRehearingTypeWarning: boolean = false;

  existingRehearingId: any = null;
  selectedFilingParty: any = null;
  selectedRehearingType: any = null;
  originalRehearingType: any = null;
  originalPaperType: any = null;
  sameType = {
    rehearingType: null,
    paperType: null,
    keep: false,
  };

  minExhibitNumber: number = null;
  editIndex: number = null;

  addedDocumentsList: Array<any> = new Array<any>();
  rehearingsTypesList: Array<any> = new Array<any>();
  availabilityList: Array<any> = new Array<any>();

  constructor(
    private logger: NGXLogger,
    private modalService: BsModalService,
    private fb: FormBuilder,
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService
  ) { }

  ngOnInit(): void {
    this.partyRepresenting = window.sessionStorage.getItem('partyRepresenting');
    this.setupForm(false);
    this.getRehearingTypes();
    this.getAvailabilities();
    this.getPetitionIdentifier();
    this.getNextExhibitNumber();
    let existingRehearing = window.sessionStorage.getItem('rehearingInfo');
    if (existingRehearing) {
      existingRehearing = JSON.parse(existingRehearing);
      window.sessionStorage.removeItem('rehearingInfo');
      this.getExistingRehearingDocuments(existingRehearing);
    }
  }

  close(selection) {
    this.logger.info(selection);
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  setupForm(clear) {
    let partyRep = null;
    if (this.partyRepresenting) {
      partyRep =
        this.partyRepresenting.toLowerCase() === 'petitioner'
          ? 'Petitioner'
          : 'Patent Owner';
    }
    this.rehearingsForm = this.fb.group({
      filingParty: [{ value: partyRep, disabled: true }],
      rehearingType: ['', Validators.required],
      docType: ['paper', Validators.required],
      paperType: ['', Validators.required],
      exhibitNumber: [null],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      artifactSubmissionIdentifier: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
    if (this.addedDocumentsList.length > 0) {
      this.keepSameRehearingType();
    } else {
      this.sameType.paperType = null;
      this.sameType.rehearingType = null;
    }
  }

  keepSameRehearingType() {
    if (this.sameType.rehearingType) {
      this.rehearingsForm
        .get('rehearingType')
        .setValue(this.sameType.rehearingType);
      this.rehearingTypeDisplayName =
        // this.sameType.rehearingType.descriptionText;
        this.sameType.rehearingType;
    }
    if (this.sameType.paperType) {
      this.rehearingsForm.get('paperType').setValue(this.sameType.paperType);
      this.paperTypeDisplayName = this.sameType.paperType.displayNameText;
    }
    this.rehearingsForm.updateValueAndValidity();
  }

  getRehearingTypes() {
    this.caseViewerService
      .getRehearingTypes(CONSTANTS.TYPE_CODES.REHEARING_TYPES)
      .pipe(take(1))
      .subscribe((rehearingTypes) => {
        this.rehearingsTypesList = rehearingTypes;
      });
  }

  getAvailabilities() {
    this.caseViewerService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilitiesResponse) => {
        this.availabilityList = availabilitiesResponse;
        this.logger.info('AvailabilitiesList', this.availabilityList);
      });
  }

  getSpecificPaperType(e) {
    // this.showRehearingTypeWarning = false;
    // this.rehearingsForm.get('rehearingType').setValue(e.item);
    // this.rehearingTypeDisplayName = e.value;
    // const rehearingType = this.rehearingsForm.value.rehearingType;

    // this.caseViewerService
    //   .getSpecificRehearingPaperType(rehearingType.code)
    //   .pipe(take(1))
    //   .subscribe(
    //     (specificPaperType) => {
    //       // if (!this.sameType.rehearingType && !this.sameType.paperType) {
    //       this.sameType.paperType = specificPaperType[0];
    //       this.sameType.rehearingType = e.item;
    //       this.sameType.keep = true;
    //       // }
    //       this.rehearingsForm.get('paperType').setValue(specificPaperType[0]);
    //       this.paperTypeDisplayName = specificPaperType[0].displayNameText;
    //     },
    //     (specificTyperError) => {
    //       this.paperTypeDisplayName = null;
    //       this.logger.error(
    //         'Could not get paper type for rehearing',
    //         specificTyperError
    //       );
    //     }
    //   );

    this.showRehearingTypeWarning = false;
    this.rehearingsForm.get('rehearingType').setValue(e);
    this.rehearingTypeDisplayName = e;
    const rehearingType = this.rehearingsForm.value.rehearingType;

    this.caseViewerService
      .getSpecificRehearingPaperType(rehearingType.code)
      .pipe(take(1))
      .subscribe(
        (specificPaperType) => {
          // if (!this.sameType.rehearingType && !this.sameType.paperType) {
          this.sameType.paperType = specificPaperType[0];
          this.sameType.rehearingType = e;
          this.sameType.keep = true;
          // }
          this.rehearingsForm.get('paperType').setValue(specificPaperType[0]);
          this.paperTypeDisplayName = specificPaperType[0].displayNameText;
        },
        (specificTyperError) => {
          this.paperTypeDisplayName = null;
          this.logger.error(
            'Could not get paper type for rehearing',
            specificTyperError
          );
        }
      );
  }

  checkForValidity(e) {
    this.logger.info(e);
    if ((e && !this.rehearingTypeDisplayName) || !e) {
      this.showRehearingTypeWarning = true;
    }
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.rehearingsModalInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  getNextExhibitNumber() {
    this.initiatePetitionService
      .getNextExhibitNumber(this.rehearingsModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        const nextNumber =
          this.partyRepresenting.toLowerCase() === 'petitioner'
            ? nextExhibitNumber.petitionerExhibitSequence
            : nextExhibitNumber.patentownerExhibitSequence;
        this.rehearingsForm.get('exhibitNumber').setValue(nextNumber);
        this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  changeDocType(docType) {
    // if (docType === 'exhibits') {
    if (docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      this.rehearingsForm
        .get('exhibitNumber')
        .setValue(this.minExhibitNumber, [Validators.required]);
      this.rehearingsForm.get('exhibitNumber').updateValueAndValidity();
      this.rehearingsForm.get('paperType').clearValidators();
      this.rehearingsForm.get('paperType').updateValueAndValidity();
      if (this.addedDocumentsList.length > 0 && this.paperDocumentExists()) {
        this.keepSameRehearingType();
      }
      if (this.addedDocumentsList.length <= 0) {
        this.showWarningMessage = true;
      }
    } else {
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = !this.paperDocumentExists();
      // this.onePaperMin = this.paperDocumentExists();
    }
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    if (event.target.files.length > 0) {
      this.rehearingsForm.get('fileToUpload').setValue(event.target.files[0]);
      this.rehearingsForm.get('fileName').setValue(event.target.files[0].name);
    }
  }

  clearForm() {
    this.logger.info('clear form');
    // this.rehearingsForm.reset();
    this.clearFile();
    this.addingToList = false;
    this.onePaperMin = false;
    // this.showWarningMessage = false;
    this.showWarningMessage = !this.paperDocumentExists();
    this.editMode = false;
    this.editIndex = null;
    console.log(this.rehearingTypeDisplayName);
    // this.rehearingTypeDisplayName = null;
    if (this.addedDocumentsList.length <= 0) {
      this.paperTypeDisplayName = null;
      this.rehearingTypeDisplayName = '';
    }
    this.setupForm(true);
  }

  clearFile() {
    if (<HTMLInputElement>document.getElementById('file')) {
      (<HTMLInputElement>document.getElementById('file')).value = '';
      this.rehearingsForm.get('fileToUpload').setValue(null);
      this.rehearingsForm.get('fileName').setValue(null);
    }
  }

  checkAvailability(action) {
    if (
      this.rehearingsForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else if (
      this.editMode &&
      this.originalRehearingType.identifier !==
      this.rehearingsForm.value.rehearingType.identifier
    ) {
      this.logger.info('Rehearing types are different');
      this.openRehearingTypeChangeModal();
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
    // if (e) {
    //   this.rehearingsForm
    //     .get('rehearingType')
    //     .setValue('', Validators.required);
    //   this.rehearingsForm.get('paperType').setValue('', Validators.required);
    //   this.paperTypeDisplayName = null;
    //   this.rehearingTypeDisplayName = null;
    //   this.rehearingsForm.updateValueAndValidity();
    // }
  }

  // rehearingType: ['', Validators.required],
  // docType: ['paper', Validators.required],
  // paperType: ['', Validators.required],

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.showWarningMessage = e;
  }

  addToList() {
    this.addingToList = true;
    this.rehearingsForm.disable();
    this.initiatePetitionService
      .addToList(
        this.rehearingsForm.value.fileToUpload,
        this.rehearingsForm.value.docType,
        this.petitionIdentifier
      )
      .pipe(take(1))
      .subscribe(
        (fileAdded) => {
          this.rehearingsForm.enable();

          let petitionDocument = null;
          let filingParty =
            this.rehearingsForm.value.filingParty === ''
              ? 'PETITIONER'
              : this.rehearingsForm.value.filingParty.toUpperCase();
          if (this.rehearingsForm.value.docType.toLowerCase() === 'paper') {
            const docId = this.rehearingsForm.value.paperType.documentTypeId
              ? this.rehearingsForm.value.paperType.documentTypeId
              : this.rehearingsForm.value.paperType.identifier;
            petitionDocument = new PetitionDocument(
              this.rehearingsForm.value.docType.toUpperCase(),
              this.rehearingsForm.value.documentName,
              this.rehearingsForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.rehearingsForm.value.availability.code,
              docId,
              this.rehearingsForm.value.paperType.code,
              this.rehearingsForm.value.fileToUpload.type,
              null,
              'Y',
              null
            );
          } else {
            petitionDocument = new PetitionDocument(
              this.rehearingsForm.value.docType.toUpperCase(),
              this.rehearingsForm.value.documentName,
              this.rehearingsForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.rehearingsForm.value.availability.code,
              null,
              CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
              this.rehearingsForm.value.fileToUpload.type,
              this.rehearingsForm.value.exhibitNumber,
              'Y',
              null
            );
          }

          const documentToAdd = new DocumentToAdd(petitionDocument);
          documentToAdd.proceedingNumberText =
            this.rehearingsModalInfo.proceedingNo;
          this.rehearingsForm.get('pageCount').setValue(fileAdded.pageCount);
          this.rehearingsForm.get('filingDate').setValue(fileAdded.filingDate);
          this.saveDocumentToCMS(documentToAdd);
        },
        (addToListFailure) => {
          // this.commonUtils.showError(addToListFailure.error.message, 'Error');
          this.commonUtils.throwError(
            'Add to list failed for Rehearing',
            addToListFailure
          );
          this.addingToList = false;
          this.rehearingsForm.enable();
          this.rehearingsForm.get('filingParty').disable();
          this.commonUtils.focusOnCloseModal('closeRehearingModal');
        }
      );
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (doc.docType.toLowerCase() === 'paper') {
          paperDocExists = true;
        }
      });
    } else {
      paperDocExists = true;
    }
    return paperDocExists;
  }

  saveDocumentToCMS(documentToAdd) {
    this.rehearingsForm.disable();
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.rehearingsForm.enable();
          this.logger.info('Saved document to CMS', saveSuccessful);
          this.selectedFilingParty = !this.selectedFilingParty
            ? this.rehearingsForm.value.filingParty
            : this.selectedFilingParty;
          this.selectedRehearingType = !this.selectedRehearingType
            ? this.rehearingsForm.value.rehearingType
            : this.selectedRehearingType;
          // this.getDocuments();
          // this.rehearingsForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          this.rehearingsForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.rehearingsForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          this.rehearingsForm
            .get('artifactSubmissionIdentifier')
            .setValue(
              saveSuccessful.petitionDocuments[0].artifactSubmissionIdentifier
            );
          // if (this.rehearingsForm.value.docType === 'exhibits') {
          if (
            this.rehearingsForm.value.docType === CONSTANTS.DOC_TYPE.EXHIBIT
          ) {
            // this.minExhibitNumber++;
            this.rehearingsForm.get('paperType').setValue('');
            this.getNextExhibitNumber();
          } else {
            this.rehearingsForm.get('exhibitNumber').setValue(null);
          }
          this.rehearingsForm
            .get('contentManagementId')
            .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
          // if (this.rehearingsForm.value.docType === 'exhibits') {
          //   this.rehearingsForm.get('paperType').setValue('');
          // }

          this.addedDocumentsList.push(this.rehearingsForm.value);
          this.logger.info('Document list', this.addedDocumentsList);
          // this.keepSameRehearingType();
          this.clearForm();
          this.rehearingsForm.get('filingParty').disable();
          this.commonUtils.focusOnCloseModal('closeRehearingModal');
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.commonUtils.throwError(
            `Save document failed for Rehearings`,
            documentSaveFailed
          );
          this.addingToList = false;
          this.rehearingsForm.enable();
          this.rehearingsForm.get('filingParty').disable();
          this.commonUtils.focusOnCloseModal('closeRehearingModal');
        }
      );
  }

  update() {
    // this.rehearingsForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.getCurrentDateString('time'));
    // this.rehearingsForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.setEST(new Date().getTime()));
    // this.addedDocumentsList[this.editIndex] = this.rehearingsForm.value;

    // this.clearForm();

    this.addingToList = true;
    this.caseViewerService
      .updateDocument(
        this.addedDocumentsList[this.editIndex],
        this.rehearingsForm,
        this.rehearingsModalInfo.proceedingNo
      )
      .pipe(take(1))
      .subscribe(
        (editSuccess) => {
          this.rehearingsForm
            .get('uploadedDate')
            .setValue(this.commonUtils.getCurrentDateString('time'));
          const contentManagementIdTemp =
            this.addedDocumentsList[this.editIndex].contentManagementId;
          const filingDateTemp =
            this.addedDocumentsList[this.editIndex].filingDate;
          this.addedDocumentsList[this.editIndex] = this.rehearingsForm.value;
          this.rehearingsForm
            .get('contentManagementId')
            .setValue(contentManagementIdTemp);
          this.rehearingsForm.get('filingDate').setValue(filingDateTemp);
          this.getNextExhibitNumber();
          this.clearForm();
          this.addingToList = false;
          this.commonUtils.setToastr('success', CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
        },
        (editFailure) => {
          this.commonUtils.throwError('Error', editFailure);
          this.addingToList = false;
          this.commonUtils.setToastr('error', CONSTANTS.TOAST_MSGS.UPDATE_DOC.ERROR)
        }
      );
  }

  openRehearingTypeChangeModal() {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: 'Change Rehearing type?',
        infoText: [
          'You have changed the rehearing type.',
          'This will automatically change the rehearing type for all other papers and exhibits listed in the List of documents.',
          'Are you sure you want to update the rehearing type?',
        ],
        showLeftBtn: true,
        leftBtnClass: 'btn-light',
        leftBtnLabel: 'No, return to page',
        showRightBtn: true,
        rightBtnClass: 'btn-primary',
        rightBtnLabel: 'Yes, change rehearing type',
        modalHeight: 175,
      },
    };
    this.rehearingChangeModalRef = this.modalService.show(InfoModalComponent, {
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.rehearingChangeModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        // this.initiatePetitionService
        //   .deleteClaim(data.claimIdentifier)
        //   .subscribe((Response) => {
        //     this.getClaimsList();
        //     this.commonUtils.showSuccess(`Claim successfully removed`, '');
        //   });
        this.changeRehearingTypeForAll();
      } else {
        this.rehearingChangeModalRef.hide();
      }
    });
  }

  changeRehearingTypeForAll() {
    this.addedDocumentsList.forEach((addedPaper) => {
      addedPaper.rehearingType = this.rehearingsForm.value.rehearingType;
      addedPaper.paperType = this.rehearingsForm.value.paperType;
    });
    // this.clearForm();
    this.update();
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        if (
          this.editMode &&
          this.originalRehearingType.identifier !==
          this.rehearingsForm.value.rehearingType.identifier
        ) {
          this.logger.info('Rehearing types are different');
          this.openRehearingTypeChangeModal();
        } else {
          action === 'add' ? this.addToList() : this.update();
        }
      }
    });
  }

  saveSubmitRehearing(rehearingStatus) {
    const filingParty = this.commonUtils.convertStringToTitleCase(
      this.partyRepresenting
    );
    this.rehearingStatus = rehearingStatus;
    this.saving = true;
    const action =
      rehearingStatus.toLowerCase() === 'initiated' ? 'saved' : 'submitted';
    const currentTime = new Date().getTime();
    this.logger.info('Rehearing form:', this.rehearingsForm);
    const rehearingObj: any = {
      rehearingStatus: rehearingStatus,
      rehearingTypeId: this.rehearingsForm.value.rehearingType.identifier,
      proceedingNumber: this.rehearingsModalInfo.proceedingNo,
      // filingParty: this.rehearingsForm.value.filingParty,
      filingParty: filingParty,
      filedDate: currentTime,
      // requestorTypeName: this.rehearingsForm.value.filingParty,
      requestorTypeName: filingParty,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        lastModifiedTimestamp: currentTime,
        createTimestamp: currentTime,
      },
      rehearingDocuments: null,
    };
    let rehearingsDocuments = [];
    this.addedDocumentsList.forEach((doc) => {
      this.sameType.paperType.documentTypeCustomAttributes.attributes[0].value = Math.trunc(currentTime / 1000).toString();
      const rehearingDoc: any = {
        artifactIdentifer: doc.artifactIdentifer,
        artifactSubmissionIdentifier: doc.artifactSubmissionIdentifier,
        category: doc.docType.toUpperCase(),
        // exhibitNumber: doc.docType === 'exhibits' ? doc.exhibitNumber : null,
        exhibitNumber:
          doc.docType === CONSTANTS.DOC_TYPE.EXHIBIT ? doc.exhibitNumber : null,
        sequenceNumber: null,
        name: doc.documentName,
        fileName: doc.fileName,
        filingParty: this.rehearingsForm.value.filingParty,
        availability: doc.availability.code,
        documentTypeIdentifier: doc.paperType.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier,
        // documentTypeCode: doc.paperType.code,
        documentTypeCode:
          doc.docType.toLowerCase() === CONSTANTS.DOC_TYPE.PAPER
            ? doc.paperType.code
            : CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
        mimeType: doc.fileToUpload.type,
        documentTypeCustomAttributes: this.sameType.paperType.documentTypeCustomAttributes
      };
      if (this.existingRehearingId) {
        rehearingDoc.filingDate = new Date(doc.uploadedDate).getTime() / 1000;
      }
      rehearingsDocuments.push(rehearingDoc);
    });
    rehearingObj.rehearingDocuments = rehearingsDocuments;

    if (this.existingRehearingId) {
      rehearingObj.rehearingId = this.existingRehearingId;
      rehearingObj.rehearingTypeId =
        this.addedDocumentsList[0].rehearingType.identifier;
      this.caseViewerService
        .updateRehearing(rehearingObj, this.existingRehearingId)
        .pipe(take(1))
        .subscribe(
          (updateRehearingResponse) => {
            this.logger.info(
              `Rehearing was successfully updated`,
              updateRehearingResponse
            );
            this.commonUtils.showSuccess(
              `Successfully ${action} rehearing request`,
              'Rehearing request'
            );
            this.close(false);
          },
          (saveRehearingError) => {
            this.logger.error(`Rehearing was NOT updated`);
            this.commonUtils.showError(
              `Rehearing request failed to update`,
              `Rehearing request`
            );
            this.saving = false;
          }
        );
    } else {
      this.caseViewerService
        .saveSubmitRehearing(rehearingObj)
        .pipe(take(1))
        .subscribe(
          (saveRehearingResponse) => {
            this.logger.info(
              `Rehearing was successfully ${action}`,
              saveRehearingResponse
            );
            this.commonUtils.showSuccess(
              `Successfully ${action} rehearing request`,
              'Rehearing request'
            );
            this.close(false);
          },
          (saveRehearingError) => {
            this.logger.error(`Rehearing was NOT ${action}`);
            const errorAction = action === 'saved' ? 'save' : 'submit';
            this.commonUtils.showError(
              `Rehearing request failed to ${errorAction}`,
              `Rehearing request`
            );
            this.saving = false;
          }
        );
    }
  }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    // this.logger.info('Edit rehearing:', this.addedDocumentsList[e]);
    // this.rehearingsForm.setValue(this.addedDocumentsList[e]);
    this.rehearingsForm = this.fb.group({
      filingParty: [this.addedDocumentsList[e].filingParty],
      rehearingType: [
        this.addedDocumentsList[e].rehearingType,
        Validators.required,
      ],
      docType: [this.addedDocumentsList[e].docType, Validators.required],
      paperType: [this.addedDocumentsList[e].paperType, Validators.required],
      exhibitNumber: [this.addedDocumentsList[e].exhibitNumber],
      availability: [
        this.addedDocumentsList[e].availability,
        Validators.required,
      ],
      documentName: [
        this.addedDocumentsList[e].documentName,
        Validators.required,
      ],
      fileToUpload: [
        this.addedDocumentsList[e].fileToUpload,
        Validators.required,
      ],
      fileName: [this.addedDocumentsList[e].fileName, Validators.required],
      uploadedDate: [this.addedDocumentsList[e].uploadedDate],
      pageCount: [this.addedDocumentsList[e].pageCount],
      artifactIdentifer: [this.addedDocumentsList[e].artifactIdentifer],
      artifactSubmissionIdentifier: [
        this.addedDocumentsList[e].artifactSubmissionIdentifier,
      ],
      contentManagementId: [this.addedDocumentsList[e].contentManagementId],
      filingDate: [this.addedDocumentsList[e].filingDate],
    });
    this.paperTypeDisplayName = this.addedDocumentsList[e].paperType
      .displayNameText
      ? this.addedDocumentsList[e].paperType.displayNameText
      : this.addedDocumentsList[e].paperType.descriptionText;
    this.rehearingTypeDisplayName = this.addedDocumentsList[e].rehearingType
      .displayName
      ? this.addedDocumentsList[e].rehearingType.displayName
      : this.addedDocumentsList[e].rehearingType.descriptionText;
    this.originalRehearingType = JSON.parse(
      JSON.stringify(this.rehearingsForm.value.rehearingType)
    );
    this.originalPaperType = JSON.parse(
      JSON.stringify(this.rehearingsForm.value.paperType)
    );
    // this.rehearingsForm
    //   .get('availability')
    //   .setValue(this.addedDocumentsList[e].availability, Validators.required);
    this.rehearingTypeDisplayName = this.addedDocumentsList[e].rehearingType;
    this.rehearingsForm.updateValueAndValidity();
  }

  getPartyRepresenting() {
    this.caseViewerService
      .getPartyRepresenting(this.rehearingsModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe(
        (partyRepresenting) => {
          if (partyRepresenting.toLowerCase() === 'patentowner') {
            partyRepresenting = 'PATENT OWNER';
          }
          window.sessionStorage.setItem('partyRepresenting', partyRepresenting);
          this.partyRepresenting = partyRepresenting;
          this.rehearingsForm
            .get('filingParty')
            .setValue(
              this.partyRepresenting.toLowerCase() === 'petitioner'
                ? 'Petitioner'
                : 'Patent Owner'
            );
        },
        (noPartyRepresentingFound) => { }
      );
  }

  getExistingRehearingDocuments(existingRehearing) {
    if (!this.partyRepresenting) {
      this.getPartyRepresenting();
    }
    this.caseViewerService
      .getExistingRehearingDocuments(existingRehearing)
      .pipe(take(1))
      .subscribe((exhistingRehearingInfo) => {
        this.logger.info('Existing rehearing info:', exhistingRehearingInfo);
        this.existingRehearingId = exhistingRehearingInfo[0].rehearingId;
        this.addedDocumentsList = [];
        setTimeout(() => {
          const foundRehearingType = this.rehearingsTypesList.find(
            ({ identifier }) =>
              identifier === exhistingRehearingInfo[0].rehearingTypeId
          );
          if (foundRehearingType) {
            this.rehearingsForm
              .get('rehearingType')
              .setValue(foundRehearingType);
            // this.rehearingTypeDisplayName = foundRehearingType.descriptionText;
            this.rehearingTypeDisplayName = foundRehearingType;
            this.sameType.rehearingType = foundRehearingType;
            this.sameType.keep = true;
            this.rehearingsForm.updateValueAndValidity();
          }

          // const specificInfo = {
          //   item: foundRehearingType,
          //   value: foundRehearingType.descriptionText,
          // };

          this.caseViewerService
            .getSpecificRehearingPaperType(foundRehearingType.code)
            .pipe(take(1))
            .subscribe(
              (specificPaperType) => {
                const specificPaperTypeSingle = specificPaperType[0];

                this.rehearingsForm
                  .get('paperType')
                  .setValue(specificPaperTypeSingle);
                this.paperTypeDisplayName =
                  specificPaperTypeSingle.displayNameText;
                this.sameType.paperType = specificPaperTypeSingle;
                this.sameType.keep = true;
                exhistingRehearingInfo[0].rehearingDocuments.forEach(
                  (rehearingDocument) => {
                    const fileToUpload = {
                      type: 'application/pdf',
                    };
                    const foundAvailability = this.availabilityList.find(
                      ({ code }) =>
                        code === rehearingDocument.availablitySummary.code
                    );
                    const rehearingData = {
                      filingParty: rehearingDocument.filingParty,
                      rehearingType: foundRehearingType,
                      docType:
                        rehearingDocument.artifactSummary.descriptionText.toLowerCase(),
                      // paperType: specificPaperTypeSingle,
                      paperType:
                        rehearingDocument.artifactSummary.descriptionText.toLowerCase() ===
                          'paper'
                          ? specificPaperTypeSingle
                          : CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
                      exhibitNumber: rehearingDocument.exhibitNumber
                        ? rehearingDocument.exhibitNumber
                        : null,
                      // documentNumber: rehearingDocument.documentNumber
                      //   ? rehearingDocument.documentNumber
                      //   : null,
                      availability: foundAvailability,
                      documentName: rehearingDocument.name,
                      fileToUpload: fileToUpload,
                      fileName: rehearingDocument.fileName,
                      uploadedDate: this.commonUtils.setEST(
                        rehearingDocument.filingDate
                      ),
                      pageCount: rehearingDocument.pageCount
                        ? rehearingDocument.pageCount
                        : null,
                      artifactIdentifer: rehearingDocument.artifactIdentifer,
                      artifactSubmissionIdentifier:
                        rehearingDocument.artifactSubmissionIdentifier,
                      contentManagementId:
                        rehearingDocument.contentManagementId,
                      filingDate: rehearingDocument.filingDate,
                    };
                    this.addedDocumentsList.push(rehearingData);
                  }
                );
                this.showWarningMessage = !this.paperDocumentExists();
              },
              (specificTyperError) => {
                this.paperTypeDisplayName = null;
                this.logger.error(
                  'Could not get paper type for rehearing',
                  specificTyperError
                );
              }
            );
        }, 200);

        // this.getSpecificPaperType(specificInfo);
      });
  }

  deleteRehearing() {
    if (this.existingRehearingId) {
      this.caseViewerService
        .deleteRehearing(this.existingRehearingId)
        .pipe(take(1))
        .subscribe(
          (deleteRehearingSuccess) => {
            this.logger.info(
              'Delete rehearing success',
              deleteRehearingSuccess
            );
            this.commonUtils.showSuccess(
              'Successfully deleted rehearing request',
              'Delete rehearing request'
            );
            this.close(true);
          },
          (deleteRehearingFailure) => {
            this.logger.error(
              'Failed to delete rehearing',
              deleteRehearingFailure
            );
            this.commonUtils.showError(
              'Failed to delete rehearing request',
              'Delete rehearing request'
            );
          }
        );
    } else {
      // this.close(true);

      if (this.addedDocumentsList.length > 0) {
        this.addedDocumentsList.forEach((document) => {
          this.deleteDocument(document.artifactIdentifer);
        });
      } else {
        this.close(true);
      }
    }
  }

  deleteDocument(artifactID) {
    this.initiatePetitionService
      .deleteDocument(artifactID)
      .pipe(take(1))
      .subscribe(
        (deleteDocumentSuccess) => {
          this.logger.info(
            'Document deleted successfully',
            deleteDocumentSuccess
          );
          this.close(true);
        },
        (deleteDocumentFailure) => {
          this.logger.error('Failed to delete document', deleteDocumentFailure);
          this.commonUtils.showError(
            deleteDocumentFailure.error.message,
            'Delete document'
          );
        }
      );
  }

  clearSelection() {
    this.rehearingTypeDisplayName = '';
    this.rehearingsForm.get('rehearingType').setValue('', Validators.required);
  }

  checkForm() {
    this.logger.info('Rehearing form: ', this.rehearingsForm);
  }
}
