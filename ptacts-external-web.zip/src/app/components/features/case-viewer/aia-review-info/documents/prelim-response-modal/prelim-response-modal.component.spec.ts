import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrelimResponseModalComponent } from './prelim-response-modal.component';

describe('PrelimResponseModalComponent', () => {
  let component: PrelimResponseModalComponent;
  let fixture: ComponentFixture<PrelimResponseModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrelimResponseModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrelimResponseModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
