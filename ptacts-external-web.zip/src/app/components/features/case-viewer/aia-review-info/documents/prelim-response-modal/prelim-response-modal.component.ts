import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { InitiatePetitionService } from 'src/app/components/features/initiate-petition/initiate-petition.service';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../../case-viewer.service';

@Component({
  selector: 'app-prelim-response-modal',
  templateUrl: './prelim-response-modal.component.html',
  styleUrls: ['./prelim-response-modal.component.scss'],
})
export class PrelimResponseModalComponent implements OnInit {
  pRModalInfo: any = this.modalService.config.initialState;
  publicModalRef: BsModalRef;
  pRChangeModalRef: BsModalRef;
  pRForm: FormGroup;
  partyRepresenting: string;

  pRTypeDisplayName: string = '';
  paperTypeDisplayName: string = null;
  petitionIdentifier: string = null;
  pRStatus: string = null;

  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;

  editMode: boolean = false;
  saving: boolean = false;
  addingToList: boolean = false;
  showWarningMessage: boolean = false;
  onePaperMin: boolean = false;
  showPRTypeWarning: boolean = false;
  showPaperErrorMessage: boolean = false;

  selectedFilingParty: any = null;
  selectedPRType: any = null;
  originalPRType: any = null;
  originalPaperType: any = null;
  sameType = {
    pRType: null,
    paperType: null,
    keep: false,
  };

  minExhibitNumber: number = null;
  editIndex: number = null;

  addedDocumentsList: Array<any> = new Array<any>();
  pRTypesList: Array<any> = new Array<any>();
  availabilityList: Array<any> = new Array<any>();
  listOfExistingExhibitNumbers = [];

  constructor(
    private logger: NGXLogger,
    private modalService: BsModalService,
    private fb: FormBuilder,
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService
  ) { }

  ngOnInit(): void {
    this.partyRepresenting = window.sessionStorage.getItem('partyRepresenting');
    this.setupForm(false);
    this.getPRTypes();
    this.getAvailabilities();
    this.getPetitionIdentifier();
    this.getNextExhibitNumber();
    this.getAllExhibitNumbers();
  }

  close(selection) {
    this.logger.info(selection);
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  setupForm(clear) {
    const partyRep =
      this.partyRepresenting.toLowerCase() === 'petitioner'
        ? 'Petitioner'
        : 'Patent Owner';
    this.pRForm = this.fb.group({
      filingParty: [partyRep],
      pRType: ['', Validators.required],
      docType: ['paper', Validators.required],
      paperType: ['', Validators.required],
      exhibitNumber: [null],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
    // if (this.addedDocumentsList.length > 0) {
    //   this.keepSameRehearingType();
    // } else {
    this.sameType.paperType = null;
    this.sameType.pRType = null;
    // }
  }

  keepSameRehearingType() {
    this.pRForm.get('pRType').setValue(this.sameType.pRType);
    this.pRForm.get('paperType').setValue(this.sameType.paperType);
    this.paperTypeDisplayName = this.sameType.paperType.displayName;
    this.pRTypeDisplayName = this.sameType.pRType.descriptionText;
    this.pRForm.updateValueAndValidity();
  }

  getPRTypes() {
    this.caseViewerService
      // .getRehearingTypes(CONSTANTS.TYPE_CODES.REHEARING_TYPES)
      .getPrelimResponseTypes()
      .pipe(take(1))
      .subscribe((pRTypes) => {
        this.pRTypesList = pRTypes;
      });
  }

  getAvailabilities() {
    this.caseViewerService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilitiesResponse) => {
        this.availabilityList = availabilitiesResponse;
        this.logger.info('AvailabilitiesList', this.availabilityList);
      });
  }

  getSpecificPaperType(e) {
    // this.showPRTypeWarning = false;
    // this.pRForm.get('pRType').setValue(e.item);
    // this.pRTypeDisplayName = e.value;
    // const prType = this.pRForm.value.pRType;
    // this.pRForm.get('paperType').setValue(e.item);
    // this.paperTypeDisplayName = e.value;

    this.showPRTypeWarning = false;
    this.pRForm.get('pRType').setValue(e);
    this.pRTypeDisplayName = e;
    const prType = this.pRForm.value.pRType;
    this.pRForm.get('paperType').setValue(e);
    this.paperTypeDisplayName = e.displayNameText;

    // this.caseViewerService
    //   .getSpecificRehearingPaperType(prType.code)
    //   .pipe(take(1))
    //   .subscribe(
    //     (specificPaperType) => {
    //
    //       // if (!this.sameType.rehearingType && !this.sameType.paperType) {
    //       this.sameType.paperType = specificPaperType;
    //       this.sameType.pRType = e.item;
    //       this.sameType.keep = true;
    //       // }
    //       this.pRForm.get('paperType').setValue(specificPaperType);
    //       this.paperTypeDisplayName = specificPaperType.displayNameText;
    //     },
    //     (specificTyperError) => {
    //       this.paperTypeDisplayName = null;
    //       this.logger.error(
    //         'Could not get paper type for rehearing',
    //         specificTyperError
    //       );
    //     }
    //   );
  }

  checkForValidity(e) {
    this.logger.info(e);
    if ((e && !this.pRTypeDisplayName) || (!e && !this.pRTypeDisplayName)) {
      this.showPRTypeWarning = true;
    }
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.pRModalInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  getNextExhibitNumber() {
    this.initiatePetitionService
      .getNextExhibitNumber(this.pRModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        const nextNumber =
          this.partyRepresenting.toLowerCase() === 'petitioner'
            ? nextExhibitNumber.petitionerExhibitSequence
            : nextExhibitNumber.patentownerExhibitSequence;
        this.pRForm.get('exhibitNumber').setValue(nextNumber);
        this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  getAllExhibitNumbers() {
    this.caseViewerService
      .getAllExhibitNumbers(
        this.pRModalInfo.proceedingNo,
        this.partyRepresenting
      )
      .pipe(take(1))
      .subscribe((allExhibitNumbers: any) => {
        this.listOfExistingExhibitNumbers = allExhibitNumbers;
      });
  }

  changeDocType(docType) {
    // if (docType === 'exhibits') {
    if (docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
      this.showPaperErrorMessage = false;
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      this.pRForm
        .get('exhibitNumber')
        .setValue(this.minExhibitNumber, [Validators.required]);
      this.pRForm.get('exhibitNumber').updateValueAndValidity();
      this.pRForm.get('paperType').clearValidators();
      this.pRForm.get('paperType').updateValueAndValidity();
      this.pRForm.get('pRType').clearValidators();
      this.pRForm.get('pRType').updateValueAndValidity();
      // if (this.addedDocumentsList.length > 0) {
      //   this.keepSameRehearingType();
      // }
      if (this.addedDocumentsList.length <= 0) {
        this.showWarningMessage = true;
      }
    } else {
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = false;
      this.pRForm.get('pRType').setValidators(Validators.required);
      this.pRForm.get('pRType').updateValueAndValidity();
    }
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    if (event.target.files.length > 0) {
      this.pRForm.get('fileToUpload').setValue(event.target.files[0]);
      this.pRForm.get('fileName').setValue(event.target.files[0].name);
    }
  }

  clearForm() {
    this.logger.info('clear form');
    this.clearFile();
    this.addingToList = false;
    this.showPaperErrorMessage = false;
    this.onePaperMin = false;
    this.showWarningMessage = false;
    this.showPRTypeWarning = false;
    this.editMode = false;
    this.editIndex = null;
    this.pRTypeDisplayName = null;
    this.paperTypeDisplayName = null;
    this.setupForm(true);
  }

  clearFile() {
    if (<HTMLInputElement>document.getElementById('file')) {
      (<HTMLInputElement>document.getElementById('file')).value = '';
      this.pRForm.get('fileToUpload').setValue(null);
      this.pRForm.get('fileName').setValue(null);
    }
  }

  checkAvailability(action) {
    if (
      this.pRForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else if (
      this.editMode &&
      this.originalPRType.identifier !== this.pRForm.value.pRType.identifier
    ) {
      this.logger.info('Preliminary response types are different');
      this.openPRTypeChangeModal();
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
    if (e) {
      this.pRForm.get('pRType').setValue('', Validators.required);
      this.pRForm.get('paperType').setValue('', Validators.required);
      this.paperTypeDisplayName = null;
      this.pRTypeDisplayName = null;
      this.pRForm.updateValueAndValidity();
    }
  }

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.showWarningMessage = e;
  }

  addToList() {
    if (!this.paperDocumentExists()) {
      this.addingToList = true;
      this.pRForm.disable();
      this.initiatePetitionService
        .addToList(
          this.pRForm.value.fileToUpload,
          this.pRForm.value.docType,
          this.petitionIdentifier
        )
        .pipe(take(1))
        .subscribe(
          (fileAdded) => {
            // this.logger.info('Saved document to CMS', fileAdded);
            // this.selectedFilingParty = !this.selectedFilingParty
            //   ? this.pRForm.value.filingParty
            //   : this.selectedFilingParty;
            // this.selectedPRType = !this.selectedPRType
            //   ? this.pRForm.value.pRType
            //   : this.selectedPRType;
            // // this.getDocuments();
            // this.pRForm
            //   .get('uploadedDate')
            //   .setValue(this.commonUtils.getCurrentDateString('time'));
            // // this.pRForm
            // //   .get('artifactIdentifer')
            // //   .setValue(fileAdded.petitionDocuments[0].artifactIdentifer);
            // if (this.pRForm.value.docType === 'exhibits') {
            //   this.minExhibitNumber++;
            // } else {
            //   this.pRForm.get('exhibitNumber').setValue(null);
            // }
            // if (this.pRForm.value.docType === 'exhibits') {
            //   this.pRForm.get('paperType').setValue('');
            // }

            // this.addedDocumentsList.push(this.pRForm.value);
            // this.clearForm();

            this.pRForm.enable();
            let petitionDocument = null;
            let filingParty =
              this.pRForm.value.filingParty === ''
                ? 'PETITIONER'
                : this.pRForm.value.filingParty.toUpperCase();
            if (this.pRForm.value.docType.toLowerCase() === 'paper') {
              const docId = this.pRForm.value.paperType.documentTypeId
                ? this.pRForm.value.paperType.documentTypeId
                : this.pRForm.value.paperType.identifier;
              petitionDocument = new PetitionDocument(
                this.pRForm.value.docType.toUpperCase(),
                this.pRForm.value.documentName,
                this.pRForm.value.fileName,
                filingParty,
                // 'BOARD',
                this.pRForm.value.availability.code,
                docId,
                this.pRForm.value.paperType.code,
                this.pRForm.value.fileToUpload.type,
                null,
                'N',
                null
              );
            } else {
              petitionDocument = new PetitionDocument(
                this.pRForm.value.docType.toUpperCase(),
                this.pRForm.value.documentName,
                this.pRForm.value.fileName,
                filingParty,
                // 'BOARD',
                this.pRForm.value.availability.code,
                null,
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.pRForm.value.fileToUpload.type,
                this.pRForm.value.exhibitNumber,
                'N',
                null
              );
            }

            const documentToAdd = new DocumentToAdd(petitionDocument);
            documentToAdd.proceedingNumberText = this.pRModalInfo.proceedingNo;
            this.pRForm.get('pageCount').setValue(fileAdded.pageCount);
            this.pRForm.get('filingDate').setValue(fileAdded.filingDate);
            this.pRForm
              .get('uploadedDate')
              .setValue(this.commonUtils.setEST(new Date().getTime()));
            // this.saveDocumentToCMS(documentToAdd);
            this.pRForm
              .get('exhibitNumber')
              .setValue(petitionDocument.exhibitNumber);
            this.addedDocumentsList.push(this.pRForm.value);
            if (this.pRForm.value.docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
              // this.getNextExhibitNumber();
              this.minExhibitNumber = this.commonUtils.getNextExhibitNumber({
                currentNumber: this.pRForm.get('exhibitNumber').value,
                listOfNumbers: this.listOfExistingExhibitNumbers,
              });
            }
            this.commonUtils.focusOnCloseModal('closePrelimResponseModal');
            this.clearForm();
          },
          (addToListFailure) => {
            this.addingToList = false;
            this.pRForm.enable();
            this.commonUtils.throwError(
              `Add to list failed for Preliminary Response`,
              addToListFailure
            );
            this.commonUtils.focusOnCloseModal('closePrelimResponseModal');
          }
        );
    } else {
      this.showPaperErrorMessage = true;
      this.pRForm.enable();
      this.commonUtils.focusOnCloseModal('closePrelimResponseModal');
    }
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.docType.toLowerCase() === 'paper' &&
          this.pRForm.value.docType === 'paper'
        ) {
          paperDocExists = true;
        }
      });
    }
    return paperDocExists;
  }

  saveDocumentToCMS(documentToAdd) {
    this.pRForm.disable();
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.pRForm.enable();
          this.logger.info('Saved document to CMS', saveSuccessful);
          this.selectedFilingParty = !this.selectedFilingParty
            ? this.pRForm.value.filingParty
            : this.selectedFilingParty;
          this.selectedPRType = !this.selectedPRType
            ? this.pRForm.value.pRType
            : this.selectedPRType;
          // this.getDocuments();
          // this.pRForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          this.pRForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.pRForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          // if (this.pRForm.value.docType === 'exhibits') {
          if (this.pRForm.value.docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
            // this.minExhibitNumber++;
            this.pRForm.get('paperType').setValue('');
            this.getNextExhibitNumber();
          } else {
            this.pRForm.get('exhibitNumber').setValue(null);
          }
          this.pRForm
            .get('contentManagementId')
            .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
          // if (this.pRForm.value.docType === 'exhibits') {
          //   this.pRForm.get('paperType').setValue('');
          // }

          this.addedDocumentsList.push(this.pRForm.value);
          this.clearForm();
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.addingToList = false;
          this.pRForm.enable();
          this.commonUtils.throwError(
            `Save document failed for Preliminary Response`,
            documentSaveFailed
          );
        }
      );
  }

  update() {
    // this.pRForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.getCurrentDateString('time'));

    // this.pRForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.setEST(new Date().getTime()));
    // this.addedDocumentsList[this.editIndex] = this.pRForm.value;
    // this.getNextExhibitNumber();
    // this.clearForm();
    this.addingToList = true;
    // const tempDoc = this.addedDocumentsList[this.editIndex];
    // let tempCat = tempDoc.docType.toUpperCase();

    // let updateDocObj = {
    //   artifactIdentifer: tempDoc.artifactIdentifer,
    //   audit: {
    //     lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
    //     createUserIdentifier: window.sessionStorage.getItem('email'),
    //   },
    //   availability: this.pRForm.value.availability.code,
    //   category: tempCat,
    //   contentManagementId: tempDoc.contentManagementId,
    //   documentTypeIdentifier: tempDoc.paperType.identifier,
    //   fileSize: tempDoc.fileToUpload.size,
    //   filingDate: tempDoc.filingDate,
    //   filingParty: tempDoc.filingParty.toUpperCase(),
    //   name: this.pRForm.value.documentName,
    //   proceedingNumberText: this.pRModalInfo.proceedingNo,
    //   ptabDefaultRefreshTime: null,
    //   ptabReadOnlyUser: false,
    //   textExtractionIndicator: null,
    //   exhibitNumber: this.pRForm.value.exhibitNumber
    //     ? this.pRForm.value.exhibitNumber
    //     : null,
    // };

    this.pRForm
      .get('uploadedDate')
      .setValue(this.commonUtils.getCurrentDateString('time'));
    this.addedDocumentsList[this.editIndex] = this.pRForm.value;

    this.clearForm();
    this.addingToList = false;

    if (
      this.pRForm.value.docType.toLowerCase() === CONSTANTS.DOC_TYPE.EXHIBIT
    ) {
      this.getNextExhibitNumber();
    }
    this.commonUtils.setToastr('success', CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
    // this.caseViewerService
    //   .updateDocument(
    //     this.addedDocumentsList[this.editIndex],
    //     this.pRForm,
    //     this.pRModalInfo.proceedingNo
    //   )
    //   .pipe(take(1))
    //   .subscribe(
    //     (editSuccess) => {
    //       this.pRForm
    //         .get('uploadedDate')
    //         .setValue(this.commonUtils.getCurrentDateString('time'));
    //       this.addedDocumentsList[this.editIndex] = this.pRForm.value;
    //       this.getNextExhibitNumber();
    //       this.clearForm();
    //       this.addingToList = false;
    //     },
    //     (editFailure) => {
    //       this.addingToList = false;
    //     }
    //   );
  }

  openPRTypeChangeModal() {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: 'Change preliminary response type?',
        infoText: [
          'You have changed the Preliminary response type.',
          'This will automatically change the preliminary response type for all other papers and exhibits listed in the List of documents.',
          'Are you sure you want to update the preliminary response type?',
        ],
        showLeftBtn: true,
        leftBtnClass: 'btn-light',
        leftBtnLabel: 'No, return to page',
        showRightBtn: true,
        rightBtnClass: 'btn-primary',
        rightBtnLabel: 'Yes, change preliminary type',
        modalHeight: 175,
      },
    };
    this.pRChangeModalRef = this.modalService.show(InfoModalComponent, {
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.pRChangeModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.changePRTypeForAll();
      } else {
        this.pRChangeModalRef.hide();
      }
    });
  }

  changePRTypeForAll() {
    this.addedDocumentsList.forEach((addedPaper) => {
      addedPaper.pRType = this.pRForm.value.pRType;
      addedPaper.paperType = this.pRForm.value.paperType;
    });
    // this.clearForm();
    this.update();
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        if (
          this.editMode &&
          this.originalPRType.identifier !== this.pRForm.value.pRType.identifier
        ) {
          this.logger.info('Preliminary response types are different');
          this.openPRTypeChangeModal();
        } else {
          action === 'add' ? this.addToList() : this.update();
        }
      }
    });
  }

  submitPR() {
    const currentDate = Math.trunc(new Date().getTime() / 1000);
    this.saving = true;
    let petitionDocument = null;
    let documentObj = {
      partyRequestTypes: [],
      proceedingNumberText: this.pRModalInfo.proceedingNo,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        createUserIdentifier: window.sessionStorage.getItem('email'),
      },
      petitionDocuments: [],
      joinderOrginalIndicator: null,
    };
    this.addedDocumentsList.forEach((doc) => {
      if (doc.docType.toLowerCase() === 'paper') {
        const docId = doc.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier;
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileName,
          doc.filingParty,
          // 'BOARD',
          doc.availability.code,
          docId,
          doc.paperType.code,
          doc.fileToUpload.type,
          null,
          'Y',
          null
        );
      } else {
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileName,
          doc.filingParty,
          // 'BOARD',
          doc.availability.code,
          null,
          CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
          doc.fileToUpload.type,
          doc.exhibitNumber,
          'Y',
          null
        );
      }
      if (
        doc.paperType.documentTypeCustomAttributes &&
        doc.paperType.documentTypeCustomAttributes.attributes &&
        doc.paperType.documentTypeCustomAttributes.attributes.length > 0
      ) {
        petitionDocument.documentTypeCustomAttributes =
          doc.paperType.documentTypeCustomAttributes;
        petitionDocument.documentTypeCustomAttributes.attributes[0].value =
          currentDate.toString();
      }
      documentObj.petitionDocuments.push(petitionDocument);
    });
    this.caseViewerService
      .submitOtherDocuments(documentObj)
      .pipe(take(1))
      .subscribe(
        (otherDocumentsResponse) => {
          this.commonUtils.showSuccess(
            `Successfully submitted preliminary response`,
            'Submit preliminary response'
          );
          this.saving = false;
          this.logger.info(otherDocumentsResponse);
          this.close(true);
        },
        (prelimSubmissionFailure) => {
          this.commonUtils.showError(
            prelimSubmissionFailure.error.message,
            'Submit preliminary response'
          );
          this.saving = false;
        }
      );
  }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    if (this.addedDocumentsList[e].pageCount == undefined) {
      this.addedDocumentsList[e].pageCount = null;
    }
    this.pRForm.setValue(this.addedDocumentsList[e]);
    this.paperTypeDisplayName = this.addedDocumentsList[e].paperType.displayName
      ? this.addedDocumentsList[e].paperType.displayName
      : this.addedDocumentsList[e].paperType.descriptionText;
    // this.pRTypeDisplayName = this.addedDocumentsList[e].pRType.displayName
    //   ? this.addedDocumentsList[e].pRType.displayName
    //   : this.addedDocumentsList[e].pRType.descriptionText;
    this.pRTypeDisplayName = this.addedDocumentsList[e].pRType;
    this.pRForm.updateValueAndValidity();
    this.originalPRType = JSON.parse(JSON.stringify(this.pRForm.value.pRType));
    this.originalPaperType = JSON.parse(
      JSON.stringify(this.pRForm.value.paperType)
    );
  }

  clearSelection() {
    this.pRTypeDisplayName = '';
    this.pRForm.get('pRType').setValue('', Validators.required);
  }

  checkForm() {
    this.logger.info('Rehearing form: ', this.pRForm);
  }
}
