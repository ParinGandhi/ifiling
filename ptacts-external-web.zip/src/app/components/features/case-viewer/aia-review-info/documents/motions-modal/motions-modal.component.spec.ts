import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotionsModalComponent } from './motions-modal.component';

describe('MotionsComponent', () => {
  let component: MotionsModalComponent;
  let fixture: ComponentFixture<MotionsModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MotionsModalComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotionsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
