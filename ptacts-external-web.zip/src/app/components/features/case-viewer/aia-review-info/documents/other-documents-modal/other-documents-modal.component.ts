import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../../../../initiate-petition/initiate-petition.service';
import { CaseViewerService } from '../../../case-viewer.service';

@Component({
  selector: 'app-other-documents-modal',
  templateUrl: './other-documents-modal.component.html',
  styleUrls: ['./other-documents-modal.component.scss'],
})
export class OtherDocumentsModalComponent implements OnInit {
  noticeOfAppealModalInfo: any = this.modalService.config.initialState;
  publicModalRef: BsModalRef;
  noticeOfAppealForm: FormGroup;
  addedDocumentsList: Array<any> = new Array<any>();
  showWarningMessage: boolean = false;
  availabilityList: Array<any> = new Array<any>();
  editMode: boolean = false;
  editIndex: number = null;
  petitionIdentifier: string = null;
  selectedFilingParty: any = null;
  showPaperErrorMessage: boolean = false;
  onePaperMin: boolean = false;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;
  minExhibitNumber: number = null;
  paperTypeDisplayName: string = null;
  saving: boolean = false;
  addingToList: boolean = false;
  partyRepresenting: string = null;
  appealFiledDate: any = null;
  otherPaperTypes: any = null;
  otherTypeDisplayName: string = null;
  listOfExistingExhibitNumbers = [];

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private logger: NGXLogger,
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService
  ) { }

  ngOnInit(): void {
    this.partyRepresenting = window.sessionStorage.getItem('partyRepresenting');
    this.getAvailabilities();
    this.getNoticeOfAppealPaperTypes();
    this.getPetitionIdentifier();
    this.setupForm();
    this.getNextExhibitNumber();
    this.getAllExhibitNumbers();
    // this.commonUtils.getNextExhibitNumber({
    //   currentNumber: 1015,
    //   listOfNumbers: this.listOfExistingExhibitNumbers,
    // });
  }

  getNextExhibitNumber() {
    this.initiatePetitionService
      .getNextExhibitNumber(this.noticeOfAppealModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        const nextNumber =
          this.partyRepresenting.toLowerCase() === 'petitioner'
            ? nextExhibitNumber.petitionerExhibitSequence
            : nextExhibitNumber.patentownerExhibitSequence;
        this.noticeOfAppealForm.get('exhibitNumber').setValue(nextNumber);
        this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  getAllExhibitNumbers() {
    this.caseViewerService
      .getAllExhibitNumbers(
        this.noticeOfAppealModalInfo.proceedingNo,
        this.partyRepresenting
      )
      .pipe(take(1))
      .subscribe((allExhibitNumbers: any) => {
        this.listOfExistingExhibitNumbers = allExhibitNumbers;
      });
  }

  getAvailabilities() {
    this.caseViewerService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilitiesResponse) => {
        this.availabilityList = availabilitiesResponse;
        this.logger.info('AvailabilitiesList', this.availabilityList);
      });
  }

  getNoticeOfAppealPaperTypes() {
    this.caseViewerService
      .getOtherDocumentPaperTypes(
        this.noticeOfAppealModalInfo.proceedingNo,
        this.partyRepresenting.toUpperCase()
      )
      .pipe(take(1))
      .subscribe((noticeOfAppealPaperTypes) => {
        // this.noticeOfAppealPaperTypesList = noticeOfAppealPaperTypes;
        // this.otherPaperTypes = noticeOfAppealPaperTypes.stateDocumentTypes;

        // noticeOfAppealPaperTypes.stateDocumentTypes.forEach((element) => {
        //   const tempDisplayNameText = element.displayNameText
        //     .split(':')
        //     .map((item) => item.trim());
        //   element.displayNameText = tempDisplayNameText[0];
        //   if (tempDisplayNameText[1]) {
        //     element.displayNameText = `${element.displayNameText} : ${tempDisplayNameText[1]}`;
        //   }
        // });
        noticeOfAppealPaperTypes.stateDocumentTypes =
          this.commonUtils.removeSpaceFromPaperTypes(
            noticeOfAppealPaperTypes.stateDocumentTypes
          );

        this.otherPaperTypes = this.commonUtils.sortAlphabetically(
          noticeOfAppealPaperTypes.stateDocumentTypes,
          'displayNameText'
        );
      });
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.noticeOfAppealModalInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  setupForm() {
    this.noticeOfAppealForm = this.fb.group({
      filingParty: [this.partyRepresenting.toLowerCase()],
      docType: ['paper', Validators.required],
      paperType: ['', Validators.required],
      exhibitNumber: [null],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    if (event.target.files.length > 0) {
      this.noticeOfAppealForm
        .get('fileToUpload')
        .setValue(event.target.files[0]);
      this.noticeOfAppealForm
        .get('fileName')
        .setValue(event.target.files[0].name);
    }
  }

  clearForm() {
    this.noticeOfAppealForm.get('docType').enable();
    this.noticeOfAppealForm.get('fileName').enable();
    this.noticeOfAppealForm.reset();
    this.clearFile();
    this.setupForm();
    this.editMode = false;
    this.showWarningMessage = false;
    this.showPaperErrorMessage = false;
    this.onePaperMin = false;
    this.editIndex = null;
    this.paperTypeDisplayName = null;
    this.saving = false;
    this.addingToList = false;
    this.otherTypeDisplayName = null;
  }

  clearFile() {
    const fileElement = document.getElementById('file');
    if (fileElement) {
      (<HTMLInputElement>document.getElementById('file')).value = '';
      this.noticeOfAppealForm.get('fileToUpload').setValue(null);
      this.noticeOfAppealForm.get('fileName').setValue(null);
    }
  }

  changeDocType(docType) {
    if (docType === 'exhibit') {
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      this.noticeOfAppealForm
        .get('exhibitNumber')
        .setValue(this.minExhibitNumber, [Validators.required]);
      this.noticeOfAppealForm.get('exhibitNumber').updateValueAndValidity();
      this.noticeOfAppealForm.get('paperType').clearValidators();
      this.noticeOfAppealForm.get('paperType').updateValueAndValidity();
      // if (this.addedDocumentsList.length <= 0) {
      //   this.showWarningMessage = true;
      // }
    } else {
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = false;
    }
  }

  addToList() {
    // if (!this.paperDocumentExists()) {
    this.addingToList = true;
    this.noticeOfAppealForm.disable();
    if (
      this.noticeOfAppealForm.value.docType.toLowerCase() ===
      CONSTANTS.DOC_TYPE.PAPER
    ) {
      this.noticeOfAppealForm.get('exhibitNumber').setValue('');
    }
    this.initiatePetitionService
      .addToList(
        this.noticeOfAppealForm.value.fileToUpload,
        this.noticeOfAppealForm.value.docType,
        this.petitionIdentifier
      )
      .pipe(take(1))
      .subscribe(
        (fileAdded) => {
          // this.logger.info('Added to list', fileAdded);
          // this.selectedFilingParty = !this.selectedFilingParty
          //   ? this.noticeOfAppealForm.value.filingParty
          //   : this.selectedFilingParty;
          // this.noticeOfAppealForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          // // this.noticeOfAppealForm
          // //   .get('artifactIdentifer')
          // //   .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          // if (this.noticeOfAppealForm.value.docType === 'exhibits') {
          //   this.minExhibitNumber++;
          // } else {
          //   this.noticeOfAppealForm.get('exhibitNumber').setValue(null);
          // }
          // this.noticeOfAppealForm.get('pageCount').setValue(fileAdded.pageCount);
          // this.addedDocumentsList.push(this.noticeOfAppealForm.value);
          // this.clearForm();
          this.noticeOfAppealForm.enable();
          this.showPaperErrorMessage = !this.paperDocumentExists();
          let petitionDocument = null;
          let filingParty =
            this.noticeOfAppealForm.value.filingParty === ''
              ? 'PETITIONER'
              : this.noticeOfAppealForm.value.filingParty.toUpperCase();
          if (this.noticeOfAppealForm.value.docType.toLowerCase() === 'paper') {
            const docId = this.noticeOfAppealForm.value.paperType.documentTypeId
              ? this.noticeOfAppealForm.value.paperType.documentTypeId
              : this.noticeOfAppealForm.value.paperType.identifier;
            petitionDocument = new PetitionDocument(
              this.noticeOfAppealForm.value.docType.toUpperCase(),
              this.noticeOfAppealForm.value.documentName,
              this.noticeOfAppealForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.noticeOfAppealForm.value.availability.code,
              docId,
              this.noticeOfAppealForm.value.paperType.code,
              this.noticeOfAppealForm.value.fileToUpload.type,
              null,
              'Y',
              null
            );
          } else {
            petitionDocument = new PetitionDocument(
              this.noticeOfAppealForm.value.docType.toUpperCase(),
              this.noticeOfAppealForm.value.documentName,
              this.noticeOfAppealForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.noticeOfAppealForm.value.availability.code,
              null,
              CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
              this.noticeOfAppealForm.value.fileToUpload.type,
              this.noticeOfAppealForm.value.exhibitNumber,
              'Y',
              null
            );
          }

          const documentToAdd = new DocumentToAdd(petitionDocument);
          documentToAdd.proceedingNumberText =
            this.noticeOfAppealModalInfo.proceedingNo;
          this.noticeOfAppealForm
            .get('pageCount')
            .setValue(fileAdded.pageCount);
          this.noticeOfAppealForm
            .get('filingDate')
            .setValue(fileAdded.filingDate);
          this.noticeOfAppealForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.logger.log('Document to add:', documentToAdd);
          this.addingToList = false;
          // this.saveDocumentToCMS(documentToAdd);
          this.addedDocumentsList.push(this.noticeOfAppealForm.value);
          if (
            this.noticeOfAppealForm.value.docType.toLowerCase() ===
            CONSTANTS.DOC_TYPE.EXHIBIT
          ) {
            // this.getNextExhibitNumber();
            this.minExhibitNumber = this.commonUtils.getNextExhibitNumber({
              currentNumber: this.noticeOfAppealForm.get('exhibitNumber').value,
              listOfNumbers: this.listOfExistingExhibitNumbers,
            });
          }
          this.clearForm();
          this.showPaperErrorMessage = !this.paperDocumentExists();
          this.commonUtils.focusOnCloseModal('closeOtherDocumentsModal');
        },
        (addToListFailure) => {
          this.addingToList = false;
          this.noticeOfAppealForm.enable();
          this.commonUtils.throwError(
            `Add to list failed for Other document`,
            addToListFailure
          );
          this.commonUtils.focusOnCloseModal('closeOtherDocumentsModal');
        }
      );
    // } else {
    //   this.showPaperErrorMessage = true;
    // }
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.docType.toLowerCase() === 'paper' &&
          this.noticeOfAppealForm.value.docType === 'paper'
        ) {
          paperDocExists = true;
        }
      });
    }
    return paperDocExists;
  }

  saveDocumentToCMS(documentToAdd) {
    this.noticeOfAppealForm.disable();
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.noticeOfAppealForm.enable();
          this.logger.info('Saved document to CMS', saveSuccessful);
          this.selectedFilingParty = !this.selectedFilingParty
            ? this.noticeOfAppealForm.value.filingParty
            : this.selectedFilingParty;
          // this.noticeOfAppealForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          this.noticeOfAppealForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.noticeOfAppealForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          if (this.noticeOfAppealForm.value.docType === 'exhibit') {
            // this.minExhibitNumber++;
            this.getNextExhibitNumber();
          } else {
            this.noticeOfAppealForm.get('exhibitNumber').setValue(null);
          }
          this.noticeOfAppealForm
            .get('contentManagementId')
            .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
          this.addedDocumentsList.push(this.noticeOfAppealForm.value);
          this.clearForm();
          this.showPaperErrorMessage = !this.paperDocumentExists();
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.commonUtils.throwError(
            `Save document failed for Other document`,
            documentSaveFailed
          );
          this.addingToList = false;
          this.noticeOfAppealForm.enable();
        }
      );
  }

  submitDocuments() {
    this.saving = true;
    let petitionDocument = null;
    let documentObj = {
      partyRequestTypes: [],
      proceedingNumberText: this.noticeOfAppealModalInfo.proceedingNo,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        createUserIdentifier: window.sessionStorage.getItem('email'),
      },
      petitionDocuments: [],
      joinderOrginalIndicator: null,
    };
    this.addedDocumentsList.forEach((doc) => {
      if (doc.docType.toLowerCase() === 'paper') {
        const docId = doc.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier;
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileToUpload.name,
          doc.filingParty,
          // 'BOARD',
          doc.availability.code,
          docId,
          doc.paperType.code,
          doc.fileToUpload.type,
          null,
          'Y',
          null
        );
      } else {
        petitionDocument = new PetitionDocument(
          doc.docType.toUpperCase(),
          doc.documentName,
          doc.fileToUpload.name,
          doc.filingParty,
          // 'BOARD',
          doc.availability.code,
          null,
          CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
          doc.fileToUpload.type,
          doc.exhibitNumber,
          'Y',
          null
        );
      }
      documentObj.petitionDocuments.push(petitionDocument);
    });
    this.caseViewerService
      .submitOtherDocuments(documentObj)
      .pipe(take(1))
      .subscribe(
        (otherDocumentsResponse) => {
          this.commonUtils.showSuccess(
            'Document(s) uploaded successfully.',
            'Other document upload'
          );
          this.saving = false;
          this.logger.info(otherDocumentsResponse);
          this.close(true);
        },
        (submitFailure) => {
          this.logger.error(submitFailure.error.message);
          this.commonUtils.showError(
            submitFailure.error.message,
            'Other document upload'
          );
          this.saving = false;
        }
      );
  }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    // if (this.addedDocumentsList[e].pageCount == undefined) {
    //   this.addedDocumentsList[e].pageCount = 1;
    // }
    if (this.addedDocumentsList[e].pageCount == undefined) {
      this.addedDocumentsList[e].pageCount = null;
    }
    if (!this.addedDocumentsList[e]?.fileName) {
      this.addedDocumentsList[e].fileName =
        this.addedDocumentsList[e].documentName;
    }
    this.noticeOfAppealForm.setValue(this.addedDocumentsList[e]);
    // this.otherTypeDisplayName = this.addedDocumentsList[e].paperType.displayName
    //   ? this.addedDocumentsList[e].paperType.displayName
    //   : this.addedDocumentsList[e].paperType.descriptionText;
    this.otherTypeDisplayName = this.addedDocumentsList[e].paperType;
    if (this.addedDocumentsList[e].docType === 'exhibit') {
      this.noticeOfAppealForm.get('paperType').clearValidators();
      this.noticeOfAppealForm.get('paperType').updateValueAndValidity();
      this.noticeOfAppealForm
        .get('exhibitNumber')
        .setValidators(Validators.required);
      this.noticeOfAppealForm.get('exhibitNumber').updateValueAndValidity();
    }
    this.noticeOfAppealForm.updateValueAndValidity();
    // this.noticeOfAppealForm.get('docType').disable();
    this.noticeOfAppealForm.get('fileName').disable();
  }

  onMotionTypeSelect(e) { }

  getSpecificPaperType(e) {
    // this.noticeOfAppealForm.get('paperType').setValue(e.item);
    // this.paperTypeDisplayName = e.value;
    this.noticeOfAppealForm.get('paperType').setValue(e);
    this.paperTypeDisplayName = e.value;
  }

  update() {
    this.addingToList = true;
    // this.noticeOfAppealForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.getCurrentDateString('time'));
    // this.noticeOfAppealForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.setEST(new Date().getTime()));
    // this.noticeOfAppealForm.get('docType').enable();
    // this.noticeOfAppealForm.get('fileName').enable();
    // this.addedDocumentsList[this.editIndex] = this.noticeOfAppealForm.value;

    // this.clearForm();
    // this.caseViewerService
    //   .updateDocument(
    //     this.addedDocumentsList[this.editIndex],
    //     this.noticeOfAppealForm,
    //     this.noticeOfAppealModalInfo.proceedingNo
    //   )
    //   .pipe(take(1))
    //   .subscribe(
    //     (editSuccess) => {
    //       this.noticeOfAppealForm
    //         .get('uploadedDate')
    //         .setValue(this.commonUtils.getCurrentDateString('time'));
    //       this.addedDocumentsList[this.editIndex] =
    //         this.noticeOfAppealForm.value;
    //       this.getNextExhibitNumber();
    //       this.clearForm();
    //       this.addingToList = false;
    //     },
    //     (editFailure) => {
    //       this.addingToList = false;
    //     }
    //   );

    this.noticeOfAppealForm
      .get('uploadedDate')
      .setValue(this.commonUtils.getCurrentDateString('time'));
    this.addedDocumentsList[this.editIndex] = this.noticeOfAppealForm.value;

    this.clearForm();
    this.addingToList = false;

    if (
      this.noticeOfAppealForm.value.docType.toLowerCase() ===
      CONSTANTS.DOC_TYPE.EXHIBIT
    ) {
      this.getNextExhibitNumber();
    }
    this.commonUtils.setToastr('success', CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
  }

  saveSubmitNoticeOfAppeal() {
    this.saving = true;
    const currentTime = new Date().getTime();
    this.logger.info('Notice of appeal form:', this.noticeOfAppealForm);
    let noticeOfAppealObj = {
      proceedingNumberText: this.noticeOfAppealModalInfo.proceedingNo,
      filingParty: this.selectedFilingParty
        ? this.selectedFilingParty
        : 'Petitioner',
      motionStatusDate: null,
      submittedDate: currentTime,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        lastModifiedTimestamp: currentTime,
        createTimestamp: currentTime,
      },
      noticeOfAppealDocuments: null,
    };
    let noticeOfAppealDocuments = [];
    this.addedDocumentsList.forEach((doc) => {
      const noticeOfAppealDoc = {
        category: doc.docType.toUpperCase(),
        exhibitNumber: doc.docType === 'exhibit' ? doc.exhibitNumber : null,
        sequenceNumber: null,
        name: doc.documentName,
        fileName: doc.fileToUpload.name,
        filingParty: this.selectedFilingParty
          ? this.selectedFilingParty
          : 'Petitioner',
        availability: doc.availability.code,
        documentTypeIdentifier: doc.paperType.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier,
        documentTypeCode: doc.paperType.code,
        mimeType: doc.fileToUpload.type,
      };
      noticeOfAppealDocuments.push(noticeOfAppealDoc);
    });
    noticeOfAppealObj.noticeOfAppealDocuments = noticeOfAppealDocuments;

    this.caseViewerService
      .saveSubmitMotion(noticeOfAppealDocuments)
      .pipe(take(1))
      .subscribe(
        (saveMotionResponse) => {
          this.logger.info('Motion saved successfully', saveMotionResponse);
          // this.setSuccessToastr(motionStatus);
          this.commonUtils.showSuccess(
            'Successfully submitted notice of appeal',
            'Notice of appeal'
          );
          this.close(false);
        },
        (motionSaveError) => {
          this.logger.error('Motion failed to save', motionSaveError);
          this.commonUtils.showError(
            motionSaveError.error.message,
            'Notice of appeal'
          );
          this.saving = false;
        }
      );
  }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
  }

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.showWarningMessage = e;
  }

  close(selection) {
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  checkForm() {
    this.logger.info('Motions form: ', this.noticeOfAppealForm);
    this.logger.info('Warning message: ', this.showWarningMessage);
    this.logger.info('Saving: ', this.saving);
    this.logger.info('Adding to list: ', this.addingToList);
  }

  checkAvailability(action) {
    if (
      this.noticeOfAppealForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        action === 'add' ? this.addToList() : this.update();
      }
    });
  }

  clearSelection() {
    this.otherTypeDisplayName = null;
    this.noticeOfAppealForm.get('paperType').setValue('', Validators.required);
  }
}
