import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { Audit } from 'src/app/models/common/Audit.model';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { EditDocument } from 'src/app/models/documents/EditDocument.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../../../../initiate-petition/initiate-petition.service';
import { CaseViewerService } from '../../../case-viewer.service';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { getPartyRepresenting } from 'src/app/store/ptacts/ptacts.actions';

@Component({
  selector: 'app-motions',
  templateUrl: './motions-modal.component.html',
  styleUrls: ['./motions-modal.component.scss'],
})
export class MotionsModalComponent implements OnInit {
  motionsModalInfo: any = this.modalService.config.initialState;
  publicModalRef: BsModalRef;
  modalTitle: string = null;
  actionType: string = null;
  motionsForm: FormGroup;
  addedDocumentsList: Array<any> = new Array<any>();
  showWarningMessage: boolean = false;
  availabilityList: Array<any> = new Array<any>();
  motionTypesList: Array<any> = new Array<any>();
  motionsPaperTypesList: Array<any> = new Array<any>();
  existingMotionsList: Array<any> = new Array<any>();
  editMode: boolean = false;
  editIndex: number = null;
  petitionIdentifier: string = null;
  selectedFilingParty: any = null;
  selectedMotionType: any = null;
  originalMotionType: any = null;
  showPaperErrorMessage: boolean = false;
  onePaperMin: boolean = false;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;
  minExhibitNumber: number = null;
  selectedMotionId: number = null;
  paperTypeDisplayName: string = null;
  motionTypeDisplayName: string = '';
  saving: boolean = false;
  addingToList: boolean = false;
  motionStatus: string = null;
  partyRepresenting: string = null;
  existingMotionId: any = null;
  isPHV: boolean = false;
  phvPaymentInfo: any = null;
  paymentMade: boolean = false;
  filingPartySelected: boolean = false;
  existingMotionInfo: any = null;
  selectedOpposition: string = null;
  selectedReply: string = null;

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private logger: NGXLogger,
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService,
    private store: Store<PtactsState>
  ) { }

  ngOnInit(): void {
    this.getPartyRepresenting();
    this.getAvailabilities();
    this.getMotionTypes();
    // this.getMotionsPaperTypes();
    this.getPetitionIdentifier();
    // this.getDocuments();
    this.setupForm();
    // this.updateFormValidation();
    this.setModalTitle(this.motionsModalInfo.actionType);
    this.getFeeInfo();
    let existingMotion = window.sessionStorage.getItem('motionInfo');
    if (existingMotion) {
      existingMotion = JSON.parse(existingMotion);
      window.sessionStorage.removeItem('motionInfo');
      this.getExistingMotionDocuments(existingMotion);
    }
  }

  getPartyRepresenting() {
    this.store.dispatch(
      getPartyRepresenting({ proceedingNo: this.motionsModalInfo.proceedingNo })
    );
    setTimeout(() => {
      this.store
        .select(PtactsSelectors.getPartyRepresentingState)
        .subscribe((partyRepresenting) => {
          this.partyRepresenting = partyRepresenting;
        });
      this.getNextExhibitNumber();
      this.updateFormValidation();
    }, 500);
  }

  getNextExhibitNumber() {
    this.initiatePetitionService
      .getNextExhibitNumber(this.motionsModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        const nextNumber =
          this.partyRepresenting?.toLowerCase() === 'petitioner'
            ? nextExhibitNumber.petitionerExhibitSequence
            : nextExhibitNumber.patentownerExhibitSequence;
        this.motionsForm.get('exhibitNumber').setValue(nextNumber);
        this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  getAvailabilities() {
    this.caseViewerService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilitiesResponse) => {
        this.availabilityList = availabilitiesResponse;
        this.logger.info('AvailabilitiesList', this.availabilityList);
      });
  }

  getMotionTypes() {
    this.caseViewerService
      .getMotionTypes('motionTypes', true)
      .pipe(take(1))
      .subscribe((motionTypes) => {
        this.motionTypesList = motionTypes;
      });
  }

  getSpecificPaperType(e) {
    this.motionsForm.controls.motionType.markAsTouched();
    this.motionsForm.get('motionType').setValue(e);
    this.motionTypeDisplayName = e;
    // this.selectedMotionType = this.motionsForm.value.motionType;
    // this.originalMotionType = JSON.parse(JSON.stringify(this.selectedMotionType));
    const motionType = this.motionsForm.value.motionType;

    // this.motionsForm.controls.motionType.markAsTouched();
    // this.motionsForm.get('motionType').setValue(e.item);
    // this.motionTypeDisplayName = e.value;
    // // this.selectedMotionType = this.motionsForm.value.motionType;
    // // this.originalMotionType = JSON.parse(JSON.stringify(this.selectedMotionType));
    // const motionType = this.motionsForm.value.motionType;

    this.caseViewerService
      .getSpecificMotionPaperType(motionType.code)
      .pipe(take(1))
      .subscribe((specificPaperType) => {
        this.isPHV = false;
        if (!this.isPHV) {
          this.isPHV = specificPaperType.code === 'MOT:PHV';
        }
        this.motionsForm.get('paperType').setValue(specificPaperType);
        this.paperTypeDisplayName = specificPaperType.displayNameText;
      });
  }

  getMotionsPaperTypes(categoryType) {
    this.caseViewerService
      .getMotionPaperTypes(categoryType)
      .pipe(take(1))
      .subscribe((motionsPaperTypes) => {
        // this.motionsPaperTypesList = motionsPaperTypes;
        this.motionsForm.get('paperType').setValue(motionsPaperTypes[0]);
        this.paperTypeDisplayName = motionsPaperTypes[0].displayNameText;
      });
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.motionsModalInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  getMotionsOnCase() {
    this.existingMotionsList = [];
    this.caseViewerService
      .getMotionsOnCase(
        this.motionsModalInfo.proceedingNo,
        true,
        this.actionType,
        this.partyRepresenting
      )
      .pipe(take(1))
      .subscribe((motionsOnCase) => {
        this.logger.info('Motions on the case:', motionsOnCase);

        for (var i = 0; i < motionsOnCase.length; i++) {
          for (var j = 0; j < motionsOnCase[i].artifactContent.length; j++) {
            if (motionsOnCase[i].artifactContent[j].paperNumber) {
              let obj = {
                filedDateString: motionsOnCase[i].filedDateString,
                documentName: motionsOnCase[i].artifactContent[j].documentName,
                paperNumber: motionsOnCase[i].artifactContent[j].paperNumber,
                motionTypeNm: motionsOnCase[i].motionTypeNm
              }
              this.existingMotionsList.push(obj);
            }
          }
        }
        //this.existingMotionsList = motionsOnCase;
        console.log(this.existingMotionsList);
        // if (this.actionType === 'OPPOSITION') {
        //   motionsOnCase.forEach((motion) => {
        //     if (
        //       motion.filingParty.toLowerCase() !==
        //       this.partyRepresenting.toLocaleLowerCase()
        //     ) {
        //       this.existingMotionsList.push(motion);
        //     }
        //   });
        // } else if (this.actionType === 'REPLY') {
        //   motionsOnCase.forEach((motion) => {
        //     if (
        //       motion.filingParty.toLowerCase() ===
        //       this.partyRepresenting.toLocaleLowerCase()
        //     ) {
        //       this.existingMotionsList.push(motion);
        //     }
        //   });
        // } else {
        //   this.existingMotionsList = motionsOnCase;
        // }
      });
  }

  getExistingMotionDocuments(existingMotion) {
    this.caseViewerService
      .getExistingMotionDocuments(existingMotion)
      .pipe(take(1))
      .subscribe(
        (existingMotionInfo) => {
          this.logger.info('Existing motion info:', existingMotionInfo);
          // this.existingRehearingId = existingMotionInfo[0].rehearingId;
          this.existingMotionInfo = existingMotionInfo;
          this.existingMotionId = existingMotionInfo[0].motionId;
          this.addedDocumentsList = [];
          // this.selectedFilingParty = this.commonUtils.convertStringToTitleCase(
          //   existingMotionInfo[0].userPartyGroupType
          // );
          this.selectedFilingParty = this.commonUtils.convertStringToTitleCase(
            existingMotionInfo[0].requestorTypeName
          );
          if (this.selectedFilingParty.toLowerCase() === 'joint request') {
            this.motionsForm.get('filingParty').setValue('Joint Request');
          }
          setTimeout(() => {
            const foundMotionType = this.motionTypesList.find(
              ({ identifier }) =>
                identifier === existingMotionInfo[0].motionTypeId
            );
            this.selectedMotionType = foundMotionType;
            // this.motionTypeDisplayName = foundMotionType;

            // this.originalMotionType = JSON.parse(JSON.stringify(foundMotionType));
            // if (foundMotionType) {
            //   this.motionsForm.get('motionType').setValue(foundMotionType);
            //   // this.motionTypeDisplayName = foundMotionType.descriptionText;
            //   // this.sameType.rehearingType = foundMotionType;
            //   // this.sameType.keep = true;
            //   this.motionsForm.updateValueAndValidity();
            // }

            // const specificInfo = {
            //   item: foundMotionType,
            //   value: foundMotionType.descriptionText,
            // };
            // if (foundMotionType.identifier === 3) {
            //   this.isPHV = true;
            //   this.getFeeInfo();
            //   this.getMotionByMotionId(this.existingMotionId);
            // }
            this.caseViewerService
              .getSpecificMotionPaperType(foundMotionType.code)
              .pipe(take(1))
              .subscribe(
                (specificPaperType) => {
                  // this.paperTypeDisplayName = specificPaperType.displayNameText;
                  // this.motionsForm.get('paperType').setValue(specificPaperType);

                  // this.sameType.paperType = specificPaperType;
                  // this.sameType.keep = true;
                  if (
                    existingMotionInfo.length > 0 &&
                    existingMotionInfo[0].motionDocuments &&
                    existingMotionInfo[0].motionDocuments.length > 0
                  ) {
                    if (foundMotionType.identifier === 3) {
                      this.isPHV = true;
                      // this.getFeeInfo();
                      this.getMotionByMotionId(this.existingMotionId);
                    }
                    existingMotionInfo[0].motionDocuments.forEach(
                      (motionDocument) => {
                        const fileToUpload = {
                          type: 'application/pdf',
                        };
                        const foundAvailability = this.availabilityList.find(
                          ({ code }) =>
                            code === motionDocument.availablitySummary.code
                        );
                        const existingMotionData = {
                          filingParty: motionDocument.filingParty,
                          motionType: foundMotionType,
                          opposition: [null],
                          reply: [null],
                          docType:
                            motionDocument.artifactSummary.descriptionText,
                          paperType:
                            motionDocument.artifactSummary.descriptionText.toLowerCase() ===
                              'paper'
                              ? specificPaperType
                              : CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
                          exhibitNumber: motionDocument.exhibitNumber
                            ? motionDocument.exhibitNumber
                            : null,
                          // documentNumber: motionDocument.documentNumber
                          //   ? motionDocument.documentNumber
                          //   : null,
                          availability: foundAvailability,
                          documentName: motionDocument.name,
                          fileToUpload: fileToUpload,
                          fileName: motionDocument.fileName,
                          uploadedDate: this.commonUtils.setEST(
                            motionDocument.filingDate
                          ),
                          pageCount: motionDocument.pageCount
                            ? motionDocument.pageCount
                            : null,
                          artifactIdentifer: motionDocument.artifactIdentifer,
                          artifactSubmissionIdentifier:
                            motionDocument.artifactSubmissionIdentifier,
                          contentManagementId:
                            motionDocument.contentManagementId,
                          filingDate: motionDocument.filingDate,
                        };
                        this.addedDocumentsList.push(existingMotionData);
                      }
                    );
                    this.showWarningMessage = !this.paperDocumentExists();
                  }
                  this.disableFilingParty();
                },
                (specificTyperError) => {
                  this.paperTypeDisplayName = null;
                  this.logger.error(
                    'Could not get paper type for rehearing',
                    specificTyperError
                  );
                }
              );
          }, 200);

          // this.getSpecificPaperType(specificInfo);
        },
        (existingMotionError) => { }
      );
  }

  getMotionByMotionId(motionId) {
    this.caseViewerService
      .getMotionByMotionId(motionId)
      .pipe(take(1))
      .subscribe((motionDetails: any) => {
        // motionDetails.commentText = '2342356';
        if (motionDetails.commentText) {
          let commentText = motionDetails.commentText.split('@');
          if (commentText.length === 2) {
            this.paymentMade = true;
          }
        }
      });
  }

  setupForm() {
    this.motionsForm = this.fb.group({
      filingParty: [''],
      motionType: ['', Validators.required],
      opposition: [null],
      reply: [null],
      docType: ['paper', Validators.required],
      paperType: [''],
      exhibitNumber: [null],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      artifactSubmissionIdentifier: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
  }

  updateFormValidation() {
    switch (this.motionsModalInfo.actionType) {
      case 'MOTION':
        this.motionsForm.get('filingParty').setValidators(Validators.required);
        this.motionsForm.get('filingParty').updateValueAndValidity();
        break;
      case 'OPPOSITION':
        this.motionsForm.get('opposition').setValidators(Validators.required);
        // this.motionsForm.get('opposition').setValue('default');
        this.motionsForm.get('opposition').updateValueAndValidity();
        this.motionsForm.get('motionType').clearValidators();
        this.motionsForm.get('motionType').updateValueAndValidity();
        this.getMotionsOnCase();
        break;
      case 'REPLY':
        this.motionsForm.get('reply').setValidators(Validators.required);
        // this.motionsForm.get('reply').setValue('default');
        this.motionsForm.get('reply').updateValueAndValidity();
        this.motionsForm.get('motionType').clearValidators();
        this.motionsForm.get('motionType').updateValueAndValidity();
        this.getMotionsOnCase();
        break;
      default:
        break;
    }
  }

  setModalTitle(actionType) {
    this.actionType = actionType;
    this.modalTitle = CONSTANTS.MOTIONS[actionType];
    if (actionType !== 'MOTION') {
      this.getMotionsPaperTypes(actionType);
    }
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    if (event.target.files.length > 0) {
      this.motionsForm.get('fileToUpload').setValue(event.target.files[0]);
      this.motionsForm.get('fileName').setValue(event.target.files[0].name);
    }
  }

  clearForm() {
    let tempOpposition = null;
    let tempReply = null;
    const tempFilingParty = this.motionsForm.get('filingParty').value;
    if (this.motionsModalInfo.actionType === 'OPPOSITION') {
      tempOpposition = this.motionsForm.get('opposition').value;
      if (this.addedDocumentsList.length > 0 && tempOpposition) {
        this.selectedOpposition = `${tempOpposition.filedDateString} -- ${tempOpposition.motionTypeNm}`;
      } else {
        this.selectedOpposition = null;
      }
    } else if (this.motionsModalInfo.actionType === 'REPLY') {
      tempReply = this.motionsForm.get('reply').value;
      if (this.addedDocumentsList.length > 0 && tempReply) {
        this.selectedReply = `${tempReply.filedDateString} -- ${tempReply.motionTypeNm}`;
      } else {
        this.selectedReply = null;
      }
    }
    this.motionsForm.reset();
    this.clearFile();
    this.setupForm();
    this.setModalTitle(this.actionType);
    this.updateFormValidation();
    this.editMode = false;
    this.showWarningMessage = false;
    this.showPaperErrorMessage = false;
    this.onePaperMin = false;
    this.editIndex = null;
    this.paperTypeDisplayName = null;
    this.motionTypeDisplayName = null;
    this.motionStatus = null;
    this.saving = false;
    this.addingToList = false;
    this.selectedMotionType = this.originalMotionType;
    if (this.motionsModalInfo.actionType === 'OPPOSITION') {
      if (this.addedDocumentsList.length > 0) {
        this.motionsForm.get('opposition').setValue(tempOpposition);
        this.motionsForm.get('opposition').clearValidators();
        this.motionsForm.controls.opposition.updateValueAndValidity();
      }
    } else if (this.motionsModalInfo.actionType === 'REPLY') {
      if (this.addedDocumentsList.length > 0) {
        this.motionsForm.get('reply').clearValidators();
        this.motionsForm.get('reply').setValue(tempReply);
        this.motionsForm.controls.reply.updateValueAndValidity();
      }
    }
    if (this.filingPartySelected) {
      this.motionsForm
        .get('filingParty')
        .setValue(tempFilingParty, Validators.required);
      this.filingPartySelected = true;
      this.motionsForm.controls.filingParty.updateValueAndValidity();
    } else {
      this.filingPartySelected = false;
    }
    if (this.addedDocumentsList.length === 0 && this.isPHV) {
      this.isPHV = false;
      this.paymentMade = false;
    } else {
      this.isPHV = false;
      this.addedDocumentsList.forEach((motionDoc) => {
        if (
          motionDoc.docType.toLowerCase() === 'paper' &&
          motionDoc.paperType.identifier === 215 &&
          motionDoc.paperType.code === 'MOT:PHV'
        ) {
          this.isPHV = true;
        }
      });
      if (this.isPHV) {
        this.getMotionByMotionId(this.existingMotionId);
      }
    }
    // if (this.motionsModalInfo.actionType === 'OPPOSITION') {
    //   this.motionsForm.get('opposition').setValue(tempOpposition);
    //   this.motionsForm.controls.opposition.updateValueAndValidity();
    // } else if (this.motionsModalInfo.actionType === 'REPLY') {
    //   this.motionsForm.get('reply').setValue(tempReply);
    //   this.motionsForm.controls.reply.updateValueAndValidity();
    // }
  }

  clearFile() {
    const fileEl = <HTMLInputElement>document.getElementById('file');
    if (fileEl) {
      fileEl.value = '';
    }
    this.motionsForm.get('fileToUpload').setValue(null);
    this.motionsForm.get('fileName').setValue(null);
  }

  changeDocType(docType) {
    // if (docType === 'exhibit') {
    if (docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      // this.motionsForm.get('motionType').setValue('');
      // this.motionTypeDisplayName = null;
      this.motionsForm
        .get('exhibitNumber')
        .setValue(this.minExhibitNumber, [Validators.required]);
      this.motionsForm.get('exhibitNumber').updateValueAndValidity();
      this.motionsForm.get('paperType').clearValidators();
      this.motionsForm.get('paperType').updateValueAndValidity();
      this.motionsForm.get('motionType').clearValidators();
      this.motionsForm.get('motionType').updateValueAndValidity();
      if (this.addedDocumentsList.length <= 0) {
        this.showWarningMessage = true;
      }
    } else {
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = false;
      // this.motionsForm.get('paperType').setValue('', Validators.required);
      // this.motionsForm.get('paperType').updateValueAndValidity();
      // this.motionsForm.get('motionType').setValue('', Validators.required);
      // this.motionsForm.get('motionType').updateValueAndValidity();
    }
  }

  addToList() {
    if (!this.paperDocumentExists()) {
      this.addingToList = true;
      this.motionsForm.disable();
      this.initiatePetitionService
        .addToList(
          this.motionsForm.value.fileToUpload,
          this.motionsForm.value.docType,
          this.petitionIdentifier
        )
        .pipe(take(1))
        .subscribe(
          (fileAdded) => {
            this.motionsForm.enable();
            // let fp = this.motionsForm.value.filingParty;
            // if (fp === '') {
            //   fp = this.commonUtils.convertToTitleCase(
            //     this.partyRepresenting.toLowerCase()
            //   );
            // }
            let petitionDocument = null;
            // let filingParty = fp;
            if (this.motionsForm.value.docType.toLowerCase() === 'paper') {
              const docId = this.motionsForm.value.paperType.documentTypeId
                ? this.motionsForm.value.paperType.documentTypeId
                : this.motionsForm.value.paperType.identifier;
              petitionDocument = new PetitionDocument(
                this.motionsForm.value.docType.toUpperCase(),
                this.motionsForm.value.documentName,
                this.motionsForm.value.fileName,
                this.commonUtils.convertToTitleCase(this.partyRepresenting),
                // 'BOARD',
                this.motionsForm.value.availability.code,
                docId,
                this.motionsForm.value.paperType.code,
                this.motionsForm.value.fileToUpload.type,
                null,
                'Y',
                null
              );
            } else {
              petitionDocument = new PetitionDocument(
                // this.motionsForm.value.docType.toUpperCase(),
                // 'EXHIBIT',
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.motionsForm.value.documentName,
                this.motionsForm.value.fileName,
                this.commonUtils.convertToTitleCase(this.partyRepresenting),
                // 'BOARD',
                this.motionsForm.value.availability.code,
                null,
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.motionsForm.value.fileToUpload.type,
                this.motionsForm.value.exhibitNumber,
                'Y',
                null
              );
            }

            const documentToAdd = new DocumentToAdd(petitionDocument);
            documentToAdd.proceedingNumberText =
              this.motionsModalInfo.proceedingNo;
            this.motionsForm.get('pageCount').setValue(fileAdded.pageCount);
            this.motionsForm.get('filingDate').setValue(fileAdded.filingDate);
            this.saveDocumentToCMS(documentToAdd);
          },
          (addToListFailure) => {
            this.commonUtils.focusOnCloseModal('closeMotionsModal');
            this.addingToList = false;
            this.motionsForm.enable();
            this.commonUtils.throwError(
              `Add to list failed for ${this.actionType}`,
              addToListFailure
            );
          }
        );
    } else {
      this.showPaperErrorMessage = true;
      this.addingToList = false;
      this.motionsForm.enable();
      this.commonUtils.focusOnCloseModal('closeMotionsModal');
    }
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.docType.toLowerCase() === 'paper' &&
          this.motionsForm.value.docType === 'paper'
        ) {
          paperDocExists = true;
        }
      });
    }
    return paperDocExists;
  }

  saveDocumentToCMS(documentToAdd) {
    this.motionsForm.disable();
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.motionsForm.enable();
          this.logger.info('Saved document to CMS', saveSuccessful);
          // this.selectedFilingParty = !this.selectedFilingParty
          //   ? this.motionsForm.value.filingParty
          //   : this.selectedFilingParty;
          this.selectedFilingParty = this.partyRepresenting;
          // this.selectedMotionType = !this.selectedMotionType
          //   ? this.motionsForm.value.motionType
          //   : this.selectedMotionType;
          // this.getDocuments();
          // this.motionsForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          this.motionsForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.motionsForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          this.motionsForm
            .get('artifactSubmissionIdentifier')
            .setValue(
              saveSuccessful.petitionDocuments[0].artifactSubmissionIdentifier
            );
          // if (this.motionsForm.value.docType === 'exhibit') {
          if (this.motionsForm.value.docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
            // this.minExhibitNumber++;
            this.getNextExhibitNumber();
          } else {
            this.motionsForm.get('exhibitNumber').setValue(null);
            // this.selectedMotionType = !this.selectedMotionType
            //   ? this.motionsForm.value.motionType
            //   : this.selectedMotionType;
          }
          this.motionsForm
            .get('contentManagementId')
            .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
          this.addedDocumentsList.push(this.motionsForm.value);
          this.selectedMotionType = this.motionsForm.value.motionType;
          this.originalMotionType = this.selectedMotionType;
          this.clearForm();
          // this.showPaperErrorMessage = !this.paperDocumentExists();
          this.showWarningMessage = !this.paperDocumentExists();
          if (this.isPHV) {
            this.getFeeInfo();
          }
          console.log('Action type: ', this.actionType);
          this.disableFilingParty();
          this.commonUtils.focusOnCloseModal('closeMotionsModal');
        },
        (documentSaveFailed) => {
          this.commonUtils.throwError(
            `Save document failed for ${this.actionType}`,
            documentSaveFailed
          );
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.addingToList = false;
          this.motionsForm.enable();
          this.commonUtils.focusOnCloseModal('closeMotionsModal');
        }
      );
  }

  getDocuments() {
    this.initiatePetitionService
      .getDocuments(this.motionsModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((petitionDocumentList) => {
        this.logger.info('Petition documents list', petitionDocumentList);
        this.addedDocumentsList = petitionDocumentList;
      });
  }

  getFeeInfo() {
    this.caseViewerService
      .getPaymentInfoByProceedingNo(this.motionsModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((paymentInfo) => {
        this.phvPaymentInfo = paymentInfo;
      });
  }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    // this.partyRepresenting = this.addedDocumentsList[e].filingParty;
    if (this.addedDocumentsList[e].pageCount == undefined) {
      this.addedDocumentsList[e].pageCount = null;
    }
    this.motionsForm.setValue(this.addedDocumentsList[e]);
    let tempFilingParty = null;
    if (this.addedDocumentsList[e].filingParty.toLowerCase() === 'petitioner') {
      tempFilingParty = 'Petitioner';
    } else if (
      this.addedDocumentsList[e].filingParty.toLowerCase() === 'patent owner'
    ) {
      tempFilingParty = 'Patent Owner';
    } else if (
      this.addedDocumentsList[e].filingParty.toLowerCase() === 'joint request'
    ) {
      tempFilingParty = 'Joint Request';
    }
    this.motionsForm
      .get('filingParty')
      .setValue(tempFilingParty, Validators.required);
    this.motionsForm.controls.filingParty.updateValueAndValidity();
    this.motionsForm
      .get('docType')
      .setValue(this.motionsForm.get('docType').value.toLowerCase());
    // const tempDocType =
    //   this.addedDocumentsList[e].docType.toLowerCase() === 'paper'
    //     ? 'paper'
    //     : 'exhibit';
    // this.motionsForm.get('docType').setValue(tempDocType);
    this.paperTypeDisplayName = this.addedDocumentsList[e].paperType.displayName
      ? this.addedDocumentsList[e].paperType.displayName
      : this.addedDocumentsList[e].paperType.descriptionText;

    // this.motionTypeDisplayName = this.addedDocumentsList[e].motionType
    //   .displayName
    //   ? this.addedDocumentsList[e].motionType.displayName
    //   : this.addedDocumentsList[e].motionType.descriptionText;
    this.motionTypeDisplayName = this.addedDocumentsList[e].motionType;
    // if (this.motionsForm.get('docType').value.toLowerCase() === 'exhibit') {
    if (
      this.motionsForm.get('docType').value.toLowerCase() ===
      CONSTANTS.DOC_TYPE.EXHIBIT
    ) {
      this.motionsForm.get('motionType').clearValidators();
    }
    this.motionsForm.controls.motionType.updateValueAndValidity();
    this.motionsForm.updateValueAndValidity();
  }

  onMotionTypeSelect(e) { }

  update() {
    this.addingToList = true;
    // const tempDoc = this.addedDocumentsList[this.editIndex];
    // let tempCat = tempDoc.docType.toUpperCase();
    // // if (tempCat === 'EXHIBIT') {
    // //   tempCat = 'EXHIBIT';
    // // }
    // let updateDocObj = {
    //   artifactIdentifer: tempDoc.artifactIdentifer,
    //   audit: {
    //     lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
    //     createUserIdentifier: window.sessionStorage.getItem('email'),
    //   },
    //   availability: this.motionsForm.value.availability.code,
    //   category: tempCat,
    //   contentManagementId: tempDoc.contentManagementId,
    //   documentTypeIdentifier: tempDoc.paperType.identifier,
    //   fileSize: tempDoc.fileToUpload.size,
    //   filingDate: tempDoc.filingDate,
    //   filingParty: tempDoc.filingParty.toUpperCase(),
    //   name: this.motionsForm.value.documentName,
    //   proceedingNumberText: this.motionsModalInfo.proceedingNo,
    //   ptabDefaultRefreshTime: null,
    //   ptabReadOnlyUser: false,
    //   textExtractionIndicator: null,
    //   exhibitNumber: this.motionsForm.value.exhibitNumber
    //     ? this.motionsForm.value.exhibitNumber
    //     : null,
    // };
    //  if (tempDoc.exhibitNumber) {
    //   updateDocObj.exhibitNumber = tempDoc.exhibitNumber;
    //  }

    // const docToEdit = new EditDocument(updateDocObj);

    this.addedDocumentsList[this.editIndex].filingParty =
      this.commonUtils.convertToTitleCase(this.partyRepresenting);
    this.caseViewerService
      .updateDocument(
        this.addedDocumentsList[this.editIndex],
        this.motionsForm,
        this.motionsModalInfo.proceedingNo
      )
      .pipe(take(1))
      .subscribe(
        (editSuccess) => {
          this.motionsForm
            .get('uploadedDate')
            .setValue(this.commonUtils.getCurrentDateString('time'));
          if (this.motionsForm.get('filingParty').value == null) {
            this.motionsForm.get('filingParty').setValue('');
          }
          this.addedDocumentsList[this.editIndex] = this.motionsForm.value;
          this.getNextExhibitNumber();
          this.clearForm();
          this.addingToList = false;
          this.commonUtils.setToastr('success', CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
        },
        (editFailure) => {
          this.addingToList = false;
          this.commonUtils.throwError(
            `Edit document failed for ${this.actionType}`,
            editFailure
          );
          this.commonUtils.setToastr('error', CONSTANTS.TOAST_MSGS.UPDATE_DOC.ERROR)
        }
      );

    // this.motionsForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.setEST(new Date().getTime()));
    // this.addedDocumentsList[this.editIndex] = this.motionsForm.value;
    // if (this.isPHV) {
    //   this.getFeeInfo();
    // }
    // this.clearForm();
  }

  saveSubmitMotion(motionStatus) {
    let motionFilingParty = null;
    // if (
    //   this.motionsModalInfo.actionType === 'OPPOSITION' ||
    //   this.motionsModalInfo.actionType === 'REPLY'
    // ) {
    //   filingParty = this.commonUtils.convertToTitleCase(
    //     this.partyRepresenting.toLowerCase()
    //   );
    // } else {
    //   filingParty = this.selectedFilingParty;
    //   filingParty = this.motionsForm.value.filingParty;
    // }
    if (
      this.motionsModalInfo.actionType === 'OPPOSITION' ||
      this.motionsModalInfo.actionType === 'REPLY'
    ) {
      motionFilingParty = this.commonUtils.convertToTitleCase(
        this.partyRepresenting.toLowerCase()
      );
    } else {
      motionFilingParty = this.selectedFilingParty;
      motionFilingParty = this.motionsForm.value.filingParty;
    }
    this.motionStatus = motionStatus;
    this.saving = true;
    const currentTime = new Date(
      this.commonUtils.setEST(new Date().getTime())
    ).getTime();
    // let motionType = this.selectedMotionType?.code;
    // if (!motionType) {
    //   motionType = this.getCaseMotionType();
    // }
    // let motionType = this.getCaseMotionType();
    // if (!motionType) {
    //   motionType =
    //     this.motionsModalInfo.actionType === 'OPPOSITION'
    //       ? 'Opposition'
    //       : 'Reply';
    // }

    let motionType = null;
    if (
      this.motionsModalInfo.actionType === 'OPPOSITION' ||
      this.motionsModalInfo.actionType === 'REPLY'
    ) {
      motionType =
        this.motionsModalInfo.actionType === 'OPPOSITION'
          ? 'Opposition'
          : 'Reply';
    } else {
      motionType = this.getCaseMotionType();
    }

    this.logger.info('Motions form:', this.motionsForm);
    let motStat = motionStatus;
    if (motStat === 'SUBMITPAY') {
      motStat = 'INITIATED';
    }
    let motionObj = {
      motionType: motionType,
      motionStatus: motStat,
      proceedingNumberText: this.motionsModalInfo.proceedingNo,
      // filingParty: this.selectedFilingParty
      //   ? this.selectedFilingParty
      //   : 'Petitioner',
      // filingParty: this.commonUtils.convertToTitleCase(
      //   this.motionsForm.get('filingParty').value
      // ),
      // motionFilingParty: this.commonUtils.convertToTitleCase(
      //   this.motionsForm.get('filingParty').value
      // ),
      motionFilingParty: this.motionsForm.get('filingParty').value
        ? this.commonUtils.convertToTitleCase(
          this.motionsForm.get('filingParty').value
        )
        : this.commonUtils.convertToTitleCase(motionFilingParty),
      motionStatusDate: null,
      submittedDate: currentTime,
      parentMotionId: this.selectedMotionId,
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        lastModifiedTimestamp: currentTime,
        createTimestamp: currentTime,
      },
      motionDocuments: null,
    };
    let motionsDocuments = [];
    this.addedDocumentsList.forEach((doc) => {
      const motionDoc = {
        artifactIdentifer: doc.artifactIdentifer,
        artifactSubmissionIdentifier: doc.artifactSubmissionIdentifier,
        category: doc.docType.toUpperCase(),
        // exhibitNumber: doc.docType === 'exhibit' ? doc.exhibitNumber : null,
        exhibitNumber:
          doc.docType.toLowerCase() === CONSTANTS.DOC_TYPE.EXHIBIT
            ? doc.exhibitNumber
            : null,
        sequenceNumber: null,
        name: doc.documentName,
        fileName: doc.fileName,
        // filingParty: this.selectedFilingParty
        //   ? this.selectedFilingParty
        //   : 'Petitioner',
        filingParty: this.commonUtils.convertToTitleCase(
          this.partyRepresenting
        ),
        availability: doc.availability.code,
        documentTypeIdentifier: doc.paperType.documentTypeId
          ? doc.paperType.documentTypeId
          : doc.paperType.identifier,
        documentTypeCode:
          doc.docType.toLowerCase() === CONSTANTS.DOC_TYPE.PAPER
            ? doc.paperType.code
            : CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
        mimeType: doc.fileToUpload.type,
      };
      motionsDocuments.push(motionDoc);
    });
    motionObj.motionDocuments = motionsDocuments;

    if (this.existingMotionId) {
      this.caseViewerService
        .updateMotion(motionObj, this.existingMotionId)
        .pipe(take(1))
        .subscribe(
          (updateMotionResponse) => {
            this.logger.info(
              `Motion was successfully updated`,
              updateMotionResponse
            );
            this.commonUtils.showSuccess(
              `Successfully updated motion`,
              'Motion'
            );
            if (this.isPHV && motionStatus === 'SUBMITPAY') {
              this.redirectToFNPG(this.existingMotionId);
            } else {
              this.close(false);
            }
          },
          (updateMotionError) => {
            // this.logger.error(`Motion was NOT updated`);
            // this.commonUtils.showError(`Motion failed to update`, `Motion`);
            this.saving = false;
            this.commonUtils.throwError(
              `Update failed for ${this.actionType}`,
              updateMotionError
            );
          }
        );
    } else {
      this.caseViewerService
        .saveSubmitMotion(motionObj)
        .pipe(take(1))
        .subscribe(
          (saveMotionResponse) => {
            this.logger.info('Motion saved successfully', saveMotionResponse);
            this.setSuccessToastr(motionStatus);
            if (this.isPHV && motionStatus === 'SUBMITPAY') {
              this.redirectToFNPG(saveMotionResponse.motionId);
            } else {
              this.close(false);
            }
          },
          (motionSaveError) => {
            // this.logger.error('Motion failed to save', motionSaveError);
            // this.commonUtils.showError(
            //   motionSaveError.error.message,
            //   this.modalTitle
            // );
            this.saving = false;
            this.commonUtils.throwError(
              `Save failed for ${this.actionType}`,
              motionSaveError
            );
          }
        );
    }
  }

  setSuccessToastr(motionStatus) {
    let action = null;
    const whatFiled =
      this.actionType === 'OPPOSITION'
        ? `filed an ${this.actionType.toLowerCase()}`
        : `filed a ${this.actionType.toLowerCase()}`;
    if (motionStatus === 'INITIATED' || motionStatus === 'SUBMITPAY') {
      action = 'saved documents';
    } else {
      action = whatFiled;
    }
    // const action = motionStatus === 'INITIATED' ? 'saved documents' : whatFiled;
    // const title =
    //   this.actionType === 'OPPOSITION'
    //     ? `File an ${this.actionType.toLowerCase()}`
    //     : `File a ${this.actionType.toLowerCase()}`;
    this.commonUtils.showSuccess(`Successfully ${action}`, null);
  }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
    this.isPHV = false;
    this.disableFilingParty();
    if (this.addedDocumentsList.length <= 0) {
      this.selectedOpposition = null;
      this.selectedReply = null;
    }
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.paperType.identifier === 215 &&
          doc.paperType.code === 'MOT:PHV'
        ) {
          this.isPHV = true;
        }
      });
    }
  }

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.showWarningMessage = e;
    this.isPHV = false;
    if (!e) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.paperType.identifier === 215 &&
          doc.paperType.code === 'MOT:PHV'
        ) {
          this.isPHV = true;
        }
      });
    } else if (this.motionsModalInfo.actionType === 'OPPOSITION') {
      this.selectedOpposition = null;
    } else if (this.motionsModalInfo.actionType === 'REPLY') {
      this.selectedReply = null;
    }
    this.disableFilingParty();
  }

  close(selection) {
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  setMotionId(idType) {
    this.logger.info('Motions form: ', this.motionsForm);
    this.selectedMotionId = this.motionsForm.value[idType].motionId;
  }

  checkForm() {
    this.logger.info('Motions form: ', this.motionsForm);
    this.logger.info('Warning message: ', this.showWarningMessage);
    this.logger.info('Saving: ', this.saving);
    this.logger.info('Adding to list: ', this.addingToList);
  }

  checkAvailability(action) {
    if (
      this.motionsForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        action === 'add' ? this.addToList() : this.update();
      }
    });
  }

  deleteMotion() {
    if (this.existingMotionId) {
      this.caseViewerService
        .deleteMotion(this.existingMotionId)
        .pipe(take(1))
        .subscribe(
          (deleteMotionSuccess) => {
            this.logger.info('Delete motion success', deleteMotionSuccess);

            this.commonUtils.showSuccess(
              'Successfully deleted motion request',
              'Delete motion request'
            );
            this.close(true);
          },
          (deleteMotionFailure) => {
            this.logger.error('Failed to delete motion', deleteMotionFailure);
            this.commonUtils.showError(
              'Failed to delete motion request',
              'Delete motion request'
            );
          }
        );
    } else {
      if (this.addedDocumentsList.length > 0) {
        this.addedDocumentsList.forEach((document) => {
          this.deleteDocument(document.artifactIdentifer);
        });
      } else {
        this.close(true);
      }
    }
  }

  deleteDocument(artifactID) {
    this.initiatePetitionService
      .deleteDocument(artifactID)
      .pipe(take(1))
      .subscribe(
        (deleteDocumentSuccess) => {
          this.logger.info(
            'Document deleted successfully',
            deleteDocumentSuccess
          );
          this.close(true);
        },
        (deleteDocumentFailure) => {
          this.logger.error('Failed to delete document', deleteDocumentFailure);
          this.commonUtils.showError(
            deleteDocumentFailure.error.message,
            'Delete document'
          );
        }
      );
  }

  redirectToFNPG(motionId) {
    const currentTime = new Date().getTime();
    let motionsPhv = {
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        lastModifiedTimestamp: currentTime,
        createTimestamp: currentTime,
      },
      quantity: 1,
      motionId: motionId,
    };
    this.caseViewerService
      .redirectToFPNGForMotions(this.petitionIdentifier, motionsPhv)
      .pipe(take(1))
      .subscribe(
        (successUpload) => {
          window.sessionStorage.setItem('paymentType', motionId);
          this.pay(successUpload);
        },
        (failureUpload) => {
          this.logger.error('Submit petition failed: ', failureUpload);
          this.commonUtils.showError(
            failureUpload.error.message,
            'Action cannot be performed'
          );
        }
      );
  }

  pay(data) {
    this.close(false);
    var form = document.createElement('form');
    form.target = '_self';
    form.method = 'POST';
    form.action = data.paymentURL;
    // var params = data.paymentForm;

    // for (var i in params) {
    //   if (params.hasOwnProperty(i)) {
    //     var input = document.createElement('input');
    //     input.type = 'hidden';
    //     input.name = i;
    //     input.value = params[i];
    //     form.appendChild(input);
    //   }
    // }

    document.body.appendChild(form);
    form.submit();
    window.open('', '_self');
  }

  disableFilingParty() {
    this.filingPartySelected = false;
    this.addedDocumentsList.forEach((document) => {
      if (
        document.docType.toLowerCase() === CONSTANTS.DOC_TYPE.PAPER &&
        this.actionType.toLowerCase() === 'motion'
      ) {
        // if (this.addedDocumentsList[e].filingParty.toLowerCase() === 'petitioner') {
        //   tempFilingParty = 'Petitioner';
        // } else if (
        //   this.addedDocumentsList[e].filingParty.toLowerCase() === 'patent owner'
        // ) {
        //   tempFilingParty = 'Patent Owner';
        // }

        const filingParty = document.filingParty;
        let words = filingParty.split(' ');

        for (let i = 0; i < words.length; i++) {
          words[i] = words[i][0].toUpperCase() + words[i].substr(1);
        }

        const titleCaseFilingParty = words.join(' ');

        const isJointRequest =
          this.motionsForm.get('filingParty').value.toLowerCase() ===
          'joint request';
        if (!isJointRequest) {
          this.motionsForm
            .get('filingParty')
            .setValue(titleCaseFilingParty, Validators.required);
        }
        this.filingPartySelected = true;
        this.motionsForm.controls.filingParty.updateValueAndValidity();
      }
    });
  }

  onBlurCheck(e) {
    this.motionsForm.controls.motionType.markAsTouched();

    if (!e) {
      this.motionsForm.get('motionType').setValue('', Validators.required);
      this.motionTypeDisplayName = null;
      this.motionsForm.get('paperType').setValue('', Validators.required);
      this.paperTypeDisplayName = null;
    }
  }

  getCaseMotionType() {
    // if (this.existingMotionInfo && this.existingMotionInfo.length > 0) {
    //   const foundMotionType = this.motionTypesList.find(
    //     ({ identifier }) =>
    //       identifier === this.existingMotionInfo[0].motionTypeId
    //   );
    //   return foundMotionType.code;
    // }
    if (this.addedDocumentsList && this.addedDocumentsList.length > 0) {
      let foundMotionType = null;
      this.addedDocumentsList.forEach((addedDoc) => {
        if (!foundMotionType) {
          if (addedDoc.docType.toLowerCase() === 'paper') {
            foundMotionType = this.motionTypesList.find(
              (identifier) =>
                identifier.identifier === addedDoc?.motionType?.identifier
            );
          } else if (
            addedDoc.docType.toLowerCase() === 'exhibit' &&
            addedDoc?.motionType?.identifier
          ) {
            foundMotionType = this.motionTypesList.find(
              (identifier) =>
                identifier.identifier === addedDoc?.motionType?.identifier
            );
          } else if (
            addedDoc.docType.toLowerCase() === 'exhibit' &&
            !addedDoc?.motionType?.identifier
          ) {
            foundMotionType = this.motionTypesList.find(
              (identifier) => identifier.code === 'Motion'
            );
          }
        }
      });
      // const foundMotionType = this.motionTypesList.find(
      //   ({ identifier }) =>
      //     identifier === this.existingMotionInfo[0].motionTypeId
      // );
      if (foundMotionType && foundMotionType.code) {
        return foundMotionType.code;
      } else {
        return null;
      }
    }
  }

  clearSelection() {
    this.motionTypeDisplayName = '';
  }
}
