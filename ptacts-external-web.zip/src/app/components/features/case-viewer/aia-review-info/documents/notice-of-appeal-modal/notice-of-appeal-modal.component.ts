import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { EditDocument } from 'src/app/models/documents/EditDocument.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../../../../initiate-petition/initiate-petition.service';
import { CaseViewerService } from '../../../case-viewer.service';

@Component({
  selector: 'app-notice-of-appeal-modal',
  templateUrl: './notice-of-appeal-modal.component.html',
  styleUrls: ['./notice-of-appeal-modal.component.scss'],
})
export class NoticeOfAppealModalComponent implements OnInit {
  noticeOfAppealModalInfo: any = this.modalService.config.initialState;
  publicModalRef: BsModalRef;
  // modalTitle: string = null;
  // actionType: string = null;
  noticeOfAppealForm: FormGroup;
  addedDocumentsList: Array<any> = new Array<any>();
  showWarningMessage: boolean = false;
  availabilityList: Array<any> = new Array<any>();
  // motionTypesList: Array<any> = new Array<any>();
  // noticeOfAppealPaperTypesList: Array<any> = new Array<any>();
  // existingMotionsList: Array<any> = new Array<any>();
  editMode: boolean = false;
  editIndex: number = null;
  petitionIdentifier: string = null;
  selectedFilingParty: any = null;
  // selectedMotionType: any = null;
  showPaperErrorMessage: boolean = false;
  onePaperMin: boolean = false;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;
  minExhibitNumber: number = null;
  // selectedMotionId: number = null;
  paperTypeDisplayName: string = null;
  // motionTypeDisplayName: string = null;
  saving: boolean = false;
  addingToList: boolean = false;
  // motionStatus: string = null;
  partyRepresenting: string = null;
  appealFiledDate: any = null;
  noticeOfAppealPaperType: any = null;

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private logger: NGXLogger,
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService
  ) { }

  ngOnInit(): void {
    this.partyRepresenting = window.sessionStorage.getItem('partyRepresenting');
    this.setupForm();
    this.getAvailabilities();
    // this.getMotionTypes();
    this.getNoticeOfAppealPaperTypes();
    this.getPetitionIdentifier();
    // this.getDocuments();
    // this.updateFormValidation();
    // this.setModalTitle(this.motionsModalInfo.actionType);
    this.getNextExhibitNumber();
  }

  getNextExhibitNumber() {
    this.initiatePetitionService
      .getNextExhibitNumber(this.noticeOfAppealModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((nextExhibitNumber: any) => {
        this.logger.info('Exhibit number info:', nextExhibitNumber);
        const nextNumber =
          this.partyRepresenting.toLowerCase() === 'petitioner'
            ? nextExhibitNumber.petitionerExhibitSequence
            : nextExhibitNumber.patentownerExhibitSequence;
        this.noticeOfAppealForm.get('exhibitNumber').setValue(nextNumber);
        this.minExhibitNumber = parseInt(nextNumber);
      });
  }

  getAvailabilities() {
    this.caseViewerService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilitiesResponse) => {
        this.availabilityList = availabilitiesResponse;
        this.logger.info('AvailabilitiesList', this.availabilityList);
      });
  }

  // getMotionTypes() {
  //   this.caseViewerService
  //     .getMotionTypes('motionTypes', true)
  //     .pipe(take(1))
  //     .subscribe((motionTypes) => {
  //       this.motionTypesList = motionTypes;
  //     });
  // }

  // getSpecificPaperType(e) {
  //   this.noticeOfAppealForm.get('motionType').setValue(e.item);
  //   this.motionTypeDisplayName = e.value;
  //   const motionType = this.noticeOfAppealForm.value.motionType;

  //   this.caseViewerService
  //     .getSpecificMotionPaperType(motionType.code)
  //     .pipe(take(1))
  //     .subscribe((specificPaperType) => {
  //
  //       this.noticeOfAppealForm.get('paperType').setValue(specificPaperType);
  //       this.paperTypeDisplayName = specificPaperType.displayNameText;
  //     });
  // }

  getNoticeOfAppealPaperTypes() {
    this.caseViewerService
      .getNoticeOfAppealPaperTypes(CONSTANTS.NOTICE_OF_APPEAL_PAPER_TYPE_ID)
      .pipe(take(1))
      .subscribe((noticeOfAppealPaperTypes) => {
        // this.noticeOfAppealPaperTypesList = noticeOfAppealPaperTypes;
        this.noticeOfAppealPaperType = noticeOfAppealPaperTypes[0];
        this.noticeOfAppealForm
          .get('paperType')
          .setValue(this.noticeOfAppealPaperType);
        this.paperTypeDisplayName =
          this.noticeOfAppealPaperType.displayNameText;
      });
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.noticeOfAppealModalInfo.proceedingNo)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  // getMotionsOnCase() {
  //   this.existingMotionsList = [];
  //   this.caseViewerService
  //     .getMotionsOnCase(
  //       this.motionsModalInfo.proceedingNo,
  //       true,
  //       this.actionType,
  //       this.partyRepresenting
  //     )
  //     .pipe(take(1))
  //     .subscribe((motionsOnCase) => {
  //       this.logger.info('Motions on the case:', motionsOnCase);
  //       this.existingMotionsList = motionsOnCase;
  //       // if (this.actionType === 'OPPOSITION') {
  //       //   motionsOnCase.forEach((motion) => {
  //       //     if (
  //       //       motion.filingParty.toLowerCase() !==
  //       //       this.partyRepresenting.toLocaleLowerCase()
  //       //     ) {
  //       //       this.existingMotionsList.push(motion);
  //       //     }
  //       //   });
  //       // } else if (this.actionType === 'REPLY') {
  //       //   motionsOnCase.forEach((motion) => {
  //       //     if (
  //       //       motion.filingParty.toLowerCase() ===
  //       //       this.partyRepresenting.toLocaleLowerCase()
  //       //     ) {
  //       //       this.existingMotionsList.push(motion);
  //       //     }
  //       //   });
  //       // } else {
  //       //   this.existingMotionsList = motionsOnCase;
  //       // }
  //     });
  // }

  setupForm() {
    this.noticeOfAppealForm = this.fb.group({
      filingParty: [this.partyRepresenting.toLowerCase()],
      docType: ['paper', Validators.required],
      paperType: [this.noticeOfAppealPaperType],
      exhibitNumber: [null],
      availability: ['', Validators.required],
      documentName: [null, Validators.required],
      fileToUpload: [null, Validators.required],
      fileName: [null, Validators.required],
      uploadedDate: [null],
      pageCount: [null],
      artifactIdentifer: [null],
      artifactSubmissionIdentifier: [null],
      contentManagementId: [null],
      filingDate: [null],
    });
  }

  // updateFormValidation() {
  //   switch (this.motionsModalInfo.actionType) {
  //     case 'MOTION':
  //       this.noticeOfAppealForm.get('filingParty').setValidators(Validators.required);
  //       this.noticeOfAppealForm.get('filingParty').updateValueAndValidity();
  //       break;
  //     case 'OPPOSITION':
  //       this.noticeOfAppealForm.get('opposition').setValidators(Validators.required);
  //       this.noticeOfAppealForm.get('opposition').setValue('default');
  //       this.noticeOfAppealForm.get('opposition').updateValueAndValidity();
  //       this.getMotionsOnCase();
  //       break;
  //     case 'REPLY':
  //       this.noticeOfAppealForm.get('reply').setValidators(Validators.required);
  //       this.noticeOfAppealForm.get('reply').setValue('default');
  //       this.noticeOfAppealForm.get('reply').updateValueAndValidity();
  //       this.getMotionsOnCase();
  //       break;
  //     default:
  //       break;
  //   }
  // }

  // setModalTitle(actionType) {
  //   this.actionType = actionType;
  //   this.modalTitle = CONSTANTS.MOTIONS[actionType];
  //   if (actionType !== 'MOTION') {
  //     this.getMotionsPaperTypes(actionType);
  //   }
  // }

  fileChange(event) {
    this.logger.info('File info: ', event);
    if (event.target.files.length > 0) {
      this.noticeOfAppealForm
        .get('fileToUpload')
        .setValue(event.target.files[0]);
      this.noticeOfAppealForm
        .get('fileName')
        .setValue(event.target.files[0].name);
    }
  }

  clearForm() {
    this.noticeOfAppealForm.reset();
    this.clearFile();
    this.setupForm();
    // this.setModalTitle(this.actionType);
    // this.updateFormValidation();
    this.editMode = false;
    this.showWarningMessage = false;
    this.showPaperErrorMessage = false;
    this.onePaperMin = false;
    this.editIndex = null;
    // this.paperTypeDisplayName = null;
    // this.motionTypeDisplayName = null;
    // this.motionStatus = null;
    this.saving = false;
    this.addingToList = false;
  }

  clearFile() {
    const fileEl = <HTMLInputElement>document.getElementById('file');
    if (fileEl) {
      fileEl.value = '';
      this.noticeOfAppealForm.get('fileToUpload').setValue(null);
      this.noticeOfAppealForm.get('fileName').setValue(null);
    }
  }

  changeDocType(docType) {
    // if (docType === 'exhibits') {
    if (docType === CONSTANTS.DOC_TYPE.EXHIBIT) {
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
      this.noticeOfAppealForm
        .get('exhibitNumber')
        .setValue(this.minExhibitNumber, [Validators.required]);
      this.noticeOfAppealForm.get('exhibitNumber').updateValueAndValidity();
      this.noticeOfAppealForm.get('paperType').clearValidators();
      this.noticeOfAppealForm.get('paperType').updateValueAndValidity();
      if (this.addedDocumentsList.length <= 0) {
        this.showWarningMessage = true;
      }
    } else {
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
      this.showWarningMessage = false;
    }
  }

  addToList() {
    // if (!this.paperDocumentExists()) {
    this.addingToList = true;
    this.noticeOfAppealForm.disable();
    this.initiatePetitionService
      .addToList(
        this.noticeOfAppealForm.value.fileToUpload,
        this.noticeOfAppealForm.value.docType,
        this.petitionIdentifier
      )
      .pipe(take(1))
      .subscribe(
        (fileAdded) => {
          this.noticeOfAppealForm.enable();
          let petitionDocument = null;
          let filingParty =
            this.noticeOfAppealForm.value.filingParty === ''
              ? 'PETITIONER'
              : this.noticeOfAppealForm.value.filingParty.toUpperCase();
          if (this.noticeOfAppealForm.value.docType.toLowerCase() === 'paper') {
            const docId = this.noticeOfAppealForm.value.paperType.documentTypeId
              ? this.noticeOfAppealForm.value.paperType.documentTypeId
              : this.noticeOfAppealForm.value.paperType.identifier;
            petitionDocument = new PetitionDocument(
              this.noticeOfAppealForm.value.docType.toUpperCase(),
              this.noticeOfAppealForm.value.documentName,
              this.noticeOfAppealForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.noticeOfAppealForm.value.availability.code,
              docId,
              this.noticeOfAppealForm.value.paperType.code,
              this.noticeOfAppealForm.value.fileToUpload.type,
              null,
              'Y',
              null
            );
          } else {
            petitionDocument = new PetitionDocument(
              this.noticeOfAppealForm.value.docType.toUpperCase(),
              this.noticeOfAppealForm.value.documentName,
              this.noticeOfAppealForm.value.fileName,
              filingParty,
              // 'BOARD',
              this.noticeOfAppealForm.value.availability.code,
              null,
              CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
              this.noticeOfAppealForm.value.fileToUpload.type,
              this.noticeOfAppealForm.value.exhibitNumber,
              'Y',
              null
            );
          }

          const documentToAdd = new DocumentToAdd(petitionDocument);
          documentToAdd.proceedingNumberText =
            this.noticeOfAppealModalInfo.proceedingNo;
          this.noticeOfAppealForm
            .get('pageCount')
            .setValue(fileAdded.pageCount);
          this.noticeOfAppealForm
            .get('filingDate')
            .setValue(fileAdded.filingDate);
          this.saveDocumentToCMS(documentToAdd);
        },
        (addToListFailure) => {
          this.commonUtils.focusOnCloseModal('closeNoticeOfAppealsModal');
          this.addingToList = false;
          this.noticeOfAppealForm.enable();
          this.commonUtils.throwError(
            `Add to list failed for Notice of Appeal`,
            addToListFailure
          );
        }
      );
    // } else {
    //   this.showPaperErrorMessage = true;
    // }
  }

  paperDocumentExists() {
    let paperDocExists: boolean = false;
    if (this.addedDocumentsList.length > 0) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.docType.toLowerCase() === 'paper' &&
          this.noticeOfAppealForm.value.docType === 'paper'
        ) {
          paperDocExists = true;
        }
      });
    }
    return paperDocExists;
  }

  saveDocumentToCMS(documentToAdd) {
    this.noticeOfAppealForm.disable();
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.noticeOfAppealForm.enable();
          this.logger.info('Saved document to CMS', saveSuccessful);
          this.selectedFilingParty = !this.selectedFilingParty
            ? this.noticeOfAppealForm.value.filingParty
            : this.selectedFilingParty;
          // this.selectedMotionType = !this.selectedMotionType
          //   ? this.noticeOfAppealForm.value.motionType
          //   : this.selectedMotionType;
          // this.getDocuments();
          this.noticeOfAppealForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.noticeOfAppealForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          this.noticeOfAppealForm
            .get('artifactSubmissionIdentifier')
            .setValue(
              saveSuccessful.petitionDocuments[0].artifactSubmissionIdentifier
            );
          // if (this.noticeOfAppealForm.value.docType === 'exhibits') {
          if (
            this.noticeOfAppealForm.value.docType === CONSTANTS.DOC_TYPE.EXHIBIT
          ) {
            // this.minExhibitNumber++;
            this.getNextExhibitNumber();
          } else {
            this.noticeOfAppealForm.get('exhibitNumber').setValue(null);
          }
          this.noticeOfAppealForm
            .get('contentManagementId')
            .setValue(saveSuccessful.petitionDocuments[0].contentManagementId);
          this.addedDocumentsList.push(this.noticeOfAppealForm.value);
          this.clearForm();
          this.onePaperMin = !this.paperDocumentExists();
          this.commonUtils.focusOnCloseModal('closeNoticeOfAppealsModal');
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.commonUtils.focusOnCloseModal('closeNoticeOfAppealsModal');
          this.addingToList = false;
          this.noticeOfAppealForm.enable();
          this.commonUtils.throwError(
            `Save document failed for Notice of Appeal`,
            documentSaveFailed
          );
        }
      );
  }

  // getDocuments() {
  //   this.initiatePetitionService
  //     .getDocuments(this.motionsModalInfo.proceedingNo)
  //     .pipe(take(1))
  //     .subscribe((petitionDocumentList) => {
  //       this.logger.info('Petition documents list', petitionDocumentList);
  //       this.addedDocumentsList = petitionDocumentList;
  //     });
  // }

  editDocument(e) {
    this.editMode = true;
    this.editIndex = e;
    if (this.addedDocumentsList[e].pageCount == undefined) {
      this.addedDocumentsList[e].pageCount = null;
    }
    this.noticeOfAppealForm.setValue(this.addedDocumentsList[e]);
    this.paperTypeDisplayName = this.addedDocumentsList[e].paperType.displayName
      ? this.addedDocumentsList[e].paperType.displayName
      : this.addedDocumentsList[e].paperType.descriptionText;
    // this.motionTypeDisplayName = this.addedDocumentsList[e].motionType
    // .displayName
    // ? this.addedDocumentsList[e].motionType.displayName
    // : this.addedDocumentsList[e].motionType.descriptionText;
    this.noticeOfAppealForm.updateValueAndValidity();
  }

  onMotionTypeSelect(e) { }

  update() {
    this.addingToList = true;
    // const tempDoc = this.addedDocumentsList[this.editIndex];
    // let tempCat = tempDoc.docType.toUpperCase();
    // if (tempCat === 'EXHIBITS') {
    //   tempCat = CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase()
    // }
    // let updateDocObj = {
    //   artifactIdentifer: tempDoc.artifactIdentifer,
    //   // "audit": {
    //   //   "lastModifiedUserIdentifier": window.sessionStorage.getItem('email'),
    //   //   "createUserIdentifier": window.sessionStorage.getItem('email')
    //   // },
    //   availability: this.noticeOfAppealForm.value.availability.code,
    //   category: tempCat,
    //   contentManagementId: tempDoc.contentManagementId,
    //   documentTypeIdentifier: tempDoc.paperType.identifier,
    //   fileSize: tempDoc.fileToUpload.size,
    //   filingDate: tempDoc.filingDate,
    //   filingParty: tempDoc.filingParty.toUpperCase(),
    //   documentName: this.noticeOfAppealForm.value.documentName,
    //   proceedingNumberText: this.noticeOfAppealModalInfo.proceedingNo,
    //   ptabDefaultRefreshTime: null,
    //   ptabReadOnlyUser: false,
    //   textExtractionIndicator: null,
    // };

    // const docToEdit = new EditDocument(updateDocObj);

    this.caseViewerService
      .updateDocument(
        this.addedDocumentsList[this.editIndex],
        this.noticeOfAppealForm,
        this.noticeOfAppealModalInfo.proceedingNo
      )
      .pipe(take(1))
      .subscribe(
        (editSuccess) => {
          this.noticeOfAppealForm
            .get('uploadedDate')
            .setValue(this.commonUtils.getCurrentDateString('time'));
          this.addedDocumentsList[this.editIndex] =
            this.noticeOfAppealForm.value;

          this.clearForm();
          this.addingToList = false;
          this.commonUtils.setToastr('success', CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
        },
        (editFailure) => {
          this.commonUtils.throwError('Error', editFailure);
          this.addingToList = false;
          this.commonUtils.setToastr('error', CONSTANTS.TOAST_MSGS.UPDATE_DOC.ERROR)
        }
      );
    // this.noticeOfAppealForm
    //   .get('uploadedDate')
    //   .setValue(this.commonUtils.getCurrentDateString('time'));
    // this.addedDocumentsList[this.editIndex] = this.noticeOfAppealForm.value;

    // this.clearForm();
  }

  showDate() { }

  submitNoticeOfAppeal() {
    let appealPartyTypeCode =
      this.noticeOfAppealForm.value.filingParty.toLowerCase() === 'petitioner'
        ? this.noticeOfAppealForm.value.filingParty.toUpperCase()
        : 'PATENTOWNER';

    const appealDate = this.appealFiledDate.split('-');
    appealDate.push(appealDate.shift());
    this.saving = true;
    const currentTime = new Date(
      this.commonUtils.setEST(new Date().getTime())
    ).getTime();
    this.logger.info('Notice of appeal form:', this.noticeOfAppealForm);
    let noticeOfAppealObj = {
      appealStatusCode: 'Awaiting Decision',
      appealTypeName: 'AIA REVIEW APPEAL',
      proceedingNumber: this.noticeOfAppealModalInfo.proceedingNo,
      appealPartyTypeCode: appealPartyTypeCode,
      appealNoticeDate: new Date(appealDate.join('-')).getTime(),
      audit: {
        lastModifiedUserIdentifier: window.sessionStorage.getItem('email'),
        lastModifiedTimestamp: currentTime,
        createTimestamp: currentTime,
      },
      appealDocuments: null,
    };
    let noticeOfAppealDocuments = [];
    this.addedDocumentsList.forEach((doc) => {
      const noticeOfAppealDoc = {
        artifactIdentifer: doc.artifactIdentifer,
        artifactSubmissionIdentifier: doc.artifactSubmissionIdentifier,
        documentTypeIdentifier: doc.paperType.identifier,
        category: doc.docType.toUpperCase(),
        exhibitNumber: doc.exhibitNumber,
        documentTypeCustomAttributes: null,
        name: doc.documentName,
        mimeType: doc.fileToUpload.type,
        documentTypeCode:
          doc.docType.toLowerCase() === CONSTANTS.DOC_TYPE.PAPER
            ? doc.paperType.code
            : CONSTANTS.EXHIBIT_DOC_TYPE_CODE,
      };
      if (
        doc.paperType.documentTypeCustomAttributes &&
        doc.paperType.documentTypeCustomAttributes.attributes &&
        doc.paperType.documentTypeCustomAttributes.attributes.length > 0
      ) {
        noticeOfAppealDoc.documentTypeCustomAttributes =
          doc.paperType.documentTypeCustomAttributes;
        noticeOfAppealDoc.documentTypeCustomAttributes.attributes[0].value =
          noticeOfAppealObj.appealNoticeDate / 1000;
      } else {
        delete noticeOfAppealDoc.documentTypeCustomAttributes;
      }
      noticeOfAppealDocuments.push(noticeOfAppealDoc);
    });
    noticeOfAppealObj.appealDocuments = noticeOfAppealDocuments;
    this.caseViewerService
      .submitNoticeOfAppeal(noticeOfAppealObj)
      .pipe(take(1))
      .subscribe(
        (submitNoticeOfAppealsResponse) => {
          this.logger.info(
            'Motion saved successfully',
            submitNoticeOfAppealsResponse
          );
          this.commonUtils.showSuccess(
            'Successfully submitted notice of appeal',
            'Notice of appeal'
          );
          this.close(false);
        },
        (submitNoticeOfAppealsError) => {
          this.logger.error(
            'Motion failed to save',
            submitNoticeOfAppealsError
          );
          this.commonUtils.showError(
            submitNoticeOfAppealsError.error.message,
            'Notice of appeal'
          );
          this.saving = false;
        }
      );
  }

  // setSuccessToastr(motionStatus) {
  //   const whatFiled =
  //     this.actionType === 'OPPOSITION'
  //       ? `filed an ${this.actionType.toLowerCase()}`
  //       : `filed a ${this.actionType.toLowerCase()}`;
  //   const action = motionStatus === 'INITIATED' ? 'saved documents' : whatFiled;
  //   // const title =
  //   //   this.actionType === 'OPPOSITION'
  //   //     ? `File an ${this.actionType.toLowerCase()}`
  //   //     : `File a ${this.actionType.toLowerCase()}`;
  //   this.commonUtils.showSuccess(`Successfully ${action}`, null);
  // }

  onePaperMinRequired(e) {
    this.onePaperMin = e;
  }

  checkIfPaperIsAdded(e) {
    this.clearForm();
    this.onePaperMin = e;
  }

  close(selection) {
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  // setMotionId(idType) {
  //   this.logger.info('Motions form: ', this.noticeOfAppealForm);
  //   this.selectedMotionId = this.noticeOfAppealForm.value[idType].motionId;
  // }

  checkForm() {
    this.logger.info('Motions form: ', this.noticeOfAppealForm);
    this.logger.info('Warning message: ', this.showWarningMessage);
    this.logger.info('Saving: ', this.saving);
    this.logger.info('Adding to list: ', this.addingToList);
  }

  checkAvailability(action) {
    if (action === 'add' && this.paperDocumentExists()) {
      this.showPaperErrorMessage = true;
    } else if (
      this.noticeOfAppealForm.value.availability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else {
      action === 'add' ? this.addToList() : this.update();
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        action === 'add' ? this.addToList() : this.update();
      }
    });
  }
}
