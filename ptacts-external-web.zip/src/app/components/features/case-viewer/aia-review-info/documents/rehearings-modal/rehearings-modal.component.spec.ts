import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RehearingsModalComponent } from './rehearings-modal.component';

describe('RehearingsModalComponent', () => {
  let component: RehearingsModalComponent;
  let fixture: ComponentFixture<RehearingsModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RehearingsModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RehearingsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
