import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-delete-staff-modal',
  templateUrl: './delete-staff-modal.component.html',
  styleUrls: ['./delete-staff-modal.component.scss'],
})
export class DeleteStaffModalComponent implements OnInit {
  deleteStaffModalInfo: any = this.modalService.config.initialState;

  constructor(private modalService: BsModalService) {}

  ngOnInit(): void {}

  close(selection) {
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }
}
