import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteStaffModalComponent } from './delete-staff-modal.component';

describe('DeleteStaffModalComponent', () => {
  let component: DeleteStaffModalComponent;
  let fixture: ComponentFixture<DeleteStaffModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteStaffModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteStaffModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
