import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { CaseViewerService } from '../../case-viewer.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { StaffModalComponent } from './staff-modal/staff-modal.component';

import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../../initiate-petition/initiate-petition.service';
import { DeleteStaffModalComponent } from './delete-staff-modal/delete-staff-modal.component';

@Component({
  selector: 'app-counsel',
  templateUrl: './counsel.component.html',
  styleUrls: ['./counsel.component.scss'],
})
export class CounselComponent implements OnInit, AfterViewInit {
  counselInfo: any;
  petitionInfo: any = null;
  staffModalRef: BsModalRef;

  @Input() petitionerCounsel: any;
  @Input() poCounsel: any;
  @Input() staffActions: any;
  @Output() updateCounsel: EventEmitter<boolean> = new EventEmitter<boolean>();

  lastRefresh = new Date();
  refreshSort: boolean;
  partyRepresenting: string = null;

  constructor(
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService,
    public modalService: BsModalService,
    private store: Store<PtactsState>,
    private initiatePetitionService: InitiatePetitionService
  ) { }

  ngOnInit(): void {
    console.log('Staff Actions: ', this.staffActions);
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );

    // this.getCounselInfo();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.store
        .select(PtactsSelectors.getPartyRepresentingState)
        .subscribe((partyRepresenting) => {
          this.partyRepresenting = partyRepresenting;
          this.getCounselInfo();
        });
    }, 500);
  }

  refresh(val) {
    this.refreshSort = val;
    this.counselInfo = null;
    this.petitionerCounsel = null;
    this.poCounsel = null;
    // this.getCounselInfo();
    this.updateCounsel.emit(true);
    this.lastRefresh = new Date();
  }

  getCounselInfo() {
    // this.caseViewerService.getCounselInfo(this.petitionInfo.proceedingNumberText).subscribe((data) => {
    //   this.counselInfo = data;
    if (this.counselInfo?.petitionCounsel) {
      this.counselInfo.petitionCounsel.parties.sort(this.sortCounselType);
      this.petitionerCounsel = this.counselInfo.petitionCounsel.parties;
    }
    if (this.counselInfo?.poCounsel) {
      this.counselInfo.petitionCounsel.parties.sort(this.sortCounselType);
      this.poCounsel = this.counselInfo.poCounsel.parties;
    }
    // if (this.partyRepresenting.toLowerCase() === 'petitioner') {
    //   this.filterStaff(this.petitionerCounsel, 'petitioner');
    // } else {
    //   this.filterStaff(this.poCounsel, 'patentowner');
    // }
    // });
  }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }

  // filterStaff(parties, partyRep) {
  //   this.staffActions.staffCount = 0;
  //   parties.forEach((party) => {
  //     if (party.partySubType.toLowerCase() === 'staff') {
  //       this.staffActions.staffCount++;
  //     }
  //     if (
  //       party.partySubType.toLowerCase() === 'lead' &&
  //       party.personType.length > 0
  //     ) {
  //       party.personType[0].electronicAddress.forEach((address) => {
  //         if (
  //           address.hasOwnProperty('email') &&
  //           address.email === this.loggedInUserEmail
  //         ) {
  //           if (partyRep === 'petitioner') {
  //             this.staffActions.showPetitionerButton = true;
  //           } else if (partyRep === 'patentowner') {
  //             this.staffActions.showPatentOwnerButton = true;
  //           }
  //         }
  //       });
  //     }
  //   });
  // }

  copyEmails(counselType) {
    let emails = [];
    if (counselType == 'petitionCounsel') {
      this.petitionerCounsel.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    } else if (counselType == 'poCounsel') {
      this.poCounsel.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    }
    // if (
    //   this.counselInfo[counselType] &&
    //   this.counselInfo[counselType].parties.length > 0
    // ) {
    //   this.counselInfo[counselType].parties.forEach((party) => {
    //     party.personType[0].electronicAddress.forEach((electronicAddress) => {
    //       if (electronicAddress.hasOwnProperty('email')) {
    //         emails.push(electronicAddress.email);
    //       }
    //     });
    //   });
    // }
    this.commonUtils.copyToClipboard(emails.join(', '), counselType);
  }

  addUpdateStaff(staffToEdit, editMode) {
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.petitionInfo.proceedingNumberText,
        closeModal: false,
        editMode: editMode,
        staffToEdit: staffToEdit,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.staffModalRef = this.modalService.show(
      StaffModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.staffModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
        this.refresh(true);
      }
    });
  }

  confirmDelete(staffToDelete) {
    const staffName = `${staffToDelete.personType[0].firstName} ${staffToDelete.personType[0].lastName}`;
    const initialState: ModalOptions = {
      initialState: {
        staffName: staffName,
        closeModal: false,
      },
      class: 'modal-lg',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.staffModalRef = this.modalService.show(
      DeleteStaffModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.staffModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
        this.deleteStaff(staffToDelete);
      }
    });
  }

  deleteStaff(staffToDelete) {
    console.log('Staff to delete: ', staffToDelete);
    this.caseViewerService
      .deleteStaff(
        this.petitionInfo.proceedingNumberText,
        staffToDelete.identifier
      )
      .pipe(take(1))
      .subscribe(
        (deleteStaffSuccess) => {
          this.commonUtils.showSuccess(
            'Successfully deleted staff',
            'Delete staff'
          );
          this.refresh(true);
        },
        (deleteStaffFailure) => {
          this.commonUtils.showError(
            deleteStaffFailure.error.message,
            'Delete staff'
          );
        }
      );
  }
}
