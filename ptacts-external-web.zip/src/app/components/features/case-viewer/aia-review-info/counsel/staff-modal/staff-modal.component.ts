import { Component, OnInit, AfterViewInit } from '@angular/core';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators } from '@angular/forms';
import { CONSTANTS } from 'src/app/constants/constants';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from 'src/app/components/features/initiate-petition/initiate-petition.service';
import { take } from 'rxjs/operators';
import { InterestedParty } from 'src/app/models/parties/InterestedParty.model';
import { CaseViewerService } from '../../../case-viewer.service';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { getPartyRepresenting } from 'src/app/store/ptacts/ptacts.actions';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';

@Component({
  selector: 'app-staff-modal',
  templateUrl: './staff-modal.component.html',
  styleUrls: ['./staff-modal.component.scss'],
})
export class StaffModalComponent implements OnInit, AfterViewInit {
  staffModalInfo: any = this.modalService.config.initialState;
  findStaff: string = null;
  countries: Array<any> = new Array();
  states: Array<any> = new Array();
  staffList: Array<any> = new Array();
  stateIsRequired: boolean = false;
  editMode: boolean = false;
  staffToEdit: any = null;
  partyRepresenting: string = null;
  modalRef: BsModalRef;
  regNotFound: boolean = false;
  emailNotFound: boolean = false;
  staffFound: boolean = false;
  staffName: string = null;
  myUsptoLink = {
    MyUSPTO: null,
  };

  staffForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: [
      '',
      [Validators.required, Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)],
    ],
    regNo: [''],
    phoneNumber: ['', [Validators.required, this.commonUtils.ValidatePhoneFax]],
    faxNumber: ['', this.commonUtils.ValidatePhoneFax],
    country: ['', Validators.required],
    address1: [''],
    address2: [''],
    city: [''],
    state: [''],
    zip: [''],
  });

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    public commonUtils: CommonUtilitiesService,
    private initiatePetitionService: InitiatePetitionService,
    private caseViewerService: CaseViewerService,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    this.getMyUSPTOLink();
    this.getCountries();
    console.log('Staff to edit: ', this.staffModalInfo.staffToEdit);
    if (this.staffModalInfo.editMode) {
      this.setStaffToEdit(this.staffModalInfo.staffToEdit);
    }
  }

  ngAfterViewInit() {
    this.setStaffName();
    setTimeout(() => {
      this.store
        .select(PtactsSelectors.getPartyRepresentingState)
        .subscribe((partyRepresenting) => {
          this.partyRepresenting = partyRepresenting;
          this.getAllStaff();
        });
    }, 500);
  }

  getMyUSPTOLink() {
    this.initiatePetitionService
      .getMyUSPTOLink()
      .pipe(take(1))
      .subscribe((myUSPTOLinkResponse: any) => {
        myUSPTOLinkResponse.forEach((element) => {
          this.myUsptoLink.MyUSPTO = element.descriptionText;
        });
      });
  }

  setStaffName() {
    if (
      this.staffToEdit?.personType &&
      this.staffToEdit?.personType.length > 0
    ) {
      if (this.staffToEdit?.personType[0]?.firstName) {
        this.staffName = this.staffToEdit.personType[0].firstName;
      }
      if (this.staffToEdit?.personType[0]?.lastName) {
        this.staffName = `${this.staffName} ${this.staffToEdit.personType[0].lastName}`;
      }
    }
  }

  getCountries() {
    this.initiatePetitionService
      .getCountries()
      .pipe(take(1))
      .subscribe((countriesResponse) => {
        this.countries = countriesResponse;
        // if (this.editMode) {
        //   if (this.counselForm.get('country').value.value) {
        //     const foundCountry: any = this.countries.find((country: any) => {
        //       return (
        //         country.value === this.counselForm.get('country').value.value
        //       );
        //     });
        //     this.counselForm.get('country').setValue(foundCountry);
        //     this.getStates(foundCountry.value);
        //   }
        // }
      });
  }

  getStates(countryCode) {
    this.states = [];
    this.modifyStateReq(countryCode);
    this.initiatePetitionService
      .getStates(countryCode)
      .pipe(take(1))
      .subscribe((statesList) => {
        this.states = statesList;
        // if (this.editMode) {
        //   if (this.counselForm.get('state').value.value) {
        //     const foundState = this.states.find((stateToFind: any) => {
        //       return (
        //         stateToFind.value === this.counselForm.get('state').value.value
        //       );
        //     });
        //     if (foundState) {
        //       this.counselForm.get('state').setValue(foundState);
        //     } else {
        //       this.counselForm.controls.state.setValue('');
        //     }
        //   }
        // } else {
        //   this.counselForm.controls.state.setValue('');
        // }
      });
  }

  modifyStateReq(countryCode) {
    this.stateIsRequired = false;
    if (CONSTANTS.MANDATORY_COUNTRIES.includes(countryCode)) {
      this.stateIsRequired = true;
      this.staffForm.get('state').setValidators([Validators.required]);
    } else {
      this.staffForm.get('state').clearValidators();
    }
    this.staffForm.get('state').updateValueAndValidity();
  }

  close(selection) {
    this.modalService.config.initialState.closeModal = selection;
    this.modalService.hide();
  }

  findByEmail(regOrEmail) {
    // this.registrationNoNotFound = false;
    this.regNotFound = false;
    this.emailNotFound = false;
    let searchCriteria = `email=${regOrEmail.toLowerCase().trim()}`;
    this.initiatePetitionService
      .findByRegOrEmail(searchCriteria)
      .pipe(take(1))
      .subscribe(
        (foundCounsels) => {
          if (foundCounsels.length === 1) {
            // if (foundCounsels[0].registrationNo) {
            //   this.registrationNoNotFound = false;
            //   this.setForm(foundCounsels[0]);
            // } else {
            //   this.registrationNoNotFound = true;
            //   this.setForm(foundCounsels[0]);
            // }
            this.staffFound = true;
            this.setForm(foundCounsels[0]);
          } else {
            this.emailNotFound = true;
            this.stateIsRequired = false;
            this.staffForm.reset();
            this.staffForm.disable();
            this.staffForm.updateValueAndValidity();
            this.setForm(foundCounsels[0]);
          }
        },
        (notFoundResponse) => {}
      );
  }

  clearForm() {
    this.stateIsRequired = false;
    this.staffForm.reset();
    // this.staffForm.disable();
    // this.staffForm.get('counselType').clearValidators();
    // this.staffForm.get('proSe').setValue('No');
    // this.staffForm.get('counselType').setValue('leadCounsel');
    this.staffForm.updateValueAndValidity();
    this.findStaff = null;
    // this.disableCounselTypes();
    // this.regOrEmailNotFound = false;
    // this.editMode = false;
    // this.allowSwap = false;
    // this.findCounsel = null;
    // this.registrationNoNotFound = false;
    // this.regNotFound = false;
    // this.emailNotFound = false;
  }

  onKeyUp(x) {
    if (x.code === 'Enter' || x.code === 'NumpadEnter') {
      this.findByEmail(this.findStaff);
    }
  }

  addStaff() {
    const staffToAdd = this.setStaffObj();

    this.caseViewerService
      .addStaff(staffToAdd)
      .pipe(take(1))
      .subscribe(
        (addStaffSuccess) => {
          this.commonUtils.showSuccess('Successfully added staff', 'Add Staff');
          this.close(true);
          // this.staffList.push(addStaffSuccess.parties[0]);
          // this.staffList.push(this.setStaffList(this.staffForm.value));
        },
        (addCounselFailure) => {
          this.commonUtils.showError(
            addCounselFailure.error.message,
            'Add Staff Action cannot be performed'
          );
        }
      );
    // this.staffList.push(this.setStaffList(this.staffForm.value));
    // this.commonUtils.showSuccess('Successfully added staff', 'Staff');
    // this.clearForm();
  }

  setStaffObj() {
    const staffToAddUpdate = new InterestedParty();
    // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
    staffToAddUpdate.caseNo = this.staffModalInfo.proceedingNo;
    // staffToAddUpdate.parties[0].submitterType = 'PETITIONER';
    // staffToAddUpdate.parties[0].partyType = 'COUNSEL';
    // staffToAddUpdate.parties[0].partySubType =
    //   this.selectedProSe === 'Y' ? 'PROSE' : this.selectedCounselType;
    staffToAddUpdate.parties[0].proseIndicator = 'N';
    if (this.editMode) {
      staffToAddUpdate.parties[0].identifier = this.staffToEdit.identifier;
      staffToAddUpdate.parties[0].personType[0].identifier =
        this.staffToEdit.personType[0].identifier;
    }
    staffToAddUpdate.parties[0].registrationNo = this.staffForm.value.regNo;
    staffToAddUpdate.parties[0].personType[0].firstName =
      this.staffForm.value.firstName;
    staffToAddUpdate.parties[0].personType[0].lastName =
      this.staffForm.value.lastName;
    staffToAddUpdate.parties[0].personType[0].mailingAddress =
      this.addMailingAddress(this.staffForm);
    staffToAddUpdate.parties[0].personType[0].electronicAddress =
      this.addElectronicAddress(this.staffForm);
    staffToAddUpdate.parties[0].orgType = [];
    return staffToAddUpdate;
  }

  addMailingAddress(mailingAddressInfo) {
    const mailingArray = [];
    let mailObj = {
      country: null,
      streetLineOneText: mailingAddressInfo.value.address1,
      streetLineTwoText: mailingAddressInfo.value.address2,
      city: mailingAddressInfo.value.city,
      state: null,
      zipCode: mailingAddressInfo.value.zip,
      addressType: 'BUS',
      identifier: null,
    };

    if (
      mailingAddressInfo.value.country &&
      mailingAddressInfo.value.country.hasOwnProperty('value')
    ) {
      mailObj.country = mailingAddressInfo.value.country.value;
    }
    if (
      mailingAddressInfo.value.state &&
      mailingAddressInfo.value.state.hasOwnProperty('value')
    ) {
      mailObj.state = mailingAddressInfo.value.state.value;
    }

    if (
      this.editMode &&
      this.staffToEdit.personType[0].mailingAddress &&
      this.staffToEdit.personType[0].mailingAddress.length > 0
    ) {
      mailObj.identifier =
        this.staffToEdit.personType[0].mailingAddress[0].identifier;
    }

    mailingArray.push(mailObj);
    return mailingArray;
  }

  addElectronicAddress(electronicAddressInfo) {
    const tempArr = [];
    const email = {
      email: electronicAddressInfo.value.email,
      emailType: 'WE',
      extention: null,
      identifier: null,
    };
    const phone = {
      extension: electronicAddressInfo.value.extension,
      identifier: null,
      teleCommAddresType: 'W',
      telephoneNumber: electronicAddressInfo.value.phoneNumber,
    };
    const fax = {
      extension: null,
      identifier: null,
      teleCommAddresType: 'F',
      fax: electronicAddressInfo.value.faxNumber,
    };
    if (
      this.editMode &&
      this.staffToEdit.personType[0].electronicAddress &&
      this.staffToEdit.personType[0].electronicAddress.length > 0
    ) {
      this.staffToEdit.personType[0].electronicAddress.forEach((element) => {
        if (element.email) {
          email.identifier = element.identifier;
        }
        if (element.extension || element.telephoneNumber) {
          phone.identifier = element.identifier;
        }
        if (element.fax) {
          fax.identifier = element.identifier;
        }
      });
    }
    tempArr.push(email);
    tempArr.push(phone);
    tempArr.push(fax);

    return tempArr;
  }

  setStaffList(cForm) {
    const tempStaff = {
      partySubType: this.staffModalInfo.staffType,
      counselType: 'Staff',
      name: `${cForm.firstName} ${cForm.lastName}`,
      email: cForm.email,
      regNo: cForm.regNo,
      phoneNo: cForm.phoneNumber,
      fax: cForm.faxNumber,
      form: cForm,
    };
    return tempStaff;
  }

  editStaff(staffToEdit, action, index) {
    // if (action === 'edit') {
    this.editMode = true;
    // this.editIndex = index;
    this.staffToEdit = staffToEdit;
    this.setForm(this.staffToEdit);
    // } else {
    //   this.allowSwap = true;
    //   if (this.counselList.length === 2) {
    //     this.counselList.forEach((counsel) => {
    //       if (!counsel.regNo || counsel.regNo === '') {
    //         if (
    //           (staffToEdit.partySubType.toLowerCase() === 'lead' ||
    //             staffToEdit.partySubType.toLowerCase() === 'prose') &&
    //           (action.toLowerCase() === 'firstbkup' ||
    //             action.toLowerCase() === 'backup')
    //         ) {
    //           this.allowSwap = false;
    //           this.commonUtils.showError(
    //             'Cannot switch lead counsel',
    //             'Switch Counsel'
    //           );
    //         }
    //       }
    //     });
    //   }
    //   if (this.allowSwap) {
    //     this.editMode = true;
    //     staffToEdit.counselInfo.partySubType = action.toUpperCase();
    //     this.staffToEdit = staffToEdit.counselInfo;
    //     this.setForm(staffToEdit.counselInfo);
    //   }
    // }
  }

  setForm(staffInfo) {
    let foundCountry = null;
    if (staffInfo?.personType[0]?.mailingAddress?.length > 0) {
      if (staffInfo.personType[0].mailingAddress[0].country) {
        foundCountry = this.countries.find((country: any) => {
          return (
            country.value === staffInfo.personType[0].mailingAddress[0].country
          );
        });
        this.staffForm.get('country').setValue(foundCountry);
        this.modifyStateReq(foundCountry.value);
        if (staffInfo.personType[0].mailingAddress[0].state) {
        }

        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            if (statesList) {
              this.states = statesList;
              let foundState = this.states.find((state: any) => {
                return (
                  state.value ===
                  staffInfo.personType[0].mailingAddress[0].state
                );
              });
              this.staffForm.get('state').setValue(foundState);
            }
          });
      }
    }
    // this.staffForm
    //   .get('proSe')
    //   .setValue(staffInfo.proseIndicator ? staffInfo.proseIndicator : 'No');
    this.staffForm.get('firstName').setValue(staffInfo.personType[0].firstName);
    this.staffForm.get('lastName').setValue(staffInfo.personType[0].lastName);
    this.staffForm.get('regNo').setValue(staffInfo.registrationNo);

    if (
      staffInfo.personType[0].mailingAddress &&
      staffInfo.personType[0].mailingAddress.length > 0
    ) {
      this.setMailingAddress(staffInfo.personType[0].mailingAddress[0]);
    }
    if (
      staffInfo.personType[0].electronicAddress &&
      staffInfo.personType[0].electronicAddress.length > 0
    ) {
      this.setElectronicAddress(staffInfo.personType[0].electronicAddress);
    }
    this.staffForm.enable();
    //this.staffForm.controls['email'].disable();
    // if (this.staffForm.value.regNo) {
    //   this.enableRegNo = false;
    // } else {
    //   this.enableRegNo = true;
    // }
  }

  updateStaff() {
    const staffToUpdate = this.setStaffObj();
    // if (!this.allowSwap) {
    this.caseViewerService
      .updateStaff(staffToUpdate)
      .pipe(take(1))
      .subscribe(
        (counselUpdate) => {
          this.commonUtils.showSuccess(
            'Successfully updated staff information',
            'Update staff'
          );
          this.close(true);
          // this.getExistingCounsels();
        },
        (counselUpdateFailure) => {
          this.commonUtils.showError(
            counselUpdateFailure.error.message,
            'Update staff'
          );
        }
      );
    // } else {
    //   this.swapCounsel(counselToUpdate);
    // }
  }

  setMailingAddress(mailAddressInfo) {
    this.staffForm.get('address1').setValue(mailAddressInfo.streetLineOneText);
    this.staffForm.get('address2').setValue(mailAddressInfo.streetLineTwoText);
    this.staffForm.get('zip').setValue(mailAddressInfo.zipCode);
    this.staffForm.get('city').setValue(mailAddressInfo.city);
  }

  setElectronicAddress(electronicAddressInfo) {
    electronicAddressInfo.forEach((element) => {
      if (element.telephoneNumber) {
        this.staffForm.get('phoneNumber').setValue(element.telephoneNumber);
      }
      if (element.fax) {
        this.staffForm.get('faxNumber').setValue(element.fax);
      }
      if (element.email) {
        this.staffForm.get('email').setValue(element.email);
      }
    });
  }

  getAllStaff() {
    console.log(this.partyRepresenting);
    this.caseViewerService
      .getCounselInfo(this.staffModalInfo.proceedingNo)
      .pipe(take(1))
      .subscribe((partiesInfo) => {
        if (this.partyRepresenting.toLowerCase() === 'petitioner') {
          this.filterStaff(partiesInfo.petitionCounsel.parties);
        } else {
          this.filterStaff(partiesInfo.poCounsel.parties);
        }
      });
  }

  filterStaff(parties) {
    this.staffList = [];
    parties.forEach((party) => {
      if (party.partySubType.toLowerCase() === 'staff') {
        this.staffList.push(party);
      }
    });
  }

  deleteStaff(staffToDelete) {
    this.initiatePetitionService
      .deleteCounsel(this.staffModalInfo.proceedingNo, staffToDelete.identifier)
      .pipe(take(1))
      .subscribe(
        (deleteStaffSuccess) => {
          this.commonUtils.showSuccess(
            'Successfully deleted staff',
            'Delete staff'
          );
          this.getAllStaff();
        },
        (deleteStaffFailure) => {
          this.commonUtils.showError(
            deleteStaffFailure.error.message,
            'Delete staff'
          );
        }
      );
  }

  openWarningModal(staffToDelete, index) {
    let title = 'Delete this record?';
    let message = ['This information will be removed from the system.'];
    let leftBtnLabel = 'No, return to page';
    let rightBtnLabel = 'Yes, delete this record';
    const initialState: any = {
      title: title,
      message: message,
      leftBtnLabel: leftBtnLabel,
      rightBtnLabel: rightBtnLabel,
      selection: false,
    };
    this.commonUtils.removeModalFadeClass();
    this.commonUtils.setSecondModalBackgroundColor();
    this.modalRef = this.modalService.show(WarningModalComponent, {
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        this.deleteStaff(staffToDelete);
      } else {
      }
    });
  }

  setStaffToEdit(staffToEdit) {
    this.staffToEdit = staffToEdit;
    this.staffForm
      .get('firstName')
      .setValue(staffToEdit.personType[0].firstName);
    this.staffForm.get('lastName').setValue(staffToEdit.personType[0].lastName);

    staffToEdit.personType[0].electronicAddress.forEach((address) => {
      if (address.hasOwnProperty('email')) {
        this.staffForm.get('email').setValue(address.email);
      }
      if (address.hasOwnProperty('telephoneNumber')) {
        this.staffForm
          .get('phoneNumber')
          .setValue(address.telephoneNumber, [
            Validators.required,
            this.commonUtils.ValidatePhoneFax,
          ]);
      }
      if (address.hasOwnProperty('fax')) {
        this.staffForm
          .get('faxNumber')
          .setValue(address.fax, this.commonUtils.ValidatePhoneFax);
      }
    });

    staffToEdit.personType[0].mailingAddress.forEach((mailingAddress) => {
      if (mailingAddress.hasOwnProperty('streetLineOneText')) {
        this.staffForm
          .get('address1')
          .setValue(mailingAddress.streetLineOneText);
      }
      if (mailingAddress.hasOwnProperty('streetLineTwoText')) {
        this.staffForm
          .get('address2')
          .setValue(mailingAddress.streetLineTwoText);
      }
      if (mailingAddress.hasOwnProperty('city')) {
        this.staffForm.get('city').setValue(mailingAddress.city);
      }
      if (mailingAddress.hasOwnProperty('zipCode')) {
        this.staffForm.get('zip').setValue(mailingAddress.zipCode);
      }
    });

    setTimeout(() => {
      let foundCountry = this.countries.find((country) => {
        console.log(country);
        return (
          country.value === staffToEdit.personType[0].mailingAddress[0].country
        );
      });

      console.log(foundCountry, staffToEdit);
      this.staffForm.get('country').setValue(foundCountry, Validators.required);

      if (staffToEdit.personType[0].mailingAddress[0].state) {
        this.getStateForEdit(foundCountry.value, staffToEdit);
      }
    }, 500);
  }

  getStateForEdit(countryCode, staffToEdit) {
    this.stateIsRequired = false;
    if (CONSTANTS.MANDATORY_COUNTRIES.includes(countryCode)) {
      this.stateIsRequired = true;
    }
    this.initiatePetitionService
      .getStates(countryCode)
      .pipe(take(1))
      .subscribe((statesList) => {
        this.states = statesList;
        const foundState = statesList.find((state) => {
          return (
            state.value === staffToEdit.personType[0].mailingAddress[0].state
          );
        });
        this.staffForm.get('state').setValue(foundState, Validators.required);
      });
  }

  openPTOLink() {
    // window.open(Urls.MYUSPTO, '_blank');
    window.open(this.myUsptoLink.MyUSPTO, '_blank');
  }
  // firstName: ['', Validators.required],
  // lastName: ['', Validators.required],
  // email: [
  //   '',
  //   [Validators.required, Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)],
  // ],
  // regNo: [''],
  // phoneNumber: ['', [Validators.required, this.commonUtils.ValidatePhoneFax]],
  // faxNumber: ['', this.commonUtils.ValidatePhoneFax],
  // country: ['', Validators.required],
  // address1: [''],
  // address2: [''],
  // city: [''],
  // state: [''],
  // zip: [''],

  //   addressType: "BUS"
  // city: "Chicago"
  // country: "US"
  // identifier: "12197698"
  // state: "IL"
  // streetLineOneText: "123 Fake St."
  // streetLineTwoText: "Suite 900"
  // zipCode: "60123"
}
