import { Component, OnInit } from '@angular/core';
import { CaseViewerService } from '../../case-viewer.service';
import { Urls } from 'src/app/constants/urls';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss'],
})
export class PaymentsComponent implements OnInit {
  petitionInfo: any = null;
  payments: any = [];
  allPayments: any;
  paymentsInfo: any;
  paymentsInfoTemp: any[] = [];
  sortCount: boolean = false;

  orderByField: any[] = [];
  orderByPaymentField: any[] = [];
  lastRefresh = new Date();
  refreshSort: boolean = true;

  constructor(private caseViewerService: CaseViewerService, private commonUtils: CommonUtilitiesService) {}

  ngOnInit(): void {
    this.sortCount = true;
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getAllPayments();
  }

  refresh(val) {
    this.refreshSort = val;
    this.orderByField = [];
    this.orderByPaymentField = [];
    this.getAllPayments();
    this.lastRefresh = new Date();
  }

  // getAllPayments() {
  //   this.caseViewerService.getPayments(this.petitionInfo.proceedingNumberText).subscribe((data) => {
  //     this.allPayments = data;
  //   });
  // }

  getAllPayments() {
    this.caseViewerService
      .getPayments(this.petitionInfo.proceedingNumberText)
      .subscribe((data) => {
        data.forEach((payment) => {
          payment.transactionDate = this.commonUtils.setEST(
            payment.transactionDate
          );
        });
        // this.paymentsInfo = data;
        this.paymentsInfo = this.commonUtils.sortPaymentTable(data, 'feeCode');
        // if (this.refreshSort) {
        //   this.sortColumns('-party');
        //   this.sortColumns('-transactionDate');
        // }
      });
  }

  sortColClick(field) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    this.sortCount = false;
  }

  correctOrder(field) {
    let tempData = [];
    tempData = this.paymentsInfo;
    this.paymentsInfo = [];
    let order = field.charAt(0) === '-' ? 'desc' : 'asc';
    if (this.paymentsInfoTemp.length > 0) {
      this.paymentsInfoTemp.sort(this.compareValues(field, order));
    } else {
      tempData.sort(this.compareValues(field, order));
    }

    this.paymentsInfoTemp = tempData;
    this.paymentsInfo = this.paymentsInfoTemp;
  }

  sortColumns(field) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    field = !this.orderByField.includes(field) ? field : '-' + field;
    if (field.includes('-')) {
      let indx = this.orderByField.indexOf(field.substring(1));
      if (indx != -1) {
        this.orderByField.splice(indx);
      }
    }
    if (!field.includes('-')) {
      let indx = this.orderByField.indexOf('-' + field);
      if (indx != -1) {
        this.orderByField.splice(indx);
      }
    }
    if (this.orderByField.indexOf(field) == -1) {
      this.orderByField.push(field);
    }
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }
}
