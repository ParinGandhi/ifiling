import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealPartyComponent } from './real-party.component';

describe('RealPartyComponent', () => {
  let component: RealPartyComponent;
  let fixture: ComponentFixture<RealPartyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealPartyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealPartyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
