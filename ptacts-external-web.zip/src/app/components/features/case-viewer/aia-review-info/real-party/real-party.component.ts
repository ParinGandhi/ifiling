import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer.service';

@Component({
  selector: 'app-real-party',
  templateUrl: './real-party.component.html',
  styleUrls: ['./real-party.component.scss'],
})
export class RealPartyComponent implements OnInit {
  petitionInfo: any = null;
  @Input() realPartyInfo: any;
  @Input() poRealPartyInfo: any;
  @Output() updateRealParty: EventEmitter<boolean> =
    new EventEmitter<boolean>();

  lastRefresh = new Date();
  refreshSort: boolean;

  constructor(
    private caseViewerService: CaseViewerService,
    public commonUtils: CommonUtilitiesService
  ) {}

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    // this.getRealPartyInfo();
  }

  refresh(val) {
    this.refreshSort = val;
    // this.getRealPartyInfo();
    this.updateRealParty.emit(true);
    this.lastRefresh = new Date();
  }

  getRealPartyInfo() {
    this.caseViewerService
      .getCounselInfo(this.petitionInfo.proceedingNumberText)
      .subscribe((data) => {
        if (data.petitionRealParty) {
          this.realPartyInfo = data.petitionRealParty.parties;
        }
        if (data.poRealParty) {
          this.poRealPartyInfo = data.poRealParty.parties;
        }
      });
  }
}
