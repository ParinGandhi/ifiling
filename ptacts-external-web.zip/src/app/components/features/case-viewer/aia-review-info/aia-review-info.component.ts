import { Location } from '@angular/common';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CaseViewerService } from '../case-viewer.service';
import { DocumentsComponent } from './documents/documents.component';

@Component({
  selector: 'app-aia-review-info',
  templateUrl: './aia-review-info.component.html',
  styleUrls: ['./aia-review-info.component.scss'],
})
export class AiaReviewInfoComponent implements OnInit, AfterViewInit {
  @ViewChild(DocumentsComponent)
  private documentsChildComponent: DocumentsComponent;

  petitionInfo: any;
  showClaims: boolean;
  isRealParty: boolean = false;
  isDocClaims: boolean = true;
  isCounsel: boolean = false;
  isPayments: boolean = false;
  isClaimsTabActive: boolean = false;
  caseInfo = {
    serialNo: null,
    proceedingNo: null,
  };
  docuementHeaderName: any;
  counselInfo: any;
  petitionerCounsel: any;
  poCounsel: any;
  rpInfo: any;
  realPartyInfo: any;
  poRealPartyInfo: any;
  staffActions = {
    petitionerStaffCount: 0,
    patentOwnerStaffCount: 0,
    showPetitionerButton: false,
    showPatentOwnerButton: false,
    showPetitionerActions: false,
    showPatentOwnerActions: false,
  };
  loggedInUserEmail: string = null;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private caseViewerService: CaseViewerService
  ) {}

  ngOnInit(): void {
    const rehearingInfo = this.router.getCurrentNavigation();
    this.caseInfo = {
      serialNo: this.activatedRoute.snapshot.params['applicationNumber'],
      proceedingNo: this.activatedRoute.snapshot.params['caseNumber'],
    };
    if (window.sessionStorage.getItem('petitionInfo')) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }
    if (this.petitionInfo.trialType == 'DER') {
      this.showClaims = false;
      this.docuementHeaderName = 'Documents';
    } else {
      this.showClaims = true;
      this.docuementHeaderName = 'Documents & claims';
    }
    this.loggedInUserEmail = window.sessionStorage.getItem('email');
    this.getPartiesInfo();
  }

  ngAfterViewInit() {
    const rehearingInfo = window.sessionStorage.getItem('rehearingInfo');
    const motionInfo = window.sessionStorage.getItem('motionInfo');
    if (rehearingInfo) {
      this.documentsChildComponent.openRehearingRequestModal();
    } else if (motionInfo) {
      this.documentsChildComponent.openMotionsModal('MOTION');
    }
  }

  isDocClaimsOpen() {
    this.isDocClaims = !this.isDocClaims;
  }

  isRealPartyOpen() {
    this.isRealParty = !this.isRealParty;
  }

  isCounselOpen() {
    this.isCounsel = !this.isCounsel;
  }

  isPaymentsOpen() {
    this.isPayments = !this.isPayments;
  }

  expandCollapse(isExpand) {
    let sections = document.getElementsByClassName(
      'caseviewerSection'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const tag of Array.from(sections)) {
      if (isExpand) {
        tag.classList.add('show');
      } else {
        tag.classList.remove('show');
      }
    }

    let sectionButtons = document.getElementsByClassName(
      'caseviewerSectionBtn'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const btn of Array.from(sectionButtons)) {
      if (isExpand) {
        btn.classList.remove('collapsed');
        btn.setAttribute('aria-expanded', 'true');
      } else {
        btn.classList.add('collapsed');
        btn.setAttribute('aria-expanded', 'false');
      }
    }
  }

  getPartiesInfo() {
    this.caseViewerService
      .getCounselInfo(this.petitionInfo.proceedingNumberText)
      .subscribe((data) => {
        this.counselInfo = data;
        this.rpInfo = data;
        if (data.petitionCounsel) {
          data.petitionCounsel.parties.sort(this.sortCounselType);
          this.petitionerCounsel = data.petitionCounsel.parties;
          this.filterStaff(this.petitionerCounsel, 'petitioner');
        }
        if (data.poCounsel) {
          data.petitionCounsel.parties.sort(this.sortCounselType);
          this.poCounsel = data.poCounsel.parties;
          this.filterStaff(this.poCounsel, 'patentowner');
        }
        if (data.petitionRealParty) {
          this.realPartyInfo = data.petitionRealParty.parties;
        }
        if (data.poRealParty) {
          this.poRealPartyInfo = data.poRealParty.parties;
        }
      });
  }

  filterStaff(parties, partyRep) {
    if (partyRep === 'petitioner') {
      this.staffActions.petitionerStaffCount = 0;
    } else {
      this.staffActions.patentOwnerStaffCount = 0;
    }
    parties.forEach((party) => {
      if (party.partySubType.toLowerCase() === 'staff') {
        if (partyRep === 'petitioner') {
          this.staffActions.petitionerStaffCount++;
        } else {
          this.staffActions.patentOwnerStaffCount++;
        }
      }
      if (
        party.partySubType.toLowerCase() === 'lead' &&
        party.personType.length > 0
      ) {
        party.personType[0].electronicAddress.forEach((address) => {
          if (
            address.hasOwnProperty('email') &&
            address.email === this.loggedInUserEmail
          ) {
            if (partyRep === 'petitioner') {
              this.staffActions.showPetitionerButton = true;
            } else if (partyRep === 'patentowner') {
              this.staffActions.showPatentOwnerButton = true;
            }
          }
        });
      }
    });
  }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }
}
