import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiaReviewInfoComponent } from './aia-review-info.component';

describe('AiaReviewInfoComponent', () => {
  let component: AiaReviewInfoComponent;
  let fixture: ComponentFixture<AiaReviewInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AiaReviewInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AiaReviewInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
