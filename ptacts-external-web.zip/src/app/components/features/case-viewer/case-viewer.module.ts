import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared.module';
import { CaseViewerComponent } from './case-viewer.component';
import { CaseViewerRoutingModule } from './case-viewer-routing.module';
import { HeaderComponent } from './header/header.component';
import { AiaReviewInfoComponent } from './aia-review-info/aia-review-info.component';
import { DocumentsComponent } from './aia-review-info/documents/documents.component';
import { MotionsModalComponent } from './aia-review-info/documents/motions-modal/motions-modal.component';
import { DocumentSectionComponent } from './aia-review-info/documents/motions-modal/document-section/document-section.component';
import { ClaimsComponent } from './aia-review-info/claims/claims.component';
import { RealPartyComponent } from './aia-review-info/real-party/real-party.component';
import { CounselComponent } from './aia-review-info/counsel/counsel.component';
import { PaymentsComponent } from './aia-review-info/payments/payments.component';
import { DataTableComponent } from 'src/app/components/common/data-table/data-table.component';
import { RehearingRequestsCvComponent } from './rehearing-requests-cv/rehearing-requests-cv.component';
import { RehearingsModalComponent } from './aia-review-info/documents/rehearings-modal/rehearings-modal.component';
import { MotionsCvComponent } from './motions-cv/motions-cv.component';
import { PrelimResponseModalComponent } from './aia-review-info/documents/prelim-response-modal/prelim-response-modal.component';
import { NoticeOfAppealModalComponent } from './aia-review-info/documents/notice-of-appeal-modal/notice-of-appeal-modal.component';
import { NoticeOfAppealsCvComponent } from './notice-of-appeals-cv/notice-of-appeals-cv.component';
import { OtherDocumentsModalComponent } from './aia-review-info/documents/other-documents-modal/other-documents-modal.component';
import { StaffModalComponent } from './aia-review-info/counsel/staff-modal/staff-modal.component';
import { DeleteStaffModalComponent } from './aia-review-info/counsel/delete-staff-modal/delete-staff-modal.component';

@NgModule({
  declarations: [
    CaseViewerComponent,
    HeaderComponent,
    AiaReviewInfoComponent,
    DocumentsComponent,
    MotionsModalComponent,
    DocumentSectionComponent,
    // ListOfDocumentsComponent,
    ClaimsComponent,
    RealPartyComponent,
    CounselComponent,
    PaymentsComponent,
    //DataTableComponent,
    RehearingRequestsCvComponent,
    RehearingsModalComponent,
    MotionsCvComponent,
    PrelimResponseModalComponent,
    NoticeOfAppealModalComponent,
    NoticeOfAppealsCvComponent,
    OtherDocumentsModalComponent,
    StaffModalComponent,
    DeleteStaffModalComponent,
  ],
  imports: [CommonModule, SharedModule, CaseViewerRoutingModule],
})
export class CaseViewerModule {}
