import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticeOfAppealsCvComponent } from './notice-of-appeals-cv.component';

describe('NoticeOfAppealsCvComponent', () => {
  let component: NoticeOfAppealsCvComponent;
  let fixture: ComponentFixture<NoticeOfAppealsCvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoticeOfAppealsCvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NoticeOfAppealsCvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
