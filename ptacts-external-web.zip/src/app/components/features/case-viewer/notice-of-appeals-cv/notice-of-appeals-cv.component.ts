import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { DatePipe } from '@angular/common';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-notice-of-appeals-cv',
  templateUrl: './notice-of-appeals-cv.component.html',
  styleUrls: ['./notice-of-appeals-cv.component.scss'],
})
export class NoticeOfAppealsCvComponent implements OnInit {
  expanded: boolean = false;
  allClassActive: boolean = false;
  pendingClassActive: boolean = false;
  unsubmittedClassActive: boolean = false;
  tableOptions: any;
  dataList: any;
  motions = {
    ALL: [],
    INITIATED: [],
    PENDING_REVIEW: [],
  };
  orderByField: any[] = [];
  petitionInfo: any = null;
  petitionIdentifier: any;
  loading: boolean = true;

  constructor(
    public commonUtils: CommonUtilitiesService,
    private datePipe: DatePipe,
    private caseViewerService: CaseViewerService,
    private logger: NGXLogger,
    private initiatePetitionService: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.pendingClassActive = true;
    this.getAppealsOnProceeding();
    this.getPetitionIdentifier();
  }

  getAppealsOnProceeding() {
    this.loading = true;
    this.caseViewerService
      .getAppealsOnProceeding(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (appealList) => {
          this.dataList = appealList;
          this.setMotionsTable();
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
  }

  setMotionsTable() {
    this.tableOptions = {
      //btnId: this.REHEARINGS,
      tableId: 'noticeOfAppealTable',
      tableHeaderClass: 'noticeOfAppealTableHeader',
      tableBodyClass: 'noticeOfAppealTableBody',
      columnDefs: [
        {
          name: 'Filing date (mm/dd/yyyy)',
          displayName: 'Filing date (mm/dd/yyyy)',
          field: 'filingDate',
          width: '185px',
          minWidth: '185px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Date appeal filed (mm/dd/yyyy)',
          displayName: 'Date appeal filed (mm/dd/yyyy)',
          field: 'appealNoticeDt',
          width: '185px',
          minWidth: '185px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Filing Party',
          displayName: 'Filing party',
          field: 'requestorTypeName',
          width: '140px',
          minWidth: '140px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Appeal status',
          displayName: 'Appeal status',
          field: 'appealStatusCd',
          width: '140px',
          minWidth: '140px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Court decision date',
          displayName: 'Court decision date',
          field: 'courtDecisionDt',
          width: '170px',
          minWidth: '170px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Decision by',
          displayName: 'Decision by',
          field: 'exteralCourtDecisionBy',
          width: '170px',
          minWidth: '170px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'Court mandate date',
          displayName: 'Court mandate date',
          field: 'courtMandateDt',
          width: '170px',
          minWidth: '170px',
          type: 'string',
          searchText: null,
        },
        {
          name: 'View appeal',
          displayName: 'View appeal',
          field: 'viewNotice',
          width: '140px',
          minWidth: '140px',
          type: 'string',
          searchText: null,
        },
      ],
      data: this.dataList ? JSON.parse(JSON.stringify(this.dataList)) : null,
    };
    this.orderByField.push('filingDate');
    this.sortColumn('filingDate', 'desc');
  }

  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    });
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field, sortType)
      : this.correctOrder('-' + field, sortType);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
  }

  correctOrder(field, sortType) {
    if (this.dataList && this.dataList.length > 0) {
      this.dataList.forEach((ele) => {
        if (ele.motionStatusDate === undefined) {
          ele.motionStatusDate = null;
        }
      });
      const tempData = [...this.dataList];
      this.dataList = [];
      const order = field.charAt(0) === '-' ? 'desc' : 'asc';
      tempData.sort(this.compareValues(field, order));
      this.dataList = [...tempData];
    }
  }

  exportCSVFile(fileTitle) {
    fileTitle = `${fileTitle} ${this.commonUtils.getCurrentDateString(
      new Date()
    )}`;
    const dataToExport = [];
    this.dataList.forEach((element) => {
      let row: any = {};
      row.filingDate = this.datePipe.transform(
        element.filingDate,
        'MM/dd/yyyy'
      );
      row.appealNoticeDt = this.datePipe.transform(
        element.appealNoticeDt,
        'MM/dd/yyyy'
      );
      row.requestorTypeName = this.commonUtils.convertStringToTitleCase(
        element.requestorTypeName
      );
      row.appealStatusCd = this.commonUtils.convertStringToTitleCase(
        element.appealStatusCd
      );
      row.courtDecisionDt = element.courtDecisionDt
        ? this.datePipe.transform(element.courtDecisionDt, 'MM/dd/yyyy')
        : null;
      row.externalCourtDecisionBy = element.exteralCourtDecisionBy;
      row.courtMandateDt = element.courtMandateDt
        ? this.datePipe.transform(element.courtMandateDt, 'MM/dd/yyyy')
        : null;
      dataToExport.push(row);
    });
    let headers = [
      'Filing date (mm/dd/yyyy)',
      'Date appeal filed (mm/dd/yyyy)',
      'Filing party',
      'Appeal status',
      'Court decision date (mm/dd/yyyy)',
      'Decision by',
      'Court mandate date (mm/dd/yyyy)',
    ];
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);
  }

  openPdf(data, proceedingId) {
    this.caseViewerService.openPdf(
      this.petitionIdentifier,
      data.artifactIdentifer
    );
    // .pipe(take(1))
    // .subscribe(
    //   (pdfResponse) => {
    //     this.commonUtils.openPdfNew(pdfResponse);
    //   },
    //   (pdfResponseError) => {
    //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   }
    // );
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }
}
