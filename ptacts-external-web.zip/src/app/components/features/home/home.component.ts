import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { setAnonymousSearch } from 'src/app/store/ptacts/ptacts.actions';
import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { Router } from '@angular/router';
import { HomeService } from './home.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  caseSearch: CaseSearchModel = new CaseSearchModel();
  trialTypes = [
    {
      name: 'IPR',
      checked: true,
    },
    {
      name: 'PGR',
      checked: true,
    },
    {
      name: 'CBM',
      checked: true,
    },
    {
      name: 'DER',
      checked: true,
    },
  ];

  htmlContent = {
    contactUs: '',
    information: '',
    poRespondent: '',
    petitioner: '',
    welcome: '',
  };

  constructor(
    private store: Store<PtactsState>,
    private router: Router,
    private homeService: HomeService
  ) {}

  ngOnInit(): void {
    this.getTabsHtml();
  }

  getTabsHtml() {
    this.homeService
      .getHomeTabsHtml()
      .pipe(take(1))
      .subscribe((htmlDataResponse: any) => {
        if (htmlDataResponse) {
          htmlDataResponse.forEach((homeTab) => {
            this.htmlContent[homeTab.valueText] = homeTab.descriptionText;
          });
        }
      });
  }

  search() {
    window.sessionStorage.setItem('email', 'anonymous');
    this.caseSearch.trailTypes = [];
    this.trialTypes.forEach((trialType) => {
      if (trialType.checked) {
        this.caseSearch.trailTypes.push(trialType.name);
      }
    });

    this.store.dispatch(
      setAnonymousSearch({
        anonymousSearch: JSON.parse(JSON.stringify(this.caseSearch)),
      })
    );

    this.router.navigate(['/ui/public-search']);
  }

  clear() {
    this.caseSearch = new CaseSearchModel();
    this.trialTypes.forEach((trialType) => {
      trialType.checked = true;
    });
  }
}
