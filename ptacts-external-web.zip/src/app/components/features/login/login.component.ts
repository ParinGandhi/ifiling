import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  changeLoading,
  getLoginDetailsForNonOKTA,
  getUserDetails,
  setUserDetails,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';

import { NGXLogger } from 'ngx-logger';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { LoginService } from './login.service';
import { take } from 'rxjs/operators';
import { HomeService } from '../home/home.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  userId: string;
  errorMessage: string = null;

  constructor(
    private logger: NGXLogger,
    private store: Store<PtactsState>,
    private router: Router,
    private commonUtils: CommonUtilitiesService,
    private loginService: LoginService,
    private homeService: HomeService
  ) {}

  ngOnInit(): void {}

  login(loginForm: NgForm) {
    if (loginForm.value.userName) {
      window.sessionStorage.setItem(
        'email',
        loginForm.value.userName.toLowerCase()
      );
    }
    this.store.dispatch(
      getLoginDetailsForNonOKTA(loginForm.value.userName.toLowerCase())
    );
    // this.loginService
    //   .getUserInfo(loginForm.value.userName)
    //   .pipe(take(1))
    //   .subscribe(
    //     (userInfo) => {this.router.navigate(['/ui/my-docket']);
    //       // const userDetails = {
    //       //   lastName: userInfo.lastName,
    //       //   patronId: null,
    //       //   displayName: null,
    //       //   roles: userInfo.roles,
    //       //   userId: userInfo.emailId,
    //       //   employeeNumber: null,
    //       //   firstName: userInfo.firstName,
    //       //   emailAddress: userInfo.emailId,
    //       //   ptabDefaultRefreshTime: userInfo.ptabDefaultRefreshTime,
    //       //   employeeType: null,
    //       //   ptabReadOnlyUser: userInfo.ptabReadOnlyUser,
    //       //   clientIP: null,
    //       //   middleName: null,
    //       //   passwordExpired: null,
    //       //   authLevel: null,
    //       // };
    //       // this.store.dispatch(
    //       //   setUserDetails({
    //       //     payload: userDetails,
    //       //   })
    //       // );
    //       this.store.dispatch(getUserDetails());

    //       window.sessionStorage.removeItem('source');
    //       window.sessionStorage.setItem('userInfo', JSON.stringify(userInfo));
    //       this.store.dispatch(
    //         setUserIdAction({
    //           payload: `${userInfo.lastName}, ${userInfo.firstName}`,
    //         })
    //       );
    //       // this.getLoggedInUserDetails();
    //       window.sessionStorage.setItem('email', userInfo.emailId);
    //
    //     },
    //     (loginFailure) => {
    //       this.errorMessage = loginFailure.error.message;
    //       window.sessionStorage.setItem('email', 'anonymous');
    //     }
    //   );

    // this.commonUtils.showSuccess(`login success`,'');

    // this.logger.info('Login form: ', loginForm.value);
    // this.loginService
    //   .getUsers(loginForm.value)
    //   .pipe(take(1))
    //   .subscribe(
    //     (userInfo) => {
    //       this.store.dispatch(
    //         setUserIdAction({
    //           payload: `${userInfo.lastName}, ${userInfo.firstName}`,
    //         })
    //       );
    //       this.router.navigate(['/my-docket']);
    //     },
    //     (userResponseFailure) => {
    //       this.logger.error('Login failed', userResponseFailure);
    //       this.errorMessage = userResponseFailure.error.message;
    //       this.clearForm(loginForm);
    //     }
    //   );
    this.router.navigate(['/ui/my-docket']);    
  }

  getLoggedInUserDetails() {
    this.homeService
      .getLoggedInUserDetails()
      .pipe(take(1))
      .subscribe((loggedInUserDetails: any) => {
        this.store.dispatch(setUserDetails({ payload: loggedInUserDetails }));
        if (loggedInUserDetails && loggedInUserDetails.userId) {
          window.sessionStorage.setItem('email', loggedInUserDetails.userId);
        }
        // $.sessionTimeoutWidget.staySignedIn();
      });
  }

  clearForm(loginForm) {
    loginForm.reset();
  }

  changeLoading() {
    this.store.dispatch(changeLoading({ request: true }));
  }
}
