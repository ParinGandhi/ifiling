import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { CancelComponent } from './cancel/cancel.component';
import { ErrorReceiptComponent } from './error-receipt/error-receipt.component';
import { ExternalComponent } from './external.component';
import { ReceiptComponent } from './receipt/receipt.component';

const routes: Routes = [
  {
    path: '',
    component: ExternalComponent,
    children: [
      {
        path: 'receipt',
        component: ReceiptComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'errorReceipt',
        component: ErrorReceiptComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'cancel',
        component: CancelComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ExternalRoutingModule {}
