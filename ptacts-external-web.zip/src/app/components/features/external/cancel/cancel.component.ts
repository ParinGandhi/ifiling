import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cancel',
  templateUrl: './cancel.component.html',
  styleUrls: ['./cancel.component.scss']
})
export class CancelComponent implements OnInit {

  constructor(private router: Router,private zone: NgZone) { }

  ngOnInit(): void {
    this.zone.run(() => {
      this.router.navigate(['/ui/initiate-petition/review']);
    });
  }

}
