import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-error-receipt',
  templateUrl: './error-receipt.component.html',
  styleUrls: ['./error-receipt.component.scss'],
})
export class ErrorReceiptComponent implements OnInit {
  petitionInfo: any;
  petitionIdentifier: any;
  isPHV: boolean = true;
  paymentData: any;
  paymentSummary = [];
  paymentStatus: boolean = false;
  petitionStatus = {
    successful: false,
    unsuccessful: false,
  };
  serialNumber: string = null;
  poLabelValue: any;
  printing: boolean = false;
  motionPaymentFailed: boolean = false;
  motionSubmitted: boolean = false;

  constructor(
    public initiatePetitionService: InitiatePetitionService,
    private commonUtils: CommonUtilitiesService,
    private caseViewerService: CaseViewerService
  ) {}

  ngOnInit(): void {
    const url = document.location.href.split('/');

    this.petitionIdentifier = url[url.indexOf('petition') + 1];
    this.petitionInfo = window.sessionStorage.getItem('petitionInfo');
    if (this.petitionInfo) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }

    const paymentType = window.sessionStorage.getItem('paymentType');
    if (paymentType) {
      this.isPHV = true;
      this.getMotionsPaymentReceipt(paymentType);
    } else {
      this.isPHV = false;
      this.getPaymentReceipt();
    }
  }

  getMotionsPaymentReceipt(motionId) {
    this.caseViewerService
      .getMotionByMotionId(motionId)
      .subscribe((motionData: any) => {
        this.motionSubmitted =
          motionData.motionStatus.toLowerCase() === 'pending review';
        if (!motionData.commentText || motionData.commentText.trim() === '') {
          this.motionPaymentFailed = true;
          // this.getSpecificMotionDetails(motionData.paymentId);
        } else {
          const commentText = motionData.commentText.split('@');
          if (commentText.length === 1) {
            this.motionPaymentFailed = true;
          }
          this.getSpecificMotionDetails(commentText[0]);
        }
        // this.getBasicPetitionDetails();
      });
  }

  getPaymentReceipt() {
    this.initiatePetitionService
      .getPaymentsReceipt(this.petitionIdentifier)
      .subscribe((Response) => {
        this.paymentData = Response;
        Object.keys(this.paymentData.transactionVOs).forEach((key) => {
         
          this.paymentSummary.push(this.paymentData.transactionVOs[key]);
        });
        if (this.paymentData?.paymentStatusCode == 'CLEARED') {
          this.paymentStatus = true;
        }
        this.getBasicPetitionDetails();
        this.getPetitionIdentifier();
      });
  }

  getSpecificMotionDetails(paymentId) {
    this.caseViewerService
      .getSpecificMotionPaymentDetails(this.petitionIdentifier, paymentId)
      .subscribe((specificMotionPaymentInfo) => {
       
        this.paymentData = specificMotionPaymentInfo;
        Object.keys(this.paymentData.transactionVOs).forEach((key) => {
         
          this.paymentSummary.push(this.paymentData.transactionVOs[key]);
        });
        if (this.paymentData?.paymentStatusCode == 'CLEARED') {
          this.paymentStatus = true;
        }
        this.getBasicPetitionDetails();
        this.getPetitionIdentifier();
      });
  }

  getBasicPetitionDetails() {
    this.initiatePetitionService
      // .getBasicPetitionDetails(this.petitionInfo.proceedingNumberText)
      // .getBasicPetitionDetails(this.petitionInfo.proceedingNumberText)
      .getBasicPetitionDetails(this.paymentData.proceedingNumber)
      .subscribe((Response) => {
        if (Response?.caseStateSummary?.stateId >= 2) {
          // this.petitionStatus = true;
          this.petitionStatus.successful = true;
        } else {
          // this.petitionStatus = false;
          this.petitionStatus.unsuccessful = true;
        }
      });
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      // .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .getCaseInfoByProceedingNo(this.paymentData.proceedingNumber)
      .subscribe((caseInfoByProceedingResponse) => {
        // this.petitionIdentifier =
        //   caseInfoByProceedingResponse.petitionIdentifier;
        this.poLabelValue = caseInfoByProceedingResponse.patentNumber;
        this.getCaseInfo();
        // const paymentType = window.sessionStorage.getItem('paymentType');
        // if (paymentType) {
        //   this.getMotionsPaymentReceipt(paymentType);
        // } else {
        //   this.getPaymentReceipt();
        // }
      });
  }

  getCaseInfo() {
    this.caseViewerService
      .caseSearch(this.paymentData.proceedingNumber)
      .pipe(take(1))
      .subscribe((caseInfoResponse) => {
       
        if (caseInfoResponse.serialNumber && caseInfoResponse.serialNumber[0]) {
          this.serialNumber = caseInfoResponse.serialNumber[0];
        }
      });
  }

  openPDF(): void {
    this.printing = true;
    this.commonUtils.generateReceiptPdf('successReceipt');
    setTimeout(() => {
      this.printing = false;
    }, 5000);
  }

  openCaseViewer() {
    this.commonUtils.openCaseViewer(
      this.paymentData.proceedingNumber,
      '/aia-review-info',
      '_blank'
    );
  }
}
