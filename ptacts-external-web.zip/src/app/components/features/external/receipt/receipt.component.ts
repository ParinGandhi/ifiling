import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';
// import jsPDF from 'jspdf';
// import html2canvas from 'html2canvas';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.scss'],
})
export class ReceiptComponent implements OnInit {
  petitionInfo: any;
  petitionIdentifier: any;
  paymentData: any;
  paymentSummary = [];
  poLabelValue: any;
  // petitionStatus: boolean;
  petitionStatus = {
    successful: false,
    unsuccessful: false,
  };
  paymentStatus: boolean = false;
  printing: boolean = false;
  isPHV: boolean = true;
  serialNumber: string = null;
  motionSubmitted: boolean = false;
  ptactsCaseInfo: any;
  poPatentNumber: any;
  poApplNumber: any;
  pePatentNumber: any;
  peApplNumber: any;

  constructor(
    public initiatePetitionService: InitiatePetitionService,
    private commonUtils: CommonUtilitiesService,
    private caseViewerService: CaseViewerService
  ) {}

  ngOnInit(): void {
    const url = document.location.href.split('/');

    this.petitionIdentifier = url[url.indexOf('petition') + 1];
    this.petitionInfo = window.sessionStorage.getItem('petitionInfo');
    if (this.petitionInfo) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }
    // this.petitionInfo = {
    //   proceedingNumberText: 'IPR2022-01647',
    // };

    // this.getPetitionIdentifier();
    // this.petitionIdentifier = 1547661;
    // this.getBasicPetitionDetails();
    // this.getPaymentReceipt();
    const paymentType = window.sessionStorage.getItem('paymentType');
    if (paymentType) {
      this.isPHV = true;
      this.getMotionsPaymentReceipt(paymentType);
      this.getPHVCaseHeaderInfo();
    } else {
      this.isPHV = false;
      this.getPaymentReceipt();
    }
    this.getCaseHeaderInfo();
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      // .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .getCaseInfoByProceedingNo(this.paymentData.proceedingNumber)
      .subscribe((caseInfoByProceedingResponse) => {
        // this.petitionIdentifier =
        //   caseInfoByProceedingResponse.petitionIdentifier;
        this.poLabelValue = caseInfoByProceedingResponse.patentNumber;
        //this.getCaseInfo();
        // const paymentType = window.sessionStorage.getItem('paymentType');
        // if (paymentType) {
        //   this.getMotionsPaymentReceipt(paymentType);
        // } else {
        //   this.getPaymentReceipt();
        // }
      });
  }

  getCaseInfo() {
    this.caseViewerService
      .caseSearch(this.paymentData.proceedingNumber)
      .pipe(take(1))
      .subscribe((caseInfoResponse) => {
       
        if (caseInfoResponse.serialNumber && caseInfoResponse.serialNumber[0]) {
          this.serialNumber = caseInfoResponse.serialNumber[0];
        }
      });
  }

  getPHVCaseHeaderInfo() {
    this.caseViewerService
      .getCaseHeaderInfo(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseHeaderResponse) => {
        this.ptactsCaseInfo = caseHeaderResponse[0];
        if(this.ptactsCaseInfo?.patentNumberText){
          this.poPatentNumber = this.ptactsCaseInfo?.patentNumberText;
        }
        else if(this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPatentOwnerRespondentApplicationNumber){
          this.poApplNumber = this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPatentOwnerRespondentApplicationNumber;
        }
        if(this.ptactsCaseInfo?.petitionerPatentNumber){
          this.pePatentNumber = this.ptactsCaseInfo?.petitionerPatentNumber;
        }
        else if(this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPetitionerApplicationNumber){
          this.peApplNumber = this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPetitionerApplicationNumber;
        }
      });
  }

  getCaseHeaderInfo() {
    // this.caseViewerService
    //   .getCaseHeaderInfo(this.petitionInfo.proceedingNumberText)
    //   .pipe(take(1))
    //   .subscribe((caseHeaderResponse) => {
    //     this.ptactsCaseInfo = caseHeaderResponse[0];
    //    
    //     //this.caseType = this.ptactsCaseInfo.proceedingNumber.substring(0, 3);
    //     if(this.ptactsCaseInfo?.patentNumberText){
    //       this.poPatentNumber = this.ptactsCaseInfo?.patentNumberText;
    //     }
    //     else if(this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPatentOwnerRespondentApplicationNumber){
    //       this.poApplNumber = this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPatentOwnerRespondentApplicationNumber;
    //     }
    //     if(this.ptactsCaseInfo?.petitionerPatentNumber){
    //       this.pePatentNumber = this.ptactsCaseInfo?.petitionerPatentNumber;
    //     }
    //     else if(this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPetitionerApplicationNumber){
    //       this.peApplNumber = this.ptactsCaseInfo?.derproceedingTypeDetails?.firstListedPetitionerApplicationNumber;
    //     }
    //   });

      if(this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.applicationNumberText)
      {
        this.peApplNumber = this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.applicationNumberText;
      }
      else if(this.petitionInfo?.petitionerApplicationNumber)
      {
        this.peApplNumber = this.petitionInfo?.petitionerApplicationNumber;
      }
      if(this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.patentNumber)
      {
        this.pePatentNumber = this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.patentNumber;
      }
      else if(this.petitionInfo?.petitionerPatentNumber)
      {
        this.pePatentNumber = this.petitionInfo?.petitionerPatentNumber;
      }
      if(this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.applicationNumberText)
      {
        this.poApplNumber = this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.applicationNumberText;
      }
      else if(this.petitionInfo?.poApplicationNumber)
      {
        this.poApplNumber = this.petitionInfo?.poApplicationNumber;
      }
      else if(this.petitionInfo?.patentOwnerApplDetails?.applicationNumber)
      {
        this.poApplNumber = this.petitionInfo?.patentOwnerApplDetails?.applicationNumber;
      }
      if(this.petitionInfo.patentOwnerApplDetails?.applicationBasicInformation?.patentNumber)
      {
        this.poPatentNumber = this.petitionInfo.patentOwnerApplDetails?.applicationBasicInformation?.patentNumber;
      }
      else if(this.petitionInfo?.poPatentNumber)
      {
        this.poPatentNumber = this.petitionInfo?.poPatentNumber;
      }
      else if(this.petitionInfo?.patentOwnerApplDetails?.patentNumber)
      {
        this.poPatentNumber = this.petitionInfo?.patentOwnerApplDetails?.patentNumber;
      }
  }

  getMotionsPaymentReceipt(motionId) {
    this.caseViewerService
      .getMotionByMotionId(motionId)
      .subscribe((motionData: any) => {
        // const commentText = motionData.commentText.split('@');
        // this.getSpecificMotionDetails(commentText[0]);
        this.motionSubmitted =
          motionData.motionStatus.toLowerCase() === 'pending review';
        const commentText = motionData.commentText.split('@');
        // if (commentText.length === 1) {
        //   this.motionPaymentFailed = true;
        // }
        this.getSpecificMotionDetails(commentText[0]);
      });
  }

  getSpecificMotionDetails(paymentId) {
    this.caseViewerService
      .getSpecificMotionPaymentDetails(this.petitionIdentifier, paymentId)
      .subscribe((specificMotionPaymentInfo) => {
       
        this.paymentData = specificMotionPaymentInfo;
        Object.keys(this.paymentData.transactionVOs).forEach((key) => {
         
          this.paymentSummary.push(this.paymentData.transactionVOs[key]);
        });
        if (this.paymentData?.paymentStatusCode == 'CLEARED') {
          this.paymentStatus = true;
        }
        this.getBasicPetitionDetails(specificMotionPaymentInfo);
        this.getPetitionIdentifier();
      });
  }

  getPaymentReceipt() {
    this.initiatePetitionService
      .getPaymentsReceipt(this.petitionIdentifier)
      .subscribe((Response) => {
        this.paymentData = Response;
        Object.keys(this.paymentData.transactionVOs).forEach((key) => {
         
          this.paymentSummary.push(this.paymentData.transactionVOs[key]);
        });
        if (this.paymentData?.paymentStatusCode == 'CLEARED') {
          this.paymentStatus = true;
        }
        this.getBasicPetitionDetails(Response);
        this.getPetitionIdentifier();
      });
  }

  getBasicPetitionDetails(Response) {
    // this.initiatePetitionService
    //   // .getBasicPetitionDetails(this.petitionInfo.proceedingNumberText)
    //   // .getBasicPetitionDetails(this.petitionInfo.proceedingNumberText)
    //   .getBasicPetitionDetails(this.paymentData.proceedingNumber)
    //   .subscribe((Response) => {
        if (Response?.caseStateSummary?.stateId >= 2) {
          // this.petitionStatus = true;
          this.petitionStatus.successful = true;
        } else {
          // this.petitionStatus = false;
          this.petitionStatus.unsuccessful = true;
        }
      // });
  }

  openPDF(): void {
    this.printing = true;
    this.commonUtils.generateReceiptPdf('successReceipt');
    setTimeout(() => {
      this.printing = false;
    }, 5000);
  }

  openCaseViewer() {
    this.commonUtils.openCaseViewer(
      this.paymentData.proceedingNumber,
      '/aia-review-info',
      '_blank'
    );
  }
}
