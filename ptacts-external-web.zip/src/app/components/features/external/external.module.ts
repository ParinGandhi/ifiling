import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared.module';
import { ExternalComponent } from './external.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { ErrorReceiptComponent } from './error-receipt/error-receipt.component';
import { ExternalRoutingModule } from './external-routing.module';
import { CancelComponent } from './cancel/cancel.component';

@NgModule({
  declarations: [ExternalComponent, ReceiptComponent, ErrorReceiptComponent, CancelComponent],
  imports: [CommonModule, SharedModule, ExternalRoutingModule],
})
export class ExternalModule {}
