import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounselMnComponent } from './counsel-mn.component';

describe('CounselMnComponent', () => {
  let component: CounselMnComponent;
  let fixture: ComponentFixture<CounselMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CounselMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
