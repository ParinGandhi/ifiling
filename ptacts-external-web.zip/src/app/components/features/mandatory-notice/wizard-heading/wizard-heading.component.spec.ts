import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardHeadingComponent } from './wizard-heading.component';

describe('WizardHeadingComponent', () => {
  let component: WizardHeadingComponent;
  let fixture: ComponentFixture<WizardHeadingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WizardHeadingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardHeadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
