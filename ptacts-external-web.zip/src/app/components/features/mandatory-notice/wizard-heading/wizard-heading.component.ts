import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-heading',
  templateUrl: './wizard-heading.component.html',
  styleUrls: ['./wizard-heading.component.scss'],
})
export class WizardHeadingComponent implements OnInit {
  @Input() title;
  @Input() proceedingNumber;
  @Input() onBehalfOf;

  constructor() {}

  ngOnInit(): void {}
}
