import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { ClearState } from 'src/app/guards/clear-state.guard';
import { CounselGuard } from 'src/app/guards/counsel.guard';
import { WarningMessage } from 'src/app/guards/warning-message.guard';
import { AdditionalRealPartyMnComponent } from './additional-real-party-mn/additional-real-party-mn.component';
import { CounselMnComponent } from './counsel-mn/counsel-mn.component';
import { DocumentsMnComponent } from './documents-mn/documents-mn.component';
import { MandatoryNoticeComponent } from './mandatory-notice.component';
import { PetitionInformationMnComponent } from './petition-information-mn/petition-information-mn.component';
import { RealPartyMnComponent } from './real-party-mn/real-party-mn.component';
import { ReviewMnComponent } from './review-mn/review-mn.component';
import { VerificationMnComponent } from './verification-mn/verification-mn.component';

const routes: Routes = [
  {
    path: '',
    component: MandatoryNoticeComponent,
    canDeactivate: [ClearState],
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'verification',
      },
      {
        path: 'verification',
        component: VerificationMnComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'petition-information',
        component: PetitionInformationMnComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'documents',
        component: DocumentsMnComponent,
        canActivate: [AuthGuard],
        canDeactivate: [WarningMessage],
      },
      {
        path: 'real-party',
        component: RealPartyMnComponent,
        canActivate: [AuthGuard],
        canDeactivate: [WarningMessage],
      },
      {
        path: 'additional-real-party',
        component: AdditionalRealPartyMnComponent,
        canActivate: [AuthGuard],
        canDeactivate: [WarningMessage],
      },
      {
        path: 'counsel',
        component: CounselMnComponent,
        canActivate: [AuthGuard, CounselGuard],
        canDeactivate: [WarningMessage],
      },
      {
        path: 'review',
        component: ReviewMnComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MandatoryNoticeRoutingModule {}
