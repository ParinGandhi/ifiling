import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewMnComponent } from './review-mn.component';

describe('ReviewMnComponent', () => {
  let component: ReviewMnComponent;
  let fixture: ComponentFixture<ReviewMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
