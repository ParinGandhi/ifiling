import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { MandatoryNoticeValidations } from 'src/app/models/common/MandatoryNoticeValidations.model';
import { setMandatoryNoticeValidations } from 'src/app/store/ptacts/ptacts.actions';
import { MandatoryNoticeService } from '../mandatory-notice.service';
import { MandatoryNotice } from 'src/app/models/mandatory-notice/MandatoryNotice.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { InterestedParty } from 'src/app/models/parties/InterestedParty.model';
import { Party } from 'src/app/models/parties/Party.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { CertificationModalComponent } from '../certification-modal/certification-modal.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-review-mn',
  templateUrl: './review-mn.component.html',
  styleUrls: ['./review-mn.component.scss'],
})
export class ReviewMnComponent implements OnInit {
  documentsInfo: any = null;
  realPartyInfo: any = null;
  additionalRealPartyInfo: any = null;
  counselInfo: any = null;
  mandatoryNoticeInfo: any = null;
  noDocumentsMessage: boolean = false;
  noRealPartyMessage: boolean = false;
  noAdditionalRealPartyMessage: boolean = false;
  noCounselMessage: boolean = false;
  validations: MandatoryNoticeValidations = new MandatoryNoticeValidations();
  canSubmit: boolean = false;
  showCounselSection: boolean = false;
  mandatoryNoticeToSubmit: MandatoryNotice = new MandatoryNotice();
  loggedInUser: any = null;
  certifyModalRef: BsModalRef;
  submitting: boolean = false;
  onBehalfOf: string = null;
  fromInternal: boolean = false;

  constructor(
    private store: Store<PtactsState>,
    private logger: NGXLogger,
    public mandatoryNoticeService: MandatoryNoticeService,
    private commonUtils: CommonUtilitiesService,
    private modalService: BsModalService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loggedInUser = JSON.parse(
      window.sessionStorage.getItem('userDetails')
    );
    this.logger.info(
      'Mandatory notice to submit:',
      this.mandatoryNoticeToSubmit
    );
    this.getMandatoryNoticeInfo();
    this.setDocumentsOptions();
    this.setRealPartyOptions();
    this.setAdditionalRealPartyOptions();
    this.setCounselOptions();
    this.getExistingDocuments();
    this.getExistingRealParty();
    this.getExistingAdditionalRealParty();
    this.getExistingCounsel();
    this.store
      .select(PtactsSelectors.getMandatoryNoticeValidations)
      .pipe(take(1))
      .subscribe((mnValidations) => {
        const isEmpty = Object.keys(mnValidations).length === 0;
        if (!isEmpty) {
          this.validations = JSON.parse(JSON.stringify(mnValidations));
        }
      });

    this.store
      .select(PtactsSelectors.getMandatoryNoticeShowCounsel)
      .subscribe((mnShowCounsel) => {
        this.showCounselSection = mnShowCounsel;
      });

    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    if (window.sessionStorage.getItem('source')) {
      this.fromInternal = true;
    }

    this.validateSubmit();
  }

  getMandatoryNoticeInfo() {
    this.store
      .select(PtactsSelectors.getMandatoryState)
      .pipe(take(1))
      .subscribe((mandatoryNoticeInfo) => {
        this.mandatoryNoticeInfo = mandatoryNoticeInfo;
      });
  }

  setDocumentsOptions() {
    this.documentsInfo = {
      tableId: 'documentsTable',
      tableHeaderClass: 'documentsTableHeader',
      tableBodyClass: 'documentsTableBody',
      tableType: 'documents',
      columnDefs: [
        {
          displayName: 'Upload date (mm/dd/yyyy)',
          field: 'challengedGroupClaimList',
          width: '185px',
          showCopy: false,
        },
        {
          displayName: 'Paper type',
          field: 'ground',
          width: null,
          showCopy: false,
        },
        {
          displayName: 'Document name',
          field: 'reasonText',
          width: null,
          showCopy: false,
        },
        {
          displayName: 'Pages',
          field: 'reasonText',
          width: '55px',
          showCopy: false,
        },
        {
          displayName: 'Availability',
          field: 'reasonText',
          width: '155px',
          showCopy: false,
        },
      ],
      data: [],
    };
  }

  setRealPartyOptions() {
    this.realPartyInfo = {
      tableId: 'realPartyTable',
      tableHeaderClass: 'realPartyTableHeader',
      tableBodyClass: 'realPartyTableBody',
      tableType: 'realParty',
      columnDefs: [
        {
          displayName: 'Name',
          field: 'challengedGroupClaimList',
          width: null,
          showCopy: false,
        },
        {
          displayName: 'Individual or Organization',
          field: 'ground',
          width: '14%',
          showCopy: false,
        },
        {
          displayName: 'Address',
          field: 'reasonText',
          width: '20%',
          showCopy: false,
        },
        {
          displayName: 'Email',
          field: 'reasonText',
          width: '20%',
          showCopy: false,
        },
        {
          displayName: 'Phone number',
          field: 'reasonText',
          width: '10%',
          showCopy: false,
        },
        {
          displayName: 'Fax number',
          field: 'reasonText',
          width: '10%',
          showCopy: false,
        },
      ],
      data: null,
    };
  }

  setAdditionalRealPartyOptions() {
    this.additionalRealPartyInfo = {
      tableId: 'additionalRealPartyTable',
      tableHeaderClass: 'additionalRealPartyTableHeader',
      tableBodyClass: 'additionalRealPartyTableBody',
      tableType: 'additionalRealParty',
      columnDefs: [
        {
          displayName: 'Name',
          field: 'name',
          width: null,
          showCopy: false,
        },
        {
          displayName: 'Individual or Organization',
          field: 'type',
          width: '14%',
          showCopy: false,
        },
        {
          displayName: 'Address',
          field: 'address',
          width: '20%',
          showCopy: false,
        },
        {
          displayName: 'Email',
          field: 'email',
          width: '20%',
          showCopy: false,
        },
        {
          displayName: 'Phone number',
          field: 'phone',
          width: '10%',
          showCopy: false,
        },
        {
          displayName: 'Fax number',
          field: 'fax',
          width: '10%',
          showCopy: false,
        },
      ],
      data: [],
    };
  }

  setCounselOptions() {
    this.counselInfo = {
      tableId: 'counselTable',
      tableHeaderClass: 'counselTableHeader',
      tableBodyClass: 'counselTableBody',
      tableType: 'counsel',
      columnDefs: [
        {
          displayName: 'Counsel type',
          field: 'counselType',
          width: '10%',
          showCopy: false,
        },
        {
          displayName: 'Name',
          field: 'name',
          width: '40%',
          showCopy: false,
        },
        {
          displayName: 'Email',
          field: 'email',
          width: null,
          showCopy: true,
        },
        {
          displayName: 'USPTO Reg #',
          field: 'regNo',
          width: '10%',
          showCopy: false,
        },
        {
          displayName: 'Phone number',
          field: 'phoneNo',
          width: '10%',
          showCopy: false,
        },
        {
          displayName: 'Fax number',
          field: 'fax',
          width: '10%',
          showCopy: false,
        },
      ],
      data: [],
    };
  }

  getExistingDocuments() {
    this.store
      .select(PtactsSelectors.getMandatoryNoticeDocuments)
      .pipe(take(1))
      .subscribe((mnDocuments) => {
        if (mnDocuments.length > 0) {
          this.documentsInfo.data = [...mnDocuments];
        } else {
          this.noDocumentsMessage = true;
        }
      });
  }

  getExistingRealParty() {
    this.store
      .select(PtactsSelectors.getMandatoryNoticeRealParty)
      .pipe(take(1))
      .subscribe((mnRealParty) => {
        const isEmpty = Object.keys(mnRealParty).length === 0;
        if (!isEmpty) {
          this.realPartyInfo.data = mnRealParty;
        } else {
          this.noRealPartyMessage = true;
        }
      });
  }

  getExistingAdditionalRealParty() {
    this.store
      .select(PtactsSelectors.getMandatoryNoticeAddtionalRealParty)
      .pipe(take(1))
      .subscribe((mnAdditionalRealParty) => {
        const isEmpty = mnAdditionalRealParty.length <= 0;
        if (!isEmpty) {
          this.additionalRealPartyInfo.data = [...mnAdditionalRealParty];
        } else {
          this.noAdditionalRealPartyMessage = true;
        }
      });
  }

  getExistingCounsel() {
    this.store
      .select(PtactsSelectors.getMandatoryNoticeCounsel)
      .pipe(take(1))
      .subscribe((mnCounsel) => {
        const isEmpty = mnCounsel.length <= 0;
        if (!isEmpty) {
          this.counselInfo.data = [...mnCounsel];
        } else {
          this.noCounselMessage = true;
        }
      });
  }

  validateSubmit() {
    this.canSubmit = true;
    // ! Check if mandatory notice is verified
    if (Object.keys(this.mandatoryNoticeInfo).length === 0) {
      this.validations.validations.verification.incomplete = true;
      this.validations.validations.petitionInfo.incomplete = true;
    }
    // ! Document check
    if (!this.validations.validations.documents.complete) {
      this.canSubmit = false;
      this.validations.validations.documents.incomplete = true;
    }
    // ! Real party check
    if (!this.validations.validations.realParty.complete) {
      this.canSubmit = false;
      this.validations.validations.realParty.incomplete = true;
    }
    if (this.additionalRealPartyInfo.data.length > 0) {
      this.validations.validations.additionalRealParty.complete = true;
    }
    if (
      this.showCounselSection &&
      (!this.validations.validations.counsel.complete ||
        this.validations.validations.counsel.incomplete)
    ) {
      this.canSubmit = false;
      this.validations.validations.counsel.incomplete = true;
    }

    this.store.dispatch(
      setMandatoryNoticeValidations({
        mnValidations: this.validations,
      })
    );
  }

  submit() {
    this.setDocumentsForSubmit();
    this.mandatoryNoticeToSubmit.proceedingParties.poRealParty =
      this.setRealPartyForSubmit(this.realPartyInfo.data);
    this.setAdditionalRealPartyForSubmit(this.additionalRealPartyInfo.data);
    this.setCounselForSubmit(this.counselInfo.data);
    this.setSubmitterInfoForSubmit();
    this.logger.info('Final MN Object:', this.mandatoryNoticeToSubmit);
    this.submitting = true;
    this.mandatoryNoticeService
      .submitMandatoryNotice(this.mandatoryNoticeToSubmit)
      .pipe(take(1))
      .subscribe(
        (mandatoryNoticeSuccess) => {
          this.commonUtils.showSuccess(
            'Successfully submitted mandatory notice',
            'Mandatory notice'
          );
          this.submitting = false;
          this.mandatoryNoticeService.clearValidations();
          this.mandatoryNoticeService.clearState();
          if (this.fromInternal) {
            window.sessionStorage.removeItem('onBehalfOf');
            window.sessionStorage.removeItem('source');
            setTimeout(() => {
              window.close();
            }, 1000);
          } else {
            this.router.navigate(['/ui/my-docket']);
          }
        },
        (mandatoryNoticeFailure) => {
          this.commonUtils.showError(
            mandatoryNoticeFailure.error.message,
            'Mandatory notice failed to submit'
          );
          this.submitting = false;
        }
      );
  }

  setDocumentsForSubmit() {
    this.documentsInfo.data.forEach((doc) => {
      this.logger.info('doc to submit', doc);
      const mandatoryNoticeDocument = new PetitionDocument(
        doc.docType.toUpperCase(),
        doc.documentName,
        doc.fileName,
        doc.filingParty,
        doc.availability.code,
        doc.paperType.identifier,
        doc.paperType.code,
        doc.fileToUpload.type,
        null,
        'N',
        null
      );
      this.mandatoryNoticeToSubmit.petitionDocuments.push(
        mandatoryNoticeDocument
      );
    });
    this.logger.info('MN To Submit:', this.mandatoryNoticeToSubmit);
  }

  setAdditionalRealPartyForSubmit(partyInfo) {
    let index = 2;
    if (partyInfo && partyInfo.length > 0) {
      partyInfo.forEach((realParty) => {
        const additionalRealPartyToAdd: Party = new Party();
        // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
        // additionalRealPartyToAdd.caseNo =
        //   this.mandatoryNoticeInfo.proceedingNumber;
        additionalRealPartyToAdd.submitterType = 'PATENTOWNER';
        additionalRealPartyToAdd.partyType = 'REAL PARTY';
        additionalRealPartyToAdd.partySubType = null;
        additionalRealPartyToAdd.rankNo = index;
        additionalRealPartyToAdd.proseIndicator =
          realParty.formValue.proSe.toLowerCase() === 'no' ? 'N' : 'Y';
        additionalRealPartyToAdd.registrationNo = null;
        if (realParty.formValue.partyType.toLowerCase() === 'individual') {
          additionalRealPartyToAdd.personType[0].firstName =
            realParty.formValue.firstName;
          additionalRealPartyToAdd.personType[0].lastName =
            realParty.formValue.lastName;
          additionalRealPartyToAdd.personType[0].mailingAddress =
            this.addMailingAddress(realParty.formValue);
          additionalRealPartyToAdd.personType[0].electronicAddress =
            this.addElectronicAddress(realParty.formValue);
          additionalRealPartyToAdd.orgType = [];
        } else if (
          realParty.formValue.partyType.toLowerCase() === 'organization'
        ) {
          additionalRealPartyToAdd.orgType[0].legalname =
            realParty.formValue.organizationName;
          additionalRealPartyToAdd.orgType[0].orgAddress =
            this.addMailingAddress(realParty.formValue);
          additionalRealPartyToAdd.orgType[0].electronicAddress =
            this.addElectronicAddress(realParty.formValue);
          additionalRealPartyToAdd.personType = [];
        }
        this.mandatoryNoticeToSubmit.proceedingParties.poRealParty.parties.push(
          additionalRealPartyToAdd
        );
        index++;
      });
      this.logger.info('mandatoryNoticeToSubmit', this.mandatoryNoticeToSubmit);
    }
  }

  setRealPartyForSubmit(partyInfo) {
    const realPartyToAdd = new InterestedParty();
    // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
    realPartyToAdd.caseNo = this.mandatoryNoticeInfo.proceedingNumber;
    realPartyToAdd.parties[0].submitterType = 'PATENTOWNER';
    realPartyToAdd.parties[0].partyType = 'REAL PARTY';
    realPartyToAdd.parties[0].partySubType = null;
    realPartyToAdd.parties[0].rankNo = 1;
    realPartyToAdd.parties[0].proseIndicator =
      partyInfo.proSe.toLowerCase() === 'no' ? 'N' : 'Y';
    realPartyToAdd.parties[0].registrationNo = partyInfo.regNo;
    if (partyInfo.partyType.toLowerCase() === 'individual') {
      realPartyToAdd.parties[0].personType[0].firstName = partyInfo.firstName;
      realPartyToAdd.parties[0].personType[0].lastName = partyInfo.lastName;
      realPartyToAdd.parties[0].personType[0].mailingAddress =
        this.addMailingAddress(partyInfo);
      realPartyToAdd.parties[0].personType[0].electronicAddress =
        this.addElectronicAddress(partyInfo);
      realPartyToAdd.parties[0].orgType = [];
    } else if (partyInfo.partyType.toLowerCase() === 'organization') {
      realPartyToAdd.parties[0].orgType[0].legalname =
        partyInfo.organizationName;
      realPartyToAdd.parties[0].orgType[0].orgAddress =
        this.addMailingAddress(partyInfo);
      realPartyToAdd.parties[0].orgType[0].electronicAddress =
        this.addElectronicAddress(partyInfo);
      realPartyToAdd.parties[0].personType = [];
    }

    return realPartyToAdd;
  }

  setCounselForSubmit(partyInfo) {
    if (partyInfo && partyInfo.length > 0) {
      let index = 1;
      partyInfo.forEach((counsel) => {
        const counselToAdd = new InterestedParty();
        // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
        counselToAdd.caseNo = this.mandatoryNoticeInfo.proceedingNumber;
        counselToAdd.parties[0].submitterType = 'PATENTOWNER';
        counselToAdd.parties[0].partyType = 'COUNSEL';
        counselToAdd.parties[0].partySubType = counsel.partySubType;
        counselToAdd.parties[0].proseIndicator = 'N';
        counselToAdd.parties[0].rankNo = index;
        counselToAdd.parties[0].registrationNo = counsel.regNo;
        counselToAdd.parties[0].personType[0].firstName =
          counsel.form.firstName;
        counselToAdd.parties[0].personType[0].lastName = counsel.form.lastName;
        counselToAdd.parties[0].personType[0].mailingAddress =
          this.addMailingAddress(counsel.form);
        counselToAdd.parties[0].personType[0].electronicAddress =
          this.addElectronicAddress(counsel.form);
        counselToAdd.parties[0].orgType = [];
        if (index > 1) {
          this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties.push(
            counselToAdd.parties[0]
          );
        } else {
          this.mandatoryNoticeToSubmit.proceedingParties.poCounsel =
            counselToAdd;
        }
        index++;
      });

      this.logger.info('mandatoryNoticeToSubmit', this.mandatoryNoticeToSubmit);
    } else if (
      this.mandatoryNoticeToSubmit.proceedingParties.poRealParty.parties[0].proseIndicator.toLowerCase() ===
      'y'
    ) {
      this.mandatoryNoticeToSubmit.proceedingParties.poCounsel = JSON.parse(
        JSON.stringify(
          this.mandatoryNoticeToSubmit.proceedingParties.poRealParty
        )
      );
      if (
        this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties
          .length > 1
      ) {
        this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties.splice(
          1,
          this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties
            .length
        );
      }
      this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties[0].partyType =
        'COUNSEL';
      this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties[0].partySubType =
        'PROSE';
      this.mandatoryNoticeToSubmit.proceedingParties.poCounsel.parties[0].proseIndicator =
        'Y';
      this.logger.info('mandatoryNoticeToSubmit', this.mandatoryNoticeToSubmit);
    }
  }

  setSubmitterInfoForSubmit() {
    const submitterToAdd = new InterestedParty();
    submitterToAdd.caseNo = this.mandatoryNoticeInfo.proceedingNumber;
    submitterToAdd.parties[0].submitterType = 'PATENTOWNER';
    submitterToAdd.parties[0].partyType = 'SUBMITTER';
    submitterToAdd.parties[0].proseIndicator = 'N';
    submitterToAdd.parties[0].rankNo = 1;
    submitterToAdd.parties[0].personType[0].firstName =
      this.loggedInUser.firstName;
    submitterToAdd.parties[0].personType[0].lastName =
      this.loggedInUser.lastName;
    if (this.loggedInUser.emailId) {
      submitterToAdd.parties[0].personType[0].electronicAddress[0].email =
        this.loggedInUser.emailId;
      submitterToAdd.parties[0].personType[0].electronicAddress[0].emailType =
        'WE';
    } else {
      submitterToAdd.parties[0].personType[0].electronicAddress = [];
    }
    submitterToAdd.parties[0].personType[0].mailingAddress = [];
    this.mandatoryNoticeToSubmit.caseNumber =
      this.mandatoryNoticeInfo.proceedingNumber;
    this.mandatoryNoticeToSubmit.partyGroupType = 'PATENTOWNER';
    submitterToAdd.parties[0].orgType = [];

    this.mandatoryNoticeToSubmit.proceedingParties.submitter = submitterToAdd;
  }

  addMailingAddress(mailingAddressInfo) {
    let mailingArray;
    if (
      !mailingAddressInfo.address1 &&
      !mailingAddressInfo.address2 &&
      !mailingAddressInfo.city &&
      !mailingAddressInfo.zip &&
      !mailingAddressInfo.country &&
      !mailingAddressInfo.state
    ) {
      // mailingArray.push(null);
      mailingArray = [];
    } else {
      mailingArray = [];
      let mailObj = {
        country: null,
        streetLineOneText: mailingAddressInfo.address1,
        streetLineTwoText: mailingAddressInfo.address2,
        city: mailingAddressInfo.city,
        state: null,
        zipCode: mailingAddressInfo.zip,
        addressType: 'BUS',
        identifier: null,
      };

      if (
        mailingAddressInfo.country &&
        mailingAddressInfo.country.hasOwnProperty('value')
      ) {
        mailObj.country = mailingAddressInfo.country.value;
      }
      if (
        mailingAddressInfo.state &&
        mailingAddressInfo.state.hasOwnProperty('value')
      ) {
        mailObj.state = mailingAddressInfo.state.value;
      }

      mailingArray.push(mailObj);
    }

    return mailingArray;
  }

  addElectronicAddress(electronicAddressInfo) {
    let tempArr;
    if (
      !electronicAddressInfo.email &&
      !electronicAddressInfo.extension &&
      !electronicAddressInfo.phoneNumber &&
      !electronicAddressInfo.faxNumber
    ) {
      tempArr = [];
    } else {
      tempArr = [];
      let email = {
        email: electronicAddressInfo.email,
        emailType: 'WE',
        extention: null,
        identifier: null,
      };
      let phone = {
        extension: electronicAddressInfo.extension,
        identifier: null,
        teleCommAddresType: 'W',
        telephoneNumber: electronicAddressInfo.phoneNumber,
      };
      let fax = {
        extension: null,
        identifier: null,
        teleCommAddresType: 'F',
        fax: electronicAddressInfo.faxNumber,
      };

      // if (
      //   !electronicAddressInfo.extension ||
      //   !electronicAddressInfo.phoneNumber
      // ) {
      //   phone = null;
      // }
      // if (!electronicAddressInfo.faxNumber) {
      //   fax = null;\
      // }
      tempArr.push(email);
      tempArr.push(phone);
      tempArr.push(fax);
    }

    return tempArr;
  }

  certifySubmit() {
    const initialState: ModalOptions = {
      initialState: {
        certify: false,
      },
      animated: true,
      ignoreBackdropClick: true,
    };
    this.certifyModalRef = this.modalService.show(
      CertificationModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.certifyModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.certify) {
        // action === 'add' ? this.addToList() : this.update();
        this.submit();
      }
    });
  }

  expandCollapse(isExpand) {
    let sections = document.getElementsByClassName(
      'caseviewerSection'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const tag of Array.from(sections)) {
      if (isExpand) {
        tag.classList.add('show', 'in');
        tag.removeAttribute('style');
      } else {
        tag.classList.remove('show', 'in');
      }
    }

    let sectionButtons = document.getElementsByClassName(
      'caseviewerSectionBtn'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const btn of Array.from(sectionButtons)) {
      if (isExpand) {
        btn.classList.remove('collapsed');
        btn.setAttribute('aria-expanded', 'true');
      } else {
        btn.classList.add('collapsed');
        btn.setAttribute('aria-expanded', 'false');
      }
    }
  }
}
