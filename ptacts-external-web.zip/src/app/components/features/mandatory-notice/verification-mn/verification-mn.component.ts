import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { CONSTANTS } from 'src/app/constants/constants';
import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { MandatoryNoticeService } from '../mandatory-notice.service';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import {
  setMandatoryNoticeInfo,
  setMandatoryNoticeValidations,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';
import { MandatoryNoticeValidations } from 'src/app/models/common/MandatoryNoticeValidations.model';

@Component({
  selector: 'app-verification-mn',
  templateUrl: './verification-mn.component.html',
  styleUrls: ['./verification-mn.component.scss'],
})
export class VerificationMnComponent implements OnInit {
  verifiedCaseList: Array<any> = new Array<any>();
  numberToSearch: string = null;
  verificationInfoFound: boolean = false;
  varificationInfoNotFound: boolean = false;
  loading: boolean = false;
  canCreateMandatoryNotice: boolean = false;
  verificationObj: CaseSearchModel;
  orderByField: any[] = [];
  mnVerificationModalRef: BsModalRef;
  selectedRecord: any = null;
  loggedInUser: string = null;
  userInfo: any = null;
  validations: MandatoryNoticeValidations = new MandatoryNoticeValidations();
  onBehalfOf: string = null;

  mnTableOptions = {
    tableId: 'mnTable',
    tableHeaderClass: 'mnTableHeader',
    tableBodyClass: 'mnTableBody',
    headerCheckboxId: 'mnCheckboxId',
    sortCount: true,
    columnDefs: [
      {
        name: 'AIA Review #',
        displayName: 'AIA Review #',
        field: 'proceedingNumber',
        width: '135px',
        minWidth: '135px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'Filing date (mm/dd/yyyy)',
        displayName: 'Filing date (mm/dd/yyyy)',
        field: 'prcdCreatedTsString',
        width: '135px',
        minWidth: '135px',
        type: 'date',
        searchText: null,
      },
      {
        name: 'Petitioner application #',
        displayName: 'Petitioner application #',
        field: 'petiApplicationId',
        width: '125px',
        minWidth: '125px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'Petitioner patent #',
        displayName: 'Petitioner patent #',
        field: 'petiPatentNumber',
        width: '120px',
        minWidth: '120px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'PO/Respondent app #',
        displayName: 'PO/Respondent app #',
        field: 'poApplicationId',
        width: '120px',
        minWidth: '120px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'PO/Respondent patent #',
        displayName: 'PO/Respondent patent #',
        field: 'poPatentNumber',
        width: '120px',
        minWidth: '120px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'Petitioner name',
        displayName: 'Petitioner name',
        field: 'petiRealParty',
        width: '5%',
        minWidth: '175px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'PO/Respondent name',
        displayName: 'PO/Respondent name',
        field: 'poRealParty',
        width: '5%',
        minWidth: '175px',
        type: 'string',
        searchText: null,
      },
      {
        name: 'Status',
        displayName: 'Status',
        field: 'statusDisplay',
        width: '120px',
        minWidth: '120px',
        type: 'string',
        searchText: null,
      },
    ],
  };
  sortCount: boolean = true;

  constructor(
    private mandatoryNoticeService: MandatoryNoticeService,
    private modalService: BsModalService,
    private commonUtils: CommonUtilitiesService,
    private router: Router,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    //! To get user info when coming from internal application
    setTimeout(() => {
      this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    }, 500);
    const prefix = 'fromInternal';
    if (window.name.substring(0, prefix.length) === prefix) {
      window.sessionStorage.setItem('source', 'internal');
      const data = JSON.parse(atob(window.name.substring(prefix.length)));

      // window.sessionStorage.setItem('userInfo', JSON.stringify(data));
      window.sessionStorage.setItem('userDetails', JSON.stringify(data));
      // this.store.dispatch(
      //   setUserIdAction({
      //     payload: `${data.lastName}, ${data.firstName}`,
      //   })
      // );
      window.sessionStorage.setItem('email', data.emailId);
      window.sessionStorage.setItem(
        'onBehalfOf',
        `${data.lastName}, ${data.firstName} (${data.emailId})`
      );
      if (data.cfkPatronId) {
        window.sessionStorage.setItem('cfkPatronId', data.cfkPatronId);
      }
    }
    this.loggedInUser = window.sessionStorage.getItem('email');
    // this.userInfo = JSON.parse(window.sessionStorage.getItem('userInfo'));
    this.userInfo = JSON.parse(window.sessionStorage.getItem('userDetails'));
    this.mandatoryNoticeService.clearValidations();
    this.mandatoryNoticeService.clearState();
    this.store
      .select(PtactsSelectors.getMandatoryNoticeValidations)
      .pipe(take(1))
      .subscribe((mnValidations) => {
        const isEmpty = Object.keys(mnValidations).length === 0;
        if (!isEmpty) {
          this.validations = JSON.parse(JSON.stringify(mnValidations));
        }
      });
  }

  getVerifiedInfo() {
    this.sortCount = true;
    this.verifiedCaseList = [];
    this.verificationInfoFound = false;
    this.varificationInfoNotFound = false;
    this.canCreateMandatoryNotice = false;
    this.loading = true;
    this.verificationObj.isMnNotice = true;
    this.mandatoryNoticeService
      .getVerificationProceedings(this.verificationObj)
      .pipe(take(1))
      .subscribe(
        (verificationResponse) => {
          if (verificationResponse.length <= 0) {
            this.varificationInfoNotFound = true;
            this.loading = false;
          } else if (verificationResponse.length > 0) {
            this.verifiedCaseList = verificationResponse;
            this.verificationInfoFound = true;
            this.loading = false;
            this.orderByField = [];
            this.sortColumn('-prcdCreatedTs', 'desc');
          } else if (
            this.verificationObj.patentNumber &&
            !this.verificationObj.applicationNumber
          ) {
            this.verificationObj.applicationNumber =
              this.verificationObj.patentNumber;
            this.verificationObj.patentNumber = null;
            this.getVerifiedInfo();
          } else {
            this.varificationInfoNotFound = false;
            this.loading = false;
          }
        },
        () => {
          if (
            this.verificationObj.patentNumber &&
            !this.verificationObj.applicationNumber
          ) {
            this.verificationObj.applicationNumber =
              this.verificationObj.patentNumber;
            this.verificationObj.patentNumber = null;
            this.getVerifiedInfo();
          } else {
            this.varificationInfoNotFound = true;
            this.loading = false;
          }
        }
      );
  }

  setVerificationObj() {
    this.clearSearchFields();
    this.verificationObj = new CaseSearchModel();
    if (
      CONSTANTS.TRIAL_TYPES.some((trialType) =>
        this.numberToSearch.toUpperCase().includes(trialType)
      )
    ) {
      this.verificationObj.proceedingNumber = this.numberToSearch.toUpperCase();
    } else {
      // this.verificationObj.patentNumber = this.numberToSearch.toUpperCase();
      this.verificationObj.patentNumber =
        this.commonUtils.cleanPatentAndApplicationNumbers(this.numberToSearch);
    }
    this.getVerifiedInfo();
  }

  onSelection(record) {
    this.canCreateMandatoryNotice = true;
    this.selectedRecord = record;
    this.store.dispatch(
      setMandatoryNoticeInfo({
        mnNotice: record,
      })
    );
  }

  clear() {
    this.numberToSearch = null;
    this.varificationInfoNotFound = false;
    this.verificationInfoFound = false;
    this.canCreateMandatoryNotice = false;
    this.verifiedCaseList = [];
    this.verificationObj = new CaseSearchModel();
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  sortColClick(field) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    this.sortCount = false;
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    if (this.sortCount) {
      this.orderByField = ['-prcdCreatedTsString', '-proceedingNumber'];
    }
  }

  correctOrder(field) {
    let tempData = [];
    tempData = this.verifiedCaseList;
    this.verifiedCaseList = [];
    let order = field.charAt(0) === '-' ? 'desc' : 'asc';
    tempData.sort(this.compareValues(field, order));

    this.verifiedCaseList = tempData;
  }

  clearSearchFields() {
    this.mnTableOptions.columnDefs.forEach((column) => {
      column.searchText = null;
    });
  }

  showAlreadyRepresentingModal() {
    let modalInfo = {
      title: 'Warning',
      infoText: [
        'You are already representing the petitioner for the selected case.',
        'Would you like to submit an updated mandatory notice?',
      ],
      leftBtnClass: 'btn-light',
      leftBtnLabel: 'Go back',
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, add updated mandatory notice',
    };

    this.openWarningModal(modalInfo);
  }

  showMandatoryNoticeExistsModal() {
    let modalInfo = {
      title: 'Mandatory notice exists',
      infoText: [
        'The selected case already has an approved mandatory notice.',
        'Would you like to submit an updated mandatory notice?',
      ],
      leftBtnClass: 'btn-light',
      leftBtnLabel: 'Go back',
      rightBtnClass: 'btn-primary',
      rightBtnLabel: 'Yes, add updated mandatory notice',
    };

    this.openWarningModal(modalInfo);
  }

  openWarningModal(modalInfo) {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: modalInfo.title,
        infoText: modalInfo.infoText,
        showLeftBtn: true,
        leftBtnClass: modalInfo.leftBtnClass,
        leftBtnLabel: modalInfo.leftBtnLabel,
        showRightBtn: true,
        rightBtnClass: modalInfo.rightBtnClass,
        rightBtnLabel: modalInfo.rightBtnLabel,
        modalHeight: 175,
      },
    };
    this.mnVerificationModalRef = this.modalService.show(InfoModalComponent, {
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.mnVerificationModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.commonUtils.openCaseViewer(
          this.selectedRecord.proceedingNumber,
          '/aia-review-info'
        );
      }
    });
  }

  verifyBeforeCreate() {
    const fullName = `${this.userInfo.lastName}, ${this.userInfo.firstName}`;
    // const allPartiesInfo = JSON.parse(this.selectedRecord.allPartiesInfo);
    // const petitionerCounselList = allPartiesInfo?.petitioner?.counselList;
    // const poCounselList = allPartiesInfo?.patentOwner?.counselList;

    this.mandatoryNoticeService
      .getPartyRepresenting(this.selectedRecord.proceedingNumber)
      .pipe(take(1))
      .subscribe(
        (partyRepresenting) => {
          if (partyRepresenting.toLowerCase() === 'patentowner') {
            this.showMandatoryNoticeExistsModal();
          } else if (partyRepresenting.toLowerCase() === 'petitioner') {
            this.showAlreadyRepresentingModal();
          } else {
            window.sessionStorage.setItem(
              'mnProceeding',
              this.selectedRecord.proceedingNumber
            );
            // this.validations.verification.complete = true;
            // const validationTemp = {
            //   validations: this.validations,
            // };
            this.validations.validations.verification.complete = true;
            this.validations.validations.verification.incomplete = false;
            this.validations.validations.verified = true;
            this.store.dispatch(
              setMandatoryNoticeValidations({
                mnValidations: this.validations,
              })
            );

            document.getElementById('mnPetitionInformation').tabIndex = 0;
            document.getElementById('mnDocs').tabIndex = 0;
            document.getElementById('mnRealParty').tabIndex = 0;
            document.getElementById('mnAddRealParty').tabIndex = 0;
            const mnCounsel = document.getElementById('mnCounsel');
            if (mnCounsel) {
              mnCounsel.tabIndex = 0;
            }
            document.getElementById('mnReview').tabIndex = 0;
            document.getElementById('mnVerification').tabIndex = -1;

            this.router.navigate(['/ui/mandatory-notice/petition-information']);
          }
        },
        (noPartyRepresentingFound) => {}
      );

    // if (
    //   petitionerCounselList?.length > 0 &&
    //   petitionerCounselList.some((counselName) =>
    //     fullName.toLowerCase().trim().includes(counselName.toLowerCase().trim())
    //   )
    // ) {
    //   this.showAlreadyRepresentingModal();
    // } else if (
    //   poCounselList?.length > 0 &&
    //   poCounselList.some((counselName) =>
    //     fullName.toLowerCase().trim().includes(counselName.toLowerCase().trim())
    //   )
    // ) {
    //   this.showMandatoryNoticeExistsModal();
    // } else {
    //   window.sessionStorage.setItem(
    //     'mnProceeding',
    //     this.selectedRecord.proceedingNumber
    //   );
    //   // this.validations.verification.complete = true;
    //   // const validationTemp = {
    //   //   validations: this.validations,
    //   // };
    //   this.validations.validations.verification.complete = true;
    //   this.validations.validations.verification.incomplete = false;
    //   this.validations.validations.verified = true;
    //   this.store.dispatch(
    //     setMandatoryNoticeValidations({
    //       mnValidations: this.validations,
    //     })
    //   );
    //   this.router.navigate(['/ui/mandatory-notice/petition-information']);
    // }

    //   this.caseViewerService
    //   .getPartyRepresenting(this.selectedRecord.proceedingNumber)
    //   .pipe(take(1))
    //   .subscribe(
    //     (partyRepresenting) => {
    //       if (partyRepresenting.toLowerCase() === 'patentowner') {
    //         partyRepresenting = 'PATENT OWNER';
    //       }

    //     },
    //     (noPartyRepresentingFound) => {
    //
    //     }
    //   );
  }
}
