import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerificationMnComponent } from './verification-mn.component';

describe('VerificationMnComponent', () => {
  let component: VerificationMnComponent;
  let fixture: ComponentFixture<VerificationMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerificationMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerificationMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
