import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Urls } from 'src/app/constants/urls';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { InfoModalComponent } from '../../common/info-modal/info-modal.component';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import {
  setMandatoryNoticeAdditionalRealParty,
  setMandatoryNoticeCounsel,
  setMandatoryNoticeDocuments,
  setMandatoryNoticeInfo,
  setMandatoryNoticeRealParty,
  setMandatoryNoticeShowCounsel,
  setMandatoryNoticeValidations,
} from 'src/app/store/ptacts/ptacts.actions';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { MandatoryNotice } from 'src/app/models/mandatory-notice/MandatoryNotice.model';
import { MandatoryNoticeValidations } from 'src/app/models/common/MandatoryNoticeValidations.model';
import { WarningModalComponent } from '../../common/warning-modal/warning-modal.component';
import { GridHelperService } from 'src/app/services/grid-helper.service';

@Injectable({
  providedIn: 'root',
})
export class MandatoryNoticeService {
  private EXTERNAL_SERVICE_BASE: string = environment.EXTERNAL_SERVICE_API;
  private TRIAL_BASE_URL: string = environment.TRIAL_SERVICE_API;
  deleteMandatoryNoticeModalRef: BsModalRef;
  warningMessageModalRef: BsModalRef;

  constructor(
    private http: HttpClient,
    private logger: NGXLogger,
    public modalService: BsModalService,
    private router: Router,
    private store: Store<PtactsState>,
    private commonUtils: CommonUtilitiesService,
    private gridService: GridHelperService
  ) {}

  getDownloadHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true,
      crossDomain: true,
      responseType: 'arraybuffer' as 'json',
    };

    return httpOptions;
  }

  //! Mandatory Notice verification
  getVerificationProceedings(verificationObj): Observable<any> {
    return this.http
      .post(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.MANDATORY_NOTICE.VERIFICATION}`,
        verificationObj
      )
      .pipe(
        map((verificationResponse: Array<any>) => {
          // let nonDERCases = [];
          verificationResponse.forEach((currentCase) => {
            // if (!currentCase.proceedingNumber.includes('DER')) {
            //   nonDERCases.push(currentCase);
            // }
            currentCase.prcdCreatedTsString =
              this.gridService.convertFilingDate(currentCase.prcdCreatedTs);
          });

          verificationResponse.sort(function (objA, objB) {
            var filedDateA = objA.prcdCreatedTs;
            var filedDateB = objB.prcdCreatedTs;

            if (filedDateA && filedDateB) {
              const tempA = filedDateA.split(' ');
              const tempB = filedDateB.split(' ');

              filedDateA = new Date(tempA[0]).getTime();
              filedDateB = new Date(tempB[0]).getTime();
              // Sort first on day
              if (filedDateA > filedDateB) {
                return 1;
              } else if (filedDateA < filedDateB) {
                return -1;
              } else {
                // If the days are the same,
                // do a nested sort on total.
                var proceedingNoA = objA.proceedingNumber;
                var proceedingNoB = objB.proceedingNumber;

                // return proceedingNoA.localeCompare(proceedingNoB, 'en', {
                //   numeric: true,
                //   sensitivity: 'base',
                // });

                if (proceedingNoA < proceedingNoB) {
                  return 1;
                } else if (proceedingNoA > proceedingNoB) {
                  return -1;
                } else {
                  return 0;
                }

                // if (proceedingNoA < proceedingNoB) {
                //   return 1;
                // } else if (proceedingNoA > proceedingNoB) {
                //   return -1;
                // } else {
                //   return 0;
                // }
              }
            } else {
              return 0;
            }
          });

          // return nonDERCases;
          return verificationResponse;
        })
      );
  }

  getTrialTypes(referenceType: string, isPublic: boolean) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((trialTypes) => {
          return trialTypes;
        })
      );
  }

  getAvailabilities(referenceType: string, isPublic: boolean) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((availabilities) => {
          return availabilities;
        })
      );
  }

  getMandatoryNoticePaperTypes(): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/references?typeCode=documentTypes&event=MN`
      )
      .pipe(
        map((mnTypes) => {
          let requiredMNTypes = [];
          mnTypes.forEach((element) => {
            if (element.identifier === 242 || element.identifier === 243) {
              requiredMNTypes.push(element);
            }
          });
          return requiredMNTypes;
        })
      );
  }

  addToList(fileToUpload: any, category: string, petitionIdentifier: string) {
    const formData: FormData = new FormData();
    formData.append('file', fileToUpload);
    formData.set('category', category);
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionIdentifier}/documents`,
        formData
      )
      .pipe(
        map((documentData) => {
          return documentData;
        })
      );
  }

  openPdf(proceedingId: string, artifactId: string) {
    window.open(
      `${this.EXTERNAL_SERVICE_BASE}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`,
      '_blank'
    );
    // return this.http
    //   .get(
    //     `${this.EXTERNAL_SERVICE_BASE}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`,
    //     { responseType: 'arraybuffer' as 'json' }
    //   )
    //   .pipe(
    //     map((pdfResponse) => {
    //       return pdfResponse;
    //     })
    //   );

    // deleteMandatoryNotice() {

    // }
  }

  openPdfWithFileName(url) {
    // window.open(this.COMMON_BASE_URL + url);
    // window.open(this.EXTERNAL_SERVICE_BASE + url);
    return this.http.get(
      this.EXTERNAL_SERVICE_BASE + url,
      // 'https://ptacts-pvt.etc.uspto.gov/ptacts' + url,
      this.getDownloadHeaders()
    );
  }

  deleteDocument(artifactIdentifer: number): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.DELETE}${artifactIdentifer}`
      )
      .pipe(
        map((deleteDocumentResponse) => {
          return deleteDocumentResponse;
        })
      );
  }

  deleteMandatoryNotice() {
    const initialState: ModalOptions = {
      initialState: {
        modal: {
          isConfirm: false,
          title: 'Delete mandatory notice?',
          infoText: [
            'Are you sure you want to delete this mandatory notice with all associated documents and information?',
          ],
          showLeftBtn: true,
          leftBtnClass: 'btn-light',
          leftBtnLabel: 'No, continue',
          showRightBtn: true,
          rightBtnClass: 'btn-danger',
          rightBtnLabel: 'Yes, delete mandatory notice',
          modalHeight: 175,
        },
      },
      class: 'modal-lg',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.deleteMandatoryNoticeModalRef = this.modalService.show(
      InfoModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.deleteMandatoryNoticeModalRef.onHide.subscribe(
      (reason: string | any) => {
        if (reason.initialState.modal.isConfirm) {
          window.sessionStorage.setItem('deleteMn', 'Y');
          this.store
            .select(PtactsSelectors.getMandatoryNoticeDocuments)
            .pipe(take(1))
            .subscribe((mnDocuments) => {
              if (mnDocuments.length > 0) {
                this.logger.info('Documents to delete:', mnDocuments);
                mnDocuments.forEach((doc) => {
                  this.deleteDocument(doc.artifactIdentifer);
                });
              }
            });

          this.clearValidations();

          this.clearState();

          this.commonUtils.showSuccess(
            'Successfully deleted mandatory notice.',
            'Delete mandatory notice'
          );

          if (window.sessionStorage.getItem('source')) {
            window.close();
          } else {
            this.router.navigate(['/ui/my-docket']);
          }
        }
      }
    );
  }

  submitMandatoryNotice(
    mandatoryNoticeToSubmit: MandatoryNotice
  ): Observable<any> {
    return (
      this.http
        // .post<any>(
        //   `${this.TRIAL_BASE_URL}/mandatory-notice`,
        //   mandatoryNoticeToSubmit
        // )
        .post<any>(
          `${this.EXTERNAL_SERVICE_BASE}/mandatory-notice`,
          mandatoryNoticeToSubmit
        )
        .pipe(
          map((mandatoryNoticeResponse) => {
            return mandatoryNoticeResponse;
          })
        )
    );
  }

  clearValidations() {
    // const validations = new MandatoryNoticeValidations();
    let validations: MandatoryNoticeValidations = {
      validations: {
        verified: false,
        verification: {
          complete: false,
          incomplete: false,
        },
        petitionInfo: {
          complete: false,
          incomplete: false,
        },
        documents: {
          complete: false,
          incomplete: false,
          mnExists: false,
        },
        realParty: {
          complete: false,
          incomplete: false,
          realPartyExists: false,
        },
        additionalRealParty: {
          complete: false,
          incomplete: false,
        },
        counsel: {
          complete: false,
          incomplete: false,
          leadExists: false,
        },
      },
    };

    this.store.dispatch(
      setMandatoryNoticeValidations({
        mnValidations: validations,
      })
    );

    this.disableSideNav();
  }

  clearState() {
    this.store.dispatch(
      setMandatoryNoticeInfo({
        mnNotice: null,
      })
    );

    this.store.dispatch(
      setMandatoryNoticeDocuments({
        mnDocuments: [],
      })
    );

    this.store.dispatch(setMandatoryNoticeRealParty({ mnRealParty: null }));

    this.store.dispatch(
      setMandatoryNoticeAdditionalRealParty({
        mnAdditionalRealParty: [],
      })
    );

    this.store.dispatch(
      setMandatoryNoticeCounsel({
        mnCounsel: [],
      })
    );

    this.store.dispatch(
      setMandatoryNoticeShowCounsel({ mnShowCounsel: false })
    );
  }

  disableSideNav() {
    const mnPetitionInformation = document.getElementById(
      'mnPetitionInformation'
    );
    if (mnPetitionInformation) {
      mnPetitionInformation.tabIndex = -1;
    }

    const mnDocs = document.getElementById('mnDocs');
    if (mnDocs) {
      mnDocs.tabIndex = -1;
    }

    const mnRealParty = document.getElementById('mnRealParty');
    if (mnRealParty) {
      mnRealParty.tabIndex = -1;
    }

    const mnAddRealParty = document.getElementById('mnAddRealParty');
    if (mnAddRealParty) {
      mnAddRealParty.tabIndex = -1;
    }

    const mnCounsel = document.getElementById('mnCounsel');
    if (mnCounsel) {
      mnCounsel.tabIndex = -1;
    }

    const mnReview = document.getElementById('mnReview');
    if (mnReview) {
      mnReview.tabIndex = -1;
    }

    const mnVerification = document.getElementById('mnVerification');
    if (mnVerification) {
      mnVerification.tabIndex = -1;
    }
  }

  openContinueWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Clicking continue will advance to the next screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.warningMessageModalRef = this.modalService.show(
      WarningModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    return this.warningMessageModalRef;
  }

  getPartyRepresenting(proceedingNumber: string): Observable<any> {
    return this.http
      .get(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.PARTY_REPRESENTING}${proceedingNumber}`,
        { responseType: 'text' }
      )
      .pipe(
        map((partyRepresenting) => {
          return partyRepresenting;
        })
      );
  }
}
