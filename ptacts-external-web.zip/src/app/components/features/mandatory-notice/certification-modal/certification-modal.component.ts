import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-certification-modal',
  templateUrl: './certification-modal.component.html',
  styleUrls: ['./certification-modal.component.scss'],
})
export class CertificationModalComponent implements OnInit {
  modalData = this.modalService.config.initialState;
  certified: boolean = false;

  constructor(
    public modalRef: BsModalRef,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {}

  close(val) {
    this.modalService.config.initialState.certify = val;
    this.modalService.hide();
  }
}
