import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsMnComponent } from './documents-mn.component';

describe('DocumentsMnComponent', () => {
  let component: DocumentsMnComponent;
  let fixture: ComponentFixture<DocumentsMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentsMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
