import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import {
  setMandatoryNoticeDocuments,
  setMandatoryNoticeValidations,
} from 'src/app/store/ptacts/ptacts.actions';
import { CONSTANTS } from 'src/app/constants/constants';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';
import { MandatoryNoticeService } from '../mandatory-notice.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { Router } from '@angular/router';
import { MandatoryNoticeValidations } from 'src/app/models/common/MandatoryNoticeValidations.model';
// import * as formatInTimeZone from 'date-fns-tz/formatInTimeZone';

@Component({
  selector: 'app-documents-mn',
  templateUrl: './documents-mn.component.html',
  styleUrls: ['./documents-mn.component.scss'],
})
export class DocumentsMnComponent implements OnInit, OnDestroy {
  mandatoryNoticeDocumentForm: FormGroup;
  availabilities: Array<any> = new Array<any>();
  paperTypes: Array<any> = new Array<any>();
  selectedPaperType: any = '';
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;
  addedDocumentsList: Array<any> = new Array<any>();
  editMode: boolean = false;
  addingToList: boolean = false;
  editIndex: number = null;
  petitionIdentifier: string = null;
  mandatoryNoticeInfo: any = null;
  publicModalRef: BsModalRef;
  showMultiplePaperTypeError: boolean = false;
  validations: MandatoryNoticeValidations = new MandatoryNoticeValidations();
  goToNexSection: boolean = false;
  componentName: string = 'documents';
  onBehalfOf: string = null;
  trimPattern = '^[^ ][wW ]*[^ ]';

  constructor(
    private store: Store<PtactsState>,
    private modalService: BsModalService,
    private logger: NGXLogger,
    private fb: FormBuilder,
    public mandatoryNoticeService: MandatoryNoticeService,
    private initiatePetitionService: InitiatePetitionService,
    public commonUtils: CommonUtilitiesService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // const myDate = new Date();
    //
    //   formatInTimeZone(myDate, 'America/Chicago', 'MM/dd/yyyy hh:mm:ss zzz')
    // );
    this.store
      .select(PtactsSelectors.getMandatoryState)
      .pipe(take(1))
      .subscribe((mandatoryNoticeInfo) => {
        this.mandatoryNoticeInfo = mandatoryNoticeInfo;
      });
    this.store
      .select(PtactsSelectors.getMandatoryNoticeDocuments)
      .pipe(take(1))
      .subscribe((mnDocuments) => {
        if (mnDocuments.length > 0) {
          this.addedDocumentsList = [...mnDocuments];
        }
      });

    this.store
      .select(PtactsSelectors.getMandatoryNoticeValidations)
      .pipe(take(1))
      .subscribe((mnValidations) => {
        const isEmpty = Object.keys(mnValidations).length === 0;
        if (!isEmpty) {
          this.validations = JSON.parse(JSON.stringify(mnValidations));
        }
      });
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.setupForm();
    this.getAvailabilities();
    this.getMandatoryNoticePaperTypes();
    // this.getPetitionIdentifier();
  }

  ngOnDestroy() {
    // this.continue(false);
    // if (!this.goToNexSection) {
    //   this.openContinueWarningModal(this.goToNexSection);
    // }
  }

  setupForm() {
    this.mandatoryNoticeDocumentForm = this.fb.group({
      docType: [{ value: 'Paper', disabled: true }],
      selectedPaper: ['', Validators.required],
      paperType: [''],
      availability: ['', Validators.required],
      filingParty: ['PATENT OWNER'],
      documentName: ['', Validators.required],
      selectedFile: [''],
      fileToUpload: [null, Validators.required],
      fileName: [{ value: '', disabled: false }, Validators.required],
      editMode: [false],
      pageCount: [''],
      uploadedDate: [null],
      artifactIdentifer: [null],
    });
  }

  getAvailabilities() {
    this.mandatoryNoticeService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilities) => {
        this.availabilities = availabilities;
        this.logger.info('Availabilities: ', this.availabilities);
      });
  }

  getMandatoryNoticePaperTypes() {
    this.mandatoryNoticeService
      .getMandatoryNoticePaperTypes()
      .pipe(take(1))
      .subscribe((mandatoryNoticePaperTypes) => {
        this.paperTypes = this.commonUtils.removeSpaceFromPaperTypes(
          mandatoryNoticePaperTypes
        );
        // this.paperTypes = [
        //   {
        //     identifier: 243,
        //     code: 'NOT:MN',
        //     descriptionText: 'Notice:  Mandatory Notice',
        //     displayNameText: 'Notice:  Mandatory Notice',
        //     significantIndicator: 'N',
        //     joinderCheckIndicator: 'N',
        //   },
        //   {
        //     identifier: 242,
        //     code: 'NOT:POA',
        //     descriptionText: 'Notice:  Power of Attorney',
        //     displayNameText: 'Notice:  Power of Attorney',
        //     significantIndicator: 'N',
        //     joinderCheckIndicator: 'N',
        //   },
        // ];
      });
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.mandatoryNoticeInfo.proceedingNumber)
      .subscribe(
        (caseInfoByProceedingResponse) => {
          this.petitionIdentifier =
            caseInfoByProceedingResponse.petitionIdentifier;
        },
        (petitionIdentifierError) => { }
      );
  }

  onPaperTypeSelect(event) {
    // this.mandatoryNoticeDocumentForm.controls.documentName.setValue(
    //   event.item.displayNameText
    // );
    // this.mandatoryNoticeDocumentForm.get('paperType').setValue(event.item);
    // this.selectedPaperType = event.item;
    // this.logger.info('Selected Paper type', this.selectedPaperType);
    this.showMultiplePaperTypeError = false;
    this.mandatoryNoticeDocumentForm.controls.documentName.setValue(
      event.displayNameText
    );
    this.mandatoryNoticeDocumentForm.controls.selectedPaper.setValue(event);
    this.mandatoryNoticeDocumentForm.get('paperType').setValue(event);
    this.selectedPaperType = event;
    this.logger.info('Selected Paper type', this.selectedPaperType);
  }

  fileChange(event) {
    this.logger.info('File info: ', event);
    this.mandatoryNoticeDocumentForm
      .get('fileToUpload')
      .setValue(event.target.files[0]);
    this.mandatoryNoticeDocumentForm
      .get('fileName')
      .setValue(event.target.files[0].name);
  }

  edit(docToEdit, index) {
    this.editMode = true;
    this.editIndex = index;
    this.mandatoryNoticeDocumentForm.setValue(docToEdit);
    const foundAvailability = this.availabilities.find((availability: any) => {
      return availability.code === docToEdit.availability.code;
    });
    this.mandatoryNoticeDocumentForm
      .get('availability')
      .setValue(foundAvailability, Validators.required);
    this.selectedPaperType = docToEdit.selectedPaper.displayNameText;
    // this.paperTypeDisplayName = this.addedDocumentsList[e].paperType.displayName
    //   ? this.addedDocumentsList[e].paperType.displayName
    //   : this.addedDocumentsList[e].paperType.descriptionText;
    // this.motionTypeDisplayName = this.addedDocumentsList[e].motionType
    //   .displayName
    //   ? this.addedDocumentsList[e].motionType.displayName
    //   : this.addedDocumentsList[e].motionType.descriptionText;
    this.mandatoryNoticeDocumentForm.updateValueAndValidity();
  }

  addToList() {
    // if (!this.duplicatesFound()) {
    this.addingToList = true;
    this.showMultiplePaperTypeError = false;
    this.mandatoryNoticeService
      .addToList(
        this.mandatoryNoticeDocumentForm.value.fileToUpload,
        CONSTANTS.DOC_TYPE.PAPER,
        // this.petitionIdentifier
        this.mandatoryNoticeInfo.proceedingId
      )
      .pipe(take(1))
      .subscribe(
        (fileAdded) => {
          let petitionDocument = null;
          // let filingParty = this.mandatoryNoticeDocumentForm
          //   .get('filingParty')
          //   .setValue('PATENT OWNER');
          // const docId = this.mandatoryNoticeDocumentForm.value.paperType
          //   .documentTypeId
          //   ? this.mandatoryNoticeDocumentForm.value.paperType.documentTypeId
          //   : this.mandatoryNoticeDocumentForm.value.paperType.identifier;
          petitionDocument = new PetitionDocument(
            this.mandatoryNoticeDocumentForm.get('docType').value.toUpperCase(),
            this.mandatoryNoticeDocumentForm.value.documentName,
            this.mandatoryNoticeDocumentForm.value.fileName,
            this.mandatoryNoticeDocumentForm.value.filingParty,
            // 'BOARD',
            this.mandatoryNoticeDocumentForm.value.availability.code,
            this.mandatoryNoticeDocumentForm.value.paperType.identifier,
            this.mandatoryNoticeDocumentForm.value.paperType.code,
            this.mandatoryNoticeDocumentForm.value.fileToUpload.type,
            null,
            'N',
            null
          );

          const documentToAdd = new DocumentToAdd(petitionDocument);
          documentToAdd.proceedingNumberText =
            this.mandatoryNoticeInfo.proceedingNumber;
          this.mandatoryNoticeDocumentForm
            .get('pageCount')
            .setValue(fileAdded.pageCount);
          // this.saveDocumentToCMS(documentToAdd);
          // this.addedDocumentsList.push(documentToAdd)
          this.mandatoryNoticeDocumentForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          // this.mandatoryNoticeDocumentForm
          //   .get('artifactIdentifer')
          //   .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          let tempDocForm = this.mandatoryNoticeDocumentForm.value;
          tempDocForm.docType =
            this.mandatoryNoticeDocumentForm.get('docType').value;
          this.addedDocumentsList.push(this.mandatoryNoticeDocumentForm.value);
          this.store.dispatch(
            setMandatoryNoticeDocuments({
              mnDocuments: [...this.addedDocumentsList],
            })
          );
          this.clearForm();
        },
        (addToListFailure) => {
          // this.commonUtils.showError(
          //   'Failed to add document to list',
          //   'Add to list'
          // );
          // this.logger.error('Failed to add document to list', addToListFailure);
          this.commonUtils.throwError(
            `Add to list failed for Mandatory Notice`,
            addToListFailure
          );
          this.addingToList = false;
        }
      );
    // } else {

    // }
  }

  duplicatesFound() {
    let duplicateFound = false;
    if (!this.editMode) {
      this.addedDocumentsList.forEach((doc) => {
        if (
          doc.paperType.identifier ===
          this.mandatoryNoticeDocumentForm.value.paperType.identifier
        ) {
          duplicateFound = true;
        }
      });
    }
    return duplicateFound;
  }

  saveDocumentToCMS(documentToAdd) {
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          this.logger.info('Saved document to CMS', saveSuccessful);
          // this.mandatoryNoticeDocumentForm
          //   .get('uploadedDate')
          //   .setValue(this.commonUtils.getCurrentDateString('time'));
          this.mandatoryNoticeDocumentForm
            .get('uploadedDate')
            .setValue(this.commonUtils.setEST(new Date().getTime()));
          this.mandatoryNoticeDocumentForm
            .get('artifactIdentifer')
            .setValue(saveSuccessful.petitionDocuments[0].artifactIdentifer);
          let tempDocForm = this.mandatoryNoticeDocumentForm.value;
          tempDocForm.docType =
            this.mandatoryNoticeDocumentForm.get('docType').value;
          this.addedDocumentsList.push(this.mandatoryNoticeDocumentForm.value);
          this.store.dispatch(
            setMandatoryNoticeDocuments({
              mnDocuments: [...this.addedDocumentsList],
            })
          );
          this.clearForm();
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.commonUtils.throwError(
            `Save document failed for Mandatory Notice`,
            documentSaveFailed
          );
          this.addingToList = false;
        }
      );
  }

  checkAvailability(action) {
    if (!this.duplicatesFound()) {
      if (
        this.mandatoryNoticeDocumentForm.value.availability.code.toLowerCase() ===
        CONSTANTS.AVAILABILITY_CODE.PUBLIC
      ) {
        this.openPublicAvailabilityModal(action);
      } else {
        action === 'add' ? this.addToList() : this.update();
      }
    } else {
      this.showMultiplePaperTypeError = true;
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        action === 'add' ? this.addToList() : this.update();
      }
    });
  }

  clearForm() {
    this.mandatoryNoticeDocumentForm.reset();
    this.setupForm();
    this.clearFile();
    this.editMode = false;
    this.editIndex = null;
    this.addingToList = false;
    this.showMultiplePaperTypeError = false;
    this.selectedPaperType = '';
  }

  clearFile() {
    const el = document.getElementById('file');
    if (el) {
      (<HTMLInputElement>document.getElementById('file')).value = '';
      this.mandatoryNoticeDocumentForm.get('fileToUpload').setValue(null);
      this.mandatoryNoticeDocumentForm.get('fileName').setValue(null);
    }
  }

  update() {
    this.mandatoryNoticeDocumentForm
      .get('uploadedDate')
      .setValue(this.commonUtils.getCurrentDateString('time'));
    let tempDocToUpdate = this.mandatoryNoticeDocumentForm.value;
    tempDocToUpdate.docType =
      this.mandatoryNoticeDocumentForm.get('docType').value;
    this.addedDocumentsList[this.editIndex] = tempDocToUpdate;
    this.store.dispatch(
      setMandatoryNoticeDocuments({
        mnDocuments: [...this.addedDocumentsList],
      })
    );
    this.commonUtils.setToastr("success", CONSTANTS.TOAST_MSGS.UPDATE_DOC.SUCCESS)
    this.clearForm();
  }

  deleteDocument(index) {
    // const artifactID = this.addedDocumentsList[index].artifactIdentifer;
    // this.initiatePetitionService
    //   .deleteDocument(artifactID)
    //   .pipe(take(1))
    //   .subscribe(
    //     (deleteDocumentSuccess) => {
    //       this.addedDocumentsList.splice(index, 1);
    //       this.logger.info(
    //         'Document deleted successfully',
    //         deleteDocumentSuccess
    //       );
    //       this.commonUtils.showSuccess(
    //         'Document deleted successfully',
    //         'Delete document'
    //       );
    //       this.store.dispatch(
    //         setMandatoryNoticeDocuments({
    //           mnDocuments: [...this.addedDocumentsList],
    //         })
    //       );
    //     },
    //     (deleteDocumentFailure) => {
    //       this.logger.error('Failed to delete document', deleteDocumentFailure);
    //       this.commonUtils.showError(
    //         deleteDocumentFailure.error.message,
    //         'Delete document'
    //       );
    //     }
    //   );
    this.addedDocumentsList.splice(index, 1);
    this.logger.info('Document deleted successfully');
    this.store.dispatch(
      setMandatoryNoticeDocuments({
        mnDocuments: [...this.addedDocumentsList],
      })
    );
    this.commonUtils.showSuccess(
      'Document deleted successfully',
      'Delete document'
    );
  }

  openPdf(data, colName) {
    this.mandatoryNoticeService.openPdfWithFileName(
      `/petitions/${this.mandatoryNoticeInfo.proceedingId}/documents?fileName=${data.fileToUpload.name}`
    ).subscribe(
      (pdfResponse: any) => {
        console.log(pdfResponse);
        var file = new Blob([pdfResponse], { type: 'application/pdf' });
        var fileURL = URL.createObjectURL(file);
        window.open(fileURL);
      },
      (pdfFailure) => {
        console.log(pdfFailure);
      }
    );

    // if (colName) {
    //   const dataToEmit = {
    //     colName: colName,
    //     data: data,
    //   };
    //   //this.pdfEmitter.emit(dataToEmit);
    //   this.mandatoryNoticeService
    //     // .openPdf(this.petitionIdentifier, data.artifactIdentifer)
    //     .openPdf(this.mandatoryNoticeInfo.proceedingId, data.artifactIdentifer);
    //   // .pipe(take(1))
    //   // .subscribe(
    //   //   (pdfResponse) => {
    //   //     this.commonUtils.openPdfNew(pdfResponse);
    //   //   },
    //   //   (pdfResponseError) => {
    //   //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   //   }
    //   // );
    // } else {
    //   //this.pdfEmitter.emit(data);
    //   this.mandatoryNoticeService
    //     // .openPdf(this.petitionIdentifier, data.artifactIdentifer)
    //     .openPdf(this.mandatoryNoticeInfo.proceedingId, data.artifactIdentifer);
    //   // .pipe(take(1))
    //   // .subscribe(
    //   //   (pdfResponse) => {
    //   //     this.commonUtils.openPdfNew(pdfResponse);
    //   //   },
    //   //   (pdfResponseError) => {
    //   //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   //   }
    //   // );
    // }
  }

  openContinueWarningModal(goToNexSection) {
    this.goToNexSection = goToNexSection;
    if (this.mandatoryNoticeDocumentForm.dirty) {
      const response = this.mandatoryNoticeService.openContinueWarningModal();
      response.onHide.subscribe((reason: string | any) => {
        if (reason.initialState.selection) {
          this.continue(goToNexSection);
          // if (goToNexSection) {
          //   this.router.navigate(['/mandatory-notice/real-party']);
          // }
        }
      });
    } else {
      this.continue(goToNexSection);
      // if (goToNexSection) {
      //   this.router.navigate(['/mandatory-notice/real-party']);
      // }
    }
  }

  // continue(goToNexSection) {
  //   // if (this.validations?.validations?.documents) {
  //   this.validations.validations.documents.complete = null;
  //   this.validations.validations.documents.incomplete = true;
  //   this.logger.info('Doc list', this.addedDocumentsList);
  //   this.addedDocumentsList.forEach((document) => {
  //     if (document.paperType.code === 'NOT:MN') {
  //       this.validations.validations.documents.mnExists = true;
  //     }
  //   });
  //   this.validations.validations.documents.complete =
  //     this.validations.validations.documents.mnExists;
  //   this.validations.validations.documents.incomplete =
  //     !this.validations.validations.documents.complete;
  //   this.store.dispatch(
  //     setMandatoryNoticeValidations({
  //       mnValidations: this.validations,
  //     })
  //   );
  //   if (goToNexSection) {
  //     this.router.navigate(['/mandatory-notice/real-party']);
  //   }
  //   // }
  // }

  continue(goToNexSection) {
    this.router.navigate(['/ui/mandatory-notice/real-party']);
  }

  showEST() {
    const myDate = new Date().getTime();
  }

  clearSelection() {
    this.mandatoryNoticeDocumentForm
      .get('selectedPaper')
      .setValue('', Validators.required);

    this.mandatoryNoticeDocumentForm
      .get('documentName')
      .setValue('', Validators.required);
  }

  // trimWhitespace(e, textToTrim) {
  //   if (e.code === 'Space' && !textToTrim) {
  //     setTimeout(() => {
  //       const trimmedText = this.commonUtils.trimWhitespace(textToTrim);
  //       this.mandatoryNoticeDocumentForm
  //         .get('documentName')
  //         .setValue(trimmedText, Validators.required);
  //     });
  //   } else {
  //     return;
  //   }
  // }

  checkForm() {
    console.log(this.mandatoryNoticeDocumentForm);
  }
}
