import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared.module';
import { MandatoryNoticeRoutingModule } from './mandatory-notice-routing.module';
import { MandatoryNoticeComponent } from './mandatory-notice.component';
import { VerificationMnComponent } from './verification-mn/verification-mn.component';
import { DocumentsMnComponent } from './documents-mn/documents-mn.component';
import { RealPartyMnComponent } from './real-party-mn/real-party-mn.component';
import { AdditionalRealPartyMnComponent } from './additional-real-party-mn/additional-real-party-mn.component';
import { CounselMnComponent } from './counsel-mn/counsel-mn.component';
import { ReviewMnComponent } from './review-mn/review-mn.component';
import { PetitionInformationMnComponent } from './petition-information-mn/petition-information-mn.component';
import { CertificationModalComponent } from './certification-modal/certification-modal.component';
import { WizardHeadingComponent } from './wizard-heading/wizard-heading.component';

@NgModule({
  declarations: [
    MandatoryNoticeComponent,
    VerificationMnComponent,
    DocumentsMnComponent,
    RealPartyMnComponent,
    AdditionalRealPartyMnComponent,
    CounselMnComponent,
    ReviewMnComponent,
    PetitionInformationMnComponent,
    CertificationModalComponent,
    WizardHeadingComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    MandatoryNoticeRoutingModule,
  ],
})
export class MandatoryNoticeModule {}
