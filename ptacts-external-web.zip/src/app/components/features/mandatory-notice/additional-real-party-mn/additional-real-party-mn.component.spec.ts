import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalRealPartyMnComponent } from './additional-real-party-mn.component';

describe('AdditionalRealPartyMnComponent', () => {
  let component: AdditionalRealPartyMnComponent;
  let fixture: ComponentFixture<AdditionalRealPartyMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdditionalRealPartyMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalRealPartyMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
