import { Component, OnDestroy, OnInit } from '@angular/core';
import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { MandatoryNoticeService } from '../mandatory-notice.service';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { exhaustMap, map, take } from 'rxjs/operators';
import { Router } from '@angular/router';
import { NGXLogger } from 'ngx-logger';
import { setMandatoryNoticeValidations } from 'src/app/store/ptacts/ptacts.actions';
import { MandatoryNoticeValidations } from 'src/app/models/common/MandatoryNoticeValidations.model';

@Component({
  selector: 'app-petition-information-mn',
  templateUrl: './petition-information-mn.component.html',
  styleUrls: ['./petition-information-mn.component.scss'],
})
export class PetitionInformationMnComponent implements OnInit, OnDestroy {
  proceedingNumber: string = null;
  caseSearch: CaseSearchModel = new CaseSearchModel();
  mandatoryNoticeInfo: any;
  trialTypes: any = [];
  trialType: string = null;
  validations: MandatoryNoticeValidations;
  onBehalfOf: string = null;
  selectedCase: any = {};

  constructor(
    private store: Store<PtactsState>,
    private router: Router,
    public mandatoryNoticeService: MandatoryNoticeService,
    private logger: NGXLogger
  ) {}

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');

    // this.proceedingNumber = window.sessionStorage.getItem('mnProceeding');

    this.caseSearch.proceedingNumber = this.proceedingNumber;
    this.store
      .select(PtactsSelectors.getMandatoryState)
      .pipe(take(1))
      .subscribe((mandatoryNoticeInfo) => {
        this.mandatoryNoticeInfo = mandatoryNoticeInfo;
      });

    this.store
      .select(PtactsSelectors.getMandatoryNoticeValidations)
      .subscribe((mnValidations) => {
        const isEmpty = Object.keys(mnValidations).length === 0;
        if (!isEmpty) {
          this.validations = JSON.parse(JSON.stringify(mnValidations));
        }
      });
    this.getTrialTypes();
  }

  ngOnDestroy() {
    this.continue(false);
  }

  getTrialTypes() {
    this.mandatoryNoticeService
      .getTrialTypes('trialType', true)
      .pipe(take(1))
      .subscribe(
        (trialTypes) => {
          this.trialTypes = trialTypes;
          this.setTrialType();
        },
        (trialTypeFailure) => {
          this.logger.error('Error getting trial types: ', trialTypeFailure);
        }
      );
  }

  setTrialType() {
    this.logger.info('Mandatory notice info:', this.mandatoryNoticeInfo);
    // const trialTypeCode = this.mandatoryNoticeInfo.proceedingNumber.substr(
    //   0,
    //   3
    // );
    if (this.mandatoryNoticeInfo?.trialType?.toLowerCase() === 'cbm') {
      this.trialType = 'Covered Business Method';
    } else {
      this.trialTypes.forEach((element) => {
        if (this.mandatoryNoticeInfo.trialType === element.code) {
          this.trialType = element.descriptionText;
        }
      });
    }
  }

  continue(goToNexSection) {
    this.validations.validations.petitionInfo.complete = true;
    this.validations.validations.petitionInfo.incomplete = false;
    this.store.dispatch(
      setMandatoryNoticeValidations({
        mnValidations: this.validations,
      })
    );
    if (goToNexSection) {
      this.router.navigate(['/ui/mandatory-notice/documents']);
    }
  }
}
