import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PetitionInformationMnComponent } from './petition-information-mn.component';

describe('PetitionInformationComponent', () => {
  let component: PetitionInformationMnComponent;
  let fixture: ComponentFixture<PetitionInformationMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PetitionInformationMnComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PetitionInformationMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
