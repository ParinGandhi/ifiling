import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { setMandatoryNoticeRealParty } from 'src/app/store/ptacts/ptacts.actions';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-mandatory-notice',
  templateUrl: './mandatory-notice.component.html',
  styleUrls: ['./mandatory-notice.component.scss'],
})
export class MandatoryNoticeComponent implements OnInit {
  showCounselSection: boolean = false;
  validations: any = null;

  constructor(private store: Store<PtactsState>) {}

  ngOnInit(): void {
    document.title = 'Mandatory notice';
    this.store
      .select(PtactsSelectors.getMandatoryNoticeShowCounsel)
      .subscribe((mnShowCounsel) => {
        this.showCounselSection = mnShowCounsel;
      });

    this.store
      .select(PtactsSelectors.getMandatoryNoticeValidations)
      .subscribe((mnValidations) => {
       
        this.validations = mnValidations;
      });
  }
}
