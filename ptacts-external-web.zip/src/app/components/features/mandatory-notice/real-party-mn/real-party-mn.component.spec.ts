import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealPartyMnComponent } from './real-party-mn.component';

describe('RealPartyMnComponent', () => {
  let component: RealPartyMnComponent;
  let fixture: ComponentFixture<RealPartyMnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealPartyMnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealPartyMnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
