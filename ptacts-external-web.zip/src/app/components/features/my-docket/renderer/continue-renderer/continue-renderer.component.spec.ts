import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContinueRendererComponent } from './continue-renderer.component';

describe('ContinueRendererComponent', () => {
  let component: ContinueRendererComponent;
  let fixture: ComponentFixture<ContinueRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContinueRendererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContinueRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
