import { Component, NgZone, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  setNewPetitionInfo,
  setTrialInfo,
} from 'src/app/store/ptacts/ptacts.actions';
import { Router } from '@angular/router';
import { InitiatePetitionService } from '../../../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-continue-renderer',
  templateUrl: './continue-renderer.component.html',
  styleUrls: ['./continue-renderer.component.scss'],
})
export class ContinueRendererComponent implements OnInit {
  params;
  label: string;
  srText: string;

  constructor(
    private router: Router,
    private zone: NgZone,
    private store: Store<PtactsState>,
    private initiatePetitionServices: InitiatePetitionService
  ) {}

  ngOnInit(): void {}

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
    this.srText =
      'Continue petition: ' +
        this.params.data.proceedingNo +
        ', Initiated ' +
        this.params.data.prcdCreatedTsStr || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  onClick($event) {
    if (this.params.onClick instanceof Function) {
      // put anything into params u want pass into parents component
      // const params = {
      //   event: $event,
      //   rowData: this.params.node.data
      //   // ...something

      // }
      // this.params.onClick(params);
      let petitionInfo = {
        proceedingNumberText: this.params.node.data.proceedingNo,
        patentNumber: this.params.node.data.poPatentNumber,
        trialType: this.params.node.data.proceedingNo.substr(0, 3),
        petitionerPatentNumber: this.params.node.data.petitionerPatentNumber,
        petitionerApplicationNumber:
          this.params.data?.petitionerApplicationNumber,
        poApplicationNumber: this.params.data?.poApplicationNumber,
        poPatentNumber: this.params.data?.poPatentNumber,
      };
      window.sessionStorage.setItem(
        'petitionInfo',
        JSON.stringify(petitionInfo)
      );

      this.store.dispatch(setNewPetitionInfo({ request: petitionInfo }));

      this.initiatePetitionServices.setOption('enableVerifications', false);

      if (petitionInfo.trialType === 'DER') {
        this.initiatePetitionServices.setOption('isDER', true);
        this.zone.run(() => {
          this.router.navigate(['/ui/initiate-petition/petition-documents']);
        });
      } else {
        this.initiatePetitionServices.setOption('isDER', false);
        this.zone.run(() => {
          this.router.navigate(['/ui/initiate-petition/claims-challenged']);
        });
      }
    }
  }
}
