import { Component, OnInit, OnDestroy } from '@angular/core';
import { take } from 'rxjs/operators';
import { Router } from '@angular/router';
import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { MyDocketService } from '../my-docket.services';
import { ToolTipComponent } from 'src/app/components/common/tool-tip/tool-tip.component';
import {
  changeLoading,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { OpenCaseViewerComponent } from 'src/app/components/common/open-case-viewer/open-case-viewer.component';
import { AiaToolTipComponent } from '../../../common/aia-tool-tip/aia-tool-tip.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
declare let $: any;

@Component({
  selector: 'app-pending-aia-reviews',
  templateUrl: './pending-aia-reviews.component.html',
  styleUrls: ['./pending-aia-reviews.component.scss'],
})
export class PendingAiaReviewsComponent implements OnInit {
  gridOptions = new GridOptionsModel();
  gridParams = new GridParamsModel();
  userName: string;
  numberOfFilters: number;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;
  frameworkComponents: { customTooltip: typeof AiaToolTipComponent };
  loading: boolean;
  paginationPageSize = CONSTANTS.PAGINATION.DEFAULT;
  currentPage: number = 1;
  totalPages: number = null;
  recordCountInfo: RecordCountModel = new RecordCountModel();
  paginationInfo: PaginationModel = new PaginationModel();

  constructor(
    public gridHelperService: GridHelperService,
    private store: Store<PtactsState>,
    private myDocketService: MyDocketService,
    private caseViewerService: CaseViewerService,
    private commonUtils: CommonUtilitiesService,
    private router: Router,
  ) {}

  columnDefs = {
    pendingAiaReviews: [
      {
        field: 'proceedingNo',
        headerName: 'AIA Review #',
        width: '130px',
        sort: 'desc',
        sortIndex: 2,
        cellRendererFramework: OpenCaseViewerComponent,
        cellRendererParams: { fromComponent: 'pending' },
      },
      {
        field: 'filingDateStr',
        headerName: 'Filing date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '150px',
        sort: 'desc',
        sortIndex: 1,
        type: 'date',
      },
      { field: 'userRole', headerName: 'My role', width: '160px' },
      {
        field: 'userPartyGroupType',
        headerName: 'Party representing',
        width: '140px',
        cellClass: 'title-case',
      },
      {
        field: 'petitionerApplicationNumber',
        headerName: 'Petitioner application #',
      },
      { field: 'petitionerPatentNumber', headerName: 'Petitioner patent #' },
      {
        field: 'petitionerRealParty',
        headerName: 'Petitioner name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'poApplicationNumber',
        headerName: 'PO/Respondent app #',
        width: '150px',
      },
      {
        field: 'poPatentNumber',
        headerName: 'PO/Respondent patent #',
        width: '150px',
      },
      {
        field: 'poRealParty',
        headerName: 'PO/Respondent name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'status',
        headerName: 'Status',
        tooltipField: 'status',
        tooltipComponentParams: { color: 'black' },
        cellStyle: { 'text-decoration': 'underline dotted' },
      },
    ],
  };

  rowData = {
    pendingAiaReviews: [],
  };

  ngOnInit(): void {
    this.frameworkComponents = { customTooltip: AiaToolTipComponent };
    this.popoverShow();
    this.getPendingAIAReviews();
    this.loading = true;
    this.recordCountInfo.currentPage = this.currentPage;
    this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    this.paginationInfo.currentPage = this.currentPage;
  }

  popoverShow() {
    $(function () {
      $('.fa-info-circle').hover(function () {
        $('[data-toggle="popover"]').popover({ placement: 'top' }).popover();
      });
    });
  }

  /** Uncomment once service is ready to integrate */
  // getPendingAIAReviews() {
  //   this.myDocketService.getPendingAIAReviews().pipe(take(1)).subscribe((pendingAIAReviews) => {
  //     this.gridOptions.rowData = pendingAIAReviews;
  //   })
  // }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'Pending AIA reviews';
    this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    this.paginationInfo.totalPages = this.totalPages;
  }

  ngOnDestroy(): void {}

  getPendingAIAReviews() {
    const emailId = window.sessionStorage.getItem('email');
    this.myDocketService.getPendingAIAReviews(emailId).subscribe(
      (response) => {
        this.numberOfFilters = 0;
        this.rowData.pendingAiaReviews = response.body;
        // this.rowData.pendingAiaReviews = [];
        // response.forEach((resp) => {
        //   switch (resp.userPartyGroupType) {
        //     case 'PETITIONER':
        //       resp.userPartyGroupType = 'Petitioner';
        //       break;
        //     case 'PATENTOWNER':
        //       resp.userPartyGroupType = 'Patent Owner';
        //       break;
        //     default:
        //       break;
        //   }
        //   this.rowData.pendingAiaReviews.push(resp);
        // });
        this.recordCountInfo.dataLength = this.rowData.pendingAiaReviews.length;
        this.loading = false;
      },
      (error) => {
        if(error.status == 401) {
          this.router.navigate(['ui/unauthorized']);
        }
        this.rowData.pendingAiaReviews = [];
        this.loading = false;
      }
    );
  }

  onPaginationChanged(e) {}

  gridPaginationAction(e) {
    this.recordCountInfo.lastPage = false;

    // switch (e.pageAction) {
    //   case 'first':
    //     this.gridParams.gridApi.paginationGoToFirstPage();
    //     break;
    //   case 'previous':
    //     this.gridParams.gridApi.paginationGoToPreviousPage();
    //     break;
    //   case 'next':
    //     this.gridParams.gridApi.paginationGoToNextPage();
    //     break;
    //   case 'last':
    //     this.gridParams.gridApi.paginationGoToLastPage();
    //     break;
    //   case 'specificPage':
    //     this.gridParams.gridApi.paginationGoToPage(parseInt(e.pageNo));
    //     break;
    //   default:
    //     break;
    // }
    this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    this.recordCountInfo.currentPage = this.currentPage;
    this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.rowData.pendingAiaReviews.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.gridParams.gridApi.paginationSetPageSize(
        this.rowData.pendingAiaReviews.length
      );
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      // this.dataList = this.filteredData.slice(
      //   Math.floor(this.filteredData.length / pageSizeEvent) * pageSizeEvent,
      //   this.filteredData.length
      // );
      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.pendingAiaReviews.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      this.gridParams.gridApi.paginationGoToPage(
        this.paginationInfo.currentPage
      );
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // this.dataList = this.filteredData.slice(
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      //     this.paginationInfo.pageSize,
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // );
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.pendingAiaReviews.length / this.paginationInfo.pageSize
      );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.gridParams.gridApi.paginationGoToPage(
        this.recordCountInfo.currentPage - 1
      );
      // this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
      // this.recordCountInfo.currentPage = this.currentPage;
      // this.paginationInfo.currentPage = this.currentPage;
    }
    // this.paginationPageSize = pageSizeEvent;
    // this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);
    // this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    // this.paginationInfo.totalPages = this.totalPages;
  }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colId === 'proceedingNo') {
      this.checkForPartyRepresenting(e.data.proceedingNo);
    }
  }

  checkForPartyRepresenting(proceedingNo) {
    this.caseViewerService
      .getPartyRepresenting(proceedingNo)
      .pipe(take(1))
      .subscribe(
        (partyResponse) => {
          // this.commonUtils.openCaseViewer(proceedingNo, '/aia-review-info');
          if (partyResponse !== '') {
            this.commonUtils.openCaseViewer(proceedingNo, '/aia-review-info');
          } else {
            this.commonUtils.openDocumentsModal(proceedingNo);
          }
        },
        (partyFailure) => {
          this.commonUtils.throwError('', partyFailure);
        }
      );
  }
}
