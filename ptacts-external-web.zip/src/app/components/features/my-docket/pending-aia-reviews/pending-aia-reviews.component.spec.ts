import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAiaReviewsComponent } from './pending-aia-reviews.component';

describe('PendingAiaReviewsComponent', () => {
  let component: PendingAiaReviewsComponent;
  let fixture: ComponentFixture<PendingAiaReviewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingAiaReviewsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingAiaReviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
