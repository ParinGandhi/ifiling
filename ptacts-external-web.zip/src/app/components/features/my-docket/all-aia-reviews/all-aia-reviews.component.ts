import { Component, OnDestroy, OnInit } from '@angular/core';

import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { MyDocketService } from '../my-docket.services';
import { ToolTipComponent } from 'src/app/components/common/tool-tip/tool-tip.component';
import { OpenCaseViewerComponent } from 'src/app/components/common/open-case-viewer/open-case-viewer.component';
import { AiaToolTipComponent } from '../../../common/aia-tool-tip/aia-tool-tip.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
declare let $: any;

@Component({
  selector: 'app-all-aia-reviews',
  templateUrl: './all-aia-reviews.component.html',
  styleUrls: ['./all-aia-reviews.component.scss'],
})
export class AllAiaReviewsComponent implements OnInit, OnDestroy {
  gridOptions = new GridOptionsModel();
  gridParams = new GridParamsModel();
  userName: string;
  numberOfFilters: number;
  popoverContent: string = `<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>`;
  frameworkComponents: { customTooltip: typeof AiaToolTipComponent };
  loading: boolean;
  paginationPageSize = CONSTANTS.PAGINATION.DEFAULT;
  currentPage: number = 1;
  totalPages: number = null;
  recordCountInfo: RecordCountModel = new RecordCountModel();
  paginationInfo: PaginationModel = new PaginationModel();

  columnDefs = {
    allAiaReviews: [
      {
        field: 'proceedingNo',
        headerName: 'AIA Review #',
        width: '130px',
        sort: 'desc',
        sortIndex: 2,
        cellRendererFramework: OpenCaseViewerComponent,
      },
      {
        field: 'filingDateStr',
        headerName: 'Filing date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '150px',
        sort: 'desc',
        sortIndex: 1,
        type: 'date',
      },
      { field: 'userRole', headerName: 'My role', width: '160px' },
      {
        field: 'userPartyGroupType',
        headerName: 'Party representing',
        width: '130px',
        cellClass: 'title-case',
      },
      {
        field: 'petitionerApplicationNumber',
        headerName: 'Petitioner application #',
      },
      { field: 'petitionerPatentNumber', headerName: 'Petitioner patent #' },
      {
        field: 'petitionerRealParty',
        headerName: 'Petitioner name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'poApplicationNumber',
        headerName: 'PO/Respondent app #',
        width: '150px',
      },
      {
        field: 'poPatentNumber',
        headerName: 'PO/Respondent patent #',
        width: '150px',
      },
      {
        field: 'poRealParty',
        headerName: 'PO/Respondent name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'status',
        headerName: 'Status',
        tooltipField: 'status',
        //tooltipComponentParams: { color: 'black' },
        cellStyle: { 'text-decoration': 'underline dotted' },
      },
    ],
  };

  rowData = {
    allAiaReviews: [],
  };

  constructor(
    public gridHelperService: GridHelperService,
    private myDocketService: MyDocketService
  ) {}

  ngOnInit(): void {
    this.frameworkComponents = { customTooltip: AiaToolTipComponent };
    this.popoverShow();
    this.getAllAIAReviews();
    this.loading = true;
    this.recordCountInfo.currentPage = this.currentPage;
    this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    this.paginationInfo.currentPage = this.currentPage;
  }

  popoverShow() {
    $(function () {
      $('.fa-info-circle').hover(function () {
        $('[data-toggle="popover"]').popover({ placement: 'top' }).popover();
      });
    });
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'All AIA reviews';
    this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    this.paginationInfo.totalPages = this.totalPages;
  }

  ngOnDestroy(): void {}

  getAllAIAReviews() {
    const emailId = window.sessionStorage.getItem('email');
    this.myDocketService.getAllAIAReviews(emailId).subscribe(
      (response) => {
        this.numberOfFilters = 0;
        this.rowData.allAiaReviews = response;
        // this.rowData.allAiaReviews = [];
        // response.forEach((resp) => {
        //   switch (resp.userPartyGroupType) {
        //     case 'PETITIONER':
        //       resp.userPartyGroupType = 'Petitioner';
        //       break;
        //     case 'PATENTOWNER':
        //       resp.userPartyGroupType = 'Patent owner';
        //       break;
        //     default:
        //       break;
        //   }
        //   this.rowData.allAiaReviews.push(resp);
        // });
        this.recordCountInfo.dataLength = this.rowData.allAiaReviews.length;
        this.loading = false;
       
      },
      (response) => {
        this.rowData.allAiaReviews = [];
        this.loading = false;
      }
    );
  }

  gridPaginationAction(e) {
    this.recordCountInfo.lastPage = false;
   
    this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    this.recordCountInfo.currentPage = this.currentPage;
    this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.rowData.allAiaReviews.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.gridParams.gridApi.paginationSetPageSize(
        this.rowData.allAiaReviews.length
      );
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      // this.dataList = this.filteredData.slice(
      //   Math.floor(this.filteredData.length / pageSizeEvent) * pageSizeEvent,
      //   this.filteredData.length
      // );
      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.allAiaReviews.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      this.gridParams.gridApi.paginationGoToPage(
        this.paginationInfo.currentPage
      );
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // this.dataList = this.filteredData.slice(
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      //     this.paginationInfo.pageSize,
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // );
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.allAiaReviews.length / this.paginationInfo.pageSize
      );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.gridParams.gridApi.paginationGoToPage(
        this.recordCountInfo.currentPage - 1
      );
      // this.paginationInfo.pageSize = pageSizeEvent;
      // this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // // this.dataList = this.filteredData.slice(
      // //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      // //     this.paginationInfo.pageSize,
      // //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // // );
      // this.paginationInfo.totalPages = Math.ceil(
      //   this.rowData.allAiaReviews.length / this.paginationInfo.pageSize
      // );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);
      // this.gridParams.gridApi.paginationGoToPage(
      //   this.recordCountInfo.currentPage
      // );
      // this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
      // this.recordCountInfo.currentPage = this.currentPage;
      // this.paginationInfo.currentPage = this.currentPage;
    }
    // this.paginationPageSize = pageSizeEvent;
    // this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);
    // this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    // this.paginationInfo.totalPages = this.totalPages;
  }
}
