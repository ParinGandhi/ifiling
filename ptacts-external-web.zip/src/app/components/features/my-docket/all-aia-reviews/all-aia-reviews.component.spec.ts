import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllAiaReviewsComponent } from './all-aia-reviews.component';

describe('AllAiaReviewsComponent', () => {
  let component: AllAiaReviewsComponent;
  let fixture: ComponentFixture<AllAiaReviewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllAiaReviewsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllAiaReviewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
