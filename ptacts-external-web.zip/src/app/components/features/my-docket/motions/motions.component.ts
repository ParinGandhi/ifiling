import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { MyDocketService } from '../my-docket.services';
import { FilterPipe } from 'src/app/utilities/table-filter-pipe';

@Component({
  selector: 'app-motions',
  templateUrl: './motions.component.html',
  styleUrls: ['./motions.component.scss'],
})
export class MotionsComponent implements OnInit {
  expanded: boolean = false;
  allClassActive: boolean = false;
  pendingClassActive: boolean = false;
  unsubmittedClassActive: boolean = false;
  dataList: any;
  motions = {
    ALL: [],
    INITIATED: [],
    PENDING_REVIEW: [],
  };
  orderByField: any[] = [];
  motionTypes = ['ALL', 'INITIATED', 'PENDING_REVIEW'];
  activeTab: string = 'Pending';
  paginationInfo: PaginationModel = new PaginationModel();
  recordCountInfo: RecordCountModel = new RecordCountModel();
  originalData: any;
  filteredData: any;
  hasFilters: boolean = false;
  documentsTableColSpan: number = 7;
  tableOptions = {
    tableId: 'rehearingTable',
    tableHeaderClass: 'rehearingTableHeader',
    tableBodyClass: 'rehearingTableBody',
    columnDefs: [],
  };
  unsubmittedColumnDefs = [
    {
      name: 'Motion initiated date',
      displayName: 'Motion initiated date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '13%',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'proceedingNumber',
      displayName: 'AIA review #',
      field: 'proceedingNumber',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Motion type',
      displayName: 'Motion type',
      field: 'motionTypeNm',
      width: '20%',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Motion status',
      displayName: 'Motion status',
      field: 'motionStatusName',
      width: '12%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Motion',
      displayName: 'View motion',
      field: 'viewNotice',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Action(s)',
      displayName: 'Action(s)',
      field: 'action',
      width: '10%',
      type: 'string',
      searchText: null,
    },
  ];
  otherColumnDefs = [
    {
      name: 'Motion submitted date',
      displayName: 'Motion submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '13%',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'proceedingNumber',
      displayName: 'AIA review #',
      field: 'proceedingNumber',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Motion type',
      displayName: 'Motion type',
      field: 'motionTypeNm',
      width: '20%',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Motion status',
      displayName: 'Motion status',
      field: 'motionStatusName',
      width: '12%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Motion',
      displayName: 'View motion',
      field: 'viewNotice',
      width: '10%',
      type: 'string',
      searchText: null,
    },
  ];
  dataLoading = {
    ALL: false,
    INITIATED: false,
    PENDING_REVIEW: false,
  };
  sortCount: boolean = true;

  constructor(
    public commonUtils: CommonUtilitiesService,
    private datePipe: DatePipe,
    private myDocketService: MyDocketService,
    private logger: NGXLogger,
    private tableFilter: FilterPipe
  ) {}

  ngOnInit(): void {
    this.pendingClassActive = true;
    // this.dataList = [
    //   {
    //     motionId: 2710908,
    //     requestorTypeId: 2,
    //     requestorTypeName: 'Patent Owner',
    //     filedDate: '2021-07-21 14:43:19.292',
    //     motionTypeId: 8,
    //     motionTypeNm: 'Motion to Seal',
    //     motionStatusId: 2,
    //     motionStatusName: 'GRANTED',
    //     motionStatusDate: '2021-07-21 14:46:17.0',
    //     proceedingId: 1547131,
    //     proceedingNumber: 'IPR2021-00691',
    //     motionDocuments: [
    //       {
    //         documentNumber: 7,
    //         name: 'Motion to Seal',
    //         category: 'PAPER',
    //         fileName: 'Document.pdf',
    //         filingParty: 'PATENT OWNER',
    //         availability: 'Public',
    //         documentTypeIdentifier: 1,
    //         documentTypeCode: 'MOTION',
    //         documentTypeDescription: 'Motion',
    //         pageCount: 1,
    //         contentManagementId:
    //           'workspace://SpacesStore/10474851-6c4a-437f-806c-b46750bf755e;1.0',
    //         artifactIdentifer: 170133784,
    //         artifactSubmissionIdentifier: 85476384,
    //         filingDate: 1626892999,
    //         filingDateString: '07/21/2021',
    //         fileSize: 0,
    //         documentStatus: 'PENDING',
    //         directionCode: 'INCOMING',
    //         warningMessageList: [],
    //         availablitySummary: {
    //           code: 'PUBLIC',
    //           descriptionText: 'Available for everyone.',
    //           displayNameText: 'Public',
    //         },
    //         roleSummary: {
    //           code: 'PATENT OWNER',
    //           descriptionText:
    //             'Indicates artifact was submitted on behalf of Patent Owner.',
    //           displayNameText: 'Patent owner',
    //         },
    //         artifactSummary: {
    //           code: 'PAPER',
    //           descriptionText: 'Paper',
    //         },
    //       },
    //     ],
    //   },
    // ];

    this.paginationInfo.currentPage = 1;
    this.paginationInfo.pageSize = 25;

    this.motionTypes.forEach((motionType) => {
      this.getMotions(motionType);
    });
  }

  getMotions(motionType) {
    this.dataLoading[motionType] = true;
    this.myDocketService
      .getMotions(motionType)
      .pipe(take(1))
      .subscribe(
        (motionsList) => {
          this.motions[motionType] = motionsList;
          if (motionType === 'PENDING_REVIEW') {
            this.dataList = motionsList;
            this.setMotionsTable('otherColumnDefs');
          }
          this.dataLoading[motionType] = false;
        },
        () => {
          this.dataLoading[motionType] = false;
        }
      );
  }

  setMotionsTable(motionType) {
    this.tableOptions.columnDefs = this[motionType];
    this.commonUtils.clearTableFilter(this.tableOptions.columnDefs);
    this.orderByField.push('filedDate');
    this.sortColumn('filedDate', 'desc');
  }

  changeTab(tabName: any) {
    this.activeTab = tabName;
    this.hasFilters = false;
    //
    // this.tableOptions.columnDefs[0].displayName =
    //   'Motion submitted date (mm/dd/yyyy)';
    // this.filteredData = this.copyOfOriginal(this.motions[]);

    this.orderByField = [];
    if (tabName == 'All') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.ALL));
      this.setMotionsTable('otherColumnDefs');
      this.allClassActive = true;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Pending') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.PENDING_REVIEW));
      this.setMotionsTable('otherColumnDefs');
      this.allClassActive = false;
      this.pendingClassActive = true;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Unsubmitted') {
      this.dataList = JSON.parse(JSON.stringify(this.motions.INITIATED));
      this.setMotionsTable('unsubmittedColumnDefs');
      // this.tableOptions.columnDefs[0].displayName =
      //   'Motion initiated date (mm/dd/yyyy)';
      this.allClassActive = false;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = true;
    }
    this.documentsTableColSpan = this.tableOptions?.columnDefs?.length
      ? this.tableOptions.columnDefs.length
      : 0;
  }

  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    });
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  sortColClick(field) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    this.sortCount = false;
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    if (this.sortCount) {
      this.orderByField = ['-filedDate', '-proceedingNumber'];
    }
  }

  correctOrder(field) {
    let motType = null;
    switch (this.activeTab) {
      case 'All':
        motType = 'ALL';
        break;
      case 'Pending':
        motType = 'PENDING_REVIEW';
        break;
      case 'Unsubmitted':
        motType = 'INITIATED';
        break;
      default:
        break;
    }
    this.dataList.forEach((ele) => {
      if (ele.motionStatusDate === undefined) {
        ele.motionStatusDate = null;
      }
    });
    const tempData = this.hasFilters
      ? [...this.filteredData]
      : // : [...this.dataList];
        [...this.motions[motType]];
    this.hasFilters ? (this.filteredData = []) : (this.dataList = []);
    const order = field.charAt(0) === '-' ? 'desc' : 'asc';
    tempData.sort(this.compareValues(field, order));
    // this.dataList = [...tempData];
    if (!this.hasFilters) {
      this.originalData = [...tempData];
    }
    this.filteredData = [...tempData];
    this.dataList = this.filteredData.slice(
      0,
      parseInt(this.paginationInfo.pageSize)
    );
    this.paginationInfo.totalPages = Math.ceil(
      this.filteredData.length / this.paginationInfo.pageSize
    );
    this.recordCountInfo.dataLength = this.filteredData.length;
  }

  // convertToCSV(objArray) {
  //   var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
  //   var str = '';

  //   for (var i = 0; i < array.length; i++) {
  //     var line = '';
  //     for (var index in array[i]) {
  //       if (line != '') line += ',';

  //       line += array[i][index];
  //     }

  //     str += line + '\r\n';
  //   }

  //   return str;
  // }

  exportCSVFile(fileTitle) {
    fileTitle = `${
      this.activeTab
    } ${fileTitle} ${this.commonUtils.getCurrentDateString(new Date())}`;
    const dataToExport = [];
    this.filteredData.forEach((element) => {
      let row: any = {};
      row.filedDate = `${this.datePipe.transform(
        element.filedDate,
        'MM/dd/yyyy hh:mm a'
      )} ET`;
      row.proceedingNumber = element.proceedingNumber;
      row.requestorTypeName = this.commonUtils.convertStringToTitleCase(
        element.requestorTypeName
      );
      row.userPartyGroupType = this.commonUtils.convertStringToTitleCase(
        element.userPartyGroupType
      );
      row.motionTypeNm = element.motionTypeNm;
      row.motionStatusName = this.commonUtils.convertStringToTitleCase(
        element.motionStatusName
      );
      dataToExport.push(row);
    });
    // let headers = {
    //   filedDate: this.unsubmittedClassActive
    //     ? 'Motion initiated date (mm/dd/yyyy)'
    //     : 'Motion submitted date (mm/dd/yyyy)',
    //   proceedingNumber: 'AIA review #',
    //   requestorTypeName: 'Filing party',
    //   userPartyGroupType: 'Party representing',
    //   motionTypeNm: 'Motion type',
    //   motionStatusName: 'Motion status',
    // };
    let headers = [
      'AIA review #',
      'Filing party',
      'Party representing',
      'Motion type',
      'Motion status',
    ];
    headers.unshift(
      this.unsubmittedClassActive
        ? 'Motion initiated date (mm/dd/yyyy)'
        : 'Motion submitted date (mm/dd/yyyy)'
    );
    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);

    // Convert Object to JSON
    // var jsonObject = JSON.stringify(dataToExport);

    // var csv = this.convertToCSV(jsonObject);

    // var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    // var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    // // if (navigator.msSaveBlob) { // IE 10+
    // //     navigator.msSaveBlob(blob, exportedFilenmae);
    // // } else {
    // var link = document.createElement('a');
    // if (link.download !== undefined) {
    //   // feature detection
    //   // Browsers that support HTML5 download attribute
    //   var url = URL.createObjectURL(blob);
    //   link.setAttribute('href', url);
    //   link.setAttribute('download', exportedFilenmae);
    //   link.style.visibility = 'hidden';
    //   document.body.appendChild(link);
    //   link.click();
    //   document.body.removeChild(link);
    // }
    // }
  }

  openPdf(data, proceedingId) {
    this.myDocketService.openPdf(proceedingId, data.artifactIdentifer);
    // .pipe(take(1))
    // .subscribe(
    //   (pdfResponse) => {
    //     this.commonUtils.openPdfNew(pdfResponse);
    //   },
    //   (pdfResponseError) => {
    //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   }
    // );
  }

  gridPaginationAction(event) {
    this.recordCountInfo.lastPage = false;
    let fromPage = null;
    let toPage = null;
    switch (event.pageAction) {
      case 'first':
        this.dataList = this.filteredData.slice(
          0,
          this.paginationInfo.pageSize
        );
        this.paginationInfo.currentPage = 1;
        this.recordCountInfo.currentPage = 1;
        break;
      case 'previous':
        if (this.paginationInfo.currentPage > 1) {
          this.paginationInfo.currentPage--;
          this.recordCountInfo.currentPage--;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          this.dataList = this.filteredData.slice(fromPage, toPage);
        }
        break;
      case 'next':
        // this.dataList = this.copyOfOriginal();
        // this.dataList.slice(25, this.paginationInfo.pageSize);
        if (
          this.paginationInfo.currentPage <
          Math.ceil(this.filteredData.length / this.paginationInfo.pageSize)
        ) {
          this.paginationInfo.currentPage++;
          this.recordCountInfo.currentPage++;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          if (toPage > this.filteredData.length) {
            toPage = this.filteredData.length;
          }
          this.dataList = this.filteredData.slice(fromPage, toPage);
        }
        break;
      case 'last':
        this.paginationInfo.currentPage = Math.ceil(
          this.filteredData.length / this.paginationInfo.pageSize
        );
        this.recordCountInfo.currentPage = this.paginationInfo.currentPage;

        this.dataList = this.filteredData.slice(
          this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize,
          this.filteredData.length
        );
        break;
      case 'specificPage':
        // gridApi.paginationGoToPage(parseInt(event.pageNo));
        if (event.pageNo >= this.paginationInfo.totalPages) {
          event.pageNo = this.paginationInfo.totalPages - 1;
        }
        if (
          event.pageNo >= 0 &&
          event.pageNo <=
            Math.ceil(this.filteredData.length / this.paginationInfo.pageSize)
        ) {
          this.paginationInfo.currentPage = event.pageNo + 1;
          this.recordCountInfo.currentPage = event.pageNo + 1;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          if (toPage > this.filteredData.length) {
            toPage = this.filteredData.length;
          }
          this.dataList = this.filteredData.slice(fromPage, toPage);
        } else {
          this.paginationInfo.currentPage = event.pageNo + 1;
          this.recordCountInfo.currentPage = event.pageNo + 1;
        }

        break;
      default:
        break;
    }
    // this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    // this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    // this.recordCountInfo.currentPage = this.currentPage;
    // this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.filteredData.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.dataList = this.filteredData;
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      this.dataList = this.filteredData.slice(
        Math.floor(this.filteredData.length / pageSizeEvent) * pageSizeEvent,
        this.filteredData.length
      );
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.filteredData.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.filteredData.length / this.paginationInfo.pageSize
      );
      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.dataList = this.filteredData.slice(
        this.paginationInfo.currentPage * this.paginationInfo.pageSize -
          this.paginationInfo.pageSize,
        this.paginationInfo.currentPage * this.paginationInfo.pageSize
      );

      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;

      // this.paginationInfo.pageSize = pageSizeEvent;
      // this.recordCountInfo.paginationPageSize = pageSizeEvent;

      // this.dataList = this.filteredData.slice(
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      //     this.paginationInfo.pageSize,
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // );
      // this.paginationInfo.totalPages = Math.ceil(
      //   this.filteredData.length / this.paginationInfo.pageSize
      // );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
    }

    // this.recordCountInfo.paginationPageSize = this.paginationPageSize;
  }

  copyOfOriginal(dataToCopy) {
    return JSON.parse(JSON.stringify(dataToCopy));
  }

  searchEntireData() {
    this.filteredData = this.tableFilter.transform(
      this.originalData,
      this.tableOptions.columnDefs
    );
    const action = {
      pageAction: 'first',
      pageNo: null,
    };
    this.gridPaginationAction(action);
    this.paginationInfo.totalPages = Math.ceil(
      this.filteredData.length / this.paginationInfo.pageSize
    );
    this.recordCountInfo.dataLength = this.filteredData.length;
    this.hasFilters = false;
    this.tableOptions.columnDefs.forEach((column) => {
      if (column.searchText) {
        this.hasFilters = true;
      }
    });
  }

  continueMotion(motion) {
    // this.router.navigate([
    //   `case-viewer/${this.petitionInfo.serialNo}/${this.petitionInfo.proceedingNumberText}`,
    // ]);
    const motionInfo = {
      proceedingNo: motion.proceedingNumber,
      motionId: motion.motionId,
    };
    window.sessionStorage.setItem('motionInfo', JSON.stringify(motionInfo));
    this.logger.info('motion: ', motion);
    // document.getElementById('aia-review-info').click();
    this.commonUtils.openCaseViewer(
      motion.proceedingNumber,
      '/aia-review-info'
    );
    setTimeout(() => {
      window.sessionStorage.removeItem('motionInfo');
    }, 500);
  }

  deleteMotion(motionToDelete) {
    this.myDocketService
      .deleteMotion(motionToDelete.motionId)
      .pipe(take(1))
      .subscribe(
        (deleteMotionSuccess) => {
          this.logger.info('Delete motion success', deleteMotionSuccess);
          this.dataList = [];
          this.getMotions('ALL');
          this.getMotions('INITIATED');
          this.changeTab('Pending');
          this.commonUtils.showSuccess(
            'Successfully deleted motion request',
            'Delete motion request'
          );
        },
        (deleteMotionFailure) => {
          this.logger.error('Failed to delete motion', deleteMotionFailure);
          this.commonUtils.showError(
            'Failed to delete motion request',
            'Delete motion request'
          );
        }
      );
  }
}
