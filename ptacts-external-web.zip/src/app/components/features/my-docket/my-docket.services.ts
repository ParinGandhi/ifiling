/**
 * ! Example service for the user component. Business logic should be performed to the response
 * ! before returning it to the component.
 * ! Common functionality can still be in a separate service file that can be injected into
 * ! each service.
 */

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Urls } from 'src/app/constants/urls';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { environment } from 'src/environments/environment';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class MyDocketService {
  private EXTERNAL_SERVICE_BASE = environment.EXTERNAL_SERVICE_API;

  constructor(
    private http: HttpClient,
    private datePipe: DatePipe,
    private gridHelperService: GridHelperService
  ) {}

  getHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': emailId,
      }),
      withCredentials: true,
      crossDomain: true,
    };

    return httpOptions;
  }

  /** Add pending reviews calls and logic here  */
  getPendingAIAReviews(emailId): Observable<any> {
    return (
      this.http
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?caseStatus=ext-pending-aia-reviews`,
          {observe: 'response'}
        )
        // .get<any>(
        //   `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?username=${emailId}&proceedingState=ext-pending-aia-reviews`,
        //   this.getHeaders()
        // )
        .pipe(
          map((pendingAIAResponse) => {
            pendingAIAResponse.body.forEach((element) => {
              element.filingDateStr =
                this.gridHelperService.convertDateToString(element.filingDate);
              if (element.userPartyGroupType.toLowerCase() === 'petitioner') {
                element.userPartyGroupType = 'Petitioner';
              } else if (
                element.userPartyGroupType.toLowerCase() === 'patentowner'
              ) {
                element.userPartyGroupType = 'Patent Owner';
              }
            });
            return pendingAIAResponse;
          })
        )
    );
  }

  /** Add pending reviews calls and logic here  */
  getAllAIAReviews(emailId): Observable<any> {
    return (
      this.http
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?caseStatus=ext-aia-reviews`
        )
        // .get<any>(
        //   `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?username=${emailId}&proceedingState=ext-aia-reviews`,
        //   this.getHeaders()
        // )
        .pipe(
          map((allAIAResponse) => {
           
            allAIAResponse.forEach((element) => {
              element.filingDateStr =
                this.gridHelperService.convertDateToString(element.filingDate);
              if (element.userPartyGroupType.toLowerCase() === 'petitioner') {
                element.userPartyGroupType = 'Petitioner';
              } else if (
                element.userPartyGroupType.toLowerCase() === 'patentowner'
              ) {
                element.userPartyGroupType = 'Patent Owner';
              }
            });
            return allAIAResponse;
          })
        )
    );
  }

  getAllNotifications(emailId): Observable<any> {
    return (
      this.http
        // .get<any>(
        //   `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/notifications?username=${emailId}`,
        //   this.getHeaders()
        // )
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/notifications?username=${emailId}`
        )
        .pipe(
          map((notificationResponse) => {
           
            notificationResponse.forEach((element) => {
              element.allRecipientList = [];
              element.tolist
                ? element.tolist.forEach((e) => {
                    element.allRecipientList.push(e);
                  })
                : null;
              element.ccList
                ? element.ccList.forEach((e) => {
                    element.allRecipientList.push(e);
                  })
                : null;
              element.sendTimeStamp = parseInt(element.sendTimeStamp) * 1000;
              element.sendTimeStampStr = this.gridHelperService.convertDateTime(
                element.sendTimeStamp
              );
            });

            return notificationResponse;
          })
        )
    );
  }

  getEmailContent(notificationId): Observable<any> {
    return this.http
      .get<any>(
        // `${this.COMMON_BASE_URL}/notificationemail/${notificationId}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.NOTIFICATIONS.EMAIL_CONTENT}${notificationId}`
      )
      .pipe(
        map((emailResponse) => {
          return emailResponse;
        })
      );
  }

  getUsers(): Observable<any> {
    return this.http.get<Array<any>>(Urls.USERS.GET).pipe(
      map((userResponse) => {
        const tempList = [];
        userResponse.forEach((element) => {
          let newUserObj = element;
          //newUserObj.randomNumber = this.commonUtils.generateRandomNumber();
          newUserObj.randomNumber = Math.floor(Math.random() * 100) + 1;
          tempList.push(newUserObj);
        });
        return tempList;
      })
    );
  }

  getMotions(motionStatus: string): Observable<any> {
    let emailId = window.sessionStorage.getItem('email');
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/motions?motionStatus=${motionStatus}`
      )
      .pipe(
        map((motionsResponse) => {
          // const tempList = [];
          motionsResponse.forEach((element) => {
            element.filingDate = this.convertDateToString(
              new Date(element.filingDate).getTime()
            );
            // let newUserObj = element;
            // newUserObj.randomNumber = this.commonUtils.generateRandomNumber();
            // tempList.push(newUserObj);
          });
          return motionsResponse;
        })
      );
  }

  getRehearings(rehearingStatus: string): Observable<any> {
    let emailId = window.sessionStorage.getItem('email');
    return this.http
      .get<any>(
        // `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/rehearings?username=${emailId}&rehearingStatus=${rehearingStatus}`
        `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/rehearings?rehearingStatus=${rehearingStatus}`
      )
      .pipe(
        map((rehearingResponse) => {
          // return rehearingResponse;
          // const sortedResponse = [...rehearingResponse];
          // sortedResponse.sort(function (objA, objB) {
          //   var filedDateA = objA.filedDate;
          //   var filedDateB = objB.filedDate;

          //   if (filedDateA && filedDateB) {
          //     const tempA = filedDateA.split(' ');
          //     const tempB = filedDateB.split(' ');

          //     // filedDateA = new Date(tempA[0]).getTime();
          //     // filedDateB = new Date(tempB[0]).getTime();
          //     filedDateA = tempA[0];
          //     filedDateB = tempB[0];

          //     // Sort first on day
          //     if (filedDateA > filedDateB) {
          //       return 1;
          //     } else if (filedDateA < filedDateB) {
          //       return -1;
          //     } else {
          //       // If the days are the same,
          //       // do a nested sort on total.
          //       var proceedingNoA = objA.proceedingNumber;
          //       var proceedingNoB = objB.proceedingNumber;

          //       // return proceedingNoA.localeCompare(proceedingNoB, 'en', {
          //       //   numeric: true,
          //       //   sensitivity: 'base',
          //       // });

          //       if (proceedingNoA < proceedingNoB) {
          //         return 1;
          //       } else if (proceedingNoA > proceedingNoB) {
          //         return -1;
          //       } else {
          //         return 0;
          //       }

          //       // if (proceedingNoA < proceedingNoB) {
          //       //   return 1;
          //       // } else if (proceedingNoA > proceedingNoB) {
          //       //   return -1;
          //       // } else {
          //       //   return 0;
          //       // }
          //     }
          //   }
          // });
          // return sortedResponse;

          let sort1 = [...rehearingResponse].sort((a, b) => {
            const prop1 = 'filedDate';
            const prop2 = 'proceedingNumber';

            const tempA = a[prop1] ? a[prop1].split(' ') : null;
            const tempB = b[prop1] ? b[prop1].split(' ') : null;

            let filedDateA = tempA ? new Date(tempA[0]).valueOf() : null;
            let filedDateB = tempB ? new Date(tempB[0]).valueOf() : null;

            if (filedDateA == filedDateB) {
              //

              if (a[prop2] === b[prop2]) {
                return 0;
              }
              return a[prop2] > b[prop2] ? -1 : 1;
            } else {
              return filedDateA > filedDateB ? -1 : 1;
            }
          });
          return sort1;
        })
      );
  }

  /** Add unsubmitted state calls and logic here  */
  getUnsubmittedCases(emailId): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/aia-reviews?caseStatus=ext-aia-unsubmitted`
      )
      .pipe(
        map((allAIAResponse) => {
         
          allAIAResponse.forEach((element) => {
            element.prcdCreatedTsStr =
              this.gridHelperService.convertRegularDate(element.prcdCreatedTs);
            element.lastModifiedTimestampStr =
              this.gridHelperService.convertRegularDateTime(
                element.lastModifiedTimestamp
              );
          });
          return allAIAResponse;
        })
      );
  }

  getAiaAppeals(appealStatus: string): Observable<any> {
    let emailId = window.sessionStorage.getItem('email');
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/external-user-docket/appeals?appealStatus=${appealStatus}`
      )
      .pipe(
        map((motionsResponse) => {
          let sort1 = [...motionsResponse].sort((a, b) => {
            const prop1 = 'appealNoticeDt';
            const prop2 = 'proceedingNo';

            const tempA = a[prop1] ? a[prop1].split(' ') : null;
            const tempB = b[prop1] ? b[prop1].split(' ') : null;

            let filedDateA = tempA ? new Date(tempA[0]).valueOf() : null;
            let filedDateB = tempB ? new Date(tempB[0]).valueOf() : null;

            if (filedDateA == filedDateB) {
              //

              if (a[prop2] === b[prop2]) {
                return 0;
              }
              return a[prop2] > b[prop2] ? -1 : 1;
            } else {
              return filedDateA > filedDateB ? -1 : 1;
            }
          });
          return sort1;
          // motionsResponse.sort(function (objA, objB) {
          //   var filedDateA = objA.appealNoticeDt;
          //   var filedDateB = objB.appealNoticeDt;

          //   if (filedDateA && filedDateB) {
          //     // Sort first on day
          //     if (filedDateA > filedDateB) {
          //       return 1;
          //     } else if (filedDateA < filedDateB) {
          //       return -1;
          //     } else {
          //       // If the days are the same,
          //       // do a nested sort on total.
          //       var proceedingNoA = objA.proceedingNo;
          //       var proceedingNoB = objB.proceedingNo;

          //       return proceedingNoA.localeCompare(proceedingNoB, 'en', {
          //         numeric: true,
          //         sensitivity: 'base',
          //       });

          //       // if (proceedingNoA < proceedingNoB) {
          //       //   return 1;
          //       // } else if (proceedingNoA > proceedingNoB) {
          //       //   return -1;
          //       // } else {
          //       //   return 0;
          //       // }
          //     }
          //   }
          // });
          // // const tempList = [];
          // // motionsResponse.forEach((element) => {
          // //   element.appealNoticeDt = this.commonUtils.convertDateToString(
          // //     new Date(element.appealNoticeDt).getTime()
          // //   );
          // //   // let newUserObj = element;
          // //   // newUserObj.randomNumber = this.commonUtils.generateRandomNumber();
          // //   // tempList.push(newUserObj);
          // // });

          // return motionsResponse;
        })
      );
  }

  openPdf(proceedingId: string, artifactId: string) {
    const email = window.sessionStorage.getItem('email');
    let url = `${this.EXTERNAL_SERVICE_BASE}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`;
    if (email === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}/petitions/${proceedingId}/download-documents?artifactId=${artifactId}`;
    }
    window.open(url, "_blank");
    // return this.http.get(url, { responseType: 'arraybuffer' as 'json' }).pipe(
    //   map((pdfResponse) => {
    //     //return pdfResponse;
    //   })
    // );
  }

  deleteRehearing(rehearingId): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}/trials/rehearing-info/delete-rehearing/${rehearingId}`
      )
      .pipe(
        map((deleteRehearingResponse) => {
          return deleteRehearingResponse;
        })
      );
  }

  deleteMotion(motionId): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}/trials/motions/delete-motion/${motionId}`
      )
      .pipe(
        map((deleteMotionResponse) => {
          return deleteMotionResponse;
        })
      );
  }

  convertDateToString(epochDate) {
    if (!epochDate) {
      return '';
    }
    if (epochDate.toString().length > 10) {
      return this.datePipe.transform(
        parseInt(epochDate),
        'MM/dd/yyyy hh:mm a '
      );
    } else {
      return this.datePipe.transform(
        parseInt(epochDate) * 1000,
        'MM/dd/yyyy hh:mm a '
      );
    }
  }


}
