import { Component, OnDestroy, OnInit, NgZone } from '@angular/core';

import { GridOptionsModel } from 'src/app/models/common/GridOptions.model';
import { GridParamsModel } from 'src/app/models/common/GridParams.model';
import { GridHelperService } from 'src/app/services/grid-helper.service';
import { MyDocketService } from '../my-docket.services';
import { OpenCaseViewerComponent } from 'src/app/components/common/open-case-viewer/open-case-viewer.component';
import { ContinueRendererComponent } from 'src/app/components/features/my-docket/renderer/continue-renderer/continue-renderer.component';
import { CONSTANTS } from 'src/app/constants/constants';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  setNewPetitionInfo,
  setTrialInfo,
} from 'src/app/store/ptacts/ptacts.actions';
import { Router } from '@angular/router';
import { InitiatePetitionService } from '../../initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-unsubmitted-petitions',
  templateUrl: './unsubmitted-petitions.component.html',
  styleUrls: ['./unsubmitted-petitions.component.scss'],
})
export class UnsubmittedPetitionsComponent implements OnInit, OnDestroy {
  gridOptions = new GridOptionsModel();
  gridParams = new GridParamsModel();
  userName: string;
  numberOfFilters: number;
  frameworkComponents: any;
  loading: boolean;
  rowDataClicked = {};
  paginationPageSize = CONSTANTS.PAGINATION.DEFAULT;
  currentPage: number = 1;
  totalPages: number = null;
  recordCountInfo: RecordCountModel = new RecordCountModel();
  paginationInfo: PaginationModel = new PaginationModel();

  columnDefs = {
    unsubmittedCases: [
      {
        field: 'proceedingNo',
        headerName: 'AIA Review #',
        width: '150px',
        sort: 'desc',
        sortIndex: 2,
        // cellRendererFramework: OpenCaseViewerComponent,
      },
      {
        field: 'prcdCreatedTsStr',
        headerName: 'Initiated date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '145px',
        type: 'date',
      },
      { field: 'userRole', headerName: 'My role', width: '160px' },
      {
        field: 'petitionerApplicationNumber',
        headerName: 'Petitioner application #',
      },
      { field: 'petitionerPatentNumber', headerName: 'Petitioner patent #' },
      {
        field: 'petitionerRealParty',
        headerName: 'Petitioner name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'poApplicationNumber',
        headerName: 'PO/Respondent app #',
        width: '150px',
      },
      {
        field: 'poPatentNumber',
        headerName: 'PO/Respondent patent #',
        width: '150px',
      },
      {
        field: 'poRealParty',
        headerName: 'PO/Respondent name',
        comparator: this.gridHelperService.caseInsensitiveSort,
      },
      {
        field: 'lastModifiedTimestampStr',
        headerName: 'Last updated date (mm/dd/yyyy)',
        comparator: this.gridHelperService.dateComparator,
        width: '250px',
        sort: 'desc',
        sortIndex: 1,
        type: 'date',
      },
      {
        headerName: 'Action',
        cellRenderer: 'buttonRenderer',
        width: '220px',
        autoHeight: true,
        filter: false,
        cellRendererParams: {
          onClick: this.onActionClick.bind(this),
          label: 'Continue',
        },
      },
    ],
  };

  rowData = {
    unsubmittedCases: [],
  };

  constructor(
    public gridHelperService: GridHelperService,
    private myDocketService: MyDocketService,
    private router: Router,
    private zone: NgZone,
    private store: Store<PtactsState>,
    private initiatePetitionServices: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    this.frameworkComponents = {
      buttonRenderer: ContinueRendererComponent,
    };
    this.getUnsubmittedCases();
    this.loading = true;
    this.recordCountInfo.currentPage = this.currentPage;
    this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    this.paginationInfo.currentPage = this.currentPage;
  }

  onGridReady(params) {
    this.gridParams = this.gridHelperService.onGridReady(params);
    this.gridParams.gridApi.setDomLayout('autoHeight');
    this.gridParams.fileName = 'Unsubmitted';
    this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    this.paginationInfo.totalPages = this.totalPages;
  }

  ngOnDestroy(): void {}

  getUnsubmittedCases() {
    const emailId = window.sessionStorage.getItem('email');
    this.myDocketService.getUnsubmittedCases(emailId).subscribe(
      (response) => {
        this.numberOfFilters = 0;
        this.rowData.unsubmittedCases = [];
        response.forEach((resp) => {
          switch (resp.userPartyGroupType) {
            case 'PETITIONER':
              resp.userPartyGroupType = 'Petitioner';
              break;
            case 'PATENTOWNER':
              resp.userPartyGroupType = 'Patent owner';
              break;
            default:
              break;
          }
          this.rowData.unsubmittedCases.push(resp);
        });
        this.recordCountInfo.dataLength = this.rowData.unsubmittedCases.length;
        this.loading = false;
      },
      (response) => {
        this.rowData.unsubmittedCases = [];
        this.loading = false;
      }
    );
  }

  onActionClick(e) {
    this.rowDataClicked = e.rowData;
  }

  gridPaginationAction(e) {
    this.recordCountInfo.lastPage = false;

    this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    this.recordCountInfo.currentPage = this.currentPage;
    this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.rowData.unsubmittedCases.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.gridParams.gridApi.paginationSetPageSize(
        this.rowData.unsubmittedCases.length
      );
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      // this.dataList = this.filteredData.slice(
      //   Math.floor(this.filteredData.length / pageSizeEvent) * pageSizeEvent,
      //   this.filteredData.length
      // );
      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.unsubmittedCases.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      this.gridParams.gridApi.paginationGoToPage(
        this.paginationInfo.currentPage
      );
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // this.dataList = this.filteredData.slice(
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      //     this.paginationInfo.pageSize,
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // );
      this.paginationInfo.totalPages = Math.ceil(
        this.rowData.unsubmittedCases.length / this.paginationInfo.pageSize
      );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);

      this.gridParams.gridApi.paginationGoToPage(
        this.recordCountInfo.currentPage - 1
      );
      // this.paginationInfo.pageSize = pageSizeEvent;
      // this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // // this.dataList = this.filteredData.slice(
      // //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      // //     this.paginationInfo.pageSize,
      // //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // // );
      // this.paginationInfo.totalPages = Math.ceil(
      //   this.rowData.unsubmittedCases.length / this.paginationInfo.pageSize
      // );
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);
      // this.gridParams.gridApi.paginationGoToPage(
      //   this.recordCountInfo.currentPage
      // );
      // this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
      // this.recordCountInfo.currentPage = this.currentPage;
      // this.paginationInfo.currentPage = this.currentPage;
    }
    // this.paginationPageSize = pageSizeEvent;
    // this.recordCountInfo.paginationPageSize = this.paginationPageSize;
    // this.gridParams.gridApi.paginationSetPageSize(pageSizeEvent);
    // this.totalPages = this.gridParams.gridApi.paginationGetTotalPages();
    // this.paginationInfo.totalPages = this.totalPages;
  }

  onCellKeyDown(e) {
    if (e.event.key === 'Enter' && e.column.colDef.headerName === 'Action') {
      // this.checkForPartyRepresenting(e.data.proceedingNo);
      this.onClick(e);
    }
  }

  onClick(params) {
    // if (params.onClick instanceof Function) {
    // put anything into params u want pass into parents component
    // const params = {
    //   event: $event,
    //   rowData: this.params.node.data
    //   // ...something

    // }
    // this.params.onClick(params);
    let petitionInfo = {
      proceedingNumberText: params.node.data.proceedingNo,
      patentNumber: params.node.data.poPatentNumber,
      trialType: params.node.data.proceedingNo.substr(0, 3),
      petitionerPatentNumber: params.node.data.petitionerPatentNumber,
      petitionerApplicationNumber: params.data?.petitionerApplicationNumber,
      poApplicationNumber: params.data?.poApplicationNumber,
      poPatentNumber: params.data?.poPatentNumber,
    };
    window.sessionStorage.setItem('petitionInfo', JSON.stringify(petitionInfo));

    this.store.dispatch(setNewPetitionInfo({ request: petitionInfo }));

    if (petitionInfo.trialType === 'DER') {
      this.initiatePetitionServices.setOption('isDER', true);
      this.zone.run(() => {
        this.router.navigate(['/ui/initiate-petition/petition-documents']);
      });
    } else {
      this.initiatePetitionServices.setOption('isDER', false);
      this.zone.run(() => {
        this.router.navigate(['/ui/initiate-petition/claims-challenged']);
      });
    }
  }
}
