import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { AdvancedSearchComponent } from '../advanced-search/advanced-search.component';
import { AiaAppealsComponent } from './aia-appeals/aia-appeals.component';
import { AllAiaReviewsComponent } from './all-aia-reviews/all-aia-reviews.component';
import { MotionsRehearingsComponent } from './motions-rehearings/motions-rehearings.component';
import { MotionsComponent } from './motions/motions.component';
import { MyDocketComponent } from './my-docket.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { PendingAiaReviewsComponent } from './pending-aia-reviews/pending-aia-reviews.component';
import { RehearingsComponent } from './rehearings/rehearings.component';
import { UnsubmittedPetitionsComponent } from './unsubmitted-petitions/unsubmitted-petitions.component';

const routes: Routes = [
  {
    path: '',
    component: MyDocketComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'pending-aia-reviews',
      },
      {
        path: 'pending-aia-reviews',
        component: PendingAiaReviewsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'all-aia-reviews',
        component: AllAiaReviewsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'notifications',
        component: NotificationsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'motions',
        component: MotionsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'rehearings',
        component: RehearingsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'aia-appeals',
        component: AiaAppealsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'unsubmitted-petitions',
        component: UnsubmittedPetitionsComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'public-search',
        component: AdvancedSearchComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyDocketRoutingModule {}
