import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RehearingsComponent } from './rehearings.component';

describe('RehearingsComponent', () => {
  let component: RehearingsComponent;
  let fixture: ComponentFixture<RehearingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RehearingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RehearingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
