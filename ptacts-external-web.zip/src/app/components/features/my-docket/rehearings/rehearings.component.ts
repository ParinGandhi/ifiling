import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { MyDocketService } from '../my-docket.services';
import { PaginationModel } from 'src/app/models/common/Pagination.model';
import { RecordCountModel } from 'src/app/models/common/RecordCount.model';
import { FilterPipe } from 'src/app/utilities/table-filter-pipe';

@Component({
  selector: 'app-rehearings',
  templateUrl: './rehearings.component.html',
  styleUrls: ['./rehearings.component.scss'],
})
export class RehearingsComponent implements OnInit {
  expanded: boolean = false;
  allClassActive: boolean = false;
  pendingClassActive: boolean = false;
  unsubmittedClassActive: boolean = false;
  tableOptions: any;
  dataList: any;
  orderByField: any[] = [];
  paginationInfo: PaginationModel = new PaginationModel();
  recordCountInfo: RecordCountModel = new RecordCountModel();
  originalData: any;
  filteredData: any;
  hasFilters: boolean = false;
  rehearings = {
    ALL: [],
    INITIATED: [],
    PENDING_REVIEW: [],
  };
  rehearingTypes = ['ALL', 'INITIATED', 'PENDING_REVIEW'];
  activeTab: string = 'Pending';
  documentsTableColSpan: number = 7;
  unsubmittedColDef = [
    {
      name: 'Rehearing initiated date',
      displayName: 'Rehearing initiated date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '14%',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'proceedingNumber',
      displayName: 'AIA review #',
      field: 'proceedingNumber',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing type',
      displayName: 'Rehearing request type',
      field: 'rehearingTypeNm',
      width: '20%',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Rehearing status',
      displayName: 'Rehearing request status',
      field: 'rehearingStatusDisplayName',
      width: '12%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Rehearing',
      displayName: 'View rehearing request',
      field: 'viewNotice',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Action(s)',
      displayName: 'Action(s)',
      field: 'action',
      width: '10%',
      type: 'string',
      searchText: null,
    },
  ];
  otherColumnDefs = [
    {
      name: 'Rehearing submitted date',
      displayName: 'Rehearing submitted date (mm/dd/yyyy)',
      field: 'filedDate',
      width: '14%',
      type: 'datetime',
      searchText: null,
    },
    {
      name: 'proceedingNumber',
      displayName: 'AIA review #',
      field: 'proceedingNumber',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'FILING PARTY',
      displayName: 'Filing party',
      field: 'requestorTypeName',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Party representing',
      displayName: 'Party representing',
      field: 'userPartyGroupType',
      width: '10%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'Rehearing type',
      displayName: 'Rehearing request type',
      field: 'rehearingTypeNm',
      width: '20%',
      type: 'string',
      searchText: null,
    },

    {
      name: 'Rehearing status',
      displayName: 'Rehearing request status',
      field: 'rehearingStatusDisplayName',
      width: '12%',
      type: 'string',
      searchText: null,
    },
    {
      name: 'View Rehearing',
      displayName: 'View rehearing request',
      field: 'viewNotice',
      width: '10%',
      type: 'string',
      searchText: null,
    },
  ];
  dataLoading = {
    ALL: false,
    INITIATED: false,
    PENDING_REVIEW: false,
  };
  sortCount: boolean = true;
  initialRun: boolean = true;

  constructor(
    public commonUtils: CommonUtilitiesService,
    private datePipe: DatePipe,
    private myDocketService: MyDocketService,
    private logger: NGXLogger,
    private tableFilter: FilterPipe
  ) {}

  ngOnInit(): void {
    this.pendingClassActive = true;
    this.paginationInfo.currentPage = 1;
    this.paginationInfo.pageSize = 25;
    //this.setRehearingTable();
    this.rehearingTypes.forEach((rehearingType) => {
      this.getRehearing(rehearingType);
    });
  }

  getRehearing(rehearingType) {
    this.dataLoading[rehearingType] = true;
    this.myDocketService
      .getRehearings(rehearingType)
      .pipe(take(1))
      .subscribe(
        (rehearingList) => {
          this.rehearings[rehearingType] = rehearingList;
          if (rehearingType === 'PENDING_REVIEW') {
            this.dataList = rehearingList;

            this.setRehearingTable('otherColumnDefs');
          }
          this.dataLoading[rehearingType] = false;
        },
        () => {
          this.dataLoading[rehearingType] = false;
        }
      );
  }

  setRehearingTable(rehearingType) {
    this.tableOptions = {
      //btnId: this.REHEARINGS,
      tableId: 'rehearingTable',
      tableHeaderClass: 'rehearingTableHeader',
      tableBodyClass: 'rehearingTableBody',
      columnDefs: this[rehearingType],
      data: this.dataList ? JSON.parse(JSON.stringify(this.dataList)) : [],
    };
    this.commonUtils.clearTableFilter(this.tableOptions.columnDefs);
    this.orderByField.push('filedDate');
    this.sortColumn('filedDate', 'desc');
  }

  changeTab(tabName: any) {
    this.activeTab = tabName;
    this.hasFilters = false;
    this.orderByField = [];
    // this.tableOptions.columnDefs[0].displayName =
    //   'Rehearing submitted date (mm/dd/yyyy)';
    if (tabName == 'All') {
      this.dataList = JSON.parse(JSON.stringify(this.rehearings.ALL));
      this.setRehearingTable('otherColumnDefs');
      this.allClassActive = true;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Pending') {
      this.dataList = JSON.parse(
        JSON.stringify(this.rehearings.PENDING_REVIEW)
      );
      this.setRehearingTable('otherColumnDefs');
      this.allClassActive = false;
      this.pendingClassActive = true;
      this.unsubmittedClassActive = false;
    }
    if (tabName == 'Unsubmitted') {
      this.dataList = JSON.parse(JSON.stringify(this.rehearings.INITIATED));
      this.setRehearingTable('unsubmittedColDef');
      // this.tableOptions.columnDefs[0].displayName =
      //   'Rehearing initiated date (mm/dd/yyyy)';
      this.allClassActive = false;
      this.pendingClassActive = false;
      this.unsubmittedClassActive = true;
    }
    this.documentsTableColSpan = this.tableOptions?.columnDefs?.length
      ? this.tableOptions.columnDefs.length
      : 0;
  }

  expandCollapseAll(val) {
    this.dataList.forEach((notice) => {
      notice.expanded = val;
    });
  }

  compareValues(key, order = 'asc') {
    if (key.charAt(0) === '-') {
      key = key.substring(1);
    }
    return function innerSort(a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        // property doesn't exist on either object
        return 0;
      }

      const varA = typeof a[key] === 'string' ? a[key].toUpperCase() : a[key];
      const varB = typeof b[key] === 'string' ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return order === 'desc' ? comparison * -1 : comparison;
    };
  }

  // initialCompareValues(dataToSort) {
  //   dataToSort.sort(function (objA, objB) {
  //     var filedDateA = objA.filedDate;
  //     var filedDateB = objB.filedDate;
  //     //

  //     if (filedDateA && filedDateB) {
  //       const tempA = filedDateA.split(' ');
  //       const tempB = filedDateB.split(' ');
  //       //

  //       filedDateA = new Date(tempA[0]).valueOf();
  //       filedDateB = new Date(tempB[0]).valueOf();
  //       //
  //       // Sort first on day
  //       if (filedDateA > filedDateB) {
  //         return 1;
  //       } else if (filedDateA < filedDateB) {
  //         return -1;
  //       } else {
  //         // If the days are the same,
  //         // do a nested sort on total.
  //         var proceedingNoA = objA.proceedingNumber;
  //         var proceedingNoB = objB.proceedingNumber;

  //         return proceedingNoA.localeCompare(proceedingNoB, 'en', {
  //           numeric: true,
  //           sensitivity: 'base',
  //         });

  //         // if (proceedingNoA > proceedingNoB) {
  //         //   return 1;
  //         // } else if (proceedingNoA < proceedingNoB) {
  //         //   return -1;
  //         // } else {
  //         //   return 0;
  //         // }
  //       }
  //     } else {
  //       return 0;
  //     }
  //   });
  //   return dataToSort;
  // }

  initialCompareValues(arr, prop1, prop2) {
    let sort1 = [...arr].sort((a, b) => {
      const tempA = a[prop1] ? a[prop1].split(' ') : null;
      const tempB = b[prop1] ? b[prop1].split(' ') : null;

      let filedDateA = tempA ? new Date(tempA[0]).valueOf() : null;
      let filedDateB = tempB ? new Date(tempB[0]).valueOf() : null;

      if (filedDateA == filedDateB) {
        //

        if (a[prop2] === b[prop2]) {
          return 0;
        }
        return a[prop2] > b[prop2] ? -1 : 1;
      } else {
        return filedDateA > filedDateB ? -1 : 1;
      }
    });
    return sort1;
  }

  sortColClick(field) {
    // this.orderByField = [];
    this.initialRun = false;
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    this.sortCount = false;
  }

  sortColumn(field, sortType) {
    !this.orderByField.includes(field)
      ? this.correctOrder(field)
      : this.correctOrder('-' + field);
    this.orderByField = !this.orderByField.includes(field)
      ? [field]
      : ['-' + field];
    if (this.sortCount) {
      this.orderByField = ['-filedDate', '-proceedingNumber'];
    }
  }

  correctOrder(field) {
    let rehearType = null;
    switch (this.activeTab) {
      case 'All':
        rehearType = 'ALL';
        break;
      case 'Pending':
        rehearType = 'PENDING_REVIEW';
        break;
      case 'Unsubmitted':
        rehearType = 'INITIATED';
        break;
      default:
        break;
    }
    this.dataList.forEach((ele) => {
      if (ele.motionStatusDate === undefined) {
        ele.motionStatusDate = null;
      }
    });
    // const tempData = [...this.dataList];
    // this.dataList = [];
    let tempData = this.hasFilters
      ? [...this.filteredData]
      : // : [...this.dataList];
        [...this.rehearings[rehearType]];
    this.hasFilters ? (this.filteredData = []) : (this.dataList = []);
    const order = field.charAt(0) === '-' ? 'desc' : 'asc';
    // if (this.initialRun) {
    //   tempData = this.initialCompareValues(
    //     tempData,
    //     'filedDate',
    //     'proceedingNumber'
    //   );
    //   // this.initialRun = false;
    // } else {
    //   tempData.sort(this.compareValues(field, order));
    // }
    if (!this.initialRun) {
      tempData.sort(this.compareValues(field, order));
    }

    // this.originalData = [...tempData];
    // this.dataList = this.originalData.slice(0, 25);
    // this.paginationInfo.totalPages = Math.ceil(
    //   this.originalData.length / this.paginationInfo.pageSize
    // );
    // this.recordCountInfo.dataLength = this.originalData.length;
    if (!this.hasFilters) {
      this.originalData = [...tempData];
    }
    this.filteredData = [...tempData];
    this.dataList = this.filteredData.slice(
      0,
      parseInt(this.paginationInfo.pageSize)
    );
    this.paginationInfo.totalPages = Math.ceil(
      this.filteredData.length / this.paginationInfo.pageSize
    );
    this.recordCountInfo.dataLength = this.filteredData.length;
  }

  // convertToCSV(objArray) {
  //   var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
  //   var str = '';

  //   for (var i = 0; i < array.length; i++) {
  //     var line = '';
  //     for (var index in array[i]) {
  //       if (line != '') line += ',';

  //       line += array[i][index];
  //     }

  //     str += line + '\r\n';
  //   }

  //   return str;
  // }

  exportCSVFile(fileTitle) {
    fileTitle = `${
      this.activeTab
    } ${fileTitle} ${this.commonUtils.getCurrentDateString(new Date())}`;
    const dataToExport = [];
    this.filteredData.forEach((element) => {
      let row: any = {};
      row.filedDate = this.datePipe.transform(element.filedDate, 'MM/dd/yyyy');
      row.proceedingNumber = element.proceedingNumber;
      row.requestorTypeName = this.commonUtils.convertStringToTitleCase(
        element.requestorTypeName
      );
      row.userPartyGroupType = this.commonUtils.convertStringToTitleCase(
        element.userPartyGroupType
      );
      row.rehearingTypeNm = this.commonUtils.convertStringToTitleCase(
        element.rehearingTypeNm
      );
      row.rehearingStatusDisplayName = element.rehearingStatusDisplayName;
      dataToExport.push(row);
    });
    // let headers = {
    //   filedDate: this.unsubmittedClassActive
    //     ? 'Rehearing initiated date (mm/dd/yyyy)'
    //     : 'Rehearing submitted date (mm/dd/yyyy)',
    //   proceedingNumber: 'AIA review #',
    //   requestorTypeName: 'Filing party',
    //   userPartyGroupType: 'Party representing',
    //   rehearingTypeNm: 'Rehearing request type',
    //   rehearingStatusDisplayName: 'Rehearing status',
    // };
    let headers = [
      'AIA review #',
      'Filing party',
      'Party representing',
      'Rehearing request type',
      'Rehearing status',
    ];
    headers.unshift(
      this.unsubmittedClassActive
        ? 'Rehearing initiated date (mm/dd/yyyy)'
        : 'Rehearing submitted date (mm/dd/yyyy)'
    );

    this.commonUtils.exportCSVFile(headers, dataToExport, fileTitle);

    // Convert Object to JSON
    // var jsonObject = JSON.stringify(dataToExport);

    // var csv = this.convertToCSV(jsonObject);

    // var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    // var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    // // if (navigator.msSaveBlob) { // IE 10+
    // //     navigator.msSaveBlob(blob, exportedFilenmae);
    // // } else {
    // var link = document.createElement('a');
    // if (link.download !== undefined) {
    //   // feature detection
    //   // Browsers that support HTML5 download attribute
    //   var url = URL.createObjectURL(blob);
    //   link.setAttribute('href', url);
    //   link.setAttribute('download', exportedFilenmae);
    //   link.style.visibility = 'hidden';
    //   document.body.appendChild(link);
    //   link.click();
    //   document.body.removeChild(link);
    // }
    // }
  }

  openPdf(data, proceedingId) {
    this.myDocketService.openPdf(proceedingId, data.artifactIdentifer);
    // .pipe(take(1))
    // .subscribe(
    //   (pdfResponse) => {
    //     this.commonUtils.openPdfNew(pdfResponse);
    //   },
    //   (pdfResponseError) => {
    //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   }
    // );
  }

  continueRehearing(rehearing) {
    // this.router.navigate([
    //   `case-viewer/${this.petitionInfo.serialNo}/${this.petitionInfo.proceedingNumberText}`,
    // ]);
    const rehearingInfo = {
      proceedingNo: rehearing.proceedingNumber,
      rehearingId: rehearing.rehearingId,
    };
    window.sessionStorage.setItem(
      'rehearingInfo',
      JSON.stringify(rehearingInfo)
    );
    this.logger.info('Rehearing: ', rehearing);
    // document.getElementById('aia-review-info').click();
    this.commonUtils.openCaseViewer(
      rehearing.proceedingNumber,
      '/aia-review-info'
    );
    setTimeout(() => {
      window.sessionStorage.removeItem('rehearingInfo');
    }, 500);
  }

  deleteRehearing(rehearingToDelete) {
    this.myDocketService
      .deleteRehearing(rehearingToDelete.rehearingId)
      .pipe(take(1))
      .subscribe(
        (deleteRehearingSuccess) => {
          this.logger.info('Delete rehearing success', deleteRehearingSuccess);
          this.tableOptions.data = [];
          this.dataList = [];
          this.getRehearing('INITIATED');
          this.changeTab('Pending');
          this.commonUtils.showSuccess(
            'Successfully deleted rehearing request',
            'Delete rehearing request'
          );
        },
        (deleteRehearingFailure) => {
          this.logger.error(
            'Failed to delete rehearing',
            deleteRehearingFailure
          );
          this.commonUtils.showError(
            'Failed to delete rehearing request',
            'Delete rehearing request'
          );
        }
      );
  }

  gridPaginationAction(event) {
    this.recordCountInfo.lastPage = false;
    let fromPage = null;
    let toPage = null;
    switch (event.pageAction) {
      case 'first':
        this.dataList = this.filteredData.slice(
          0,
          this.paginationInfo.pageSize
        );
        this.paginationInfo.currentPage = 1;
        this.recordCountInfo.currentPage = 1;
        break;
      case 'previous':
        if (this.paginationInfo.currentPage > 1) {
          this.paginationInfo.currentPage--;
          this.recordCountInfo.currentPage--;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          this.dataList = this.filteredData.slice(fromPage, toPage);
        }
        break;
      case 'next':
        // this.dataList = this.copyOfOriginal();
        // this.dataList.slice(25, this.paginationInfo.pageSize);
        if (
          this.paginationInfo.currentPage <
          Math.ceil(this.filteredData.length / this.paginationInfo.pageSize)
        ) {
          this.paginationInfo.currentPage++;
          this.recordCountInfo.currentPage++;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          if (toPage > this.filteredData.length) {
            toPage = this.filteredData.length;
          }
          this.dataList = this.filteredData.slice(fromPage, toPage);
        }
        break;
      case 'last':
        this.paginationInfo.currentPage = Math.ceil(
          this.filteredData.length / this.paginationInfo.pageSize
        );
        this.recordCountInfo.currentPage = this.paginationInfo.currentPage;

        this.dataList = this.filteredData.slice(
          this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize,
          this.filteredData.length
        );
        break;
      case 'specificPage':
        // gridApi.paginationGoToPage(parseInt(event.pageNo));
        if (event.pageNo >= this.paginationInfo.totalPages) {
          event.pageNo = this.paginationInfo.totalPages - 1;
        }
        if (
          event.pageNo >= 0 &&
          event.pageNo <=
            Math.ceil(this.filteredData.length / this.paginationInfo.pageSize)
        ) {
          this.paginationInfo.currentPage = event.pageNo + 1;
          this.recordCountInfo.currentPage = event.pageNo + 1;
          fromPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage -
            this.paginationInfo.pageSize;
          toPage =
            this.paginationInfo.pageSize * this.paginationInfo.currentPage;
          if (toPage > this.filteredData.length) {
            toPage = this.filteredData.length;
          }
          this.dataList = this.filteredData.slice(fromPage, toPage);
        } else {
          this.paginationInfo.currentPage = event.pageNo + 1;
          this.recordCountInfo.currentPage = event.pageNo + 1;
        }

        break;
      default:
        break;
    }
    // this.gridHelperService.gridPaginationAction(e, this.gridParams.gridApi);
    // this.currentPage = this.gridParams.gridApi.paginationGetCurrentPage() + 1;
    // this.recordCountInfo.currentPage = this.currentPage;
    // this.paginationInfo.currentPage = this.currentPage;
  }

  changePageSize(pageSizeEvent) {
    this.recordCountInfo.lastPage = false;
    if (pageSizeEvent === 'All') {
      pageSizeEvent = this.filteredData.length;
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.currentPage = 1;
      this.paginationInfo.totalPages = 1;
      this.recordCountInfo.currentPage = 1;
      this.dataList = this.filteredData;
      // ! last page
    } else if (
      this.paginationInfo.currentPage === this.paginationInfo.totalPages
    ) {
      this.recordCountInfo.lastPage = true;
      this.dataList = this.filteredData.slice(
        Math.floor(this.filteredData.length / pageSizeEvent) * pageSizeEvent,
        this.filteredData.length
      );
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.filteredData.length / this.paginationInfo.pageSize
      );
      this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
    } else {
      this.paginationInfo.pageSize = pageSizeEvent;
      this.recordCountInfo.paginationPageSize = pageSizeEvent;
      this.paginationInfo.totalPages = Math.ceil(
        this.filteredData.length / this.paginationInfo.pageSize
      );
      if (this.paginationInfo.currentPage > this.paginationInfo.totalPages) {
        this.paginationInfo.currentPage = this.paginationInfo.totalPages;
        this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      }

      this.dataList = this.filteredData.slice(
        this.paginationInfo.currentPage * this.paginationInfo.pageSize -
          this.paginationInfo.pageSize,
        this.paginationInfo.currentPage * this.paginationInfo.pageSize
      );
      // this.paginationInfo.pageSize = pageSizeEvent;
      // this.recordCountInfo.paginationPageSize = pageSizeEvent;
      // this.paginationInfo.totalPages = Math.ceil(
      //   this.filteredData.length / this.paginationInfo.pageSize
      // );
      // this.paginationInfo.currentPage = this.paginationInfo.totalPages;
      // this.recordCountInfo.currentPage = this.paginationInfo.totalPages;
      // this.dataList = this.filteredData.slice(
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize -
      //     this.paginationInfo.pageSize,
      //   this.paginationInfo.currentPage * this.paginationInfo.pageSize
      // );
    }

    // this.recordCountInfo.paginationPageSize = this.paginationPageSize;
  }

  searchEntireData() {
    this.filteredData = this.tableFilter.transform(
      this.originalData,
      this.tableOptions.columnDefs
    );
    const action = {
      pageAction: 'first',
      pageNo: null,
    };
    this.gridPaginationAction(action);
    this.paginationInfo.totalPages = Math.ceil(
      this.filteredData.length / this.paginationInfo.pageSize
    );
    this.recordCountInfo.dataLength = this.filteredData.length;
    this.hasFilters = false;
    this.tableOptions.columnDefs.forEach((column) => {
      if (column.searchText) {
        this.hasFilters = true;
      }
    });
  }
}
