import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
// import { CommonService } from 'src/app/services/common.service';
import { DomSanitizer } from '@angular/platform-browser';
// import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { Store, select } from '@ngrx/store';
import { MyDocketService } from '../my-docket.services';
// import { CaseViewerState } from 'src/app/store/case-viewer/case-viewer.state';

@Component({
  selector: 'app-email-subject',
  templateUrl: './email-subject.component.html',
  styleUrls: ['./email-subject.component.less']
})

export class EmailSubjectComponent implements OnInit {
  modal: any;
  emailContent: any;
  imgSrcValue: any;
  loggedInUser: any;
  isSplAdmin: any = false;
  notResent: boolean = false;
  isLoading: boolean = true;
  noData: boolean = false;
  emailResponse: any;
  printEmailBody: any = "";
  theHtmlString: any;
  sanitized: any;
  constructor(private modalService: BsModalService, private myDocketService: MyDocketService, private toastr: ToastrService, private domSanitizer: DomSanitizer) { }

  ngOnInit(): void {

    // this.store.pipe(select(CaseViewerSelectors.userInfoData)).subscribe(data => {
    //   this.loggedInUser = data.caseDetailsData[0];

    //   this.isSplAdmin = data.isSplAdmin;
    //   if (!this.loggedInUser) {
    //     this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    //   }
    // });
    // this.notResent = this.emailContent.notificationStatus && this.emailContent.notificationStatus == 'SENT' ? true : false;
     this.getEmailBody(this.emailContent.notificationId);
  }


  close(refreshValue) {
    // this.modal.isConfirm = refreshValue;
    this.modalService.hide();
  }


  /*istanbul ignore next*/
  getEmailBody(id) {

    this.myDocketService.getEmailContent(id).subscribe(
      (response) => {
        this.isLoading = true;
        if(response != null && response.length > 0){
        response.forEach((resp) => {
          // resp.emailResponse = response;
        resp.theHtmlString = resp.htmlDocumentData;
        resp.imgSrcValue = this.domSanitizer.bypassSecurityTrustResourceUrl('data:text/html;base64,' + resp.encodedDocumentData);
        resp.sanitized =this.domSanitizer.bypassSecurityTrustHtml(resp.theHtmlString);
        });
        setTimeout(() => {
        if (document.getElementById('email')) {
          this.isLoading = false;
          let simulateMouseEvent = function (element, eventName, coordX, coordY) {
            element.dispatchEvent(new MouseEvent(eventName, {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: coordX,
              clientY: coordY,
              button: 0
            }));
          };

          let theButton = document.querySelector('div');
          let box = theButton.getBoundingClientRect(),
            coordX = box.left + (box.right - box.left) / 2,
            coordY = box.top + (box.bottom - box.top) / 2;
          simulateMouseEvent(theButton, "mousedown", coordX, coordY);
          simulateMouseEvent(theButton, "mouseup", coordX, coordY);
          simulateMouseEvent(theButton, "click", coordX, coordY);

        }
      }, 1000);
      this.emailResponse = response;
    }
      },
      (response) => {
        this.isLoading = false;
        this.noData = true;
      }
    );

    

  }
/*istanbul ignore next*/
  htmlContentVal() {
    return this.domSanitizer.bypassSecurityTrustHtml(this.theHtmlString)
  }
 /*istanbul ignore next*/
 


}
