import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/services/common.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Store } from '@ngrx/store';
import { EmailSubjectComponent } from './email-subject.component';
import { provideMockStore } from '@ngrx/store/testing';
import * as CaseViewerSelectors from 'src/app/store/case-viewer/case-viewer.selectors';
import { TrialsService } from 'src/app/services/trials.service';

describe('EmailSubjectComponent', () => {
  let component: EmailSubjectComponent;
  let fixture: ComponentFixture<EmailSubjectComponent>;

  beforeEach(() => {
    const bsModalServiceStub = () => ({ hide: () => ({}) });
    const toastrServiceStub = () => ({
      error: (message, string, object) => ({})
    });
    const commonServiceStub = () => ({
      getNotificationsList: arg => ({ subscribe: f => f({}) })
    });
    const domSanitizerStub = () => ({
      bypassSecurityTrustResourceUrl: arg => ({})
    });
    const storeStub = () => ({ pipe: arg => ({ subscribe: f => f({}) }) });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [EmailSubjectComponent],
      providers: [
        { provide: BsModalService, useFactory: bsModalServiceStub },
        { provide: ToastrService, useFactory: toastrServiceStub },
        { provide: CommonService, useFactory: commonServiceStub },
        { provide: DomSanitizer, useFactory: domSanitizerStub },
        { provide: Store, useFactory: storeStub },
        TrialsService, provideMockStore({
          selectors: [
            { selector: CaseViewerSelectors.caseInfoData, value: { proceedingNo: '37553565' } },
            {selector: CaseViewerSelectors.userInfoData,value:{caseDetailsData: []}}
          ]
        }),
      ]
    });
    fixture = TestBed.createComponent(EmailSubjectComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`isSplAdmin has default value`, () => {
    expect(component.isSplAdmin).toEqual(false);
  });

  it(`notResent has default value`, () => {
    expect(component.notResent).toEqual(false);
  });

  it(`isLoading has default value`, () => {
    expect(component.isLoading).toEqual(true);
  });

  it(`noData has default value`, () => {
    expect(component.noData).toEqual(false);
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      const storeStub: Store = fixture.debugElement.injector.get(Store);
      spyOn(component, 'getEmailBody').and.callThrough();
      spyOn(storeStub, 'pipe').and.callThrough();
      component.emailContent ={
        notificationStatus: 'SENT'
      }
      component.ngOnInit();
      expect(component.getEmailBody).toBeDefined();
      expect(storeStub.pipe).toBeDefined();
    });
  });

  it('should call close with true', () => {
    component.modal = {
      isConfirm: null
    }
    component.close(true);
  });
  // describe('getEmailBody', () => {
  //   it('makes expected calls', () => {
  //     const toastrServiceStub: ToastrService = fixture.debugElement.injector.get(
  //       ToastrService
  //     );
  //     const commonServiceStub: CommonService = fixture.debugElement.injector.get(
  //       CommonService
  //     );
  //     const domSanitizerStub: DomSanitizer = fixture.debugElement.injector.get(
  //       DomSanitizer
  //     );
  //     spyOn(toastrServiceStub, 'error').and.callThrough();
  //     spyOn(commonServiceStub, 'getNotificationsList').and.callThrough();
  //     spyOn(
  //       domSanitizerStub,
  //       'bypassSecurityTrustResourceUrl'
  //     ).and.callThrough();
  //     component.getEmailBody();
  //     expect(toastrServiceStub.error).toHaveBeenCalled();
  //     expect(commonServiceStub.getNotificationsList).toHaveBeenCalled();
  //     expect(
  //       domSanitizerStub.bypassSecurityTrustResourceUrl
  //     ).toHaveBeenCalled();
  //   });
  // });
});
