import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AiaAppealsComponent } from './aia-appeals/aia-appeals.component';
import { AllAiaReviewsComponent } from './all-aia-reviews/all-aia-reviews.component';
import { MotionsRehearingsComponent } from './motions-rehearings/motions-rehearings.component';
import { MyDocketComponent } from './my-docket.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { PendingAiaReviewsComponent } from './pending-aia-reviews/pending-aia-reviews.component';
import { UnsubmittedPetitionsComponent } from './unsubmitted-petitions/unsubmitted-petitions.component';
import { MyDocketRoutingModule } from './my-docket-routing.module';
import { SharedModule } from 'src/app/shared.module';
import { MotionsComponent } from './motions/motions.component';
// import { RehearingsComponent } from './rehearings/rehearings.component';
import { EmailBodyComponent } from './email-body/email-body.component';
import { EmailSubjectComponent } from './email-subject/email-subject.component';
import { NotificationTooltipComponent } from './notification-tooltip/notification-tooltip.component';
import { AiaToolTipComponent } from '../../common/aia-tool-tip/aia-tool-tip.component';
import { ContinueRendererComponent } from './renderer/continue-renderer/continue-renderer.component';

@NgModule({
  declarations: [
    MyDocketComponent,
    AllAiaReviewsComponent,
    PendingAiaReviewsComponent,
    NotificationsComponent,
    MotionsRehearingsComponent,
    AiaAppealsComponent,
    UnsubmittedPetitionsComponent,
    MotionsComponent,
    // RehearingsComponent,
    EmailBodyComponent,
    EmailSubjectComponent,
    NotificationTooltipComponent,
    AiaToolTipComponent,
    ContinueRendererComponent,
  ],
  imports: [CommonModule, MyDocketRoutingModule, SharedModule],
})
export class MyDocketModule {}
