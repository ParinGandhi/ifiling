import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

interface ToolTipParams extends ICellRendererParams {
  lineBreak?: boolean;
  toolTipArray?: string[];
  toolTip?: string;
}
@Component({
  selector: 'app-notification-tooltip',
  templateUrl: './notification-tooltip.component.html',
  styleUrls: ['./notification-tooltip.component.less']
})

export class NotificationTooltipComponent implements ICellRendererAngularComp {

  public params: ToolTipParams;
  public data: any;
  public toolTip: string;

  constructor() { }
/*istanbul ignore next */
  agInit(params: ToolTipParams): void {
    this.params = params;
    
  }
/*istanbul ignore next */
  refresh(params: ToolTipParams): boolean {
    this.params = params;
    return true;
  }

}