import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared.module';
import { ClaimsChallengedComponent } from './claims-challenged/claims-challenged.component';
import { InitiatePetitionRoutingModule } from './initiate-petition-routing.module';
import { InitiatePetitionComponent } from './initiate-petition.component';
import { PetitionDocumentsComponent } from './petition-documents/petition-documents.component';
import { PetitionInformationComponent } from './petition-information/petition-information.component';
import { VerificationComponent } from './verification/verification.component';
import { RealPartyComponent } from './parties/real-party/real-party.component';
import { AdditionalRealPartyComponent } from './parties/additional-real-party/additional-real-party.component';
import { CounselComponent } from './parties/counsel/counsel.component';
// import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { VerificationModalComponent } from './verification/verification-modal/verification-modal.component';
import { MultipleEmailModalComponent } from './parties/multiple-email-modal/multiple-email-modal.component';
import { DeleteModalComponent } from './petition-documents/delete-modal/delete-modal.component';
import { DocumentsIpComponent } from './review/documents-ip/documents-ip.component';
import { ClaimsIpComponent } from './review/claims-ip/claims-ip.component';
import { RealpartyIpComponent } from './review/realparty-ip/realparty-ip.component';
import { PaymentsIpComponent } from './review/payments-ip/payments-ip.component';
import { CounselIpComponent } from './review/counsel-ip/counsel-ip.component';
import { ReviewComponent } from './review/review.component';

@NgModule({
  declarations: [
    InitiatePetitionComponent,
    VerificationComponent,
    PetitionInformationComponent,
    ClaimsChallengedComponent,
    PetitionDocumentsComponent,
    RealPartyComponent,
    AdditionalRealPartyComponent,
    CounselComponent,
    VerificationModalComponent,
    MultipleEmailModalComponent,
    DeleteModalComponent,
    DocumentsIpComponent,
    ClaimsIpComponent,
    RealpartyIpComponent,
    PaymentsIpComponent,
    CounselIpComponent,
    ReviewComponent
  ],
  imports: [
    CommonModule,
    // TypeaheadModule.forRoot(),
    SharedModule,
    FormsModule,
    InitiatePetitionRoutingModule,
  ],
})
export class InitiatePetitionModule {}
