import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleEmailModalComponent } from './multiple-email-modal.component';

describe('MultipleEmailModalComponent', () => {
  let component: MultipleEmailModalComponent;
  let fixture: ComponentFixture<MultipleEmailModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultipleEmailModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleEmailModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
