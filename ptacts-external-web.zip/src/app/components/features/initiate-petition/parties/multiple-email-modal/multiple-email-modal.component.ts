import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-multiple-email-modal',
  templateUrl: './multiple-email-modal.component.html',
  styleUrls: ['./multiple-email-modal.component.scss'],
})
export class MultipleEmailModalComponent implements OnInit {
  modalData = this.modalService.config.initialState;
  selectedPetitioner = null;

  constructor(
    public modalRef: BsModalRef,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {}

  closeModal(selection) {
   
    this.modalService.config.initialState.emailSelected = selection;
    this.modalService.config.initialState.selectedPetitioner =
      this.selectedPetitioner;
    this.modalService.hide();
  }
}
