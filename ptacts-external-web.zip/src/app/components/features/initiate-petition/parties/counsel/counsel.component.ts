import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { MultipleEmailModalComponent } from '../multiple-email-modal/multiple-email-modal.component';
import { InitiatePetitionService } from '../../initiate-petition.service';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { take } from 'rxjs/operators';
import { InterestedParty } from 'src/app/models/parties/InterestedParty.model';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/constants/constants';
import { Urls } from 'src/app/constants/urls';

@Component({
  selector: 'app-counsel',
  templateUrl: './counsel.component.html',
  styleUrls: ['./counsel.component.scss'],
})
export class CounselComponent implements OnInit {
  counselForm = this.fb.group({
    // proSe: ['No', Validators.required],
    // counselType: ['LEAD', Validators.required],
    firstName: [{ value: '', disabled: true }, Validators.required],
    lastName: [{ value: '', disabled: true }, Validators.required],
    email: [
      { value: '', disabled: true },
      [Validators.required, Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)],
    ],
    regNo: [{ value: '', disabled: true }, Validators.required],
    phoneNumber: [
      { value: '', disabled: true },
      [
        // Validators.required,
        // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
        this.commonUtils.ValidatePhoneFax,
      ],
    ],
    faxNumber: [
      { value: '', disabled: true },
      // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
      this.commonUtils.ValidatePhoneFax,
    ],
    country: [{ value: '', disabled: true }, Validators.required],
    // address1: [{ value: '', disabled: true }, Validators.required],
    address1: [{ value: '', disabled: true }],
    address2: [{ value: '', disabled: true }],
    // city: [{ value: '', disabled: true }, Validators.required],
    city: [{ value: '', disabled: true }],
    state: [{ value: '', disabled: true }],
    // zip: [{ value: '', disabled: true }, Validators.required],
    zip: [{ value: '', disabled: true }],
  });

  findCounsel: string = null;
  modalRef: BsModalRef;
  petitionInfo: any = null;
  countries: [] = [];
  states: [] = [];
  updateMode: boolean = false;
  regNotFound: boolean = false;
  emailNotFound: boolean = false;
  counselList: Array<any> = new Array();
  proSeExists: boolean = false;
  leadExists: boolean = false;
  firstBackupExists: boolean = false;
  selectedProSe: string = 'N';
  selectedCounselType: string = 'LEAD';
  editMode: boolean = false;
  editIndex: number = null;
  counselToEdit: any = null;
  allowSwap: boolean = false;
  stateIsRequired: boolean = false;
  validLeadCounsel: boolean = false;
  val: any = null;
  componentName: string = 'counsel';
  onBehalfOf: string = null;
  registrationNoNotFound: boolean;
  enableRegNo: boolean;
  myUsptoLink = {
    MyUSPTO: null,
  };
  showDisabledUserWarning: boolean = false;

  constructor(
    private fb: FormBuilder,
    private logger: NGXLogger,
    private modalService: BsModalService,
    public initiatePetitionService: InitiatePetitionService,
    public commonUtils: CommonUtilitiesService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.counselForm.disable();
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getExistingCounsels();
    this.getCountries();
    this.getMyUSPTOLink();
  }

  getMyUSPTOLink() {
    this.initiatePetitionService
      .getMyUSPTOLink()
      .pipe(take(1))
      .subscribe((myUSPTOLinkResponse: any) => {
        myUSPTOLinkResponse.forEach((element) => {
          this.myUsptoLink.MyUSPTO = element.descriptionText;
        });
      });
  }

  getExistingCounsels() {
    this.initiatePetitionService
      .getCounsels(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((existingCounsels) => {
        this.logger.info('Existing counsels:', existingCounsels);
        this.counselList = existingCounsels;
        this.disableCounselTypes();
        this.setTabFlags();
      });
  }

  disableCounselTypes() {
    this.proSeExists = false;
    this.leadExists = false;
    this.firstBackupExists = false;
    this.counselList.forEach((counsel: any) => {
      switch (counsel.partySubType) {
        case 'PROSE':
          this.proSeExists = true;
          this.selectedProSe = 'N';
          break;
        case 'LEAD':
          this.leadExists = true;
          this.selectedCounselType = 'BACKUP';
          break;
        case 'FIRSTBKUP':
          this.firstBackupExists = true;
          this.selectedCounselType = 'BACKUP';
          break;
        default:
          break;
      }
    });
  }

  getCountries() {
    this.initiatePetitionService
      .getCountries()
      .pipe(take(1))
      .subscribe((countriesResponse) => {
        this.countries = countriesResponse;
        this.logger.info('Countries list: ', this.countries);
      });
  }

  getStates(countryCode) {
    this.states = [];
    this.modifyStateReq(countryCode);
    this.initiatePetitionService
      .getStates(countryCode)
      .pipe(take(1))
      .subscribe((statesList) => {
        this.states = statesList;
      });
  }

  // changeProSe(proSeVal) {
  //   if (proSeVal === 'yes') {
  //     this.counselForm.get('counselType').clearValidators();
  //   } else {
  //     this.counselForm.get('counselType').setValidators([Validators.required]);
  //   }
  //   this.counselForm.updateValueAndValidity();
  // }

  modifyStateReq(countryCode) {
    this.stateIsRequired = false;
    if (CONSTANTS.MANDATORY_COUNTRIES.includes(countryCode)) {
      this.stateIsRequired = true;
      this.counselForm.get('state').setValidators([Validators.required]);
    } else {
      this.counselForm.get('state').clearValidators();
    }
    this.counselForm.get('state').updateValueAndValidity();
  }

  findByRegOrEmail(regOrEmail) {
    this.registrationNoNotFound = false;
    this.regNotFound = false;
    this.emailNotFound = false;
    this.logger.info('Email or reg no: ', regOrEmail);
    let searchCriteria = this.commonUtils.getEmailOrRegNo(regOrEmail);
    // if (
    //   /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(
    //     regOrEmail
    //   )
    // ) {
    //   searchCriteria = `email=${regOrEmail.toLowerCase().trim()}`;
    // } else {
    //   const regNoStripped = regOrEmail.replace(/[^0-9]/g, '');
    //   searchCriteria = `registrationNumber=${regNoStripped}`;
    // }
    // searchCriteria = Number.isNaN(parseInt(regOrEmail))
    //   ? `email=${regOrEmail.toLowerCase().trim()}`
    //   : `registrationNumber=${regOrEmail}`;
    this.initiatePetitionService
      .findByRegOrEmail(searchCriteria)
      .pipe(take(1))
      .subscribe(
        (foundCounsels) => {
          if (foundCounsels.length === 1) {
            if (foundCounsels[0].registrationNo) {
              this.registrationNoNotFound = false;
              this.setForm(foundCounsels[0]);
            } else {
              this.registrationNoNotFound = true;
              this.setForm(foundCounsels[0]);
            }
          } else if (foundCounsels.length > 1) {
            this.openMultipleModal(foundCounsels);
          } else {
            if (regOrEmail.indexOf('@') !== -1) {
              this.emailNotFound = true;
              this.regNotFound = false;
            } else {
              this.regNotFound = true;
              this.emailNotFound = false;
            }
            this.stateIsRequired = false;
            this.counselForm.reset();
            this.counselForm.disable();
            this.counselForm.updateValueAndValidity();
            this.disableCounselTypes();
            this.setForm(foundCounsels[0]);
          }
          this.findCounsel = null;
        },
        (notFoundResponse) => {
          this.logger.error(
            'Email or registration number not found: ',
            notFoundResponse
          );
        }
      );
  }

  onKeyUp(x) {
    if (x.code == 'Enter' || x.code === 'NumpadEnter') {
      this.findByRegOrEmail(this.val);
      this.findCounsel = this.val;
    } else {
      this.val = this.findCounsel;
    }
  }

  clearForm() {
    this.stateIsRequired = false;
    this.counselForm.reset();
    this.counselForm.disable();
    // this.counselForm.get('counselType').clearValidators();
    // this.counselForm.get('proSe').setValue('No');
    // this.counselForm.get('counselType').setValue('leadCounsel');
    this.counselForm.updateValueAndValidity();
    this.disableCounselTypes();
    this.regNotFound = false;
    this.emailNotFound = false;
    this.editMode = false;
    this.allowSwap = false;
    this.findCounsel = null;
    this.registrationNoNotFound = false;
  }

  openMultipleModal(emailList) {
    const isFound = !emailList ? false : true;
    const title = !emailList
      ? 'User not found'
      : 'Multiple email addresses found for registration number';
    const initialState: ModalOptions = {
      initialState: {
        emailList: emailList,
        emailSelected: false,
        selectedPetitioner: null,
        isFound: isFound,
        title: title,
      },
      class: 'modal-lg',
    };
    this.modalRef = this.modalService.show(
      MultipleEmailModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.emailSelected) {
        this.logger.info('Reason: ', reason);
        this.setForm(reason.initialState.selectedPetitioner);
      } else {
        this.logger.info('Modal should close: ', reason);
      }
    });
  }

  addCounsel() {
    const counselToAdd = this.setCounselObj();
    const isProSe = this.selectedProSe === 'Yes' ? 'Y' : 'N';
    this.logger.info('Counsel to add: ', counselToAdd);
    if (this.registrationNoNotFound) {
      this.AddRegisNumber(
        this.counselForm.get('email').value,
        this.counselForm.get('regNo').value
      );
    }
    this.initiatePetitionService
      .addCounsel(counselToAdd, isProSe)
      .pipe(take(1))
      .subscribe(
        (addCounselSuccess) => {
          this.commonUtils.showSuccess(
            'Successfully added counsel',
            'Add Counsel'
          );
          this.clearForm();
          this.getExistingCounsels();
        },
        (addCounselFailure) => {
          this.logger.error('Add counsel failed: ', addCounselFailure);
          this.commonUtils.showError(
            addCounselFailure.error.message,
            'Add Counsel Action cannot be performed'
          );
        }
      );
  }

  AddRegisNumber(email, regNO) {
    let obj = { emailAddress: email, registrationNo: regNO };
    this.initiatePetitionService
      .addRegNo(obj)
      .pipe(take(1))
      .subscribe(
        (success) => { },
        (failure) => {
          this.logger.error('Add regNo failed: ', failure);
          this.commonUtils.showError(
            failure.error.message,
            'Add Registration # Action cannot be performed'
          );
        }
      );
  }

  setCounselObj() {
    const counselToAddUpdate = new InterestedParty();
    // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
    counselToAddUpdate.caseNo = this.petitionInfo.proceedingNumberText;
    counselToAddUpdate.parties[0].submitterType = 'PETITIONER';
    counselToAddUpdate.parties[0].partyType = 'COUNSEL';
    counselToAddUpdate.parties[0].partySubType =
      this.selectedProSe === 'Y' ? 'PROSE' : this.selectedCounselType;
    counselToAddUpdate.parties[0].proseIndicator = this.selectedProSe;
    if (this.editMode) {
      counselToAddUpdate.parties[0].identifier = this.counselToEdit.identifier;
      counselToAddUpdate.parties[0].personType[0].identifier =
        this.counselToEdit.personType[0].identifier;
    }
    counselToAddUpdate.parties[0].registrationNo = this.counselForm.value.regNo;
    counselToAddUpdate.parties[0].personType[0].firstName =
      this.counselForm.value.firstName;
    counselToAddUpdate.parties[0].personType[0].lastName =
      this.counselForm.value.lastName;
    counselToAddUpdate.parties[0].personType[0].mailingAddress =
      this.addMailingAddress(this.counselForm);
    counselToAddUpdate.parties[0].personType[0].electronicAddress =
      this.addElectronicAddress(this.counselForm);
    counselToAddUpdate.parties[0].orgType = [];
    return counselToAddUpdate;
  }

  addMailingAddress(mailingAddressInfo) {
    const mailingArray = [];
    let mailObj = {
      country: null,
      streetLineOneText: mailingAddressInfo.value.address1,
      streetLineTwoText: mailingAddressInfo.value.address2,
      city: mailingAddressInfo.value.city,
      state: null,
      zipCode: mailingAddressInfo.value.zip,
      addressType: 'BUS',
      identifier: null,
    };

    if (
      mailingAddressInfo.value.country &&
      mailingAddressInfo.value.country.hasOwnProperty('value')
    ) {
      mailObj.country = mailingAddressInfo.value.country.value;
    }
    if (
      mailingAddressInfo.value.state &&
      mailingAddressInfo.value.state.hasOwnProperty('value')
    ) {
      mailObj.state = mailingAddressInfo.value.state.value;
    }

    if (
      this.editMode &&
      this.counselToEdit.personType[0].mailingAddress &&
      this.counselToEdit.personType[0].mailingAddress.length > 0
    ) {
      mailObj.identifier =
        this.counselToEdit.personType[0].mailingAddress[0].identifier;
    }

    mailingArray.push(mailObj);
    return mailingArray;
  }

  addElectronicAddress(electronicAddressInfo) {
    const tempArr = [];
    const email = {
      email: electronicAddressInfo.value.email,
      emailType: 'WE',
      extention: null,
      identifier: null,
    };
    const phone = {
      extension: electronicAddressInfo.value.extension,
      identifier: null,
      teleCommAddresType: 'W',
      telephoneNumber: electronicAddressInfo.value.phoneNumber,
    };
    const fax = {
      extension: null,
      identifier: null,
      teleCommAddresType: 'F',
      fax: electronicAddressInfo.value.faxNumber,
    };
    if (
      this.editMode &&
      this.counselToEdit.personType[0].electronicAddress &&
      this.counselToEdit.personType[0].electronicAddress.length > 0
    ) {
      this.counselToEdit.personType[0].electronicAddress.forEach((element) => {
        if (element.email) {
          email.identifier = element.identifier;
        }
        if (element.extension || element.telephoneNumber) {
          phone.identifier = element.identifier;
        }
        if (element.fax) {
          fax.identifier = element.identifier;
        }
      });
    }
    tempArr.push(email);
    tempArr.push(phone);
    tempArr.push(fax);

    return tempArr;
  }

  setForm(counselInfo) {
    this.showDisabledUserWarning = false;
    this.logger.info('Counsel info:', counselInfo);
    let foundCountry = null;
    if (counselInfo?.personType[0]?.mailingAddress?.length > 0) {
      if (counselInfo.personType[0].mailingAddress[0].country) {
        foundCountry = this.countries.find((country: any) => {
          return (
            country.value ===
            counselInfo.personType[0].mailingAddress[0].country
          );
        });
        this.counselForm.get('country').setValue(foundCountry);
        this.modifyStateReq(foundCountry.value);
        if (counselInfo.personType[0].mailingAddress[0].state) {
        }

        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            if (statesList) {
              this.states = statesList;
              let foundState = this.states.find((state: any) => {
                return (
                  state.value ===
                  counselInfo.personType[0].mailingAddress[0].state
                );
              });
              this.counselForm.get('state').setValue(foundState);
            }
          });
      }
    }
    // this.counselForm
    //   .get('proSe')
    //   .setValue(counselInfo.proseIndicator ? counselInfo.proseIndicator : 'No');
    if (this.editMode) {
      this.selectedProSe = counselInfo.proseIndicator
        ? counselInfo.proseIndicator
        : 'N';
    }
    if (counselInfo?.partySubType) {
      // this.counselForm.get('counselType').setValue(counselInfo.partySubType);
      this.selectedCounselType = counselInfo.partySubType;
    }
    this.counselForm
      .get('firstName')
      .setValue(counselInfo.personType[0].firstName);
    this.counselForm
      .get('lastName')
      .setValue(counselInfo.personType[0].lastName);
    this.counselForm.get('regNo').setValue(counselInfo.registrationNo);

    if (
      counselInfo.personType[0].mailingAddress &&
      counselInfo.personType[0].mailingAddress.length > 0
    ) {
      this.setMailingAddress(counselInfo.personType[0].mailingAddress[0]);
    }
    if (
      counselInfo.personType[0].electronicAddress &&
      counselInfo.personType[0].electronicAddress.length > 0
    ) {
      this.setElectronicAddress(counselInfo.personType[0].electronicAddress);
    }
    this.counselForm.enable();
    //this.counselForm.controls['email'].disable();
    if (this.counselForm.value.regNo) {
      this.enableRegNo = false;
    } else {
      this.enableRegNo = true;
    }
    this.showDisabledUserWarning = this.commonUtils.checkForDisabledUser(counselInfo);
  }

  setMailingAddress(mailAddressInfo) {
    this.counselForm
      .get('address1')
      .setValue(mailAddressInfo.streetLineOneText);
    this.counselForm
      .get('address2')
      .setValue(mailAddressInfo.streetLineTwoText);
    this.counselForm.get('zip').setValue(mailAddressInfo.zipCode);
    this.counselForm.get('city').setValue(mailAddressInfo.city);
  }

  setElectronicAddress(electronicAddressInfo) {
    electronicAddressInfo.forEach((element) => {
      if (element.telephoneNumber) {
        this.counselForm.get('phoneNumber').setValue(element.telephoneNumber);
      }
      if (element.fax) {
        this.counselForm.get('faxNumber').setValue(element.fax);
      }
      if (element.email) {
        this.counselForm.get('email').setValue(element.email);
      }
    });
  }

  editCounsel(counselToEdit, action) {
    if (action === 'edit') {
      this.logger.info('Counsel to edit:', counselToEdit);
      this.editMode = true;
      // this.editIndex = index;
      this.counselToEdit = counselToEdit.counselInfo;
      this.setForm(counselToEdit.counselInfo);
    } else {
      this.allowSwap = true;
      if (this.counselList.length === 2) {
        this.counselList.forEach((counsel) => {
          if (!counsel.regNo || counsel.regNo === '') {
            if (
              (counselToEdit.partySubType.toLowerCase() === 'lead' ||
                counselToEdit.partySubType.toLowerCase() === 'prose') &&
              (action.toLowerCase() === 'firstbkup' ||
                action.toLowerCase() === 'backup')
            ) {
              this.allowSwap = false;
              this.commonUtils.showError(
                'Cannot switch lead counsel',
                'Switch Counsel'
              );
            }
          }
        });
      }
      if (this.allowSwap) {
        this.editMode = true;
        counselToEdit.counselInfo.partySubType = action.toUpperCase();
        this.counselToEdit = counselToEdit.counselInfo;
        this.setForm(counselToEdit.counselInfo);
      }
    }
  }

  updateCounsel() {
    const counselToUpdate = this.setCounselObj();
    if (!this.allowSwap) {
      this.initiatePetitionService
        .updateCounsel(counselToUpdate)
        .pipe(take(1))
        .subscribe(
          (counselUpdate) => {
            this.commonUtils.showSuccess(
              'Successfully updated counsel information',
              'Update Counsel'
            );
            this.editMode = false;
            this.clearForm();
            this.getExistingCounsels();
          },
          (counselUpdateFailure) => {
            this.logger.error('Counsel update failed', counselUpdateFailure);
            this.commonUtils.showError(
              counselUpdateFailure.error.message,
              'Update Counsel'
            );
          }
        );
    } else {
      this.swapCounsel(counselToUpdate);
    }
  }

  deleteCounsel(counselToDelete) {
    this.initiatePetitionService
      .deleteCounsel(
        this.petitionInfo.proceedingNumberText,
        counselToDelete.counselInfo.identifier
      )
      .pipe(take(1))
      .subscribe(
        (deleteCounselSuccess) => {
          this.logger.info(
            'Successfully deleted counsel:',
            deleteCounselSuccess
          );
          this.commonUtils.showSuccess(
            'Successfully deleted counsel',
            'Delete Counsel'
          );
          this.getExistingCounsels();
        },
        (deleteCounselFailure) => {
          this.logger.error('Failed to delete counsel:', deleteCounselFailure);
          this.commonUtils.showError(
            deleteCounselFailure.error.message,
            'Delete Counsel'
          );
        }
      );
  }

  openWarningModal(counselToDelete) {
    let title = 'Delete this record?';
    let message = ['This information will be removed from the system.'];
    let leftBtnLabel = 'No, return to page';
    let rightBtnLabel = 'Yes, delete this record';
    if (counselToDelete.partySubType.toLowerCase() === 'lead') {
      title = 'Delete Lead Counsel?';
      message = [
        'This action will delete the Lead Counsel from this petition.  A Lead Counsel is required to file a non-Pro Se Petition.',
        'Do you wish to continue?',
      ];
      leftBtnLabel = 'No, Cancel and return to previous screen';
      rightBtnLabel = 'Yes, Delete this Lead Counsel';
    }
    const initialState: any = {
      title: title,
      message: message,
      leftBtnLabel: leftBtnLabel,
      rightBtnLabel: rightBtnLabel,
      selection: false,
    };
    this.modalRef = this.modalService.show(WarningModalComponent, {
      class: 'modal-lg',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        this.deleteCounsel(counselToDelete);
      } else {
      }
    });
  }

  swapCounsel(counselToUpdate) {
    this.logger.info('Swap counsel', counselToUpdate);
    const isLeadCounsel = counselToUpdate.parties[0].partySubType === 'LEAD';
    this.initiatePetitionService
      .swapCounsel(counselToUpdate, isLeadCounsel)
      .pipe(take(1))
      .subscribe(
        (swapCounselResonse) => {
          this.logger.info('Swap counsel response', swapCounselResonse);
          this.commonUtils.showSuccess(
            'Successfully updated counsel',
            'Update Counsel'
          );
          this.clearForm();
          this.getExistingCounsels();
        },
        (swapCounselFailure) => {
          this.logger.error('Failed to swap counsel', swapCounselFailure);
          this.commonUtils.showError(
            swapCounselFailure.error.message,
            'Update Counsel'
          );
        }
      );
  }

  continue() {
    if (
      this.counselList.length <= 0 ||
      (this.counselForm.touched && !this.counselForm.pristine)
    ) {
      //this.openContinueWarningModal();
      this.router.navigate(['/ui/initiate-petition/review']);
    } else {
      this.setTabFlags();
      this.router.navigate(['/ui/initiate-petition/review']);
    }
  }

  setTabFlags() {
    this.counselList.forEach((element) => {
      if (element.counselType == 'Lead Counsel') {
        this.validLeadCounsel = true;
      }
    });
    if (this.validLeadCounsel) {
      this.initiatePetitionService.setOption('counselComplete', true);
      this.initiatePetitionService.setOption('counselInComplete', false);
    } else {
      this.initiatePetitionService.setOption('counselComplete', false);
      this.initiatePetitionService.setOption('counselInComplete', true);
    }
  }

  openContinueWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Performing this action will exit the current screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        this.initiatePetitionService.setOption('counselComplete', false);
        this.initiatePetitionService.setOption('counselInComplete', true);
        this.router.navigate(['/ui/initiate-petition/review']);
      } else {
      }
    });
  }

  // isFormValid(): boolean {
  //   return this.counselForm.disabled ? true : this.counselForm.valid;
  // }

  // logForm() {
  //   this.logger.info('Counsel form:', this.counselForm);
  //   this.logger.info('Counsel form disabled?:', this.counselForm.disabled);
  //   this.logger.info('Counsel form dirty?:', this.counselForm.dirty);
  // }
  openPTOLink() {
    // window.open(Urls.MYUSPTO, '_blank');
    window.open(this.myUsptoLink.MyUSPTO, '_blank');
  }
}
