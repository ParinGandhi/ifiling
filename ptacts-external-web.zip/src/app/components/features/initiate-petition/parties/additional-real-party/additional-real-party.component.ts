import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../initiate-petition.service';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { MultipleEmailModalComponent } from '../multiple-email-modal/multiple-email-modal.component';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/constants/constants';
import { element } from 'protractor';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';

@Component({
  selector: 'app-additional-real-party',
  templateUrl: './additional-real-party.component.html',
  styleUrls: ['./additional-real-party.component.scss'],
})
export class AdditionalRealPartyComponent implements OnInit {
  selectedPartyType: string = 'Individual';
  realPartyForm = this.fb.group({
    partyType: ['Individual', Validators.required],
    proSe: ['No', Validators.required],
    findParty: [''],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    organizationName: [''],
    email: ['', Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)],
    // phoneNumber: ['', Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)],
    phoneNumber: ['', this.commonUtils.ValidatePhoneFax],
    extension: [''],
    // faxNumber: ['', Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)],
    faxNumber: ['', this.commonUtils.ValidatePhoneFax],
    country: ['', Validators.required],
    address1: [''],
    address2: [''],
    city: [''],
    state: [''],
    zip: [''],
  });
  modalRef: BsModalRef;
  deleteModelRef: BsModalRef;
  countries: [] = [];
  states: [] = [];
  addRealPartyObj: any = null;
  petitionInfo: any = {};
  updateMode: boolean = false;
  savedRealParty: any = {};
  stateIsRequired: boolean = false;
  tempAddedRealPartyList: Array<any> = [];
  addedRealPartyList: Array<any> = [];
  editAction: boolean = false;
  obj = {};
  streetLineOneText = '';
  streetLineTwoText = '';
  city = '';
  state = '';
  zip = '';
  addr = '';
  email = '';
  fax = '';
  phone = '';
  telephoneNumber = '';
  extension = '';
  country = '';
  identifier = '';
  partyIdentifier = '';
  mailingAddressIdentifier = '';
  phoneIdentifier = '';
  emailIdentifier = '';
  faxIdentifier = '';
  componentName: string = 'additionalRealParty';
  verificationFlag: any;
  onBehalfOf: string = null;
  addingToList: boolean = false;
  loading: boolean = false;

  constructor(
    private fb: FormBuilder,
    public initiatePetitionService: InitiatePetitionService,
    private logger: NGXLogger,
    private modalService: BsModalService,
    public commonUtils: CommonUtilitiesService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.logger.info('Initial Real Party form:', this.realPartyForm);
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getCountries();
    this.addRealPartyObj = {
      caseNo: null,
      proceedingSupplementaryIdList: [],
      supplementaryIdType: null,
      caseType: null,
      identifier: null,
      parties: [
        {
          identifier: null,
          rankNo: null,
          partyType: null,
          partySubType: null,
          partySubTypeDescription: null,
          registrationNo: null,
          submitterType: null,
          proseIndicator: null,
          personType: [
            {
              identifier: null,
              firstName: null,
              lastName: null,
              middleInitial: null,
              prefferedName: null,
              mailingAddress: [
                {
                  identifier: null,
                  streetLineOneText: null,
                  streetLineTwoText: null,
                  city: null,
                  state: null,
                  zipCode: null,
                  country: null,
                  addressType: null,
                },
              ],
              electronicAddress: [
                {
                  identifier: null,
                  teleCommAddresType: null,
                  telephoneNumber: null,
                  email: null,
                  emailType: null,
                  extension: null,
                },
              ],
            },
          ],
          orgType: [
            {
              identifier: null,
              legalname: null,
              orgAddress: [
                {
                  identifier: null,
                  streetLineOneText: null,
                  streetLineTwoText: null,
                  city: null,
                  state: null,
                  zipCode: null,
                  country: null,
                  addressType: null,
                },
              ],
              electronicAddress: [
                {
                  identifier: null,
                  teleCommAddresType: null,
                  telephoneNumber: null,
                  email: null,
                  emailType: null,
                  extension: null,
                },
              ],
            },
          ],
        },
      ],
      audit: {
        lastModifiedUserIdentifier: '',
        createUserIdentifier: '',
      },
    };
    this.getExistingRealParty();
    this.verificationFlag = this.initiatePetitionService.getOption();
  }

  cancel() {
    // this.realPartyForm.reset();
    this.resetForm();
    this.editAction = false;
    this.disableNav(this.editAction);
  }

  disableNav(ea) {
    if (ea) {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.add('navdisabled');
    } else {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.remove('navdisabled');
    }
  }

  editRealParty(editValue) {
    this.editAction = true;
    //this.disableNav(this.editAction);
    this.realPartyForm.get('firstName').setValue(editValue.firstName);
    this.realPartyForm.get('lastName').setValue(editValue.lastName);
    this.realPartyForm.get('email').setValue(editValue.email);
    this.realPartyForm.get('phoneNumber').setValue(editValue.telephoneNumber);
    this.realPartyForm.get('extension').setValue(editValue.extension);
    this.realPartyForm.get('faxNumber').setValue(editValue.fax);
    var fCountry: any = this.countries.find((country: any) => {
      return country.value === editValue.country;
    });
    this.realPartyForm.get('country').setValue(fCountry);
    this.realPartyForm
      .get('address1')
      .setValue(editValue.streetLineOneText.trim());
    this.realPartyForm.get('address2').setValue(editValue.streetLineTwoText);
    this.realPartyForm.get('city').setValue(editValue.city);
    var fState: any;
    if (editValue.state) {
      this.modifyStateReq(fCountry.value);
      this.initiatePetitionService
        .getStates(fCountry.value)
        .pipe(take(1))
        .subscribe((statesList) => {
          this.states = statesList;
          fState = this.states.find((state: any) => {
            return state.value === editValue.state;
          });
          this.realPartyForm.get('state').setValue(fState);
        });
    }
    this.realPartyForm.get('zip').setValue(editValue.zip);
    this.savedRealParty.identifier = editValue.identifier;
    if (editValue.type == 'Organization') {
      this.realPartyForm.get('partyType').setValue('Organization');
      this.realPartyForm.get('organizationName').setValue(editValue.name);
      this.savedRealParty.orgType_identifier = editValue.partyIdentifier;
      this.savedRealParty.orgType_mailingAddress_identifier =
        editValue.mailingAddressIdentifier;
      this.savedRealParty.orgType_phoneIdentifier = editValue.phoneIdentifier;
      this.savedRealParty.orgType_emailIdentifier = editValue.emailIdentifier;
      this.savedRealParty.orgType_faxIdentifier = editValue.faxIdentifier;
      this.savedRealParty.orgType_orgAddress_identifier =
        editValue.mailingAddressIdentifier;
      this.realPartyForm.get('firstName').clearValidators();
      this.realPartyForm.get('lastName').clearValidators();
      this.realPartyForm.get('proSe').setValue('No');
      this.realPartyForm.get('proSe').clearValidators();
      this.realPartyForm
        .get('organizationName')
        .setValidators([Validators.required]);
      this.updateFormValidity();
    }
    if (editValue.type == 'Individual') {
      this.realPartyForm.get('partyType').setValue('Individual');
      this.savedRealParty.personType_identifier = editValue.partyIdentifier;
      this.savedRealParty.personType_mailingAddress_identifier =
        editValue.mailingAddressIdentifier;
      this.savedRealParty.personType_phoneIdentifier =
        editValue.phoneIdentifier;
      this.savedRealParty.personType_emailIdentifier =
        editValue.emailIdentifier;
      this.savedRealParty.personType_faxIdentifier = editValue.faxIdentifier;
    }
  }

  getCountries() {
    this.initiatePetitionService
      .getCountries()
      .pipe(take(1))
      .subscribe((countriesResponse) => {
        this.countries = countriesResponse;
        this.logger.info('Countries list: ', this.countries);

        if (this.updateMode && this.realPartyForm.get('country').value) {
          if (this.realPartyForm.get('country').value.value) {
            const foundCountry: any = this.countries.find((country: any) => {
              return (
                country.value === this.realPartyForm.get('country').value.value
              );
            });
            this.realPartyForm.get('country').setValue(foundCountry);
            this.getStates(foundCountry.value);
          }
        } else {
          this.realPartyForm.get('country').setValue('', Validators.required);
        }
      });
  }

  getStates(countryCode) {
    this.states = [];
    //this.realPartyForm.get('state').setValue(null);
    const savedStateToFind = this.realPartyForm.get('state').value;
    this.modifyStateReq(countryCode);
    this.initiatePetitionService
      .getStates(countryCode)
      .pipe(take(1))
      .subscribe((statesList) => {
        this.states = statesList;
        if (this.updateMode) {
          if (savedStateToFind.value) {
            const foundState = this.states.find((stateToFind: any) => {
              return stateToFind.value === savedStateToFind.value;
            });
            if (foundState) {
              this.realPartyForm.get('state').setValue(foundState);
            } else {
              this.realPartyForm.controls.state.setValue('');
            }
          }
        } else {
          this.realPartyForm.controls.state.setValue('');
        }
      });
    this.realPartyForm.controls.state.setValue('');
  }

  modifyStateReq(countryCode) {
    this.stateIsRequired = false;
    if (CONSTANTS.MANDATORY_COUNTRIES.includes(countryCode)) {
      this.stateIsRequired = true;
      this.realPartyForm.get('state').setValidators([Validators.required]);
    } else {
      this.realPartyForm.get('state').clearValidators();
    }
    this.realPartyForm.get('state').updateValueAndValidity();
  }

  getExistingRealParty() {
    this.loading = true;
    this.initiatePetitionService
      .getRealParty(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (existingRealPartyResponse) => {
          this.addedRealPartyList = [];
          this.tempAddedRealPartyList =
            existingRealPartyResponse?.petitionRealParty?.parties;
          if (this.tempAddedRealPartyList) {
            this.setList();
          }
          this.logger.info(
            'Existing additional real party info: ',
            existingRealPartyResponse
          );
          this.loading = false;

          // if (
          //   existingRealPartyResponse.petitionRealParty &&
          //   existingRealPartyResponse.petitionRealParty.parties.length > 0 &&
          //   existingRealPartyResponse.petitionRealParty.parties[
          //     existingRealPartyResponse.petitionRealParty.parties.length - 1
          //   ].personType.length > 0
          // ) {
          //   this.savedRealParty =
          //     existingRealPartyResponse.petitionRealParty.parties[
          //       existingRealPartyResponse.petitionRealParty.parties.length - 1
          //     ];
          //   this.updateMode = true;
          //   this.selectedPartyType = 'Individual';
          //   if(existingRealPartyResponse.petitionRealParty.parties[
          //     existingRealPartyResponse.petitionRealParty.parties.length - 1
          //   ].personType[0].mailingAddress.length > 0)
          //   {
          //     this.modifyStateReq(
          //     existingRealPartyResponse.petitionRealParty.parties[
          //       existingRealPartyResponse.petitionRealParty.parties.length - 1
          //     ].personType[0].mailingAddress[0].country
          //   );
          //   this.getStates(
          //     existingRealPartyResponse.petitionRealParty.parties[
          //       existingRealPartyResponse.petitionRealParty.parties.length - 1
          //     ].personType[0].mailingAddress[0].country
          //   );}
          //   setTimeout(() => {
          //     this.setForm(
          //       existingRealPartyResponse.petitionRealParty.parties[
          //         existingRealPartyResponse.petitionRealParty.parties.length - 1
          //       ],
          //       'ind'
          //     );
          //   }, 200);
          // } else if (
          //   existingRealPartyResponse.petitionRealParty &&
          //   existingRealPartyResponse.petitionRealParty.parties.length > 0 &&
          //   existingRealPartyResponse.petitionRealParty.parties[
          //     existingRealPartyResponse.petitionRealParty.parties.length - 1
          //   ].orgType.length > 0
          // ) {
          // this.savedRealParty =
          //   existingRealPartyResponse.petitionRealParty.parties[
          //     existingRealPartyResponse.petitionRealParty.parties.length - 1
          //   ];
          //   this.updateMode = true;
          //   this.selectedPartyType = 'Organization';
          //   if(existingRealPartyResponse.petitionRealParty.parties[
          //     existingRealPartyResponse.petitionRealParty.parties.length - 1
          //   ].orgType[0].orgAddress.length > 0 ){
          //   this.modifyStateReq(
          //     existingRealPartyResponse.petitionRealParty.parties[
          //       existingRealPartyResponse.petitionRealParty.parties.length - 1
          //     ].orgType[0].orgAddress[0].country
          //   );
          //   this.getStates(
          //     existingRealPartyResponse.petitionRealParty.parties[
          //       existingRealPartyResponse.petitionRealParty.parties.length - 1
          //     ].orgType[0].orgAddress[0].country
          //   );}
          //   setTimeout(() => {
          //     this.setForm(
          //       existingRealPartyResponse.petitionRealParty.parties[
          //         existingRealPartyResponse.petitionRealParty.parties.length - 1
          //       ],
          //       'org'
          //     );
          //   }, 200);
          // }
        },
        () => {
          this.loading = false;
        }
      );
  }

  setList() {
    this.tempAddedRealPartyList.forEach((element) => {
      if (element.orgType.length > 0 && element.partyType == 'ADD REAL PARTY') {
        this.clearObject();
        this.identifier = element.identifier;
        element.orgType.forEach((ele) => {
          this.partyIdentifier = ele.identifier;
          if (
            ele.orgAddress &&
            ele.orgAddress.length > 0 &&
            ele.orgAddress[0].streetLineOneText
          ) {
            this.mailingAddressIdentifier = ele.orgAddress[0].identifier;
            this.addr = ele.orgAddress[0].streetLineOneText;
            this.streetLineOneText = ele.orgAddress[0].streetLineOneText;
            if (
              ele.orgAddress[0].streetLineTwoText &&
              ele.orgAddress[0].streetLineTwoText.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr =
                  this.addr + ', ' + ele.orgAddress[0].streetLineTwoText;
              } else {
                this.addr = ele.orgAddress[0].streetLineTwoText;
              }
              this.streetLineTwoText = ele.orgAddress[0].streetLineTwoText;
            }
            if (ele.orgAddress[0].city && ele.orgAddress[0].city.trim()) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.orgAddress[0].city;
              } else {
                this.addr = ele.orgAddress[0].city;
              }
              this.city = ele.orgAddress[0].city;
            }
            if (ele.orgAddress[0].state && ele.orgAddress[0].state.trim()) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.orgAddress[0].state;
              } else {
                this.addr = ele.orgAddress[0].state;
              }
              this.state = ele.orgAddress[0].state;
            }
            if (ele.orgAddress[0].zipCode && ele.orgAddress[0].zipCode.trim()) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ' ' + ele.orgAddress[0].zipCode;
              } else {
                this.addr = ele.orgAddress[0].zipCode;
              }
              this.zip = ele.orgAddress[0].zipCode;
            }
            if (ele.orgAddress[0].country && ele.orgAddress[0].country.trim()) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.orgAddress[0].country;
              } else {
                this.addr = ele.orgAddress[0].country;
              }
              this.country = ele.orgAddress[0].country;
            }
            // if(ele.orgAddress[0].country){
            //   this.country = ele.orgAddress[0].country;
            // }
          }
          if (ele.electronicAddress.length > 0) {
            for (var i = 0; i < ele.electronicAddress.length; i++) {
              if (ele.electronicAddress[i].telephoneNumber) {
                this.phone = ele.electronicAddress[i].telephoneNumber;
                this.telephoneNumber = ele.electronicAddress[i].telephoneNumber;
                this.phoneIdentifier = ele.electronicAddress[i].identifier;
              }
              if (ele.electronicAddress[i].extension) {
                this.phone =
                  this.phone + ' ext: ' + ele.electronicAddress[i].extension;
                this.extension = ele.electronicAddress[i].extension;
              }
              if (ele.electronicAddress[i].email) {
                this.email = ele.electronicAddress[i].email;
                this.emailIdentifier = ele.electronicAddress[i].identifier;
              }
              if (ele.electronicAddress[i].fax) {
                this.fax = ele.electronicAddress[i].fax;
                this.faxIdentifier = ele.electronicAddress[i].identifier;
              }
            }
            // this.phone = ele.electronicAddress[0].telephoneNumber;
            // this.telephoneNumber = ele.electronicAddress[0].telephoneNumber;
            // this.phoneIdentifier = ele.electronicAddress[0].identifier;
            // if(ele.electronicAddress[0].extension){
            //   this.phone = this.phone + ",ext:" + ele.electronicAddress[0].extension;
            //   this.extension = ele.electronicAddress[0].extension;
            // }
            // ele.electronicAddress.forEach(val => {
            //   if(val.email){
            //     this.email = val.email;
            //     this.emailIdentifier = ele.electronicAddress[0].identifier;
            //   }
            //   if(val.fax){
            //     this.fax = val.fax;
            //     this.faxIdentifier = ele.electronicAddress[0].identifier;
            //   }
            // });
          }
          this.obj = {
            firstName: ele.firstName,
            lastName: ele.lastName,
            email: this.email,
            phone: this.phone,
            extension: this.extension,
            fax: this.fax,
            country: this.country,
            streetLineOneText: this.streetLineOneText,
            streetLineTwoText: this.streetLineTwoText,
            city: this.city,
            state: this.state,
            zip: this.zip,
            name: ele.legalname,
            type: 'Organization',
            address: this.addr,
            telephoneNumber: this.telephoneNumber,
            identifier: this.identifier,
            partyIdentifier: this.partyIdentifier,
            mailingAddressIdentifier: this.mailingAddressIdentifier,
            phoneIdentifier: this.phoneIdentifier,
            emailIdentifier: this.emailIdentifier,
            faxIdentifier: this.faxIdentifier,
          };
        });
        this.addedRealPartyList.push(this.obj);
      }
      if (
        element.personType.length > 0 &&
        element.partyType == 'ADD REAL PARTY'
      ) {
        this.clearObject();
        this.identifier = element.identifier;
        element.personType.forEach((ele) => {
          this.partyIdentifier = ele.identifier;
          if (
            ele.mailingAddress &&
            ele.mailingAddress.length > 0 &&
            ele.mailingAddress[0].streetLineOneText
          ) {
            this.mailingAddressIdentifier = ele.mailingAddress[0].identifier;
            this.addr = ele.mailingAddress[0].streetLineOneText;
            this.streetLineOneText = ele.mailingAddress[0].streetLineOneText;
            if (
              ele.mailingAddress[0].streetLineTwoText &&
              ele.mailingAddress[0].streetLineTwoText.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr =
                  this.addr + ', ' + ele.mailingAddress[0].streetLineTwoText;
              } else {
                this.addr = ele.mailingAddress[0].streetLineTwoText;
              }
              this.streetLineTwoText = ele.mailingAddress[0].streetLineTwoText;
            }
            if (
              ele.mailingAddress[0].city &&
              ele.mailingAddress[0].city.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.mailingAddress[0].city;
              } else {
                this.addr = ele.mailingAddress[0].city;
              }
              this.city = ele.mailingAddress[0].city;
            }
            if (
              ele.mailingAddress[0].state &&
              ele.mailingAddress[0].state.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.mailingAddress[0].state;
              } else {
                this.addr = ele.mailingAddress[0].state;
              }
              this.state = ele.mailingAddress[0].state;
            }
            if (
              ele.mailingAddress[0].zipCode &&
              ele.mailingAddress[0].zipCode.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ' ' + ele.mailingAddress[0].zipCode;
              } else {
                this.addr = ele.mailingAddress[0].zipCode;
              }
              this.zip = ele.mailingAddress[0].zipCode;
            }
            // if(ele.mailingAddress[0].country && ele.mailingAddress[0].country.trim()){
            //   this.country = ele.mailingAddress[0].country;
            // }
            if (
              ele.mailingAddress[0].country &&
              ele.mailingAddress[0].country.trim()
            ) {
              if (this.addr && this.addr.trim()) {
                this.addr = this.addr + ', ' + ele.mailingAddress[0].country;
              } else {
                this.addr = ele.mailingAddress[0].country;
              }
              this.country = ele.mailingAddress[0].country;
            }
          }

          if (ele.electronicAddress.length > 0) {
            // this.phone = ele.electronicAddress[0].telephoneNumber;
            // this.telephoneNumber = ele.electronicAddress[0].telephoneNumber;
            // this.phoneIdentifier = ele.electronicAddress[0].identifier;
            // if(ele.electronicAddress[0].extension){
            //   this.phone = this.phone + ",ext:" + ele.electronicAddress[0].extension;
            //   this.extension = ele.electronicAddress[0].extension;
            // }
            for (var i = 0; i < ele.electronicAddress.length; i++) {
              if (ele.electronicAddress[i].telephoneNumber) {
                this.phone = ele.electronicAddress[i].telephoneNumber;
                this.telephoneNumber = ele.electronicAddress[i].telephoneNumber;
                this.phoneIdentifier = ele.electronicAddress[i].identifier;
              }
              if (ele.electronicAddress[i].extension) {
                this.phone =
                  this.phone + ' ext: ' + ele.electronicAddress[i].extension;
                this.extension = ele.electronicAddress[i].extension;
              }
              if (ele.electronicAddress[i].email) {
                this.email = ele.electronicAddress[i].email;
                this.emailIdentifier = ele.electronicAddress[i].identifier;
              }
              if (ele.electronicAddress[i].fax) {
                this.fax = ele.electronicAddress[i].fax;
                this.faxIdentifier = ele.electronicAddress[i].identifier;
              }
            }
            // ele.electronicAddress.forEach(val => {
            //   if(val.email){
            //     this.email = val.email;
            //     this.emailIdentifier = ele.electronicAddress[0].identifier;
            //   }
            //   if(val.fax){
            //     this.fax = val.fax;
            //     this.faxIdentifier = ele.electronicAddress[0].identifier;
            //   }
            // });
          }
          this.obj = {
            firstName: ele.firstName,
            lastName: ele.lastName,
            email: this.email,
            phone: this.phone,
            extension: this.extension,
            fax: this.fax,
            country: this.country,
            streetLineOneText: this.streetLineOneText,
            streetLineTwoText: this.streetLineTwoText,
            city: this.city,
            state: this.state,
            zip: this.zip,
            name: ele.firstName + ' ' + ele.lastName,
            type: 'Individual',
            address: this.addr,
            telephoneNumber: this.telephoneNumber,
            identifier: this.identifier,
            partyIdentifier: this.partyIdentifier,
            mailingAddressIdentifier: this.mailingAddressIdentifier,
            phoneIdentifier: this.phoneIdentifier,
            emailIdentifier: this.emailIdentifier,
            faxIdentifier: this.faxIdentifier,
          };
        });
        this.addedRealPartyList.push(this.obj);
      }
    });
  }

  clearObject() {
    this.obj = {};
    this.streetLineOneText = '';
    this.streetLineTwoText = '';
    this.city = '';
    this.state = '';
    this.zip = '';
    this.addr = '';
    this.email = '';
    this.fax = '';
    this.phone = '';
    this.telephoneNumber = '';
    this.extension = '';
    this.country = '';
    this.identifier = '';
    this.partyIdentifier = '';
    this.mailingAddressIdentifier = '';
    this.phoneIdentifier = '';
    this.emailIdentifier = '';
    this.faxIdentifier = '';
  }

  findByRegOrEmail(regOrEmail) {
    let searchCriteria = Number.isNaN(parseInt(regOrEmail))
      ? `email=${regOrEmail.toLowerCase().trim()}`
      : `registrationNumber=${regOrEmail}`;
    this.initiatePetitionService
      .findByRegOrEmail(searchCriteria)
      .pipe(take(1))
      .subscribe(
        (foundParties) => {
          if (foundParties.length === 1) {
            this.setPetitioner(foundParties[0]);
          } else if (foundParties.length > 1) {
            this.openMultipleModal(foundParties);
          } else {
            this.openMultipleModal(null);
          }
        },
        (notFoundResponse) => {
          this.logger.error('Eamil or regNo not found: ', notFoundResponse);
        }
      );
  }

  setPetitioner(petitionerInfo) {
    this.logger.info('Found parties: ', petitionerInfo);
    this.realPartyForm
      .get('firstName')
      .setValue(petitionerInfo.personType[0].firstName);
    this.realPartyForm
      .get('lastName')
      .setValue(petitionerInfo.personType[0].lastName);
    this.realPartyForm
      .get('email')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].email);
    this.realPartyForm
      .get('phoneNummber')
      .setValue(
        petitionerInfo.personType[0].electronicAddress[0].telephoneNumber
      );
    this.realPartyForm
      .get('extension')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].extension);
    this.realPartyForm
      .get('faxNumber')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].faxNumber);
  }

  changePartyTypes(partyType) {
    // this.states = [];
    this.realPartyForm
      .get('email')
      .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)]);
    this.realPartyForm
      .get('phoneNumber')
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    this.realPartyForm
      .get('faxNumber')
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    switch (partyType) {
      case 'ind':
        this.realPartyForm
          .get('firstName')
          .setValidators([Validators.required]);
        this.realPartyForm.get('lastName').setValidators([Validators.required]);
        this.realPartyForm.get('organizationName').setValue('');
        this.realPartyForm.get('organizationName').clearValidators();
        break;
      case 'org':
        this.realPartyForm.get('firstName').clearValidators();
        this.realPartyForm.get('lastName').clearValidators();
        this.realPartyForm.get('proSe').setValue('No');
        this.realPartyForm.get('proSe').clearValidators();
        this.realPartyForm
          .get('organizationName')
          .setValidators([Validators.required]);
        this.changeProSe('no');
        break;
      default:
        break;
    }
    this.updateFormValidity();
  }

  changeProSe(proSeVal) {
    if (proSeVal === 'yes') {
      this.realPartyForm.get('email').setValidators([Validators.required]);
      this.realPartyForm
        .get('phoneNumber')
        .setValidators([Validators.required]);
      this.realPartyForm.get('country').setValidators([Validators.required]);
      // this.realPartyForm.get('address1').setValidators([Validators.required]);
      // this.realPartyForm.get('city').setValidators([Validators.required]);
      this.realPartyForm.get('state').setValidators([Validators.required]);
      // this.realPartyForm.get('zip').setValidators([Validators.required]);
    } else {
      // this.realPartyForm.get('email').clearValidators();
      // this.realPartyForm.get('phoneNumber').clearValidators();
      //this.realPartyForm.get('country').clearValidators();
      this.realPartyForm.get('address1').clearValidators();
      this.realPartyForm.get('city').clearValidators();
      this.realPartyForm.get('state').clearValidators();
      this.realPartyForm.get('zip').clearValidators();
    }
    this.updateFormValidity();
  }

  updateFormValidity() {
    this.realPartyForm.get('partyType').updateValueAndValidity();
    this.realPartyForm.get('proSe').updateValueAndValidity();
    this.realPartyForm.get('firstName').updateValueAndValidity();
    this.realPartyForm.get('lastName').updateValueAndValidity();
    this.realPartyForm.get('organizationName').updateValueAndValidity();
    this.realPartyForm.get('email').updateValueAndValidity();
    this.realPartyForm.get('phoneNumber').updateValueAndValidity();
    this.realPartyForm.get('extension').updateValueAndValidity();
    this.realPartyForm.get('faxNumber').updateValueAndValidity();
    this.realPartyForm.get('country').updateValueAndValidity();
    this.realPartyForm.get('address1').updateValueAndValidity();
    this.realPartyForm.get('address2').updateValueAndValidity();
    this.realPartyForm.get('city').updateValueAndValidity();
    this.realPartyForm.get('state').updateValueAndValidity();
    this.realPartyForm.get('zip').updateValueAndValidity();
  }

  clearForm() {
    this.updateMode = false;
    this.resetForm();
    // if (this.updateMode) {
    //   if (this.realPartyForm.dirty && !this.realPartyForm.pristine) {
    //     this.openWarningModal();
    //   }
    // } else {
    //   this.resetForm();
    // }
  }

  resetForm() {
    this.realPartyForm.reset();
    this.realPartyForm.get('partyType').setValidators([Validators.required]);
    this.realPartyForm.get('proSe').setValidators([Validators.required]);
    this.realPartyForm.get('firstName').setValidators([Validators.required]);
    this.realPartyForm.get('lastName').setValidators([Validators.required]);
    this.realPartyForm.get('organizationName').clearValidators();
    // this.realPartyForm.get('phoneNumber').clearValidators();
    this.realPartyForm.get('partyType').setValue('Individual');
    this.realPartyForm.get('proSe').setValue('No');
    this.updateFormValidity();
    this.logger.info('Additional real party form: ', this.realPartyForm);
  }

  openMultipleModal(emailList) {
    const isFound = !emailList ? false : true;
    const title = !emailList
      ? 'User not found'
      : 'Multiple email addresses found for registration number';
    const initialState: ModalOptions = {
      initialState: {
        emailList: emailList,
        emailSelected: false,
        selectedPetitioner: null,
        isFound: isFound,
        title: title,
      },
      class: 'modal-lg',
    };
    this.modalRef = this.modalService.show(
      MultipleEmailModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.emailSelected) {
        this.setPetitioner(reason.initialState.selectedPetitioner);
      } else {
      }
    });
  }

  addRealParty() {
    this.addingToList = true;
    this.setObjForAddUpdate('add');
    this.logger.info('Additional real party obj: ', this.addRealPartyObj);
    this.initiatePetitionService
      .addRealParty(this.addRealPartyObj, this.realPartyForm.value.proSe)
      .pipe(take(1))
      .subscribe(
        (addRealPartySuccess) => {
          this.commonUtils.showSuccess(
            'Additional real party added successfully',
            'Petitioner additional real party'
          );
          this.logger.info(
            'Additional real party added successfully',
            addRealPartySuccess
          );
          this.updateMode = true;
          // this.realPartyIndForm.controls.proSe.setValue('No');
          this.addRealPartyObj = addRealPartySuccess;
          // if (this.selectedPartyType === 'Individual') {
          //   // this.setIndForm(addRealPartySuccess.parties[0]);
          // } else {
          // }
          this.getExistingRealParty();
          this.resetForm();
          this.addingToList = false;
        },
        (addRealPartyFailure) => {
          this.logger.error(
            'Add additional real party failure: ',
            addRealPartyFailure
          );
          this.commonUtils.showError(
            'Failed to add additional real party',
            'Petitioner additional real party'
          );
          this.addingToList = false;
        }
      );
  }

  setObjForAddUpdate(actionType) {
    this.addRealPartyObj.caseNo = this.petitionInfo.proceedingNumberText;
    // this.addRealPartyObj.caseNo = 'IPR2021-01322';
    this.addRealPartyObj.parties[0].partyType = 'ADD REAL PARTY';
    this.addRealPartyObj.parties[0].submitterType = 'PETITIONER';
    this.addRealPartyObj.audit.lastModifiedUserIdentifier =
      window.sessionStorage.getItem('email');
    this.addRealPartyObj.audit.createUserIdentifier =
      window.sessionStorage.getItem('email');
    if (this.realPartyForm.value.partyType === 'Individual') {
      this.addRealPartyObj.parties[0].personType[0] = {
        firstName: this.realPartyForm.value.firstName,
        lastName: this.realPartyForm.value.lastName,
      };
      this.addRealPartyObj.parties[0].personType[0].mailingAddress =
        this.addMailingAddress(this.realPartyForm);
      this.addRealPartyObj.parties[0].personType[0].electronicAddress = [];
      this.addRealPartyObj.parties[0].personType[0].electronicAddress =
        this.addElectronicAddress(this.realPartyForm, actionType);
      this.addRealPartyObj.parties[0].orgType = [];
      if (this.realPartyForm.value.proSe === 'Yes') {
        this.addRealPartyObj.parties[0].partySubType = 'PROSE';
        this.addRealPartyObj.parties[0].proseIndicator = 'Y';
      } else {
        this.addRealPartyObj.parties[0].partySubType = null;
        this.addRealPartyObj.parties[0].proseIndicator = 'N';
      }
      if (actionType === 'update') {
        this.addRealPartyObj.parties[0].identifier =
          this.savedRealParty?.identifier;
        //if (this.savedRealParty?.personType.length > 0) {
        this.addRealPartyObj.parties[0].personType[0].identifier =
          this.savedRealParty.personType_identifier;
        //  if (this.savedRealParty.personType[0].mailingAddress.length > 0) {
        this.addRealPartyObj.parties[0].personType[0].mailingAddress[0].identifier =
          this.savedRealParty.personType_mailingAddress_identifier;
        //  }
        //}
      }
    } else {
      this.addRealPartyObj.parties[0].orgType[0] = {
        legalname: this.realPartyForm.value.organizationName,
      };
      this.addRealPartyObj.parties[0].orgType[0].orgAddress =
        this.addMailingAddress(this.realPartyForm);
      this.addRealPartyObj.parties[0].orgType[0].electronicAddress = [];
      this.addRealPartyObj.parties[0].orgType[0].electronicAddress =
        this.addElectronicAddress(this.realPartyForm, actionType);
      this.addRealPartyObj.parties[0].personType = [];
      if (actionType === 'update') {
        this.addRealPartyObj.parties[0].identifier =
          this.savedRealParty.identifier;
        //  if (this.savedRealParty.orgType.length > 0) {
        this.addRealPartyObj.parties[0].orgType[0].identifier =
          this.savedRealParty.orgType_identifier;
        this.addRealPartyObj.parties[0].orgType[0].orgAddress[0].identifier =
          this.savedRealParty.orgType_orgAddress_identifier;
        // }
      }
    }
  }

  addMailingAddress(mailingAddressInfo) {
    const mailingAddress = {
      identifier: null,
      streetLineOneText: mailingAddressInfo.value.address1,
      streetLineTwoText: mailingAddressInfo.value.address2,
      city: mailingAddressInfo.value.city,
      state: mailingAddressInfo.value.state
        ? mailingAddressInfo.value.state.value
          ? mailingAddressInfo.value.state.value
          : mailingAddressInfo.value.state
        : null,
      zipCode: mailingAddressInfo.value.zip,
      country: mailingAddressInfo.value.country
        ? mailingAddressInfo.value.country.value
        : null,
      addressType: 'RES',
    };
    const tempArr = [];
    tempArr.push(mailingAddress);
    return tempArr;
  }

  addElectronicAddress(electronicAddressInfo, actionType) {
    const tempArr = [];
    if (actionType === 'update') {
      const email = {
        email: electronicAddressInfo.value.email,
        emailType: 'WE',
        extention: null,
        identifier: null,
      };
      const phone = {
        extension: electronicAddressInfo.value.extension,
        identifier: null,
        teleCommAddresType: 'W',
        telephoneNumber: electronicAddressInfo.value.phoneNumber,
      };
      const fax = {
        extension: null,
        identifier: null,
        teleCommAddresType: 'F',
        fax: electronicAddressInfo.value.faxNumber,
      };
      if (this.realPartyForm.value.partyType === 'Individual') {
        // if (
        //   this.savedRealParty?.personType?.length > 0 &&
        //   this.savedRealParty.personType[0].electronicAddress &&
        //   this.savedRealParty.personType[0].electronicAddress.length > 0
        // ) {
        //   this.savedRealParty.personType[0].electronicAddress.forEach(
        //     (addressType) => {
        //       if (addressType.email) {
        //         email.identifier = addressType.identifier;
        //       }
        //       if (addressType.extension || addressType.phoneNumber) {
        //         phone.identifier = addressType.identifier;
        //       }
        //       if (addressType.fax) {
        //         fax.identifier = addressType.identifier;
        //       }
        //     }
        //   );
        // }
        email.identifier = this.savedRealParty.personType_emailIdentifier;
        phone.identifier = this.savedRealParty.personType_phoneIdentifier;
        fax.identifier = this.savedRealParty.personType_faxIdentifier;
      } else if (this.realPartyForm.value.partyType === 'Organization') {
        // if (
        //   this.savedRealParty?.orgType?.length > 0 &&
        //   this.savedRealParty.orgType[0].electronicAddress &&
        //   this.savedRealParty.orgType[0].electronicAddress.length > 0
        // ) {
        //   this.savedRealParty.orgType[0].electronicAddress.forEach(
        //     (addressType) => {
        //       if (addressType.email) {
        //         email.identifier = addressType.identifier;
        //       }
        //       if (addressType.extension || addressType.phoneNumber) {
        //         phone.identifier = addressType.identifier;
        //       }
        //       if (addressType.fax) {
        //         fax.identifier = addressType.identifier;
        //       }
        //     }
        //   );
        // }
        email.identifier = this.savedRealParty.orgType_emailIdentifier;
        phone.identifier = this.savedRealParty.orgType_phoneIdentifier;
        fax.identifier = this.savedRealParty.orgType_faxIdentifier;
      }

      tempArr.push(email);
      tempArr.push(phone);
      tempArr.push(fax);
    } else {
      const electronicAddress = {
        identifier: null,
        teleCommAddressType: null,
        telephoneNumber: electronicAddressInfo.value.phoneNumber,
        email: electronicAddressInfo.value.email,
        emailType: this.selectedPartyType === 'Individual' ? 'PE' : 'WE',
        extension: electronicAddressInfo.value.extension,
        fax: electronicAddressInfo.value.faxNumber,
      };
      tempArr.push(electronicAddress);
    }
    return tempArr;
  }

  setForm(partyInfo, partyType) {
    this.resetForm();
    let foundCountry = null;
    if (
      partyInfo.personType.length > 0 &&
      partyInfo.personType[0].mailingAddress.length > 0
    ) {
      if (
        partyType === 'ind' &&
        partyInfo.personType[0].mailingAddress[0].country
      ) {
        foundCountry = this.countries.find((country: any) => {
          return (
            country.value === partyInfo.personType[0].mailingAddress[0].country
          );
        });
      }
    } else if (
      partyInfo.orgType.length > 0 &&
      partyInfo.orgType[0].orgAddress.length > 0
    ) {
      if (partyType === 'org' && partyInfo.orgType[0].orgAddress[0].country) {
        foundCountry = this.countries.find((country: any) => {
          return country.value === partyInfo.orgType[0].orgAddress[0].country;
        });
      }
    }

    setTimeout(() => {
      let foundState = null;
      if (
        foundCountry &&
        partyType === 'ind' &&
        partyInfo.personType[0].mailingAddress[0].state &&
        this.states.length > 0
      ) {
        this.modifyStateReq(foundCountry.value);
        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            this.states = statesList;
            foundState = this.states.find((state: any) => {
              return (
                state.value === partyInfo.personType[0].mailingAddress[0].state
              );
            });
            this.realPartyForm.get('state').setValue(foundState);
          });
      } else if (
        foundCountry &&
        partyType === 'org' &&
        partyInfo.orgType[0].orgAddress[0].state &&
        this.states.length > 0
      ) {
        this.modifyStateReq(foundCountry.value);
        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            this.states = statesList;
            foundState = this.states.find((state: any) => {
              return state.value === partyInfo.orgType[0].orgAddress[0].state;
            });
            this.realPartyForm.get('state').setValue(foundState);
          });
      }
      this.realPartyForm
        .get('partyType')
        .setValue(partyType === 'ind' ? 'Individual' : 'Organization');

      this.realPartyForm.get('country').setValue(foundCountry);

      this.realPartyForm
        .get('proSe')
        .setValue(partyInfo.proseIndicator === 'Y' ? 'Yes' : 'No');
      if (partyType === 'ind') {
        // this.realPartyForm.get('proSe').setValue();
        this.realPartyForm
          .get('firstName')
          .setValue(partyInfo.personType[0].firstName, Validators.required);
        this.realPartyForm
          .get('lastName')
          .setValue(partyInfo.personType[0].lastName, Validators.required);
        partyInfo.personType[0].electronicAddress.forEach((element) => {
          if (element.extension) {
            this.realPartyForm.get('extension').setValue(element.extension);
          }
          if (element.telephoneNumber) {
            this.realPartyForm
              .get('phoneNumber')
              .setValue(element.telephoneNumber);
          }
          if (element.fax) {
            this.realPartyForm.get('faxNumber').setValue(element.fax);
          }
          if (element.email) {
            this.realPartyForm.get('email').setValue(element.email);
          }
        });
        if (partyInfo.personType[0].mailingAddress.length > 0) {
          this.realPartyForm
            .get('address1')
            .setValue(
              partyInfo.personType[0].mailingAddress[0].streetLineOneText
            );
          this.realPartyForm
            .get('address2')
            .setValue(
              partyInfo.personType[0].mailingAddress[0].streetLineTwoText
            );
          this.realPartyForm
            .get('city')
            .setValue(partyInfo.personType[0].mailingAddress[0].city);
          this.realPartyForm
            .get('zip')
            .setValue(partyInfo.personType[0].mailingAddress[0].zipCode);
        }
      } else if (partyType === 'org') {
        this.realPartyForm
          .get('organizationName')
          .setValue(partyInfo.orgType[0].legalname);
        if (
          partyInfo.orgType[0].electronicAddress &&
          partyInfo.orgType[0].electronicAddress.length > 0
        ) {
          partyInfo.orgType[0].electronicAddress.forEach((element) => {
            if (element.extension) {
              this.realPartyForm.get('extension').setValue(element.extension);
            }
            if (element.telephoneNumber) {
              this.realPartyForm
                .get('phoneNumber')
                .setValue(element.telephoneNumber);
            }
            if (element.fax) {
              this.realPartyForm.get('faxNumber').setValue(element.fax);
            }
            if (element.email) {
              this.realPartyForm.get('email').setValue(element.email);
            }
          });
        } else {
          this.realPartyForm.get('email').setValue('');
          this.realPartyForm.get('phoneNumber').setValue('');
          this.realPartyForm.get('extension').setValue('');
          this.realPartyForm.get('faxNumber').setValue('');
        }
        this.realPartyForm
          .get('address1')
          .setValue(partyInfo.orgType[0].orgAddress[0].streetLineOneText);
        this.realPartyForm
          .get('address2')
          .setValue(partyInfo.orgType[0].orgAddress[0].streetLineTwoText);
        this.realPartyForm
          .get('city')
          .setValue(partyInfo.orgType[0].orgAddress[0].city);
        this.realPartyForm
          .get('zip')
          .setValue(partyInfo.orgType[0].orgAddress[0].zipCode);
      }
      this.changePartyTypes(partyType);
      this.realPartyForm.markAsPristine();
      this.updateFormValidity();
    }, 400);
  }

  updateRealParty(event) {
    const button =
      event.srcElement.disabled === undefined
        ? event.srcElement.parentElement
        : event.srcElement;
    button.setAttribute('disabled', true);
    setTimeout(function () {
      button.removeAttribute('disabled');
    }, 1000);
    this.setObjForAddUpdate('update');
    this.logger.info(
      'Additional real party obj for update: ',
      this.addRealPartyObj
    );
    this.initiatePetitionService
      .updateRealParty(this.addRealPartyObj)
      .pipe(take(1))
      .subscribe(
        (addRealPartySuccess) => {
          this.commonUtils.showSuccess(
            'Additional real party updated successfully',
            'Petitioner additional real party'
          );
          this.logger.info(
            'Additional real party updated successfully',
            addRealPartySuccess
          );
          this.updateMode = true;
          this.cancel();
          this.addRealPartyObj = addRealPartySuccess;
          this.getExistingRealParty();
          this.resetForm();
        },
        (addRealPartyFailure) => {
          this.logger.error(
            'Update additional real party failure: ',
            addRealPartyFailure
          );
          this.commonUtils.showError(
            'Failed to update additional real party',
            'Petitioner additional real party'
          );
        }
      );
  }

  openWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'You have document information that has not been saved to the docket. Your changes will be lost',
          'Are you sure you want to clear the changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        // if (partyType === 'ind') {
        if (this.updateMode) {
          // this.setIndForm(this.addRealPartyObj.parties[0]);
          this.getExistingRealParty();
        } else {
          this.resetForm();
          // this.realPartyIndForm.reset();
          // this.realPartyIndForm.controls.proSe.setValue('No');
        }
        // }
      } else {
      }
    });
  }

  continue() {
    // if (this.realPartyForm.touched && !this.realPartyForm.pristine) {
    //   //this.openContinueWarningModal();
    //   this.router.navigate(['/initiate-petition/counsel']);
    // } else {
    //   if (this.addedRealPartyList.length > 0) {
    //     this.initiatePetitionService.setOption(
    //       'additionalRealPartyComplete',
    //       true
    //     );
    //   } else {
    //     this.initiatePetitionService.setOption(
    //       'additionalRealPartyComplete',
    //       false
    //     );
    //   }
    //   //this.initiatePetitionService.setOption('additionalRealPartyInComplete',false);
    //   var test: any = this.initiatePetitionService.getOption();
    //   if (test.prose) {
    //     this.router.navigate(['/initiate-petition/review']);
    //   } else {
    //     this.router.navigate(['/initiate-petition/counsel']);
    //   }

    //   //this.checkProSe();
    // }
    if (!this.verificationFlag.prose) {
      this.router.navigate(['/ui/initiate-petition/counsel']);
    } else {
      this.router.navigate(['/ui/initiate-petition/review']);
    }
  }

  checkProSe() {
    if (this.realPartyForm.value.proSe === 'Yes') {
      this.initiatePetitionService.setOption('prose', true);
      this.router.navigate(['/ui/initiate-petition/review']);
    } else {
      this.initiatePetitionService.setOption('prose', false);
      this.router.navigate(['/ui/initiate-petition/counsel']);
    }
  }

  openContinueWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Performing this action will exit the current screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        //this.initiatePetitionService.setOption('additionalRealPartyInComplete',true);
        this.initiatePetitionService.setOption(
          'additionalRealPartyComplete',
          false
        );
        this.router.navigate(['/ui/initiate-petition/counsel']);
        //this.checkProSe();
      } else {
      }
    });
  }

  deleteRealParty(data) {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: 'Delete this additional real party?',
        infoText: [
          'This additional real party information will be removed from the table view.',
        ],
        showLeftBtn: true,
        leftBtnClass: 'btn-light',
        leftBtnLabel: 'No, return to page',
        showRightBtn: true,
        rightBtnClass: 'btn-danger',
        rightBtnLabel: 'Yes, delete this record',
        modalHeight: 100,
      },
    };
    this.deleteModelRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'confirm-delete-modal',
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.deleteModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.initiatePetitionService
          .deleteRealParty(
            this.petitionInfo.proceedingNumberText,
            data.identifier
          )
          .subscribe((Response) => {
            this.getExistingRealParty();
            this.commonUtils.showSuccess(
              `Additional real party successfully removed`,
              ''
            );
          });
      }
    });
  }

  onKeyUp(x) {
    if (x.code === 'Enter' || x.code === 'NumpadEnter') {
      this.findByRegOrEmail(this.realPartyForm.value.findParty);
    }
  }

  checkForm() {
    console.log('Form: ', this.realPartyForm);
  }
}
