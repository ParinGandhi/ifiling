import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalRealPartyComponent } from './additional-real-party.component';

describe('AdditionalRealPartyComponent', () => {
  let component: AdditionalRealPartyComponent;
  let fixture: ComponentFixture<AdditionalRealPartyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdditionalRealPartyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalRealPartyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
