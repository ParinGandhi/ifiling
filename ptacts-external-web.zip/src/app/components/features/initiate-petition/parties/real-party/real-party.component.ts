import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../initiate-petition.service';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { MultipleEmailModalComponent } from '../multiple-email-modal/multiple-email-modal.component';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/constants/constants';
import { InterestedParty } from 'src/app/models/parties/InterestedParty.model';

@Component({
  selector: 'app-real-party',
  templateUrl: './real-party.component.html',
  styleUrls: ['./real-party.component.scss'],
})
export class RealPartyComponent implements OnInit {
  selectedPartyType: string = 'Individual';
  realPartyForm = this.fb.group({
    partyType: ['Individual', Validators.required],
    proSe: ['No', Validators.required],
    findParty: [''],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    organizationName: [''],
    email: ['', Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)],
    // phoneNumber: ['', Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)],
    phoneNumber: ['', this.commonUtils.ValidatePhoneFax],
    extension: [''],
    // faxNumber: ['', Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)],
    faxNumber: ['', this.commonUtils.ValidatePhoneFax],
    country: ['', Validators.required],
    address1: [''],
    address2: [''],
    city: [''],
    state: [''],
    zip: [''],
  });
  modalRef: BsModalRef;
  countries: [] = [];
  states: [] = [];
  addRealPartyObj: any = null;
  petitionInfo: any = {};
  updateMode: boolean = false;
  savedRealParty: any = null;
  savedCounsel: any = null;
  stateIsRequired: boolean = false;
  proseWarning: boolean = false;
  counselList: [] = [];
  enableUpdate: boolean = false;
  counselIdentifier: any;
  counselPartyIdentifier: any;
  verificationFlag: any;
  componentName: string = 'realParty';
  findParty: string = null;
  onBehalfOf: string = null;
  addingPetitioner: boolean = false;
  loading: boolean = false;
  fieldsDisabled: boolean;
  searchedForParty: boolean = false;
  lookupForChange: boolean = false;

  constructor(
    private fb: FormBuilder,
    public initiatePetitionService: InitiatePetitionService,
    private logger: NGXLogger,
    private modalService: BsModalService,
    public commonUtils: CommonUtilitiesService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.logger.info('Initial Real Party form:', this.realPartyForm);
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    this.getCountries();
    this.addRealPartyObj = {
      caseNo: null,
      proceedingSupplementaryIdList: [],
      supplementaryIdType: null,
      caseType: null,
      identifier: null,
      parties: [
        {
          identifier: null,
          rankNo: null,
          partyType: null,
          partySubType: null,
          partySubTypeDescription: null,
          registrationNo: null,
          submitterType: null,
          proseIndicator: null,
          personType: [
            {
              identifier: null,
              firstName: null,
              lastName: null,
              middleInitial: null,
              prefferedName: null,
              mailingAddress: [
                {
                  identifier: null,
                  streetLineOneText: null,
                  streetLineTwoText: null,
                  city: null,
                  state: null,
                  zipCode: null,
                  country: null,
                  addressType: null,
                },
              ],
              electronicAddress: [
                {
                  identifier: null,
                  teleCommAddresType: null,
                  telephoneNumber: null,
                  email: null,
                  emailType: null,
                  extension: null,
                },
              ],
            },
          ],
          orgType: [
            {
              identifier: null,
              legalname: null,
              orgAddress: [
                {
                  identifier: null,
                  streetLineOneText: null,
                  streetLineTwoText: null,
                  city: null,
                  state: null,
                  zipCode: null,
                  country: null,
                  addressType: null,
                },
              ],
              electronicAddress: [
                {
                  identifier: null,
                  teleCommAddresType: null,
                  telephoneNumber: null,
                  email: null,
                  emailType: null,
                  extension: null,
                },
              ],
            },
          ],
        },
      ],
      audit: {
        lastModifiedUserIdentifier: '',
        createUserIdentifier: '',
      },
    };
    this.getExistingRealParty();
    this.getExistingCounsels();
    this.verificationFlag = this.initiatePetitionService.getOption();
  }

  getCountries() {
    this.initiatePetitionService
      .getCountries()
      .pipe(take(1))
      .subscribe(
        (countriesResponse) => {
          this.countries = countriesResponse;
          this.logger.info('Countries list: ', this.countries);
        },
        (countriesFailure) => {}
      );
  }

  getStates(countryCode) {
    this.states = [];
    // this.realPartyForm.get('state').setValue(null);
    this.modifyStateReq(countryCode);
    this.initiatePetitionService
      .getStates(countryCode)
      .pipe(take(1))
      .subscribe(
        (statesList) => {
          this.states = statesList;
          if (this.updateMode) {
            if (this.realPartyForm.get('state').value.value) {
              const foundState = this.states.find((stateToFind: any) => {
                return (
                  stateToFind.value ===
                  this.realPartyForm.get('state').value.value
                );
              });
              if (foundState) {
                this.realPartyForm.get('state').setValue(foundState);
              } else {
                this.realPartyForm.controls.state.setValue('');
              }
            }
          } else {
            this.realPartyForm.controls.state.setValue('');
          }
        },
        () => {
          this.realPartyForm.controls.state.setValue('');
        }
      );
  }

  modifyStateReq(countryCode) {
    this.stateIsRequired = false;
    if (CONSTANTS.MANDATORY_COUNTRIES.includes(countryCode)) {
      this.stateIsRequired = true;
      this.realPartyForm.get('state').setValidators([Validators.required]);
    } else {
      this.realPartyForm.get('state').clearValidators();
    }
    this.realPartyForm.get('state').updateValueAndValidity();
  }

  getExistingRealParty() {
    this.loading = true;
    this.initiatePetitionService
      .getRealParty(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (existingRealPartyResponse) => {
          this.logger.info(
            'Existing real party info: ',
            existingRealPartyResponse
          );

          if (
            existingRealPartyResponse.petitionRealParty &&
            existingRealPartyResponse.petitionRealParty.parties.length > 0
          ) {
            for (
              var i =
                existingRealPartyResponse.petitionRealParty.parties.length - 1;
              i >= 0;
              i--
            ) {
              if (
                existingRealPartyResponse.petitionRealParty.parties[i]
                  .partyType == 'REAL PARTY'
              ) {
                this.setSavedParty(existingRealPartyResponse, i);
                break;
              }
            }
          }
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
  }

  setSavedParty(existingRealPartyResponse, i) {
    if (
      existingRealPartyResponse.petitionRealParty &&
      existingRealPartyResponse.petitionRealParty.parties.length > 0 &&
      existingRealPartyResponse.petitionRealParty.parties[i].personType.length >
        0
    ) {
      this.savedRealParty =
        existingRealPartyResponse.petitionRealParty.parties[i];
      this.updateMode = true;
      this.selectedPartyType = 'Individual';
      if (
        existingRealPartyResponse.petitionRealParty.parties[i].personType[0]
          .mailingAddress.length > 0
      ) {
        this.modifyStateReq(
          existingRealPartyResponse.petitionRealParty.parties[i].personType[0]
            .mailingAddress[0].country
        );
        this.getStates(
          existingRealPartyResponse.petitionRealParty.parties[i].personType[0]
            .mailingAddress[0].country
        );
      }
      setTimeout(() => {
        this.setForm(
          existingRealPartyResponse.petitionRealParty.parties[i],
          'ind'
        );
      }, 200);
    } else if (
      existingRealPartyResponse.petitionRealParty &&
      existingRealPartyResponse.petitionRealParty.parties.length > 0 &&
      existingRealPartyResponse.petitionRealParty.parties[i].orgType.length > 0
    ) {
      this.savedRealParty =
        existingRealPartyResponse.petitionRealParty.parties[i];
      this.updateMode = true;
      this.selectedPartyType = 'Organization';
      if (
        existingRealPartyResponse.petitionRealParty.parties[i].orgType[0]
          .orgAddress.length > 0
      ) {
        this.modifyStateReq(
          existingRealPartyResponse.petitionRealParty.parties[i].orgType[0]
            .orgAddress[0].country
        );
        this.getStates(
          existingRealPartyResponse.petitionRealParty.parties[i].orgType[0]
            .orgAddress[0].country
        );
      }
      setTimeout(() => {
        this.setForm(
          existingRealPartyResponse.petitionRealParty.parties[i],
          'org'
        );
      }, 200);
    }
  }

  findByRegOrEmail(regOrEmail) {
    this.lookupForChange = true;
    this.searchedForParty = false;
    let searchCriteria = Number.isNaN(parseInt(regOrEmail))
      ? `email=${regOrEmail.toLowerCase().trim()}`
      : `registrationNumber=${regOrEmail}`;
    this.initiatePetitionService
      .findByRegOrEmail(searchCriteria)
      .pipe(take(1))
      .subscribe(
        (foundParties) => {
          this.resetForm();
          this.realPartyForm.get('proSe').setValue('Yes');
          if (foundParties.length === 1) {
            this.searchedForParty = true;
            this.setPetitioner(foundParties[0]);
          } else if (foundParties.length > 1) {
            this.openMultipleModal(foundParties);
          } else {
            this.openMultipleModal(null);
          }
          //this.realPartyForm.updateValueAndValidity();
          this.updateButton();
          this.fieldsDisabled = false;
        },
        (notFoundResponse) => {
          this.logger.error('Email or regNo not found: ', notFoundResponse);
          this.commonUtils.showError(
            'Email or registration number not found.',
            'Find party'
          );
        }
      );
  }

  setPetitioner(petitionerInfo) {
    this.logger.info('Found parties: ', petitionerInfo);
    var str = petitionerInfo.personType[0].electronicAddress[0].telephoneNumber;
    if (str) {
      var noSpecialCharacters = str.replace(/[^a-zA-Z0-9 ]/g, '');
    } else {
      noSpecialCharacters = '';
    }

    this.realPartyForm
      .get('firstName')
      .setValue(petitionerInfo.personType[0].firstName);
    this.realPartyForm
      .get('lastName')
      .setValue(petitionerInfo.personType[0].lastName);
    this.realPartyForm
      .get('email')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].email);
    if (this.realPartyForm.value.proSe === 'Yes') {
      this.realPartyForm.get('phoneNumber').setValidators([
        //Validators.required,
        // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
        this.commonUtils.ValidatePhoneFax,
      ]);
      this.realPartyForm.get('phoneNumber').setValue(noSpecialCharacters);
    }
    this.realPartyForm
      .get('extension')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].extension);
    this.realPartyForm
      .get('faxNumber')
      .setValue(petitionerInfo.personType[0].electronicAddress[0].faxNumber);
    this.realPartyForm.enable();
  }

  changePartyTypes(partyType) {
    // this.states = [];
    switch (partyType) {
      case 'ind':
        this.realPartyForm.get('proSe').setValue('No', Validators.required);
        this.realPartyForm
          .get('firstName')
          .setValidators([Validators.required]);
        this.realPartyForm.get('lastName').setValidators([Validators.required]);
        this.realPartyForm.get('organizationName').setValue('');
        this.realPartyForm.get('organizationName').clearValidators();
        break;
      case 'org':
        this.closeWarning();
        this.realPartyForm.get('firstName').setValue('');
        this.realPartyForm.get('firstName').clearValidators();
        this.realPartyForm.get('lastName').setValue('');
        this.realPartyForm.get('lastName').clearValidators();
        this.realPartyForm.get('proSe').setValue('No');
        this.realPartyForm.get('proSe').clearValidators();
        this.realPartyForm
          .get('organizationName')
          .setValidators([Validators.required]);
        this.changeProSe('no', 'org');
        break;
      default:
        break;
    }
    this.updateFormValidity();
  }

  changeProSe(proSeVal, partyType) {
    if (partyType == 'ind') {
      this.checkCounsel();
    }
    if (!this.proseWarning) {
      const partyType = this.realPartyForm.get('partyType').value;
      const proSe = this.realPartyForm.get('proSe').value;
      // this.realPartyForm.reset();
      this.realPartyForm.get('partyType').setValue(partyType);
      this.realPartyForm.get('proSe').setValue(proSe);
      if (proSeVal === 'yes') {
        this.proseClearForm();
        this.searchedForParty = false;
        this.disableFields();
        this.fieldsDisabled = true;
        this.realPartyForm
          .get('email')
          .setValidators([
            Validators.required,
            Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL),
          ]);
        this.realPartyForm.get('phoneNumber').setValidators([
          // Validators.required,
          // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
          this.commonUtils.ValidatePhoneFax,
        ]);
        this.realPartyForm
          .get('faxNumber')
          // .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)]);
          .setValidators([this.commonUtils.ValidatePhoneFax]);
        this.realPartyForm.get('country').setValidators([Validators.required]);
        // this.realPartyForm.get('address1').setValidators([Validators.required]);
        // this.realPartyForm.get('city').setValidators([Validators.required]);
        this.realPartyForm.get('state').setValidators([Validators.required]);
        // this.realPartyForm.get('zip').setValidators([Validators.required]);
      } else {
        this.realPartyForm.enable();
        this.fieldsDisabled = false;
        this.realPartyForm
          .get('email')
          .setValidators(Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL));
        this.realPartyForm
          .get('phoneNumber')
          // .setValidators(Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX));
          .setValidators(this.commonUtils.ValidatePhoneFax);
        this.realPartyForm
          .get('faxNumber')
          // .setValidators(Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX));
          .setValidators(this.commonUtils.ValidatePhoneFax);
        //this.realPartyForm.get('email').clearValidators();
        //this.realPartyForm.get('phoneNumber').clearValidators();
        //this.realPartyForm.get('country').clearValidators();
        this.realPartyForm.get('address1').clearValidators();
        this.realPartyForm.get('city').clearValidators();
        this.realPartyForm.get('state').clearValidators();
        this.realPartyForm.get('zip').clearValidators();
      }
      this.updateFormValidity();
    }
  }

  disableFields() {
    //this.realPartyForm.disable();
    this.realPartyForm.controls['firstName'].disable();
    this.realPartyForm.controls['lastName'].disable();
    this.realPartyForm.controls['extension'].disable();
    this.realPartyForm.controls['phoneNumber'].disable();
    this.realPartyForm.controls['faxNumber'].disable();
    this.realPartyForm.controls['country'].disable();
    this.realPartyForm.controls['address1'].disable();
    this.realPartyForm.controls['address2'].disable();
    this.realPartyForm.controls['city'].disable();
    this.realPartyForm.controls['state'].disable();
    this.realPartyForm.controls['zip'].disable();

    // this.realPartyForm.controls['proSe'].enable();
    // this.realPartyForm.controls['partyType'].enable();
    // this.realPartyForm.controls['findParty'].enable();
    // this.updateButton();
  }

  updateFormValidity() {
    this.realPartyForm.get('partyType').updateValueAndValidity();
    this.realPartyForm.get('proSe').updateValueAndValidity();
    this.realPartyForm.get('firstName').updateValueAndValidity();
    this.realPartyForm.get('lastName').updateValueAndValidity();
    this.realPartyForm.get('organizationName').updateValueAndValidity();
    this.realPartyForm.get('email').updateValueAndValidity();
    this.realPartyForm.get('phoneNumber').updateValueAndValidity();
    this.realPartyForm.get('extension').updateValueAndValidity();
    this.realPartyForm.get('faxNumber').updateValueAndValidity();
    this.realPartyForm.get('country').updateValueAndValidity();
    this.realPartyForm.get('address1').updateValueAndValidity();
    this.realPartyForm.get('address2').updateValueAndValidity();
    this.realPartyForm.get('city').updateValueAndValidity();
    this.realPartyForm.get('state').updateValueAndValidity();
    this.realPartyForm.get('zip').updateValueAndValidity();
  }

  clearForm() {
    if (this.updateMode) {
      if (
        (this.realPartyForm.dirty && !this.realPartyForm.pristine) ||
        this.lookupForChange
      ) {
        this.openWarningModal();
      } else {
        this.getExistingRealParty();
      }
    } else {
      this.resetForm();
    }
    this.realPartyForm.enable();
  }

  clearFindParty() {
    this.findParty = null;
  }

  resetForm() {
    this.realPartyForm.reset();
    this.realPartyForm.get('partyType').setValidators([Validators.required]);
    this.realPartyForm.get('proSe').setValidators([Validators.required]);
    this.realPartyForm.get('firstName').setValidators([Validators.required]);
    this.realPartyForm.get('lastName').setValidators([Validators.required]);
    this.realPartyForm
      .get('email')
      .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)]);
    this.realPartyForm
      .get('phoneNumber')
      // .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)]);
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    this.realPartyForm
      .get('faxNumber')
      // .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)]);
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    this.realPartyForm.get('organizationName').clearValidators();
    //this.realPartyForm.get('phoneNumber').clearValidators();
    this.realPartyForm.get('partyType').setValue('Individual');
    this.realPartyForm.get('proSe').setValue('No');
    this.updateFormValidity();
    this.logger.info('Real party form: ', this.realPartyForm);
    this.clearFindParty();
  }

  proseClearForm() {
    this.realPartyForm.reset();
    this.states = [];
    this.realPartyForm.get('partyType').setValidators([Validators.required]);
    this.realPartyForm.get('proSe').setValidators([Validators.required]);
    this.realPartyForm.get('firstName').setValidators([Validators.required]);
    this.realPartyForm.get('lastName').setValidators([Validators.required]);
    this.realPartyForm
      .get('email')
      .setValidators([Validators.pattern(CONSTANTS.VALIDATIONS.EMAIL)]);
    this.realPartyForm
      .get('phoneNumber')
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    this.realPartyForm
      .get('faxNumber')
      .setValidators([this.commonUtils.ValidatePhoneFax]);
    this.realPartyForm.get('organizationName').clearValidators();
    this.realPartyForm.get('partyType').setValue('Individual');
    this.realPartyForm.get('proSe').setValue('Yes');
    this.updateFormValidity();
    this.clearFindParty();
  }

  // resetOrgForm() {
  //   if (this.realPartyOrgForm.dirty && !this.realPartyOrgForm.pristine) {
  //     this.openWarningModal('org');
  //   } else if (this.updateMode) {
  //     this.setOrgForm(this.addRealPartyObj.parties[0]);
  //   }

  //   // if (this.updateMode) {
  //   //   this.setOrgForm(this.addRealPartyObj.parties[0]);
  //   // } else {
  //   //   this.realPartyOrgForm.reset();
  //   // }
  // }

  openMultipleModal(emailList) {
    const isFound = !emailList ? false : true;
    const title = !emailList
      ? 'Email not found'
      : 'Multiple email addresses found for registration number';
    const initialState: ModalOptions = {
      initialState: {
        emailList: emailList,
        emailSelected: false,
        selectedPetitioner: null,
        isFound: isFound,
        title: title,
      },
      class: 'modal-lg',
    };
    this.modalRef = this.modalService.show(
      MultipleEmailModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.emailSelected) {
        this.searchedForParty = true;
        this.setPetitioner(reason.initialState.selectedPetitioner);
      } else {
      }
    });
  }

  addRealParty() {
    this.addingPetitioner = true;
    //this.realPartyForm.disable();
    this.setObjForAddUpdate('add');
    this.logger.info('Real party obj: ', this.addRealPartyObj);
    this.initiatePetitionService
      .addRealParty(this.addRealPartyObj, this.realPartyForm.value.proSe)
      .pipe(take(1))
      .subscribe(
        (addRealPartySuccess) => {
          //this.realPartyForm.enable();
          this.commonUtils.showSuccess(
            'Real party added successfully',
            'Petitioner real party'
          );
          this.logger.info(
            'Real party added successfully',
            addRealPartySuccess
          );
          this.updateMode = true;
          // this.realPartyIndForm.controls.proSe.setValue('No');
          this.addRealPartyObj = addRealPartySuccess;
          // if (this.selectedPartyType === 'Individual') {
          //   // this.setIndForm(addRealPartySuccess.parties[0]);
          // } else {
          // }
          this.getExistingRealParty();
          this.checkProseForCounsel();
          if (this.realPartyForm.value.proSe === 'Yes') {
            this.addCounsel();
          }
          this.addingPetitioner = false;
          this.lookupForChange = false;
        },
        (addRealPartyFailure) => {
          this.logger.error('Add real party failure: ', addRealPartyFailure);
          this.commonUtils.showError(
            'Failed to add real party',
            'Petitioner real party'
          );
          this.addingPetitioner = false;
          this.realPartyForm.enable();
        }
      );
  }

  addCounsel() {
    const counselToAdd = this.setCounselObj('add');
    const isProSe = this.realPartyForm.value.proSe === 'Yes' ? 'Y' : 'N';
    this.logger.info('Counsel to add: ', counselToAdd);
    this.initiatePetitionService
      .addCounsel(counselToAdd, isProSe)
      .pipe(take(1))
      .subscribe(
        (addCounselSuccess) => {
          // this.commonUtils.showSuccess(
          //   'Successfully added counsel',
          //   'Add Counsel'
          // );
          // this.clearForm();
          // this.getExistingCounsels();
          this.getExistingCounsels();
        },
        (addCounselFailure) => {
          this.logger.error('Add counsel failed: ', addCounselFailure);
          this.commonUtils.showError(
            addCounselFailure.error.message,
            'Add Counsel'
          );
        }
      );
  }

  setCounselObj(actionType) {
    const counselToAddUpdate = new InterestedParty();
    // const isProSe = this.counselForm.value.proSe === 'Yes' ? 'Y' : 'N';
    counselToAddUpdate.caseNo = this.petitionInfo.proceedingNumberText;
    counselToAddUpdate.parties[0].submitterType = 'PETITIONER';
    counselToAddUpdate.parties[0].partyType = 'COUNSEL';
    counselToAddUpdate.parties[0].partySubType = 'PROSE';
    counselToAddUpdate.parties[0].proseIndicator =
      this.realPartyForm.value.proSe === 'Yes' ? 'Y' : 'N';
    //counselToAddUpdate.parties[0].registrationNo = this.counselForm.value.regNo;
    if (actionType == 'update') {
      counselToAddUpdate.parties[0].identifier = this.counselIdentifier;
      counselToAddUpdate.parties[0].personType[0].identifier =
        this.counselPartyIdentifier;
    }

    counselToAddUpdate.parties[0].personType[0].firstName =
      this.realPartyForm.getRawValue().firstName;
    counselToAddUpdate.parties[0].personType[0].lastName =
      this.realPartyForm.getRawValue().lastName;
    counselToAddUpdate.parties[0].personType[0].mailingAddress =
      this.addMailingAddress(this.realPartyForm.getRawValue());
    counselToAddUpdate.parties[0].personType[0].electronicAddress =
      this.addElectronicAddress(
        this.realPartyForm.getRawValue(),
        actionType,
        'COUNSEL'
      );
    counselToAddUpdate.parties[0].orgType = [];
    return counselToAddUpdate;
  }

  getCounselIdentifier() {
    if (this.counselList.length > 0) {
      this.counselList.forEach((element: any) => {
        //if(element.email == this.realPartyForm.value.findParty){
        this.counselIdentifier = element.counselInfo.identifier;
        this.counselPartyIdentifier =
          element.counselInfo.personType[0].identifier;
        // }
        this.savedCounsel = element.counselInfo;
      });
    }
  }

  setObjForAddUpdate(actionType) {
    this.addRealPartyObj.caseNo = this.petitionInfo.proceedingNumberText;
    // this.addRealPartyObj.caseNo = 'IPR2021-01322';
    this.addRealPartyObj.parties[0].partyType = 'REAL PARTY';
    this.addRealPartyObj.parties[0].submitterType = 'PETITIONER';
    this.addRealPartyObj.audit.lastModifiedUserIdentifier =
      window.sessionStorage.getItem('email');
    this.addRealPartyObj.audit.createUserIdentifier =
      window.sessionStorage.getItem('email');
    if (this.realPartyForm.value.partyType === 'Individual') {
      this.addRealPartyObj.parties[0].orgType = [];
      this.addRealPartyObj.parties[0].personType[0] = {
        firstName: this.realPartyForm.getRawValue().firstName,
        lastName: this.realPartyForm.getRawValue().lastName,
      };
      this.addRealPartyObj.parties[0].personType[0].mailingAddress =
        this.addMailingAddress(this.realPartyForm.getRawValue());
      this.addRealPartyObj.parties[0].personType[0].electronicAddress = [];
      this.addRealPartyObj.parties[0].personType[0].electronicAddress =
        this.addElectronicAddress(
          this.realPartyForm.getRawValue(),
          actionType,
          'REAL PARTY'
        );
      this.addRealPartyObj.parties[0].orgType = [];
      if (this.realPartyForm.value.proSe === 'Yes') {
        this.addRealPartyObj.parties[0].partySubType = 'PROSE';
        this.addRealPartyObj.parties[0].proseIndicator = 'Y';
      } else {
        this.addRealPartyObj.parties[0].partySubType = null;
        this.addRealPartyObj.parties[0].proseIndicator = 'N';
      }
      if (actionType === 'update') {
        this.addRealPartyObj.parties[0].identifier =
          this.savedRealParty.identifier;
        //! Changing from organization to individual
        if (
          this.selectedPartyType.toLowerCase() === 'organization' &&
          this.realPartyForm.value.partyType.toLowerCase() === 'individual'
        ) {
          if (this.savedRealParty.orgType.length > 0) {
            this.addRealPartyObj.parties[0].personType[0].identifier =
              this.savedRealParty.orgType[0].identifier;
            if (this.savedRealParty.orgType[0].orgAddress.length > 0) {
              this.addRealPartyObj.parties[0].personType[0].mailingAddress[0].identifier =
                this.savedRealParty.orgType[0].orgAddress[0].identifier;
            }
          }
        } else {
          if (this.savedRealParty.personType.length > 0) {
            this.addRealPartyObj.parties[0].personType[0].identifier =
              this.savedRealParty.personType[0].identifier;
            if (this.savedRealParty.personType[0].mailingAddress.length > 0) {
              this.addRealPartyObj.parties[0].personType[0].mailingAddress[0].identifier =
                this.savedRealParty.personType[0].mailingAddress[0].identifier;
            }
          }
        }
        // if (this.savedRealParty.personType.length > 0) {
        //   this.addRealPartyObj.parties[0].personType[0].identifier =
        //     this.savedRealParty.personType[0].identifier;
        //   if (this.savedRealParty.personType[0].mailingAddress.length > 0) {
        //     this.addRealPartyObj.parties[0].personType[0].mailingAddress[0].identifier =
        //       this.savedRealParty.personType[0].mailingAddress[0].identifier;
        //   }
        // }
      }
    } else {
      this.addRealPartyObj.parties[0].personType = [];
      this.addRealPartyObj.parties[0].orgType[0] = {
        legalname: this.realPartyForm.getRawValue().organizationName,
      };
      this.realPartyForm.controls.proSe.setValue('No');
      this.addRealPartyObj.parties[0].proseIndicator = 'N';
      this.addRealPartyObj.parties[0].orgType[0].orgAddress =
        this.addMailingAddress(this.realPartyForm.getRawValue());
      this.addRealPartyObj.parties[0].orgType[0].electronicAddress = [];
      this.addRealPartyObj.parties[0].orgType[0].electronicAddress =
        this.addElectronicAddress(
          this.realPartyForm.getRawValue(),
          actionType,
          'REAL PARTY'
        );
      this.addRealPartyObj.parties[0].personType = [];
      if (actionType === 'update') {
        this.addRealPartyObj.parties[0].identifier =
          this.savedRealParty.identifier;
        //! Changing from individual to organization
        if (
          this.selectedPartyType.toLowerCase() === 'individual' &&
          this.realPartyForm.value.partyType.toLowerCase() === 'organization'
        ) {
          if (this.savedRealParty.personType.length > 0) {
            this.addRealPartyObj.parties[0].orgType[0].identifier =
              this.savedRealParty.personType[0].identifier;
            if (this.savedRealParty.personType[0].mailingAddress.length > 0) {
              this.addRealPartyObj.parties[0].orgType[0].orgAddress[0].identifier =
                this.savedRealParty.personType[0].mailingAddress[0].identifier;
            }
          }
        } else {
          if (this.savedRealParty.orgType.length > 0) {
            this.addRealPartyObj.parties[0].orgType[0].identifier =
              this.savedRealParty.orgType[0].identifier;
            if (this.savedRealParty.orgType[0].orgAddress.length > 0) {
              this.addRealPartyObj.parties[0].orgType[0].orgAddress[0].identifier =
                this.savedRealParty.orgType[0].orgAddress[0].identifier;
            }
          }
        }
        // if (this.savedRealParty.orgType.length > 0) {
        //   this.addRealPartyObj.parties[0].orgType[0].identifier =
        //     this.savedRealParty.orgType[0].identifier;
        //   if (this.savedRealParty.orgType[0].orgAddress.length > 0) {
        //     this.addRealPartyObj.parties[0].orgType[0].orgAddress[0].identifier =
        //       this.savedRealParty.orgType[0].orgAddress[0].identifier;
        //   }
        // }
      }
    }
  }

  addMailingAddress(mailingAddressInfo) {
    const mailingAddress = {
      identifier: null,
      streetLineOneText: mailingAddressInfo.address1,
      streetLineTwoText: mailingAddressInfo.address2,
      city: mailingAddressInfo.city,
      state: mailingAddressInfo.state ? mailingAddressInfo.state.value : null,
      zipCode: mailingAddressInfo.zip,
      country: mailingAddressInfo.country
        ? mailingAddressInfo.country.value
        : null,
      addressType: 'RES',
    };
    const tempArr = [];
    tempArr.push(mailingAddress);
    return tempArr;
  }

  addElectronicAddress(electronicAddressInfo, actionType, partyType) {
    const tempArr = [];
    if (actionType === 'update') {
      const email = {
        email: electronicAddressInfo.email,
        emailType: 'WE',
        extention: null,
        identifier: null,
      };
      const phone = {
        extension: electronicAddressInfo.extension,
        identifier: null,
        teleCommAddresType: 'W',
        telephoneNumber: electronicAddressInfo.phoneNumber,
      };
      const fax = {
        extension: null,
        identifier: null,
        teleCommAddresType: 'F',
        fax: electronicAddressInfo.faxNumber,
      };
      if (
        this.realPartyForm.value.partyType === 'Individual' &&
        partyType === 'REAL PARTY'
      ) {
        if (
          this.savedRealParty?.personType?.length > 0 &&
          this.savedRealParty.personType[0].electronicAddress &&
          this.savedRealParty.personType[0].electronicAddress.length > 0
        ) {
          this.savedRealParty.personType[0].electronicAddress.forEach(
            (addressType) => {
              if (addressType.email) {
                email.identifier = addressType.identifier;
              }
              if (addressType.extension || addressType.telephoneNumber) {
                phone.identifier = addressType.identifier;
              }
              if (addressType.fax) {
                fax.identifier = addressType.identifier;
              }
            }
          );
        }
      } else if (
        this.realPartyForm.value.partyType === 'Individual' &&
        partyType === 'COUNSEL'
      ) {
        if (
          this.savedCounsel?.personType?.length > 0 &&
          this.savedCounsel.personType[0].electronicAddress &&
          this.savedCounsel.personType[0].electronicAddress.length > 0
        ) {
          this.savedCounsel.personType[0].electronicAddress.forEach(
            (addressType) => {
              if (addressType.email) {
                email.identifier = addressType.identifier;
              }
              if (addressType.extension || addressType.telephoneNumber) {
                phone.identifier = addressType.identifier;
              }
              if (addressType.fax) {
                fax.identifier = addressType.identifier;
              }
            }
          );
        }
      } else if (
        this.realPartyForm.value.partyType === 'Organization' &&
        partyType === 'REAL PARTY'
      ) {
        if (
          this.savedRealParty.orgType.length > 0 &&
          this.savedRealParty.orgType[0].electronicAddress &&
          this.savedRealParty.orgType[0].electronicAddress.length > 0
        ) {
          this.savedRealParty.orgType[0].electronicAddress.forEach(
            (addressType) => {
              if (addressType.email) {
                email.identifier = addressType.identifier;
              }
              if (addressType.extension || addressType.telephoneNumber) {
                phone.identifier = addressType.identifier;
              }
              if (addressType.fax) {
                fax.identifier = addressType.identifier;
              }
            }
          );
        }
      } else if (
        this.realPartyForm.value.partyType === 'Organization' &&
        partyType === 'COUNSEL'
      ) {
        if (
          this.savedCounsel.orgType.length > 0 &&
          this.savedCounsel.orgType[0].electronicAddress &&
          this.savedCounsel.orgType[0].electronicAddress.length > 0
        ) {
          this.savedCounsel.orgType[0].electronicAddress.forEach(
            (addressType) => {
              if (addressType.email) {
                email.identifier = addressType.identifier;
              }
              if (addressType.extension || addressType.telephoneNumber) {
                phone.identifier = addressType.identifier;
              }
              if (addressType.fax) {
                fax.identifier = addressType.identifier;
              }
            }
          );
        }
      }
      tempArr.push(email);
      tempArr.push(phone);
      tempArr.push(fax);
    } else {
      const electronicAddress = {
        identifier: null,
        teleCommAddressType: null,
        telephoneNumber: electronicAddressInfo.phoneNumber,
        email: electronicAddressInfo.email,
        emailType: this.selectedPartyType === 'Individual' ? 'PE' : 'WE',
        extension: electronicAddressInfo.extension,
        fax: electronicAddressInfo.faxNumber,
      };
      tempArr.push(electronicAddress);
    }
    return tempArr;
  }

  setForm(partyInfo, partyType) {
    this.resetForm();
    let foundCountry = null;
    if (partyType === 'org') {
      this.realPartyForm.get('firstName').clearValidators();
      this.realPartyForm.get('lastName').clearValidators();
      this.realPartyForm.get('proSe').setValue('No');
      this.realPartyForm.get('proSe').clearValidators();
      this.realPartyForm
        .get('organizationName')
        .setValidators([Validators.required]);
    }
    if (
      partyInfo.personType.length > 0 &&
      partyInfo.personType[0].mailingAddress.length > 0
    ) {
      if (
        partyType === 'ind' &&
        partyInfo.personType[0].mailingAddress[0].country
      ) {
        foundCountry = this.countries.find((country: any) => {
          return (
            country.value === partyInfo.personType[0].mailingAddress[0].country
          );
        });
      }
    } else if (
      partyInfo.orgType.length > 0 &&
      partyInfo.orgType[0].orgAddress.length > 0
    ) {
      if (partyType === 'org' && partyInfo.orgType[0].orgAddress[0].country) {
        foundCountry = this.countries.find((country: any) => {
          return country.value === partyInfo.orgType[0].orgAddress[0].country;
        });
      }
    }

    setTimeout(() => {
      let foundState = null;
      if (
        foundCountry &&
        partyType === 'ind' &&
        partyInfo.personType[0].mailingAddress[0].state &&
        this.states.length > 0
      ) {
        this.modifyStateReq(foundCountry.value);
        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            this.states = statesList;
            foundState = this.states.find((state: any) => {
              return (
                state.value === partyInfo.personType[0].mailingAddress[0].state
              );
            });
            this.realPartyForm.get('state').setValue(foundState);
          });
      } else if (
        foundCountry &&
        partyType === 'org' &&
        partyInfo.orgType[0].orgAddress[0].state &&
        this.states.length > 0
      ) {
        this.modifyStateReq(foundCountry.value);
        this.initiatePetitionService
          .getStates(foundCountry.value)
          .pipe(take(1))
          .subscribe((statesList) => {
            this.states = statesList;
            foundState = this.states.find((state: any) => {
              return state.value === partyInfo.orgType[0].orgAddress[0].state;
            });
            this.realPartyForm.get('state').setValue(foundState);
          });
      }
      this.realPartyForm
        .get('partyType')
        .setValue(partyType === 'ind' ? 'Individual' : 'Organization');

      this.realPartyForm.get('country').setValue(foundCountry);

      this.realPartyForm
        .get('proSe')
        .setValue(partyInfo.proseIndicator === 'Y' ? 'Yes' : 'No');
      if (partyType === 'ind') {
        // this.realPartyForm.get('proSe').setValue();
        this.realPartyForm
          .get('firstName')
          .setValue(partyInfo.personType[0].firstName, Validators.required);
        this.realPartyForm
          .get('lastName')
          .setValue(partyInfo.personType[0].lastName, Validators.required);
        partyInfo.personType[0].electronicAddress.forEach((element) => {
          if (element.extension) {
            this.realPartyForm.get('extension').setValue(element.extension);
          }
          if (this.realPartyForm.value.proSe === 'Yes') {
            this.realPartyForm.get('phoneNumber').setValidators([
              // Validators.required,
              // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
              this.commonUtils.ValidatePhoneFax,
            ]);
            if (element.telephoneNumber) {
              this.realPartyForm
                .get('phoneNumber')
                .setValue(element.telephoneNumber);
            }
          } else {
            if (element.telephoneNumber) {
              this.realPartyForm.get('phoneNumber').setValue(
                element.telephoneNumber,
                // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)
                this.commonUtils.ValidatePhoneFax
              );
            }
          }

          if (element.fax) {
            this.realPartyForm.get('faxNumber').setValue(element.fax);
          }
          if (element.email) {
            this.realPartyForm.get('email').setValue(element.email);
          }
        });
        if (partyInfo.personType[0].mailingAddress.length > 0) {
          this.realPartyForm
            .get('address1')
            .setValue(
              partyInfo.personType[0].mailingAddress[0].streetLineOneText.trim()
            );
          this.realPartyForm
            .get('address2')
            .setValue(
              partyInfo.personType[0].mailingAddress[0].streetLineTwoText
            );
          this.realPartyForm
            .get('city')
            .setValue(partyInfo.personType[0].mailingAddress[0].city.trim());
          this.realPartyForm
            .get('zip')
            .setValue(partyInfo.personType[0].mailingAddress[0].zipCode);
        }
      } else if (partyType === 'org') {
        this.realPartyForm
          .get('organizationName')
          .setValue(partyInfo.orgType[0].legalname);
        if (
          partyInfo.orgType[0].electronicAddress &&
          partyInfo.orgType[0].electronicAddress.length > 0
        ) {
          partyInfo.orgType[0].electronicAddress.forEach((element) => {
            if (element.extension) {
              this.realPartyForm.get('extension').setValue(element.extension);
            }
            if (element.telephoneNumber) {
              this.realPartyForm.get('phoneNumber').setValue(
                element.telephoneNumber,
                // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX)
                this.commonUtils.ValidatePhoneFax
              );
            }
            if (element.fax) {
              this.realPartyForm.get('faxNumber').setValue(element.fax);
            }
            if (element.email) {
              this.realPartyForm.get('email').setValue(element.email);
            }
          });

          // this.realPartyForm
          //   .get('email')
          //   .setValue(partyInfo.orgType[0].electronicAddress[0].email);
          // this.realPartyForm
          //   .get('phoneNumber')
          //   .setValue(
          //     partyInfo.orgType[0].electronicAddress[0].telephoneNumber
          //   );
          // this.realPartyForm
          //   .get('extension')
          //   .setValue(partyInfo.orgType[0].electronicAddress[0].extension);
          // this.realPartyForm
          //   .get('faxNumber')
          //   .setValue(partyInfo.orgType[0].electronicAddress[0].fax);
        } else {
          this.realPartyForm.get('email').setValue('');
          this.realPartyForm
            .get('phoneNumber')
            // .setValue('', Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX));
            .setValue('', this.commonUtils.ValidatePhoneFax);
          this.realPartyForm.get('extension').setValue('');
          this.realPartyForm.get('faxNumber').setValue('');
        }
        if (
          partyInfo.orgType[0].orgAddress &&
          partyInfo.orgType[0].orgAddress.length > 0
        ) {
          if (partyInfo.orgType[0].orgAddress[0].streetLineOneText) {
            this.realPartyForm
              .get('address1')
              .setValue(
                partyInfo.orgType[0].orgAddress[0].streetLineOneText.trim()
              );
          }
          if (partyInfo.orgType[0].orgAddress[0].streetLineTwoText) {
            this.realPartyForm
              .get('address2')
              .setValue(partyInfo.orgType[0].orgAddress[0].streetLineTwoText);
          }
          if (partyInfo.orgType[0].orgAddress[0].city) {
            this.realPartyForm
              .get('city')
              .setValue(partyInfo.orgType[0].orgAddress[0].city.trim());
          }
          if (partyInfo.orgType[0].orgAddress[0].zipCode) {
            this.realPartyForm
              .get('zip')
              .setValue(partyInfo.orgType[0].orgAddress[0].zipCode);
          }
        }
      }
      // this.changePartyTypes(partyType);
      this.realPartyForm.markAsPristine();
      this.updateFormValidity();

      // this.realPartyForm = this.fb.group({
      //   proSe: ['No', Validators.required],
      //   findParty: [''],
      //   firstName: [partyInfo.personType[0].firstName, Validators.required],
      //   lastName: [partyInfo.personType[0].lastName, Validators.required],
      //   email: [partyInfo.personType[0].electronicAddress[0].email],
      //   phoneNumber: [
      //     partyInfo.personType[0].electronicAddress[0].telephoneNumber,
      //   ],
      //   extension: [partyInfo.personType[0].electronicAddress[0].extension],
      //   faxNumber: [partyInfo.personType[0].electronicAddress[0].fax],
      //   country: [foundCountry],
      //   address1: [partyInfo.personType[0].mailingAddress[0].streetLineOneText],
      //   address2: [partyInfo.personType[0].mailingAddress[0].streetLineTwoText],
      //   city: [partyInfo.personType[0].mailingAddress[0].city],
      //   state: [foundState],
      //   zip: [partyInfo.personType[0].mailingAddress[0].zipCode],
      // });
      // this.realPartyForm.markAsPristine();

      // this.realPartyOrgForm = this.fb.group({
      //   organizationName: ['', Validators.required],
      //   email: [partyInfo.personType[0].electronicAddress[0].email],
      //   phoneNumber: [
      //     partyInfo.personType[0].electronicAddress[0].telephoneNumber,
      //   ],
      //   extension: [partyInfo.personType[0].electronicAddress[0].extension],
      //   faxNumber: [partyInfo.personType[0].electronicAddress[0].fax],
      //   country: [foundCountry],
      //   address1: [partyInfo.personType[0].mailingAddress[0].streetLineOneText],
      //   address2: [partyInfo.personType[0].mailingAddress[0].streetLineTwoText],
      //   city: [partyInfo.personType[0].mailingAddress[0].city],
      //   state: [foundState],
      //   zip: [partyInfo.personType[0].mailingAddress[0].zipCode],
      // });
      // this.realPartyForm = this.fb.group({
      //   organizationName: ['', Validators.required],
      //   email: [''],
      //   phoneNumber: [''],
      //   extension: [''],
      //   faxNumber: [''],
      //   country: [''],
      //   address1: [''],
      //   address2: [''],
      //   city: [''],
      //   state: [''],
      //   zip: [''],
      // });
    }, 400);

    // this.realPartyIndForm.controls.firstName.setValue(
    //   partyInfo.personType[0].firstName
    // );
    // this.realPartyIndForm.controls.lastName.setValue(
    //   partyInfo.personType[0].lastName
    // );
    // this.realPartyIndForm.controls.email.setValue(
    //   partyInfo.personType[0].electronicAddress[0].email
    // );
    // this.realPartyIndForm.controls.phoneNumber.setValue(
    //   partyInfo.personType[0].electronicAddress[0].telephoneNumber
    // );
    // this.realPartyIndForm.controls.extension.setValue(
    //   partyInfo.personType[0].electronicAddress[0].extension
    // );
    // this.realPartyIndForm.controls.faxNumber.setValue(
    //   partyInfo.personType[0].electronicAddress[0].fax
    // );
    // this.realPartyIndForm.controls.address1.setValue(
    //   partyInfo.personType[0].mailingAddress[0].streetLineOneText
    // );
    // this.realPartyIndForm.controls.address2.setValue(
    //   partyInfo.personType[0].mailingAddress[0].streetLineTwoText
    // );
    // this.realPartyIndForm.controls.city.setValue(
    //   partyInfo.personType[0].mailingAddress[0].city
    // );
    // this.realPartyIndForm.controls.zip.setValue(
    //   partyInfo.personType[0].mailingAddress[0].zipCode
    // );
    // let foundCountry = this.countries.find((country: any) => {
    //   return (
    //     country.value === partyInfo.personType[0].mailingAddress[0].country
    //   );
    // });
    // this.realPartyIndForm.controls.country.setValue(foundCountry);
    // this.getStates(partyInfo.personType[0].mailingAddress[0].country);
    // setTimeout(() => {
    //   let foundState = this.states.find((state: any) => {
    //     return state.value === partyInfo.personType[0].mailingAddress[0].state;
    //   });
    //   this.realPartyIndForm.controls.state.setValue(foundState);
    // }, 200);
  }

  // setOrgForm(partyInfo) {
  //   this.getStates(partyInfo.orgType[0].orgAddress[0].country);
  //   const foundCountry = this.countries.find((country: any) => {
  //     return country.value === partyInfo.orgType[0].orgAddress[0].country;
  //   });

  //   setTimeout(() => {
  //     const foundState = this.states.find((state: any) => {
  //       return state.value === partyInfo.orgType[0].orgAddress[0].state;
  //     });
  //     // this.realPartyIndForm = this.fb.group({
  //     //   firstName: [''],
  //     //   lastName: [''],
  //     //   email: [partyInfo.orgType[0].electronicAddress[0].email],
  //     //   phoneNumber: [
  //     //     partyInfo.orgType[0].electronicAddress[0].telephoneNumber,
  //     //   ],
  //     //   extension: [partyInfo.orgType[0].electronicAddress[0].extension],
  //     //   faxNumber: [partyInfo.orgType[0].electronicAddress[0].fax],
  //     //   country: [foundCountry],
  //     //   address1: [partyInfo.orgType[0].orgAddress[0].streetLineOneText],
  //     //   address2: [partyInfo.orgType[0].orgAddress[0].streetLineTwoText],
  //     //   city: [partyInfo.orgType[0].orgAddress[0].city],
  //     //   state: [foundState],
  //     //   zip: [partyInfo.orgType[0].orgAddress[0].zipCode],
  //     // });

  //     this.realPartyIndForm = this.fb.group({
  //       proSe: ['No', Validators.required],
  //       findParty: [''],
  //       firstName: ['', Validators.required],
  //       lastName: ['', Validators.required],
  //       email: [''],
  //       phoneNumber: [''],
  //       extension: [''],
  //       faxNumber: [''],
  //       country: [''],
  //       address1: [''],
  //       address2: [''],
  //       city: [''],
  //       state: [''],
  //       zip: [''],
  //     });

  //     this.realPartyOrgForm = this.fb.group({
  //       organizationName: [partyInfo.orgType[0].legalName, Validators.required],
  //       email: [partyInfo.orgType[0].electronicAddress[0].email],
  //       phoneNumber: [
  //         partyInfo.orgType[0].electronicAddress[0].telephoneNumber,
  //       ],
  //       extension: [partyInfo.orgType[0].electronicAddress[0].extension],
  //       faxNumber: [partyInfo.orgType[0].electronicAddress[0].fax],
  //       country: [foundCountry],
  //       address1: [partyInfo.orgType[0].orgAddress[0].streetLineOneText],
  //       address2: [partyInfo.orgType[0].orgAddress[0].streetLineTwoText],
  //       city: [partyInfo.orgType[0].orgAddress[0].city],
  //       state: [foundState],
  //       zip: [partyInfo.orgType[0].orgAddress[0].zipCode],
  //     });
  //   }, 200);
  //   // this.realPartyOrgForm.controls.organizationName.setValue(
  //   //   partyInfo.orgType[0].legalname
  //   // );
  //   // this.realPartyOrgForm.controls.email.setValue(
  //   //   partyInfo.orgType[0].electronicAddress[0].email
  //   // );
  //   // this.realPartyOrgForm.controls.phoneNumber.setValue(
  //   //   partyInfo.orgType[0].electronicAddress[0].telephoneNumber
  //   // );
  //   // this.realPartyOrgForm.controls.extension.setValue(
  //   //   partyInfo.orgType[0].electronicAddress[0].extension
  //   // );
  //   // this.realPartyOrgForm.controls.faxNumber.setValue(
  //   //   partyInfo.orgType[0].electronicAddress[0].fax
  //   // );
  //   // this.realPartyOrgForm.controls.address1.setValue(
  //   //   partyInfo.orgType[0].orgAddress[0].streetLineOneText
  //   // );
  //   // this.realPartyOrgForm.controls.address2.setValue(
  //   //   partyInfo.orgType[0].orgAddress[0].streetLineTwoText
  //   // );
  //   // this.realPartyOrgForm.controls.city.setValue(
  //   //   partyInfo.orgType[0].orgAddress[0].city
  //   // );
  //   // this.realPartyOrgForm.controls.zip.setValue(
  //   //   partyInfo.orgType[0].orgAddress[0].zipCode
  //   // );
  //   // let foundCountry = this.countries.find((country: any) => {
  //   //   return country.value === partyInfo.orgType[0].orgAddress[0].country;
  //   // });
  //   // this.realPartyOrgForm.controls.country.setValue(foundCountry);
  //   // this.getStates(partyInfo.orgType[0].orgAddress[0].country);
  //   // setTimeout(() => {
  //   //   let foundState = this.states.find((state: any) => {
  //   //     return state.value === partyInfo.orgType[0].orgAddress[0].state;
  //   //   });
  //   //   this.realPartyOrgForm.controls.state.setValue(foundState);
  //   // }, 200);
  // }

  updateRealParty() {
    this.setObjForAddUpdate('update');

    this.logger.info('Real party obj for update: ', this.addRealPartyObj);
    this.initiatePetitionService
      .updateRealParty(this.addRealPartyObj)
      .pipe(take(1))
      .subscribe(
        (addRealPartySuccess) => {
          this.commonUtils.showSuccess(
            'Real party updated successfully',
            'Petitioner real party'
          );
          this.logger.info(
            'Real party updated successfully',
            addRealPartySuccess
          );
          this.updateMode = true;
          // this.realPartyIndForm.controls.proSe.setValue('No');
          this.addRealPartyObj = addRealPartySuccess;
          this.getExistingRealParty();
          this.getExistingCounsels();
          // if (this.selectedPartyType === 'Individual') {
          //   this.setForm(addRealPartySuccess.parties[0], 'ind');
          // } else {
          //   this.setForm(addRealPartySuccess.parties[0], 'org');
          // }
          this.checkProseForCounsel();

          if (this.realPartyForm.value.proSe === 'Yes') {
            if (this.counselList.length > 0) {
              this.getCounselIdentifier();
              if (this.counselIdentifier && this.counselPartyIdentifier) {
                this.updateCounsel();
              } else {
                this.addCounsel();
              }
            } else {
              this.addCounsel();
            }
          }
          this.proseWarning = false;
          this.lookupForChange = false;
        },
        (addRealPartyFailure) => {
          this.logger.error('Update real party failure: ', addRealPartyFailure);
          this.commonUtils.showError(
            'Failed to update real party',
            'Petitioner real party'
          );
        }
      );
  }

  updateCounsel() {
    const counselToUpdate = this.setCounselObj('update');
    this.initiatePetitionService
      .updateCounsel(counselToUpdate)
      .pipe(take(1))
      .subscribe(
        (counselUpdate) => {
          // this.commonUtils.showSuccess(
          //   'Successfully updated counsel information',
          //   'Update Counsel'
          // );
          // //this.editMode = false;
          // this.clearForm();
          this.getExistingCounsels();
        },
        (counselUpdateFailure) => {
          this.logger.error('Counsel update failed', counselUpdateFailure);
          this.commonUtils.showError(
            counselUpdateFailure.error.message,
            'Update Counsel'
          );
        }
      );
  }

  openWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'You have document information that has not been saved to the docket. Your changes will be lost',
          'Are you sure you want to clear the changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        // if (partyType === 'ind') {
        if (this.updateMode) {
          // this.setIndForm(this.addRealPartyObj.parties[0]);
          this.getExistingRealParty();
        } else {
          this.resetForm();
          // this.realPartyIndForm.reset();
          // this.realPartyIndForm.controls.proSe.setValue('No');
        }
        // }
        this.lookupForChange = false;
      } else {
      }
    });
  }

  continue() {
    // if (
    //   !this.realPartyForm.valid ||
    //   (this.realPartyForm.touched && !this.realPartyForm.pristine)
    // ) {
    //   this.openContinueWarningModal();
    // } else {
    //   this.initiatePetitionService.setOption('realPartyComplete', true);
    //   this.initiatePetitionService.setOption('realPartyInComplete', false);
    //   this.router.navigate(['/initiate-petition/additional-real-party']);
    //   //this.checkProSe();
    // }

    this.router.navigate(['/ui/initiate-petition/additional-real-party']);
  }

  checkProSe() {
    if (this.realPartyForm.value.proSe === 'Yes') {
      this.initiatePetitionService.setOption('prose', true);
      this.initiatePetitionService.setOption('proseFlag', true);
      this.initiatePetitionService.setOption('noticePaperType', true);
      this.initiatePetitionService.setOption('noNoticePaperType', false);
      this.router.navigate(['/ui/initiate-petition/review']);
    } else {
      this.initiatePetitionService.setOption('prose', false);
      this.initiatePetitionService.setOption('proseFlag', false);
      if (this.verificationFlag.hasAttorneyPaperType) {
        this.initiatePetitionService.setOption('noticePaperType', true);
        this.initiatePetitionService.setOption('noNoticePaperType', false);
      } else {
        this.initiatePetitionService.setOption('noticePaperType', false);
        this.initiatePetitionService.setOption('noNoticePaperType', true);
      }
      this.router.navigate(['/ui/initiate-petition/additional-real-party']);
    }
  }

  openContinueWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Performing this action will exit the current screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        if (this.savedRealParty) {
          this.initiatePetitionService.setOption('realPartyInComplete', false);
          this.initiatePetitionService.setOption('realPartyComplete', true);
        } else {
          this.initiatePetitionService.setOption('realPartyInComplete', true);
          this.initiatePetitionService.setOption('realPartyComplete', false);
        }
        this.router.navigate(['/ui/initiate-petition/additional-real-party']);
        //this.checkProSe();
      } else {
      }
    });
  }

  getExistingCounsels() {
    this.loading = true;
    this.initiatePetitionService
      .getCounsels(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (existingCounsels) => {
          this.counselList = existingCounsels;
          this.loading = false;
        },
        () => {
          this.loading = false;
        }
      );
  }

  checkCounsel() {
    if (
      this.savedRealParty &&
      this.savedRealParty.proseIndicator == 'N' &&
      this.counselList.length > 0
    ) {
      this.proseWarning = true;
      this.realPartyForm.get('proSe').setValue('No');
    } else {
      this.proseWarning = false;
    }
  }

  closeWarning() {
    this.proseWarning = false;
  }

  checkProseForCounsel() {
    if (this.realPartyForm.value.proSe === 'Yes') {
      this.initiatePetitionService.setOption('prose', true);
      this.initiatePetitionService.setOption('proseFlag', true);
      this.initiatePetitionService.setOption('noticePaperType', true);
      this.initiatePetitionService.setOption('noNoticePaperType', false);
    } else {
      this.initiatePetitionService.setOption('prose', false);
      this.initiatePetitionService.setOption('proseFlag', false);
      if (this.verificationFlag.hasAttorneyPaperType) {
        this.initiatePetitionService.setOption('noticePaperType', true);
        this.initiatePetitionService.setOption('noNoticePaperType', false);
      } else {
        this.initiatePetitionService.setOption('noticePaperType', false);
        this.initiatePetitionService.setOption('noNoticePaperType', true);
      }
    }
  }

  updateButton() {
    if (this.realPartyForm.value.proSe === 'Yes') {
      this.realPartyForm.get('phoneNumber').setValidators([
        // Validators.required,
        // Validators.pattern(CONSTANTS.VALIDATIONS.PHONE_FAX),
        this.commonUtils.ValidatePhoneFax,
      ]);
    }
    this.realPartyForm.get('country').setValidators([Validators.required]);
    // this.realPartyForm.get('address1').setValidators([Validators.required]);
    // this.realPartyForm.get('city').setValidators([Validators.required]);
    this.realPartyForm.get('state').setValidators([Validators.required]);
    // this.realPartyForm.get('zip').setValidators([Validators.required]);
    this.updateFormValidity();
  }

  onKeyUp(x) {
    if (x.code === 'Enter' || x.code === 'NumpadEnter') {
      this.findByRegOrEmail(this.findParty);
    }
  }

  checkForm() {
    this.logger.info(this.realPartyForm);
  }
}
