import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InitiatePetitionComponent } from './initiate-petition.component';

describe('InitiatePetitionComponent', () => {
  let component: InitiatePetitionComponent;
  let fixture: ComponentFixture<InitiatePetitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InitiatePetitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiatePetitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
