import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  NgForm,
  Validators,
} from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../initiate-petition.service';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  changeLoading,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { CONSTANTS } from 'src/app/constants/constants';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { DeleteModalComponent } from './delete-modal/delete-modal.component';
import { Router } from '@angular/router';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { PetitionDocument } from 'src/app/models/documents/PetitionDocument.model';
import { EditDocument } from 'src/app/models/documents/EditDocument.model';
import { PublicAvailabilityModalComponent } from 'src/app/components/common/public-availability-modal/public-availability-modal.component';
import { MyDocketService } from '../../my-docket/my-docket.services';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { __values } from 'tslib';

@Component({
  selector: 'app-petition-documents',
  templateUrl: './petition-documents.component.html',
  styleUrls: ['./petition-documents.component.scss'],
})
export class PetitionDocumentsComponent implements OnInit {
  // petitionDocumentForm = new FormGroup({
  //   docType: new FormControl('Paper'),
  //   selectedPaper: new FormControl(''),
  //   selectedAvailability: new FormControl(''),
  //   documentName: new FormControl(''),
  //   selectedFile: new FormControl(''),
  //   fileName: new FormControl(''),
  // });

  // petitionDocumentForm = this.fb.group({
  //   docType: ['Paper', Validators.required],
  //   selectedPaper: [''],
  //   selectedAvailability: ['', Validators.required],
  //   documentName: ['', Validators.required],
  //   selectedFile: [''],
  //   fileName: ['', Validators.required],
  //   exhibitNumber: [''],
  //   editMode: [false],
  // });
  modalRef: BsModalRef;
  publicModalRef: BsModalRef;
  petitionDocumentForm: FormGroup;
  paperTypes: Array<any> = [];
  availabilities: Array<any> = [];
  selectedPaperType: any = '';
  selectedDocType: any = 'Paper';
  selectedAvailability: any = null;
  documentName: any = null;
  fileName: string = null;
  fileToUpload: any = null;
  addedPaperList: Array<any> = [];
  minExhibitNumber: number = 1000;
  proceedingNumber: string = null;
  fileTypes: string = CONSTANTS.PAPER_FILE_TYPES;

  editMode: boolean = false;
  editIndex: number = null;
  petitionInfo: any = {};
  petitionIdentifier: string = null;
  showMultiplePaperTypeError: boolean = false;
  partyRep: any;
  petitionPaperType: boolean = false;
  noticePaperType: boolean = false;
  verificationFlag: any;
  componentName: string = 'documents';
  onBehalfOf: string = null;
  addingToList: boolean = false;
  selectedPaperNew: null;

  constructor(
    public initiatePetitionService: InitiatePetitionService,
    private logger: NGXLogger,
    public commonUtils: CommonUtilitiesService,
    private myDocketService: MyDocketService,
    private fb: FormBuilder,
    private store: Store<PtactsState>,
    private modalService: BsModalService,
    private router: Router,
    private caseViewerService: CaseViewerService
  ) {
    this.petitionDocumentForm = this.fb.group({
      docType: [{ value: 'Paper', disabled: false }, Validators.required],
      selectedPaper: ['', Validators.required],
      selectedAvailability: ['', Validators.required],
      documentName: ['', Validators.required],
      selectedFile: [''],
      fileName: [{ value: '', disabled: false }, Validators.required],
      exhibitNumber: [''],
      editMode: [false],
    });
  }

  ngOnInit(): void {
    //! To get user info when coming from internal application
    const prefix = 'fromInternal';
    if (window.name.substring(0, prefix.length) === prefix) {
      const data = JSON.parse(atob(window.name.substring(prefix.length)));
      if (!window.sessionStorage.getItem('petitionInfo')) {
        if (data?.proceedingNumberText) {
          this.petitionInfo = {
            proceedingNumberText: data?.proceedingNumberText,
            serialNo: data?.serialNo,
            trialType: data?.trialType,
          };
          window.sessionStorage.setItem(
            'petitionInfo',
            JSON.stringify(this.petitionInfo)
          );
        }
      }

      window.sessionStorage.setItem('userInfo', JSON.stringify(data));
      //  this.store.dispatch(
      //    setUserIdAction({
      //      payload: `${data.lastName}, ${data.firstName}`,
      //    })
      //  );
      window.sessionStorage.setItem('email', data.emailId);
      window.sessionStorage.setItem(
        'onBehalfOf',
        `${data.lastName}, ${data.firstName} (${data.emailId})`
      );
      if (data.cfkPatronId) {
        window.sessionStorage.setItem('cfkPatronId', data.cfkPatronId);
      }
    }

    this.getAvailabilities();
    // this.petitionInfo = window.sessionStorage.getItem('petitionInfo');
    // if (this.petitionInfo) {
    //   this.petitionInfo = JSON.parse(
    //     window.sessionStorage.getItem('petitionInfo')
    //   );
    // }
    if (window.sessionStorage.getItem('petitionInfo')) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.getPetitionIdentifier();
    this.getPaperTypes();
    this.getNextExhibitNumber();
    this.getDocuments();
    // this.store
    //   .select(PtactsSelectors.ptactsStateData)
    //   .pipe(take(1))
    //   .subscribe((savedState) => {
    //     this.proceedingNumber = savedState.newPetitionInfo.proceedingNumberText;
    //     this.getPaperTypes();
    //     this.getNextExhibitNumber();
    //   });
    this.getPartyRepresenting();
    this.verificationFlag = this.initiatePetitionService.getOption();
  }

  getPartyRepresenting() {
    this.caseViewerService
      .getPartyRepresenting(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (partyRepresenting) => {
          if (partyRepresenting.toLowerCase() === 'patentowner') {
            partyRepresenting = 'PATENT OWNER';
          }
          this.partyRep = partyRepresenting;
          if (this.partyRep == '') {
            this.partyRep = 'PETITIONER';
          }
        },
        (noPartyRepresentingFound) => {}
      );
  }

  getPetitionIdentifier() {
    this.initiatePetitionService
      .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
      });
  }

  addDocument(petitionDocumentForm: NgForm) {}

  getDocuments() {
    this.initiatePetitionService
      .getUnsubmittedDocuments(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (petitionDocumentList) => {
          if (!this.editMode) {
            this.getNextExhibitNumber();
          }
          this.logger.info('Petition documents list', petitionDocumentList);
          this.addedPaperList = petitionDocumentList;
          this.addedPaperList.forEach((element) => {
            if (element.filingDate) {
              // element.filingDateString = this.commonUtils.convertDateToString(
              //   element.filingDate
              // );
              element.filingDateString = this.commonUtils.setEST(
                element.filingDate
              );
            }
          });
        },
        (failure) => {
          this.addedPaperList = [];
        }
      );
  }

  getPaperTypes() {
    if (this.petitionInfo && this.petitionInfo.proceedingNumberText) {
      this.initiatePetitionService
        .getPaperTypes(
          CONSTANTS.TYPE_CODES.DOCUMENT_TYPES,
          this.petitionInfo.proceedingNumberText,
          CONSTANTS.PARTIES.PETITIONER
        )
        .pipe(take(1))
        .subscribe((paperTypes) => {
          paperTypes.forEach((element) => {
            element.displayNameText = element.displayNameText
              .split(':')
              .map((item) => item.trim());
            element.displayNameText =
              element.displayNameText[0] + ' : ' + element.displayNameText[1];
          });

          this.paperTypes = this.commonUtils.sortAlphabetically(
            paperTypes,
            'displayNameText'
          );
          this.logger.info('Paper types: ', this.paperTypes);
        });
    }
  }

  getAvailabilities() {
    this.initiatePetitionService
      .getAvailabilities('availability', true)
      .pipe(take(1))
      .subscribe((availabilities) => {
        this.availabilities = availabilities;
        // this.petitionDocumentForm.controls.selectedAvailability.setValue(
        //   this.availabilities[0]
        // );
        this.logger.info('Availabilities: ', this.availabilities);
      });
  }

  setDocumentName(paperType) {
    this.logger.info('Selected document: ', paperType);
    this.documentName = paperType.displayNameText;
    this.petitionDocumentForm.controls.documentName.setValue(
      paperType.displayNameText
    );
  }

  getNextExhibitNumber() {
    // this.jpviewService.getTrialsInfo(`${PtabTrialConstants.TRIAL_SERVICES_URL}/proceeding-party-details/exhibit-sequences?proceedingNumber=${this.documentUploadObj.proceedingNumberText}`).subscribe((exhibitSequenceResponse) => {
    if (this.petitionInfo && this.petitionInfo.proceedingNumberText) {
      this.initiatePetitionService
        .getNextExhibitNumber(this.petitionInfo.proceedingNumberText)
        .pipe(take(1))
        .subscribe((exhibitSequenceResponse) => {
          this.minExhibitNumber = exhibitSequenceResponse;
          this.petitionDocumentForm.controls.exhibitNumber.setValue(
            exhibitSequenceResponse.petitionerExhibitSequence
          );
        });
    }
  }

  setUploadType(uploadType) {
    if (uploadType === 'paper') {
      this.petitionDocumentForm
        .get('selectedPaper')
        .setValidators([Validators.required]);
      this.petitionDocumentForm.get('exhibitNumber').clearValidators();
      this.fileTypes = CONSTANTS.PAPER_FILE_TYPES;
    } else {
      this.petitionDocumentForm
        .get('exhibitNumber')
        .setValidators([Validators.required]);
      this.petitionDocumentForm.get('selectedPaper').clearValidators();
      this.fileTypes = CONSTANTS.EXHIBIT_FILE_TYPES;
    }
    this.petitionDocumentForm.get('exhibitNumber').updateValueAndValidity();
    this.petitionDocumentForm.get('selectedPaper').updateValueAndValidity();
  }

  fileChange(event) {
    this.logger.info('File info: ', event);

    if (this.petitionDocumentForm.controls.selectedFile == undefined) {
      this.petitionDocumentForm = this.fb.group({
        docType: [
          this.petitionDocumentForm.value.docType.toLowerCase() === 'paper'
            ? 'Paper'
            : 'Exhibit',
          Validators.required,
        ],
        selectedPaper: [this.selectedPaperType?.displayNameText],
        selectedAvailability: [
          this.petitionDocumentForm.value.selectedAvailability,
          Validators.required,
        ],
        documentName: [
          this.petitionDocumentForm.value.documentName,
          Validators.required,
        ],
        selectedFile: [''],
        fileName: ['', Validators.required],
        exhibitNumber: [this.petitionDocumentForm.value.exhibitNumber],
        editMode: [false],
      });
    }
    this.petitionDocumentForm.controls.selectedFile.setValue(
      event.target.files[0]
    );
    this.petitionDocumentForm.controls.fileName.setValue(
      event.target.files[0].name
    );
    // this.fileToUpload = event.target.files[0];
    // this.fileName = event.target.files[0].name;
  }

  validateAdd() {
    if (
      this.selectedDocType &&
      this.selectedPaperType &&
      this.documentName &&
      this.fileName &&
      this.selectedAvailability
    ) {
      return false;
    } else {
      return true;
    }
  }

  checkAvailability(action) {
    if (
      this.petitionDocumentForm.value.selectedAvailability.code.toLowerCase() ===
      CONSTANTS.AVAILABILITY_CODE.PUBLIC
    ) {
      this.openPublicAvailabilityModal(action);
    } else {
      action === 'add' ? this.addToList() : this.updateDocumentInfo();
    }
  }

  openPublicAvailabilityModal(action) {
    const initialState: ModalOptions = {
      initialState: {
        keepPublic: false,
      },
      class: 'modal-lg',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.publicModalRef = this.modalService.show(
      PublicAvailabilityModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.publicModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.keepPublic) {
        action === 'add' ? this.addToList() : this.updateDocumentInfo();
      }
    });
  }

  addToList() {
    if (this.checkForMulitplePaperType()) {
      this.addingToList = true;
      this.initiatePetitionService
        .addToList(
          this.petitionDocumentForm.value.selectedFile,
          this.petitionDocumentForm.value.docType,
          this.petitionIdentifier
        )
        .pipe(take(1))
        .subscribe(
          (fileAdded) => {
            this.logger.info('Added file: ', fileAdded);
            this.logger.info('Document form: ', this.petitionDocumentForm);

            let petitionDocument = null;
            if (
              this.petitionDocumentForm.value.docType.toLowerCase() === 'paper'
            ) {
              petitionDocument = new PetitionDocument(
                this.petitionDocumentForm.value.docType.toUpperCase(),
                this.petitionDocumentForm.value.documentName,
                this.petitionDocumentForm.value.selectedFile.name,
                this.partyRep,
                this.petitionDocumentForm.value.selectedAvailability.code,
                this.selectedPaperType.identifier,
                this.selectedPaperType.code,
                this.petitionDocumentForm.value.selectedFile.type,
                null,
                'N',
                null
              );
            } else {
              petitionDocument = new PetitionDocument(
                // 'EXHIBITS',
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.petitionDocumentForm.value.documentName,
                this.petitionDocumentForm.value.selectedFile.name,
                this.partyRep,
                this.petitionDocumentForm.value.selectedAvailability.code,
                null,
                CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase(),
                this.petitionDocumentForm.value.selectedFile.type,
                this.petitionDocumentForm.value.exhibitNumber,
                'N',
                null
              );
            }

            const documentToAdd = new DocumentToAdd(petitionDocument);
            documentToAdd.proceedingNumberText =
              this.petitionInfo.proceedingNumberText;
            this.logger.info('New document to add:', documentToAdd);

            this.petitionDocumentForm.disable();

            this.saveDocumentToCMS(documentToAdd);

            // // const nextExhibitNumber =
            // //   this.petitionDocumentForm.value.exhibitNumber;
            // // const wasExhibit =
            // //   this.petitionDocumentForm.value.docType === 'Exhibit';

            // this.selectedDocType = null;
            // this.selectedPaperType = null;
            // this.documentName = null;
            // this.selectedAvailability = null;
            // // this.clearForm();
            // this.clearFile();

            // // if (wasExhibit) {
            // //   this.getNextExhibitNumber();
            // //   // this.minExhibitNumber = nextExhibitNumber;
            // //   // this.petitionDocumentForm.controls.exhibitNumber.setValue(
            // //   //   nextExhibitNumber
            // //   // );
            // // }
            // this.clearForm(false);
            // this.addingToList = false;
          },
          (addToListFailure) => {
            // this.logger.error('Adding file failed: ', fileAddFailure);
            this.addingToList = false;
            this.commonUtils.throwError(
              `Add to list failed for Create Petition`,
              addToListFailure
            );
          }
        );
    } else {
      this.showMultiplePaperTypeError = true;
    }
  }

  checkForMulitplePaperType() {
    this.showMultiplePaperTypeError = false;
    let ableToAddPaper = true;
    if (this.addedPaperList.length <= 0) {
      return ableToAddPaper;
    } else {
      this.addedPaperList.forEach((addedPaper) => {
        if (
          this.selectedPaperType?.identifier === CONSTANTS.DUPLICATE_DOCUMENT_ID
        ) {
          if (
            addedPaper.documentTypeIdentifier ===
            this.selectedPaperType.identifier
          ) {
            ableToAddPaper = false;
          }
        }
      });
      return ableToAddPaper;
    }
  }

  saveDocumentToCMS(documentToAdd) {
    this.initiatePetitionService
      .saveToCMS(documentToAdd)
      .pipe(take(1))
      .subscribe(
        (saveSuccessful) => {
          // const nextExhibitNumber =
          //   this.petitionDocumentForm.value.exhibitNumber;
          // const wasExhibit =
          //   this.petitionDocumentForm.value.docType === 'Exhibit';
          this.petitionDocumentForm.enable();

          this.selectedDocType = null;
          this.selectedPaperType = null;
          this.documentName = null;
          this.selectedAvailability = null;
          // this.clearForm();
          this.clearFile();

          // if (wasExhibit) {
          //   this.getNextExhibitNumber();
          //   // this.minExhibitNumber = nextExhibitNumber;
          //   // this.petitionDocumentForm.controls.exhibitNumber.setValue(
          //   //   nextExhibitNumber
          //   // );
          // }
          this.clearForm(false);
          this.addingToList = false;
          this.logger.info('Saved document to CMS', saveSuccessful);
          this.commonUtils.showSuccess(
            'Successfully added document.',
            'Document upload'
          );
          this.getDocuments();
        },
        (documentSaveFailed) => {
          // this.logger.error(
          //   'Failed to save document to CMS',
          //   documentSaveFailed
          // );
          // this.commonUtils.showError(
          //   documentSaveFailed.error.message,
          //   'Add document'
          // );
          this.addingToList = false;
          this.petitionDocumentForm.enable();
          this.commonUtils.throwError(
            `Save document failed for Create Petition`,
            documentSaveFailed
          );
        }
      );
  }

  clearFile() {
    if (!this.editMode) {
      const fileEl = <HTMLInputElement>document.getElementById('file');
      if (fileEl) {
        fileEl.value = '';
      }
      this.petitionDocumentForm.controls.fileName.setValue('');
      this.fileName = null;
    }
  }

  clearForm(getNextExhibitNo) {
    this.petitionDocumentForm.reset();
    this.petitionDocumentForm.controls.docType.setValue('Paper');
    this.petitionDocumentForm.controls.selectedAvailability.setValue('');
    // this.petitionDocumentForm.controls.exhibitNumber.setValue(
    //   this.minExhibitNumber
    // );
    if (getNextExhibitNo) {
      this.getNextExhibitNumber();
    }
    this.clearFile();
    this.editMode = false;
    //this.disableNav(false);
    this.selectedPaperType = '';
    this.showMultiplePaperTypeError = false;
  }

  onPaperTypeSelect(event) {
    // this.petitionDocumentForm.controls.documentName.setValue(
    //   event.item.displayNameText
    // );
    // this.selectedPaperType = event.item;
    // this.logger.info('Selected Paper type', this.selectedPaperType);
    this.petitionDocumentForm.controls.documentName.setValue(
      event.displayNameText
    );
    this.petitionDocumentForm.controls.selectedPaper.setValue(event);
    this.selectedPaperType = event;
    this.selectedPaperNew = event;
    this.logger.info('Selected Paper type', this.selectedPaperType);
  }

  edit(documentToEdit, index) {
    this.editMode = true;
    this.editIndex = index;
    // this.petitionDocumentForm = new FormGroup({
    //   docType: new FormControl({ value: document.docType, disabled: true }),
    //   selectedPaper: new FormControl(document.selectedPaper),
    //   selectedAvailability: new FormControl(
    //     document.selectedAvailability,
    //     Validators.required
    //   ),
    //   documentName: new FormControl(
    //     { value: document.documentName, disabled: true },
    //     Validators.required
    //   ),
    //   selectedFile: new FormControl(document.selectedFile),
    //   fileName: new FormControl(
    //     document.selectedFile.name,
    //     Validators.required
    //   ),
    //   exhibitNumber: new FormControl(document.docNumber),
    //   editMode: new FormControl(true),
    // });
    let paperDisplayName = '';
    if (documentToEdit.category.toLowerCase() === 'paper') {
      const foundPaper = this.paperTypes.find((paper: any) => {
        return paper.identifier === documentToEdit.documentTypeIdentifier;
      });
      this.selectedPaperType = foundPaper;
      paperDisplayName = foundPaper.displayNameText
        ? foundPaper.displayNameText
        : '';
    }
    const foundAvailability = this.availabilities.find((availability: any) => {
      return availability.displayNameText === documentToEdit.availability;
    });
    this.petitionDocumentForm = this.fb.group({
      docType: [
        documentToEdit.category.toLowerCase() === 'paper' ? 'Paper' : 'Exhibit',
        Validators.required,
      ],
      selectedPaper: [paperDisplayName],
      selectedAvailability: [foundAvailability, Validators.required],
      documentName: [documentToEdit.name, Validators.required],
      // selectedFile: [documentToEdit.selectedFile],
      fileName: [documentToEdit.fileName, Validators.required],
      exhibitNumber: [documentToEdit.exhibitNumber],
      editMode: [true],
    });

    let fileElems = document.getElementsByClassName('petitionDocumentFile');

    // document.getElementById('file').disabled = true;
    //this.disableNav(true);
    // (
    //   document.getElementById('documentWithdrawPetition') as HTMLButtonElement
    // ).disabled = true;
    // (
    //   document.getElementById('documentContinue') as HTMLButtonElement
    // ).disabled = true;
    // this.petitionDocumentForm.updateValueAndValidity();
    // this.petitionDocumentForm.controls.docType.disable();
    // this.petitionDocumentForm.controls.documentName.disable();
  }

  updateDocumentInfo() {
    let foundPaperId = null;
    if (
      this.addedPaperList[this.editIndex].category.toLowerCase() === 'paper'
    ) {
      const foundPaper = this.paperTypes.find((paper: any) => {
        return (
          // paper.descriptionText === this.petitionDocumentForm.value.selectedPaper
          paper.identifier === this.selectedPaperType.identifier
        );
      });
      foundPaperId = foundPaper.identifier;
    }
    const originalDoc = this.addedPaperList[this.editIndex];
    originalDoc.paperType = this.petitionDocumentForm.value.selectedPaper
      ? this.petitionDocumentForm.value.selectedPaper
      : originalDoc.paperType;
    if (originalDoc.paperType == undefined) {
      // originalDoc.category =
      //   originalDoc.artifactSummary.code.toLowerCase() === 'exhibits'
      //     ? 'EXHIBITS'
      //     : originalDoc.artifactSummary.code;
      originalDoc.category = originalDoc.artifactSummary.code
        .toLowerCase()
        .includes(CONSTANTS.DOC_TYPE.EXHIBIT)
        ? CONSTANTS.DOC_TYPE.EXHIBIT.toUpperCase()
        : originalDoc.artifactSummary.code;
    }
    originalDoc.documentTypeIdentifier = foundPaperId;
    originalDoc.availability =
      this.petitionDocumentForm.value.selectedAvailability.code;
    originalDoc.documentName = this.petitionDocumentForm.value.documentName;
    originalDoc.proceedingNumberText = this.petitionInfo.proceedingNumberText;
    originalDoc.exhibitNumber = this.petitionDocumentForm.value.exhibitNumber
      ? this.petitionDocumentForm.value.exhibitNumber
      : originalDoc.exhibitNumber;
    const docToEdit = new EditDocument(originalDoc);
    this.logger.info('Document to edit:', docToEdit);
    this.initiatePetitionService
      .updateDocument(docToEdit, docToEdit.artifactIdentifer)
      .pipe(take(1))
      .subscribe(
        (editDocumentResponse) => {
          this.getDocuments();
          this.logger.info(
            'Successfully updated document',
            editDocumentResponse
          );
          this.commonUtils.showSuccess(
            'Successfully updated document',
            'Update document'
          );
          this.getDocuments();
          this.clearForm(false);
          (
            document.getElementById(
              'documentWithdrawPetition'
            ) as HTMLButtonElement
          ).disabled = false;
          (
            document.getElementById('documentContinue') as HTMLButtonElement
          ).disabled = false;
        },
        (editDocumentFailure) => {
          this.logger.error('Failed updating document', editDocumentFailure);
          this.commonUtils.showError(
            editDocumentFailure.error.message,
            'Update document'
          );
          this.getDocuments();
        }
      );

    //
    // this.addedPaperList[this.editIndex].paperType = this.petitionDocumentForm
    //   .value.selectedPaper
    //   ? this.petitionDocumentForm.value.selectedPaper
    //   : this.addedPaperList[this.editIndex].paperType;
    // this.addedPaperList[this.editIndex].availability =
    //   this.petitionDocumentForm.value.selectedAvailability.displayNameText;
    // this.addedPaperList[this.editIndex].documentName =
    //   this.petitionDocumentForm.value.documentName;
    // this.cancelEdit();
  }

  disableNav(ea) {
    if (ea) {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.add('navdisabled');
    } else {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.remove('navdisabled');
    }
  }

  cancelEdit() {
    this.editMode = false;
    (
      document.getElementById('documentWithdrawPetition') as HTMLButtonElement
    ).disabled = false;
    (
      document.getElementById('documentContinue') as HTMLButtonElement
    ).disabled = false;
    //this.disableNav(false);
    this.clearForm(true);
  }

  verifyDelete(documentToDelete) {
    const initialState: ModalOptions = {
      initialState: {
        deleteDocument: false,
      },
    };
    this.modalRef = this.modalService.show(DeleteModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.deleteDocument) {
        // this.addedPaperList.splice(index, 1);
        this.deleteDocument(documentToDelete.artifactIdentifer);
      }
    });
  }

  deleteDocument(artifactIdentifer) {
    this.initiatePetitionService
      .deleteDocument(artifactIdentifer)
      .pipe(take(1))
      .subscribe(
        (deleteDocumentSuccess) => {
          this.logger.info(
            'Document deleted successfully',
            deleteDocumentSuccess
          );
          this.commonUtils.showSuccess(
            'Document deleted successfully',
            'Delete document'
          );
          this.getDocuments();
        },
        (deleteDocumentFailure) => {
          this.logger.error('Failed to delete document', deleteDocumentFailure);
          this.commonUtils.showError(
            deleteDocumentFailure.error.message,
            'Delete document'
          );
        }
      );
  }

  continue() {
    if (
      (this.petitionDocumentForm.value.documentName &&
        this.addedPaperList.length != 0) ||
      this.addedPaperList.length != 0
    ) {
      this.checkPaperTypes();
      // if (this.petitionPaperType && this.noticePaperType) {
      //   this.initiatePetitionService.setOption('documentsComplete', true);
      //   this.initiatePetitionService.setOption('documentsInComplete', false);
      // } else {
      //   this.initiatePetitionService.setOption('documentsComplete', false);
      //   this.initiatePetitionService.setOption('documentsInComplete', true);
      // }
      //this.status();
      this.router.navigate(['/ui/initiate-petition/real-party']);
    } else {
      //this.openWarningModal();
      this.router.navigate(['/ui/initiate-petition/real-party']);
    }
  }

  checkPaperTypes() {
    if (this.addedPaperList.length != 0) {
      for (let i = 0; i < this.addedPaperList.length; i++) {
        if (
          this.addedPaperList[i].documentTypeDescription == 'Petition: as filed'
        ) {
          this.initiatePetitionService.setOption('petitionPaperType', true);
          this.initiatePetitionService.setOption('noPetitionPaperType', false);
          break;
        } else {
          this.initiatePetitionService.setOption('noPetitionPaperType', true);
          this.initiatePetitionService.setOption('petitionPaperType', false);
        }
      }

      for (let i = 0; i < this.addedPaperList.length; i++) {
        if (
          this.addedPaperList[i].documentTypeDescription ==
          'Notice:  Power of Attorney'
        ) {
          this.initiatePetitionService.setOption('noNoticePaperType', false);
          this.initiatePetitionService.setOption('noticePaperType', true);
          this.initiatePetitionService.setOption('hasAttorneyPaperType', true);
          break;
        } else {
          this.initiatePetitionService.setOption('noNoticePaperType', true);
          this.initiatePetitionService.setOption('noticePaperType', false);
          this.initiatePetitionService.setOption('hasAttorneyPaperType', false);
        }
      }
    }
    if (this.verificationFlag.proseFlag) {
      this.initiatePetitionService.setOption('noNoticePaperType', false);
      this.initiatePetitionService.setOption('noticePaperType', true);
    }
  }

  openWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Performing this action will exit the current screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        this.initiatePetitionService.setOption('noPetitionPaperType', true);
        this.initiatePetitionService.setOption('noNoticePaperType', true);
        this.initiatePetitionService.setOption('petitionPaperType', false);
        this.initiatePetitionService.setOption('noticePaperType', false);
        this.router.navigate(['/ui/initiate-petition/real-party']);
      } else {
      }
    });
  }

  openPdf(data) {
    this.myDocketService.openPdf(
      this.petitionIdentifier,
      data.artifactIdentifer
    );
    // .pipe(take(1))
    // .subscribe(
    //   (pdfResponse) => {
    //     this.commonUtils.openPdfNew(pdfResponse);
    //   },
    //   (pdfResponseError) => {
    //     this.logger.error('Failed to open PDF', pdfResponseError);
    //   }
    // );
  }

  clearSelection() {
    this.showMultiplePaperTypeError = false;
    this.petitionDocumentForm
      .get('selectedPaper')
      .setValue('', Validators.required);

    this.petitionDocumentForm
      .get('documentName')
      .setValue('', Validators.required);
  }

  checkForm() {
    console.log(this.petitionDocumentForm);
  }
}
