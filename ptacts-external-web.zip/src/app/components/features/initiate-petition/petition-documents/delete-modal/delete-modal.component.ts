import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.scss'],
})
export class DeleteModalComponent implements OnInit {
  modalData = this.modalService.config.initialState;

  constructor(
    public modalRef: BsModalRef,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {}

  closeModal(deleteDocument) {
   
   
    this.modalService.config.initialState.deleteDocument = deleteDocument;
    // this.modalService.hide();
    this.modalRef.hide();
  }
}
