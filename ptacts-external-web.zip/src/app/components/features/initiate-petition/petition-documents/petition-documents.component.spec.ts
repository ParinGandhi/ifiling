import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PetitionDocumentsComponent } from './petition-documents.component';

describe('PetitionDocumentsComponent', () => {
  let component: PetitionDocumentsComponent;
  let fixture: ComponentFixture<PetitionDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PetitionDocumentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PetitionDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
