import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsIpComponent } from './documents-ip.component';

describe('DocumentsIpComponent', () => {
  let component: DocumentsIpComponent;
  let fixture: ComponentFixture<DocumentsIpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentsIpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsIpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
