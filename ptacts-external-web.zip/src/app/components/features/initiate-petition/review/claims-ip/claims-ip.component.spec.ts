import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsIpComponent } from './claims-ip.component';

describe('ClaimsIpComponent', () => {
  let component: ClaimsIpComponent;
  let fixture: ComponentFixture<ClaimsIpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimsIpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsIpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
