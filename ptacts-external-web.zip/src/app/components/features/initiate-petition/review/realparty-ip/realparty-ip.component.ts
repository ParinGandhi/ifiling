import { Component, Input, OnInit } from '@angular/core';
import { CaseViewerService } from '../../../case-viewer/case-viewer.service';

@Component({
  selector: 'app-realparty-ip',
  templateUrl: './realparty-ip.component.html',
  styleUrls: ['./realparty-ip.component.scss'],
})
export class RealpartyIpComponent implements OnInit {
  @Input() realPartyList: Array<any> = [];
  @Input() addedRealPartyList: Array<any> = [];
  petitionInfo: any = null;
  realPartyInfo: any;
  poRealPartyInfo: any;

  lastRefresh = new Date();
  refreshSort: boolean;
  counter: number = 0;
  // realPartyList: Array<any> = [];
  // addedRealPartyList: Array<any> = [];
  tempAddedRealPartyList: Array<any> = [];
  obj = {};
  streetLineOneText = '';
  streetLineTwoText = '';
  city = '';
  state = '';
  zip = '';
  addr = '';
  email = '';
  fax = '';
  phone = '';
  telephoneNumber = '';
  extension = '';
  country = '';
  identifier = '';
  partyIdentifier = '';
  mailingAddressIdentifier = '';
  phoneIdentifier = '';
  emailIdentifier = '';
  faxIdentifier = '';

  constructor(private caseViewerService: CaseViewerService) {}

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
  //   setTimeout(() => {
  //   this.getRealPartyInfo();
  // }, 500);
  }

  // refresh(val) {
  //   this.refreshSort = val;
  //   this.getRealPartyInfo();
  //   this.lastRefresh = new Date();
  // }

  // getRealPartyInfo() {
  //   this.realPartyList = [];
  //   this.addedRealPartyList = [];
  //   this.tempAddedRealPartyList = this.partyInfo.petitionRealParty.parties;
  //   this.setList();
  //   // this.caseViewerService
  //   //   .getCounselInfo(this.petitionInfo.proceedingNumberText)
  //   //   .subscribe((data) => {
  //   //     this.realPartyList = [];
  //   //     this.addedRealPartyList = [];
  //   //     this.tempAddedRealPartyList = data.petitionRealParty.parties;
  //   //     this.setList();
  //   //     // if (data.petitionRealParty && data.petitionRealParty.parties.length > 0) {
  //   //     //   data.petitionRealParty.parties.forEach(element => {
  //   //     //     if(element.partyType == "REAL PARTY"){
  //   //     //       this.realPartyList.push(element)
  //   //     //     }
  //   //     //     if(element.partyType == "ADD REAL PARTY"){
  //   //     //       this.addedRealPartyList.push(element)
  //   //     //     }
  //   //     //   });
  //   //     // }
  //   //   });
  // }

  // setList() {
  //   this.tempAddedRealPartyList.forEach((element) => {
  //     if (element.orgType.length > 0) {
  //       this.clearObject();
  //       this.identifier = element.identifier;
  //       element.orgType.forEach((ele) => {
  //         this.partyIdentifier = ele.identifier;
  //         if (
  //           ele.orgAddress &&
  //           ele.orgAddress.length > 0 &&
  //           ele.orgAddress[0].streetLineOneText
  //         ) {
  //           this.mailingAddressIdentifier = ele.orgAddress[0].identifier;
  //           this.addr = ele.orgAddress[0].streetLineOneText;
  //           this.streetLineOneText = ele.orgAddress[0].streetLineOneText;
  //           if (
  //             ele.orgAddress[0].streetLineTwoText &&
  //             ele.orgAddress[0].streetLineTwoText.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr =
  //                 this.addr + ', ' + ele.orgAddress[0].streetLineTwoText;
  //             } else {
  //               this.addr = ele.orgAddress[0].streetLineTwoText;
  //             }
  //             this.streetLineTwoText = ele.orgAddress[0].streetLineTwoText;
  //           }
  //           if (ele.orgAddress[0].city && ele.orgAddress[0].city.trim()) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.orgAddress[0].city;
  //             } else {
  //               this.addr = ele.orgAddress[0].city;
  //             }
  //             this.city = ele.orgAddress[0].city;
  //           }
  //           if (ele.orgAddress[0].state && ele.orgAddress[0].state.trim()) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.orgAddress[0].state;
  //             } else {
  //               this.addr = ele.orgAddress[0].state;
  //             }
  //             this.state = ele.orgAddress[0].state;
  //           }
  //           if (ele.orgAddress[0].zipCode && ele.orgAddress[0].zipCode.trim()) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.orgAddress[0].zipCode;
  //             } else {
  //               this.addr = ele.orgAddress[0].zipCode;
  //             }
  //             this.zip = ele.orgAddress[0].zipCode;
  //           }
  //           if (ele.orgAddress[0].country && ele.orgAddress[0].country.trim()) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.orgAddress[0].country;
  //             } else {
  //               this.addr = ele.orgAddress[0].country;
  //             }
  //             this.country = ele.orgAddress[0].country;
  //           }
  //         }
  //         if (ele.electronicAddress.length > 0) {
  //           for (var i = 0; i < ele.electronicAddress.length; i++) {
  //             if (ele.electronicAddress[i].telephoneNumber) {
  //               this.phone = ele.electronicAddress[i].telephoneNumber;
  //               this.telephoneNumber = ele.electronicAddress[i].telephoneNumber;
  //               this.phoneIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //             if (ele.electronicAddress[i].extension) {
  //               this.phone =
  //                 this.phone + ' ext: ' + ele.electronicAddress[i].extension;
  //               this.extension = ele.electronicAddress[i].extension;
  //             }
  //             if (ele.electronicAddress[i].email) {
  //               this.email = ele.electronicAddress[i].email;
  //               this.emailIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //             if (ele.electronicAddress[i].fax) {
  //               this.fax = ele.electronicAddress[i].fax;
  //               this.faxIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //           }
  //         }
  //         this.obj = {
  //           firstName: ele.firstName,
  //           lastName: ele.lastName,
  //           email: this.email,
  //           phone: this.phone,
  //           extension: this.extension,
  //           fax: this.fax,
  //           country: this.country,
  //           streetLineOneText: this.streetLineOneText,
  //           streetLineTwoText: this.streetLineTwoText,
  //           city: this.city,
  //           state: this.state,
  //           zip: this.zip,
  //           name: ele.legalname,
  //           type: 'Organization',
  //           address: this.addr,
  //           telephoneNumber: this.telephoneNumber,
  //           identifier: this.identifier,
  //           partyIdentifier: this.partyIdentifier,
  //           mailingAddressIdentifier: this.mailingAddressIdentifier,
  //           phoneIdentifier: this.phoneIdentifier,
  //           emailIdentifier: this.emailIdentifier,
  //           faxIdentifier: this.faxIdentifier,
  //         };
  //       });
  //       if (element.partyType == 'REAL PARTY') {
  //         this.realPartyList.push(this.obj);
  //       }
  //       if (element.partyType == 'ADD REAL PARTY') {
  //         this.addedRealPartyList.push(this.obj);
  //       }
  //     }
  //     if (element.personType.length > 0) {
  //       this.clearObject();
  //       this.identifier = element.identifier;
  //       element.personType.forEach((ele) => {
  //         this.partyIdentifier = ele.identifier;
  //         if (
  //           ele.mailingAddress &&
  //           ele.mailingAddress.length > 0 &&
  //           ele.mailingAddress[0].streetLineOneText
  //         ) {
  //           this.mailingAddressIdentifier = ele.mailingAddress[0].identifier;
  //           this.addr = ele.mailingAddress[0].streetLineOneText;
  //           this.streetLineOneText = ele.mailingAddress[0].streetLineOneText;
  //           if (
  //             ele.mailingAddress[0].streetLineTwoText &&
  //             ele.mailingAddress[0].streetLineTwoText.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr =
  //                 this.addr + ', ' + ele.mailingAddress[0].streetLineTwoText;
  //             } else {
  //               this.addr = ele.mailingAddress[0].streetLineTwoText;
  //             }
  //             this.streetLineTwoText = ele.mailingAddress[0].streetLineTwoText;
  //           }
  //           if (
  //             ele.mailingAddress[0].city &&
  //             ele.mailingAddress[0].city.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.mailingAddress[0].city;
  //             } else {
  //               this.addr = ele.mailingAddress[0].city;
  //             }
  //             this.city = ele.mailingAddress[0].city;
  //           }
  //           if (
  //             ele.mailingAddress[0].state &&
  //             ele.mailingAddress[0].state.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.mailingAddress[0].state;
  //             } else {
  //               this.addr = ele.mailingAddress[0].state;
  //             }
  //             this.state = ele.mailingAddress[0].state;
  //           }
  //           if (
  //             ele.mailingAddress[0].zipCode &&
  //             ele.mailingAddress[0].zipCode.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.mailingAddress[0].zipCode;
  //             } else {
  //               this.addr = ele.mailingAddress[0].zipCode;
  //             }
  //             this.zip = ele.mailingAddress[0].zipCode;
  //           }
  //           if (
  //             ele.mailingAddress[0].country &&
  //             ele.mailingAddress[0].country.trim()
  //           ) {
  //             if (this.addr && this.addr.trim()) {
  //               this.addr = this.addr + ', ' + ele.mailingAddress[0].country;
  //             } else {
  //               this.addr = ele.mailingAddress[0].country;
  //             }
  //             this.country = ele.mailingAddress[0].country;
  //           }
  //         }

  //         if (ele.electronicAddress.length > 0) {
  //           for (var i = 0; i < ele.electronicAddress.length; i++) {
  //             if (ele.electronicAddress[i].telephoneNumber) {
  //               this.phone = ele.electronicAddress[i].telephoneNumber;
  //               this.telephoneNumber = ele.electronicAddress[i].telephoneNumber;
  //               this.phoneIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //             if (ele.electronicAddress[i].extension) {
  //               this.phone =
  //                 this.phone + ' ext: ' + ele.electronicAddress[i].extension;
  //               this.extension = ele.electronicAddress[i].extension;
  //             }
  //             if (ele.electronicAddress[i].email) {
  //               this.email = ele.electronicAddress[i].email;
  //               this.emailIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //             if (ele.electronicAddress[i].fax) {
  //               this.fax = ele.electronicAddress[i].fax;
  //               this.faxIdentifier = ele.electronicAddress[i].identifier;
  //             }
  //           }
  //         }
  //         this.obj = {
  //           firstName: ele.firstName,
  //           lastName: ele.lastName,
  //           email: this.email,
  //           phone: this.phone,
  //           extension: this.extension,
  //           fax: this.fax,
  //           country: this.country,
  //           streetLineOneText: this.streetLineOneText,
  //           streetLineTwoText: this.streetLineTwoText,
  //           city: this.city,
  //           state: this.state,
  //           zip: this.zip,
  //           name: ele.firstName + ' ' + ele.lastName,
  //           type: 'Individual',
  //           address: this.addr,
  //           telephoneNumber: this.telephoneNumber,
  //           identifier: this.identifier,
  //           partyIdentifier: this.partyIdentifier,
  //           mailingAddressIdentifier: this.mailingAddressIdentifier,
  //           phoneIdentifier: this.phoneIdentifier,
  //           emailIdentifier: this.emailIdentifier,
  //           faxIdentifier: this.faxIdentifier,
  //         };
  //       });
  //       if (element.partyType == 'REAL PARTY') {
  //         this.realPartyList.push(this.obj);
  //       }
  //       if (element.partyType == 'ADD REAL PARTY') {
  //         this.addedRealPartyList.push(this.obj);
  //       }
  //     }
  //   });
  // }

  // clearObject() {
  //   this.obj = {};
  //   this.streetLineOneText = '';
  //   this.streetLineTwoText = '';
  //   this.city = '';
  //   this.state = '';
  //   this.zip = '';
  //   this.addr = '';
  //   this.email = '';
  //   this.fax = '';
  //   this.phone = '';
  //   this.telephoneNumber = '';
  //   this.extension = '';
  //   this.country = '';
  //   this.identifier = '';
  //   this.partyIdentifier = '';
  //   this.mailingAddressIdentifier = '';
  //   this.phoneIdentifier = '';
  //   this.emailIdentifier = '';
  //   this.faxIdentifier = '';
  // }
}
