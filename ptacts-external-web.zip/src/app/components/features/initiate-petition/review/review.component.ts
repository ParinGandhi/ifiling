import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InfoModalComponent } from 'src/app/components/common/info-modal/info-modal.component';
import { CaseSearchModel } from 'src/app/models/common/CaseSearch.model';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { MandatoryNoticeService } from '../../mandatory-notice/mandatory-notice.service';
import { InitiatePetitionService } from '../initiate-petition.service';
import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { getPetitionIdentifier } from 'src/app/store/ptacts/ptacts.actions';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.scss'],
})
export class ReviewComponent implements OnInit {
  submitWithoutPayModalRef: BsModalRef;
  petitionInfo: any = null;
  caseInfo: any = null;
  ptactsCaseInfo: any = null;
  caseType: string = 'OTHER';
  caseStatus: any = null;
  verificationFlag: any;
  enable: boolean = true;
  petitionDocObj: any = null;
  addedPaperList: any;
  obj: {
    artifactIdentifer: any;
    artifactSubmissionIdentifier: any;
    documentTypeIdentifier: any;
    category: any;
    exhibitNumber?: any;
  };
  verificationObj: CaseSearchModel;
  patentNumber: any;
  petitionPaperType: boolean = false;
  noticePaperType: boolean = false;
  petitionIdentifier: any;
  onBehalfOf: string = null;
  paymentData: any;
  paymentStatus: boolean;
  showButtons: boolean = true;
  fromInternal: boolean = false;
  componentName: string = 'review';
  petitionStatus = {
    successful: false,
    unsuccessful: false,
  };
  partyInfo: any;
  counselInfo: any;
  petitionerCounsel: any;
  poCounsel: any;
  totalLabel: string;
  numberOfMotionPhv: number;
  paymentInfoObj: any[];
  partyObj = {};
  streetLineOneText = '';
  streetLineTwoText = '';
  city = '';
  state = '';
  zip = '';
  addr = '';
  email = '';
  fax = '';
  phone = '';
  telephoneNumber = '';
  extension = '';
  country = '';
  identifier = '';
  partyIdentifier = '';
  mailingAddressIdentifier = '';
  phoneIdentifier = '';
  emailIdentifier = '';
  faxIdentifier = '';
  realPartyList: any[];
  addedRealPartyList: any[];
  tempAddedRealPartyList: any;
  loading: boolean;
  numberOfTimesGetPaymentInfoCalled: number = 0;
  numberOfTimesActuallyGetPaymentInfoCalled: number = 0;

  constructor(
    private mandatoryNoticeService: MandatoryNoticeService,
    private logger: NGXLogger,
    private caseViewerService: CaseViewerService,
    public initiatePetitionServices: InitiatePetitionService,
    private commonUtils: CommonUtilitiesService,
    private router: Router,
    private modalService: BsModalService,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    if (window.sessionStorage.getItem('source')) {
      this.fromInternal = true;
    }
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    if (this.petitionInfo.petitionerApplDetails) {
      this.patentNumber = this.petitionInfo.petitionerApplDetails.patentNumber;
    } else if (this.petitionInfo.patentNumber) {
      this.patentNumber = this.petitionInfo.patentNumber;
    }
    this.tabValidations();
    this.getPartiesInfo();
    this.getCaseHeaderInfo();
    this.getCaseStatus();
    this.getPetitionIdentifier();

    (this.petitionDocObj = {
      audit: {
        createUserIdentifier: null,
        lastModifiedUserIdentifier: null,
      },
      proceedingNumberText: null,
      petitionDocuments: [],
    }),
      this.getDocuments();
    this.verifyPetition();
    this.submitButtonStatus();
  }

  verifyPetition() {
    this.initiatePetitionServices
      .getGeneralInfo(this.patentNumber, 'patentNumber')
      .pipe(take(1))
      .subscribe(
        (patentVerifiedResponse) => {
          this.caseInfo = patentVerifiedResponse;
        },
        (patentVerifiedFailed) => {
          this.logger.error(
            'Patent verification failed:',
            patentVerifiedFailed
          );
        }
      );
  }

  getCaseHeaderInfo() {
    this.caseViewerService
      .getCaseHeaderInfo(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseHeaderResponse) => {
        this.ptactsCaseInfo = caseHeaderResponse[0];

        this.caseType = this.ptactsCaseInfo.proceedingNumber.substring(0, 3);
      });
  }

  getCaseStatus() {
    this.caseViewerService
      .getCaseStatus(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseStatus) => {
        this.caseStatus = caseStatus[caseStatus.length - 1];
      });
  }

  expandCollapse(isExpand) {
    let sections = document.getElementsByClassName(
      'caseviewerSection'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const tag of Array.from(sections)) {
      if (isExpand) {
        tag.classList.add('show');
      } else {
        tag.classList.remove('show');
      }
    }

    let sectionButtons = document.getElementsByClassName(
      'caseviewerSectionBtn'
    ) as HTMLCollectionOf<HTMLLinkElement>;
    for (const btn of Array.from(sectionButtons)) {
      if (isExpand) {
        btn.classList.remove('collapsed');
        btn.setAttribute('aria-expanded', 'true');
      } else {
        btn.classList.add('collapsed');
        btn.setAttribute('aria-expanded', 'false');
      }
    }
  }

  submitButtonStatus() {
    this.verificationFlag = this.initiatePetitionServices.getOption();
    let size = 0;
    for (let k in this.verificationFlag) {
      size++;
      this.initiatePetitionServices.setOption('fpngCancel', false);
    }
    if (size <= 1) {
      this.verificationFlag = JSON.parse(
        window.sessionStorage.getItem('indicatorsInfo')
      );
      for (let [key, value] of Object.entries(this.verificationFlag)) {
        this.initiatePetitionServices.setOption(key, value);
      }
      this.initiatePetitionServices.setOption('fpngCancel', true);
    }

    setTimeout(() => {
      if (this.petitionInfo.trialType === 'DER') {
        if (
          (this.verificationFlag.petitionPaperType &&
            this.verificationFlag.noticePaperType &&
            this.verificationFlag.realPartyComplete &&
            this.verificationFlag.prose) ||
          (this.verificationFlag.petitionPaperType &&
            this.verificationFlag.noticePaperType &&
            this.verificationFlag.realPartyComplete &&
            this.verificationFlag.counselComplete)
        ) {
          this.enable = false;
        }
      } else {
        if (
          (this.verificationFlag.claimsComplete &&
            this.verificationFlag.petitionPaperType &&
            this.verificationFlag.noticePaperType &&
            this.verificationFlag.realPartyComplete &&
            this.verificationFlag.prose) ||
          (this.verificationFlag.claimsComplete &&
            this.verificationFlag.petitionPaperType &&
            this.verificationFlag.noticePaperType &&
            this.verificationFlag.realPartyComplete &&
            this.verificationFlag.counselComplete)
        ) {
          this.enable = false;
        }
      }
      window.sessionStorage.setItem(
        'indicatorsInfo',
        JSON.stringify(this.initiatePetitionServices.getOption())
      );
    }, 1000);
  }

  getDocuments() {
    this.initiatePetitionServices
      .getUnsubmittedDocuments(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (petitionDocumentList) => {
          this.addedPaperList = petitionDocumentList;
          this.setObject();
          //this.checkRequiredFiles();
          this.getPaymentsDocuments();
        },
        (failure) => {
          this.addedPaperList = [];
          this.getPaymentsDocuments();
        }
      );
  }

  // checkRequiredFiles(){
  //   this.addedPaperList.forEach(element => {
  //     if (element.documentTypeDescription == 'Petition: as filed') {
  //       this.petitionPaperType = true;
  //     }
  //     if (
  //       element.documentTypeDescription == 'Notice:  Power of Attorney'
  //     ) {
  //       this.noticePaperType = true;
  //     }
  //   });
  // }

  setObject() {
    this.addedPaperList.forEach((element) => {
      this.clearObject();
      this.obj.artifactIdentifer = element.artifactIdentifer;
      // this.obj.fileName = element.fileName;
      // this.obj.availability = element.availability;
      // this.obj.mimeType = "application/pdf";
      // this.obj.proceedingNumberText = this.petitionInfo.proceedingNumberText;
      // this.obj.filingParty = element.filingParty;
      this.obj.artifactSubmissionIdentifier =
        element.artifactSubmissionIdentifier;
      this.obj.documentTypeIdentifier = element.documentTypeIdentifier;
      // this.obj.petitionIdentifier = element.artifactIdentifer;
      // this.obj.name = element.name;
      this.obj.category = element.category;
      if (element.category == 'EXHIBITS') {
        this.obj.exhibitNumber = element.exhibitNumber;
      }
      // this.obj.audit.createUserIdentifier = window.sessionStorage.getItem('email');
      // this.obj.audit.lastModifiedUserIdentifier = window.sessionStorage.getItem('email');
      this.petitionDocObj.petitionDocuments.push(this.obj);
    });
    this.petitionDocObj.audit.createUserIdentifier =
      window.sessionStorage.getItem('email');
    this.petitionDocObj.audit.lastModifiedUserIdentifier =
      window.sessionStorage.getItem('email');
    this.petitionDocObj.proceedingNumberText =
      this.petitionInfo.proceedingNumberText;
  }

  clearObject() {
    this.obj = {
      artifactIdentifer: null,
      artifactSubmissionIdentifier: null,
      documentTypeIdentifier: null,
      category: null,
    };
  }

  submitPetition() {
    this.initiatePetitionServices
      .submitPetition(this.petitionDocObj)
      .pipe(take(1))
      .subscribe(
        (successUpload) => {
          this.commonUtils.showSuccess(
            'The Petition has been submitted',
            'Success'
          );
          if (this.fromInternal) {
            window.sessionStorage.removeItem('onBehalfOf');
            window.sessionStorage.removeItem('source');
            // this.router.navigate(['/home']);
            this.showButtons = true;
            this.commonUtils.showInfo(
              'This tab will close in 5 seconds',
              'Info'
            );
            setTimeout(() => {
              window.close();
            }, 5000);
          } else {
            this.router.navigate(['ui/my-docket/pending-aia-reviews']);
          }
        },
        (failureUpload) => {
          this.logger.error('Submit petition failed: ', failureUpload);
          this.commonUtils.showError(
            'Petition submission has failed',
            'Action cannot be performed'
          );
        }
      );
  }

  getPetitionIdentifier() {
    this.initiatePetitionServices
      .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
      .subscribe((caseInfoByProceedingResponse) => {
        this.petitionIdentifier =
          caseInfoByProceedingResponse.petitionIdentifier;
        this.store.dispatch(
          getPetitionIdentifier({
            proceedingNo: this.petitionInfo.proceedingNumberText,
          })
        );
        this.getPaymentReceipt();
      });
  }

  redirectToFPNG() {
    let obj1 = {};
    this.initiatePetitionServices
      .redirectToFPNG(this.petitionIdentifier, obj1)
      .pipe(take(1))
      .subscribe(
        (successUpload) => {
          this.pay(successUpload);
        },
        (failureUpload) => {
          this.logger.error('Submit petition failed: ', failureUpload);
          this.commonUtils.showError(
            failureUpload.error.message,
            'Action cannot be performed'
          );
        }
      );
  }

  pay(data) {
    var form = document.createElement('form');
    form.target = '_self';
    form.method = 'POST';
    form.action = data.paymentURL;
    // var params = data.paymentForm;

    // for (var i in params) {
    //   if (params.hasOwnProperty(i)) {
    //     var input = document.createElement('input');
    //     input.type = 'hidden';
    //     input.name = i;
    //     input.value = params[i];
    //     form.appendChild(input);
    //   }
    // }

    document.body.appendChild(form);
    form.submit();
    window.open('', '_self');
  }

  getPaymentReceipt() {
    this.initiatePetitionServices
      .getPaymentsReceipt(this.petitionIdentifier)
      .subscribe(
        (Response) => {
          this.paymentData = Response;
          if (this.paymentData?.paymentStatusCode == 'CLEARED') {
            this.paymentStatus = true;
          } else {
            this.paymentStatus = false;
          }
          this.showButtons = false;
          this.getBasicPetitionDetails(Response);
          this.totalLabel = this.paymentStatus ? 'Total paid' : 'Total Due';
        },
        (failureResponse) => {
          this.paymentStatus = false;
          this.showButtons = false;
        }
      );
  }

  getBasicPetitionDetails(Response) {
    if (Response?.caseStateSummary?.stateId >= 2 && this.paymentStatus) {
      this.router.navigate(['/ui/my-docket']);
    }
  }

  submitWithoutPay() {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: 'Submit the Petition without payment?',
        infoText: [
          'Performing this action will submit the Petition without payment of the fees.',
          'Are you sure you want to continue?',
        ],
        showLeftBtn: true,
        leftBtnClass: 'btn-light',
        leftBtnLabel: 'No, return to Review page',
        showRightBtn: true,
        rightBtnClass: 'btn-warning',
        rightBtnLabel: 'Yes, Submit Petition without payment',
        modalHeight: 175,
      },
    };
    this.submitWithoutPayModalRef = this.modalService.show(InfoModalComponent, {
      class: 'modal-lg second-modal',
      animated: true,
      ignoreBackdropClick: true,
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.submitWithoutPayModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.submitPetition();
      } else {
        this.submitWithoutPayModalRef.hide();
      }
    });
  }

  getPartiesInfo() {
    this.caseViewerService
      .getCounselInfo(this.petitionInfo.proceedingNumberText)
      .subscribe((data) => {
        this.partyInfo = data;
        this.getRealPartyInfo();
        this.getCounselInfo();
      });
  }

  getCounselInfo() {
    this.counselInfo = this.partyInfo;
    if (
      this.partyInfo.petitionCounsel &&
      this.counselInfo.petitionRealParty.parties[0].proseIndicator != 'Y'
    ) {
      this.partyInfo.petitionCounsel.parties.sort(this.sortCounselType);
      this.petitionerCounsel = this.partyInfo.petitionCounsel.parties;
    }
    if (this.partyInfo.poCounsel) {
      this.partyInfo.petitionCounsel.parties.sort(this.sortCounselType);
      this.poCounsel = this.partyInfo.poCounsel.parties;
    }
  }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }

  getPaymentsDocuments() {
    let isMotionFee = false;
    let isNormalFee = false;
    this.numberOfMotionPhv = 0;
    if (this.addedPaperList) {
      this.addedPaperList.forEach((element) => {
        if (element.documentTypeCode == 'MOT:PHV') {
          isMotionFee = true;
          this.numberOfMotionPhv = this.numberOfMotionPhv + 1;
        } else {
          isNormalFee = true;
        }
      });
    }
    this.paymentInfoObj = [];
    if (isMotionFee) {
      this.numberOfTimesGetPaymentInfoCalled++;
      this.getPaymentInfo(isMotionFee);
    }
    if (
      isNormalFee ||
      this.petitionInfo.trialType === 'DER' ||
      this.verificationFlag.claimsComplete
    ) {
      this.numberOfTimesGetPaymentInfoCalled++;
      this.getPaymentInfo(false);
    }
  }

  getPaymentInfo(isMotionFee) {
    this.numberOfTimesActuallyGetPaymentInfoCalled++;
    this.loading = true;
    this.initiatePetitionServices
      .getPaymentInfoByProceedingNo(
        this.petitionInfo.proceedingNumberText,
        isMotionFee
      )
      .subscribe(
        (paymentInfoResponse) => {
          if (paymentInfoResponse.feeCalculations) {
            if (isMotionFee) {
              paymentInfoResponse.feeCalculations[0].feeCodeQty =
                this.numberOfMotionPhv;
              paymentInfoResponse.feeCalculations[0].totalFeeAmt =
                this.numberOfMotionPhv *
                paymentInfoResponse.feeCalculations[0].feeCodeAmt;
            }
            this.paymentInfoObj.push(...paymentInfoResponse.feeCalculations);
          }
          if (
            this.numberOfTimesGetPaymentInfoCalled ==
            this.numberOfTimesActuallyGetPaymentInfoCalled
          ) {
            this.paymentInfoObj = this.commonUtils.sortPaymentTable(
              this.paymentInfoObj,
              'feeIdentifier'
            );
          }
          this.loading = false;
        },
        (failResponse) => {
          this.loading = false;
        }
      );
  }

  getRealPartyInfo() {
    this.realPartyList = [];
    this.addedRealPartyList = [];
    this.tempAddedRealPartyList = this.partyInfo.petitionRealParty?.parties;
    this.setList();
  }

  setList() {
    if (this.tempAddedRealPartyList) {
      this.tempAddedRealPartyList.forEach((element) => {
        if (element.orgType.length > 0) {
          this.clearPartiesObject();
          this.identifier = element.identifier;
          element.orgType.forEach((ele) => {
            this.partyIdentifier = ele.identifier;
            if (
              ele.orgAddress &&
              ele.orgAddress.length > 0 &&
              ele.orgAddress[0].streetLineOneText
            ) {
              this.mailingAddressIdentifier = ele.orgAddress[0].identifier;
              this.addr = ele.orgAddress[0].streetLineOneText;
              this.streetLineOneText = ele.orgAddress[0].streetLineOneText;
              if (
                ele.orgAddress[0].streetLineTwoText &&
                ele.orgAddress[0].streetLineTwoText.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr =
                    this.addr + ', ' + ele.orgAddress[0].streetLineTwoText;
                } else {
                  this.addr = ele.orgAddress[0].streetLineTwoText;
                }
                this.streetLineTwoText = ele.orgAddress[0].streetLineTwoText;
              }
              if (ele.orgAddress[0].city && ele.orgAddress[0].city.trim()) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.orgAddress[0].city;
                } else {
                  this.addr = ele.orgAddress[0].city;
                }
                this.city = ele.orgAddress[0].city;
              }
              if (ele.orgAddress[0].state && ele.orgAddress[0].state.trim()) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.orgAddress[0].state;
                } else {
                  this.addr = ele.orgAddress[0].state;
                }
                this.state = ele.orgAddress[0].state;
              }
              if (
                ele.orgAddress[0].zipCode &&
                ele.orgAddress[0].zipCode.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.orgAddress[0].zipCode;
                } else {
                  this.addr = ele.orgAddress[0].zipCode;
                }
                this.zip = ele.orgAddress[0].zipCode;
              }
              if (
                ele.orgAddress[0].country &&
                ele.orgAddress[0].country.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.orgAddress[0].country;
                } else {
                  this.addr = ele.orgAddress[0].country;
                }
                this.country = ele.orgAddress[0].country;
              }
            }
            if (ele.electronicAddress.length > 0) {
              for (var i = 0; i < ele.electronicAddress.length; i++) {
                if (ele.electronicAddress[i].telephoneNumber) {
                  this.phone = ele.electronicAddress[i].telephoneNumber;
                  this.telephoneNumber =
                    ele.electronicAddress[i].telephoneNumber;
                  this.phoneIdentifier = ele.electronicAddress[i].identifier;
                }
                if (ele.electronicAddress[i].extension) {
                  this.phone =
                    this.phone + ' ext: ' + ele.electronicAddress[i].extension;
                  this.extension = ele.electronicAddress[i].extension;
                }
                if (ele.electronicAddress[i].email) {
                  this.email = ele.electronicAddress[i].email;
                  this.emailIdentifier = ele.electronicAddress[i].identifier;
                }
                if (ele.electronicAddress[i].fax) {
                  this.fax = ele.electronicAddress[i].fax;
                  this.faxIdentifier = ele.electronicAddress[i].identifier;
                }
              }
            }
            this.partyObj = {
              firstName: ele.firstName,
              lastName: ele.lastName,
              email: this.email,
              phone: this.phone,
              extension: this.extension,
              fax: this.fax,
              country: this.country,
              streetLineOneText: this.streetLineOneText,
              streetLineTwoText: this.streetLineTwoText,
              city: this.city,
              state: this.state,
              zip: this.zip,
              name: ele.legalname,
              type: 'Organization',
              address: this.addr,
              telephoneNumber: this.telephoneNumber,
              identifier: this.identifier,
              partyIdentifier: this.partyIdentifier,
              mailingAddressIdentifier: this.mailingAddressIdentifier,
              phoneIdentifier: this.phoneIdentifier,
              emailIdentifier: this.emailIdentifier,
              faxIdentifier: this.faxIdentifier,
            };
          });
          if (element.partyType == 'REAL PARTY') {
            this.realPartyList.push(this.partyObj);
          }
          if (element.partyType == 'ADD REAL PARTY') {
            this.addedRealPartyList.push(this.partyObj);
          }
        }
        if (element.personType.length > 0) {
          this.clearPartiesObject();
          this.identifier = element.identifier;
          element.personType.forEach((ele) => {
            this.partyIdentifier = ele.identifier;
            if (
              ele.mailingAddress &&
              ele.mailingAddress.length > 0 &&
              ele.mailingAddress[0].streetLineOneText
            ) {
              this.mailingAddressIdentifier = ele.mailingAddress[0].identifier;
              this.addr = ele.mailingAddress[0].streetLineOneText;
              this.streetLineOneText = ele.mailingAddress[0].streetLineOneText;
              if (
                ele.mailingAddress[0].streetLineTwoText &&
                ele.mailingAddress[0].streetLineTwoText.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr =
                    this.addr + ', ' + ele.mailingAddress[0].streetLineTwoText;
                } else {
                  this.addr = ele.mailingAddress[0].streetLineTwoText;
                }
                this.streetLineTwoText =
                  ele.mailingAddress[0].streetLineTwoText;
              }
              if (
                ele.mailingAddress[0].city &&
                ele.mailingAddress[0].city.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.mailingAddress[0].city;
                } else {
                  this.addr = ele.mailingAddress[0].city;
                }
                this.city = ele.mailingAddress[0].city;
              }
              if (
                ele.mailingAddress[0].state &&
                ele.mailingAddress[0].state.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.mailingAddress[0].state;
                } else {
                  this.addr = ele.mailingAddress[0].state;
                }
                this.state = ele.mailingAddress[0].state;
              }
              if (
                ele.mailingAddress[0].zipCode &&
                ele.mailingAddress[0].zipCode.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.mailingAddress[0].zipCode;
                } else {
                  this.addr = ele.mailingAddress[0].zipCode;
                }
                this.zip = ele.mailingAddress[0].zipCode;
              }
              if (
                ele.mailingAddress[0].country &&
                ele.mailingAddress[0].country.trim()
              ) {
                if (this.addr && this.addr.trim()) {
                  this.addr = this.addr + ', ' + ele.mailingAddress[0].country;
                } else {
                  this.addr = ele.mailingAddress[0].country;
                }
                this.country = ele.mailingAddress[0].country;
              }
            }

            if (ele.electronicAddress.length > 0) {
              for (var i = 0; i < ele.electronicAddress.length; i++) {
                if (ele.electronicAddress[i].telephoneNumber) {
                  this.phone = ele.electronicAddress[i].telephoneNumber;
                  this.telephoneNumber =
                    ele.electronicAddress[i].telephoneNumber;
                  this.phoneIdentifier = ele.electronicAddress[i].identifier;
                }
                if (ele.electronicAddress[i].extension) {
                  this.phone =
                    this.phone + ' ext: ' + ele.electronicAddress[i].extension;
                  this.extension = ele.electronicAddress[i].extension;
                }
                if (ele.electronicAddress[i].email) {
                  this.email = ele.electronicAddress[i].email;
                  this.emailIdentifier = ele.electronicAddress[i].identifier;
                }
                if (ele.electronicAddress[i].fax) {
                  this.fax = ele.electronicAddress[i].fax;
                  this.faxIdentifier = ele.electronicAddress[i].identifier;
                }
              }
            }
            this.partyObj = {
              firstName: ele.firstName,
              lastName: ele.lastName,
              email: this.email,
              phone: this.phone,
              extension: this.extension,
              fax: this.fax,
              country: this.country,
              streetLineOneText: this.streetLineOneText,
              streetLineTwoText: this.streetLineTwoText,
              city: this.city,
              state: this.state,
              zip: this.zip,
              name: ele.firstName + ' ' + ele.lastName,
              type: 'Individual',
              address: this.addr,
              telephoneNumber: this.telephoneNumber,
              identifier: this.identifier,
              partyIdentifier: this.partyIdentifier,
              mailingAddressIdentifier: this.mailingAddressIdentifier,
              phoneIdentifier: this.phoneIdentifier,
              emailIdentifier: this.emailIdentifier,
              faxIdentifier: this.faxIdentifier,
            };
          });
          if (element.partyType == 'REAL PARTY') {
            this.realPartyList.push(this.partyObj);
          }
          if (element.partyType == 'ADD REAL PARTY') {
            this.addedRealPartyList.push(this.partyObj);
          }
        }
      });
    }
  }

  clearPartiesObject() {
    this.partyObj = {};
    this.streetLineOneText = '';
    this.streetLineTwoText = '';
    this.city = '';
    this.state = '';
    this.zip = '';
    this.addr = '';
    this.email = '';
    this.fax = '';
    this.phone = '';
    this.telephoneNumber = '';
    this.extension = '';
    this.country = '';
    this.identifier = '';
    this.partyIdentifier = '';
    this.mailingAddressIdentifier = '';
    this.phoneIdentifier = '';
    this.emailIdentifier = '';
    this.faxIdentifier = '';
  }

  tabValidations() {
    this.verificationFlag = this.initiatePetitionServices.getOption();
    console.log(this.verificationFlag);
    if (
      this.verificationFlag.claimsComplete == '' &&
      this.verificationFlag.claimsInComplete == ''
    ) {
      this.verificationFlag.claimsInComplete = true;
    }
    if (
      this.verificationFlag.petitionPaperType == '' &&
      this.verificationFlag.noticePaperType == '' &&
      this.verificationFlag.noPetitionPaperType == '' &&
      this.verificationFlag.noNoticePaperType == ''
    ) {
      this.verificationFlag.noPetitionPaperType = true;
      this.verificationFlag.noNoticePaperType = true;
    }
    if (
      this.verificationFlag.realPartyComplete == '' &&
      this.verificationFlag.realPartyInComplete == ''
    ) {
      this.verificationFlag.realPartyInComplete = true;
    }
    if (
      this.verificationFlag.counselComplete == '' &&
      this.verificationFlag.counselInComplete == ''
    ) {
      this.verificationFlag.counselInComplete = true;
    }
  }
}
