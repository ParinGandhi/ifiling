import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounselIpComponent } from './counsel-ip.component';

describe('CounselIpComponent', () => {
  let component: CounselIpComponent;
  let fixture: ComponentFixture<CounselIpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CounselIpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselIpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
