import { Component, Input, OnInit } from '@angular/core';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../../case-viewer/case-viewer.service';

@Component({
  selector: 'app-counsel-ip',
  templateUrl: './counsel-ip.component.html',
  styleUrls: ['./counsel-ip.component.scss']
})
export class CounselIpComponent implements OnInit {
  @Input() petitionerCounsel: any;
  petitionInfo: any = null;
  //petitionerCounsel: any;
  poCounsel: any;
  counselInfo: any;

  lastRefresh = new Date();
  refreshSort: boolean;


  constructor(
    private caseViewerService: CaseViewerService, private commonUtils: CommonUtilitiesService) { }

  ngOnInit(): void {
    this.petitionInfo = JSON.parse(
      window.sessionStorage.getItem('petitionInfo')
    );
    //   setTimeout(() => {
    //   this.getCounselInfo();
    // }, 500);
  }

  refresh(val) {
    this.refreshSort = val;
    this.counselInfo = null;
    this.petitionerCounsel = null;
    this.poCounsel = null;
    // this.getCounselInfo();
    this.lastRefresh = new Date();
  }

  // getCounselInfo() {
  //   // this.caseViewerService.getCounselInfo(this.petitionInfo.proceedingNumberText).subscribe((data) => {
  //     this.counselInfo = this.partyInfo;
  //     if (this.partyInfo.petitionCounsel && this.counselInfo.petitionRealParty.parties[0].proseIndicator != 'Y') {
  //       this.partyInfo.petitionCounsel.parties.sort(this.sortCounselType);
  //       this.petitionerCounsel = this.partyInfo.petitionCounsel.parties;
  //     }
  //     if (this.partyInfo.poCounsel) {
  //       this.partyInfo.petitionCounsel.parties.sort(this.sortCounselType);
  //       this.poCounsel = this.partyInfo.poCounsel.parties;
  //     }
  //   // });
  // }

  sortCounselType(a, b) {
    const rankA = a.rankNo;
    const rankB = b.rankNo;

    let comparison = 0;
    if (rankA > rankB) {
      comparison = 1;
    } else if (rankA < rankB) {
      comparison = -1;
    }
    return comparison;
  }

  copyEmails(counselType) {
    let emails = [];
    if (counselType == 'petitionCounsel') {
      this.petitionerCounsel.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    } else if (counselType == 'poCounsel') {
      this.poCounsel.forEach((party) => {
        party.personType[0].electronicAddress.forEach((electronicAddress) => {
          if (electronicAddress.hasOwnProperty('email')) {
            emails.push(electronicAddress.email);
          }
        });
      });
    }
    // if (this.counselInfo[counselType] && this.counselInfo[counselType].parties.length > 0) {
    //   this.counselInfo[counselType].parties.forEach((party) => {
    //     party.personType[0].electronicAddress.forEach((electronicAddress) => {
    //       if (electronicAddress.hasOwnProperty('email')) {
    //         emails.push(electronicAddress.email);
    //       }
    //     });
    //   });
    // }
    this.commonUtils.copyToClipboard(emails.join(", "), counselType);
  }
}

