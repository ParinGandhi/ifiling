import { Component, Input, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../initiate-petition.service';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { Store, select } from '@ngrx/store';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-payments-ip',
  templateUrl: './payments-ip.component.html',
  styleUrls: ['./payments-ip.component.scss']
})
export class PaymentsIpComponent implements OnInit {
  @Input() totalLabel: any;
  @Input() paymentInfoObj: any;
  petitionInfo: any = {};
  //paymentInfoObj: any;
  numberOfMotionPhv: number;
  paymentStatus: any;
  //totalLabel: string;
  petitionIdentifier: any;


  constructor(private initiatePetitionService: InitiatePetitionService, private store: Store<PtactsState>,) { }

  ngOnInit(): void {

    this.petitionInfo = window.sessionStorage.getItem('petitionInfo');
    if (this.petitionInfo) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }
    this.store
      .select(PtactsSelectors.getPetitionIdentifierState)
      .subscribe((petitionIdentifier) => {
        this.petitionIdentifier = petitionIdentifier;
        console.log(
          'Petition identifier from state: ',
          this.petitionIdentifier
        );
      });
    // setTimeout(() => {
    //   this.getDocuments();
    //   //this.getPetitionIdentifier();

    //   this.getPaymentReceipt();
    // }, 500);
  }

  getPaymentInfo(isMotionFee) {
    this.initiatePetitionService
      .getPaymentInfoByProceedingNo(this.petitionInfo.proceedingNumberText, isMotionFee)
      .subscribe((paymentInfoResponse) => {
        if (paymentInfoResponse.feeCalculations) {
          if (isMotionFee) {
            paymentInfoResponse.feeCalculations[0].feeCodeQty = this.numberOfMotionPhv;
            paymentInfoResponse.feeCalculations[0].totalFeeAmt = this.numberOfMotionPhv * paymentInfoResponse.feeCalculations[0].feeCodeAmt;
          }
          this.paymentInfoObj.push(...paymentInfoResponse.feeCalculations);
        }
      });
  }

  // getDocuments() {
  //   let isMotionFee = false;
  //   let isNormalFee = false;
  //   this.numberOfMotionPhv = 0;
  //   // this.initiatePetitionService
  //   //   .getUnsubmittedDocuments(this.petitionInfo.proceedingNumberText)
  //   //   .pipe(take(1))
  //   //   .subscribe(
  //   //     (petitionDocumentList) => {
  //   this.addedPaperList.forEach(element => {
  //     if (element.documentTypeCode == 'MOT:PHV') {
  //       isMotionFee = true;
  //       this.numberOfMotionPhv = this.numberOfMotionPhv + 1;
  //     } else {
  //       isNormalFee = true;
  //     }
  //   });
  //   this.paymentInfoObj = [];
  //   if (isNormalFee) {
  //     this.getPaymentInfo(false);
  //   }
  //   if (isMotionFee) {
  //     this.getPaymentInfo(isMotionFee);
  //   }

  //   //   },
  //   //   (failure) => {

  //   //   }
  //   // );
  // }

  paymentsSum() {
    return this.paymentInfoObj.map(tag => tag.totalFeeAmt).reduce((a, b) => a + b, 0);
  }

  // getPaymentReceipt() {
  //   // this.initiatePetitionService
  //   //   .getPaymentsReceipt(this.petitionIdentifier)
  //   //   .subscribe((Response) => {
  //   if (this.paymentData?.paymentStatusCode == "CLEARED") {
  //     this.paymentStatus = true;
  //   }
  //   else {
  //     this.paymentStatus = false;
  //   }
  //   this.totalLabel = this.paymentStatus ? "Total paid" : "Total Due";
  //   // }
  //   // ,(failureResponse) => {
  //   //   this.paymentStatus = false;
  //   //   this.totalLabel = "Total Due";
  //   // }
  //   // );
  // }

  // getPetitionIdentifier() {
  //   this.petitionIdentifier = window.sessionStorage.getItem('petitionIdentifier');
  //   // this.initiatePetitionService
  //   //   .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
  //   //   .subscribe((caseInfoByProceedingResponse) => {
  //   //     this.petitionIdentifier =
  //   //       caseInfoByProceedingResponse.petitionIdentifier;
  //   //     this.getPaymentReceipt();
  //   //   });
  // }

}
