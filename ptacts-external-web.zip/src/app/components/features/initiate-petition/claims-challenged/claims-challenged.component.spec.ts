import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsChallengedComponent } from './claims-challenged.component';

describe('ClaimsChallengedComponent', () => {
  let component: ClaimsChallengedComponent;
  let fixture: ComponentFixture<ClaimsChallengedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimsChallengedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsChallengedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
