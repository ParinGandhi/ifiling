import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { CommonUtilitiesService } from '../../../../services/common-utilities.service';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  NgForm,
  Validators,
} from '@angular/forms';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../initiate-petition.service';
import { InfoModalComponent } from '../../../common/info-modal/info-modal.component';
import { Router } from '@angular/router';
import { WarningModalComponent } from 'src/app/components/common/warning-modal/warning-modal.component';

@Component({
  selector: 'app-claims-challenged',
  templateUrl: './claims-challenged.component.html',
  styleUrls: ['./claims-challenged.component.scss'],
})
export class ClaimsChallengedComponent implements OnInit {
  modalRef: BsModalRef;
  deleteModelRef: BsModalRef;
  statutoryGrounds: any[] = [];
  challengedClaims: any = {};
  USC101: any[] = [];
  USC102: any[] = [];
  USC103: any[] = [];
  USC112: any[] = [];
  petitionInfo: any = {};
  claimsUpload = {
    caseNo: null,
    claims: [],
    audit: {
      lastModifiedUserIdentifier: null,
      createUserIdentifier: null,
    },
    lifeCycle: null,
  };
  claimUploadObj = {
    asCaptured: null,
    category: null,
    statGroundId: null,
    identifier: null,
  };
  //claimsChallengedForm = null;
  claimsChallengedForm = this.fb.group({
    challengedGroupClaimList: ['', Validators.required],
    selectedStatutoryGround: ['', Validators.required],
    reasonText: ['', Validators.required],
  });

  claimsInfo: any;
  selectedGroundIdentifier: any;
  editAction: boolean = false;
  claimId: any;
  expand1 = true;
  flag: boolean;
  priorArtRequired: boolean = false;
  componentName: string = 'claims';
  onBehalfOf: string = null;
  loading: boolean = false;
  adding: boolean = false;

  constructor(
    private logger: NGXLogger,
    public modalService: BsModalService,
    public initiatePetitionService: InitiatePetitionService,
    public commonUtils: CommonUtilitiesService,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    //! To get user info when coming from internal application
    console.group();
    const prefix = 'fromInternal';

    if (window.name.substring(0, prefix.length) === prefix) {
      window.sessionStorage.setItem('source', 'internal');
      const data = JSON.parse(atob(window.name.substring(prefix.length)));

      if (!window.sessionStorage.getItem('petitionInfo')) {
        if (data.proceedingNumberText && data.serialNo && data.trialType) {
          this.petitionInfo = {
            proceedingNumberText: data.proceedingNumberText,
            serialNo: data.serialNo,
            trialType: data.trialType,
          };

          window.sessionStorage.setItem(
            'petitionInfo',
            JSON.stringify(this.petitionInfo)
          );
        }
      }

      window.sessionStorage.setItem('userInfo', JSON.stringify(data));
      //  this.store.dispatch(
      //    setUserIdAction({
      //      payload: `${data.lastName}, ${data.firstName}`,
      //    })
      //  );
      window.sessionStorage.setItem('email', data.emailId);
      window.sessionStorage.setItem(
        'onBehalfOf',
        `${data.lastName}, ${data.firstName} (${data.emailId})`
      );
      if (data.cfkPatronId) {
        window.sessionStorage.setItem('cfkPatronId', data.cfkPatronId);
      }
      console.groupEnd();
    }

    const emailId = window.sessionStorage.getItem('email');
    if (window.sessionStorage.getItem('petitionInfo')) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }
    this.claimsUpload.audit.lastModifiedUserIdentifier = emailId;
    this.claimsUpload.audit.createUserIdentifier = emailId;
    this.claimsUpload.caseNo = this.petitionInfo.proceedingNumberText;

    if (this.petitionInfo.trialType === 'DER') {
      this.claimsChallengedForm = this.fb.group({
        challengedGroupClaimList: ['', Validators.required],
        selectedStatutoryGround: [''],
        reasonText: [''],
      });
      (
        document.getElementById('statutoryGroundsList') as HTMLSelectElement
      ).disabled = true;
    } else if (this.petitionInfo.trialType === 'PGR') {
      this.claimsChallengedForm = this.fb.group({
        challengedGroupClaimList: ['', Validators.required],
        selectedStatutoryGround: ['', Validators.required],
        reasonText: [''],
      });
    } else {
      this.claimsChallengedForm = this.fb.group({
        challengedGroupClaimList: ['', Validators.required],
        selectedStatutoryGround: ['', Validators.required],
        reasonText: ['', Validators.required],
      });
    }
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    this.getStatutoryGrounds();
    this.getClaimsList();
  }

  priorArtReq(value) {
    if (this.petitionInfo.trialType === 'PGR') {
      if (value === '35USC101' || value === '35USC112') {
        // this.claimsChallengedForm.get('reasonText').clearValidators();
        const tempPGRClaimsForm = this.claimsChallengedForm.value;
        this.claimsChallengedForm = this.fb.group({
          challengedGroupClaimList: [
            tempPGRClaimsForm.challengedGroupClaimList,
            Validators.required,
          ],
          selectedStatutoryGround: [
            tempPGRClaimsForm.selectedStatutoryGround,
            Validators.required,
          ],
          reasonText: [tempPGRClaimsForm.reasonText],
        });
        this.priorArtRequired = true;
        this.logger.info('Claims form', this.claimsChallengedForm);
        // this.claimsChallengedForm.
      } else {
        // this.claimsChallengedForm
        //   .get('reasonText')
        //   .setValue(null, Validators.required);
        // this.claimsChallengedForm.updateValueAndValidity();
        // this.logger.info('Claims form', this.claimsChallengedForm);
        const tempClaimsForm = this.claimsChallengedForm.value;
        this.claimsChallengedForm = this.fb.group({
          challengedGroupClaimList: [
            tempClaimsForm.challengedGroupClaimList,
            Validators.required,
          ],
          selectedStatutoryGround: [
            tempClaimsForm.selectedStatutoryGround,
            Validators.required,
          ],
          reasonText: [tempClaimsForm.reasonText, Validators.required],
        });
        this.logger.info('Claims form', this.claimsChallengedForm);
        this.priorArtRequired = false;
      }
    }
  }

  getStatutoryGrounds() {
    this.initiatePetitionService
      .getStatutoryGrounds(
        'statutoryGroundTypes',
        true,
        this.petitionInfo.trialType
      )
      .pipe(take(1))
      .subscribe(
        (statutoryGrounds) => {
          this.statutoryGrounds = statutoryGrounds;
        },
        (statutoryGroundsFailure) => {
          this.logger.error(
            'Failed to retrieve statutory grounds: ',
            statutoryGroundsFailure
          );
        }
      );
  }

  getClaimsList() {
    this.loading = true;
    this.USC101 = [];
    this.USC102 = [];
    this.USC103 = [];
    this.USC112 = [];
    this.initiatePetitionService
      .getClaims(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (claimsInfo) => {
          this.claimsInfo = claimsInfo;
          this.claimsInfo.claimMetaData.forEach((element) => {
            if (element.statutoryGndSummary.code === '35USC101') {
              this.USC101.push(element);
            } else if (element.statutoryGndSummary.code === '35USC102') {
              this.USC102.push(element);
            } else if (element.statutoryGndSummary.code === '35USC103') {
              this.USC103.push(element);
            } else if (element.statutoryGndSummary.code === '35USC112') {
              this.USC112.push(element);
            }
          });
          this.loading = false;
        },
        (claimsFailure) => {
          this.USC101 = [];
          this.USC102 = [];
          this.USC103 = [];
          this.USC112 = [];
          this.logger.error('Failed to retrieve claims: ', claimsFailure);
          this.loading = false;
        }
      );
  }

  // getSelectedGroundId() {
  //   const claimItem = this.claimsChallengedForm.value.selectedStatutoryGround;
  //    this.statutoryGrounds.forEach(el => {
  //     if(el.code === claimItem) {
  //       return this.selectedGroundIdentifier =  el.identifier;
  //     }
  //   });
  // }

  cancel() {
    this.claimsChallengedForm.reset();
    this.editAction = false;
    this.priorArtRequired = false;
    //this.disableNav(this.editAction);
  }

  verifyRequiredFields() {
    // if (
    //   this.claimsChallengedForm &&
    //   this.claimsChallengedForm.value.challengedGroupClaimList &&
    //   this.claimsChallengedForm.value.reasonText &&
    //   this.claimsChallengedForm.value.selectedStatutoryGround
    // ) {
    //   this.flag = true;
    //   this.initiatePetitionService.setOption('claimsComplete', true);
    //   this.initiatePetitionService.setOption('claimsInComplete', false);
    // } else if (
    if (
      this.USC101.length != 0 ||
      this.USC102.length != 0 ||
      this.USC103.length != 0 ||
      this.USC112.length != 0
    ) {
      this.initiatePetitionService.setOption('claimsComplete', true);
      this.initiatePetitionService.setOption('claimsInComplete', false);
      if (
        this.claimsChallengedForm.value.challengedGroupClaimList ||
        this.claimsChallengedForm.value.reasonText ||
        this.claimsChallengedForm.value.selectedStatutoryGround
      ) {
        this.flag = false;
      } else {
        this.flag = true;
      }
    } else {
      this.initiatePetitionService.setOption('claimsComplete', false);
      this.initiatePetitionService.setOption('claimsInComplete', true);
      this.flag = false;
    }
  }

  addClaim() {
    this.adding = true;
    if (
      this.petitionInfo.trialType === 'PGR' &&
      this.claimsChallengedForm.get('reasonText').value === null
    ) {
      this.claimsChallengedForm.controls.reasonText.setValue('');
    }

    const claimItem = this.claimsChallengedForm.value.selectedStatutoryGround;
    this.statutoryGrounds.forEach((el) => {
      if (el.code === claimItem) {
        this.selectedGroundIdentifier = el.identifier;
        return false;
      }
    });
    this.claimsUpload.claims = [];
    this.claimUploadObj = {
      asCaptured: this.claimsChallengedForm.value.challengedGroupClaimList,
      category:
        this.claimsChallengedForm.value.reasonText === ''
          ? '-'
          : this.claimsChallengedForm.value.reasonText,
      statGroundId: this.selectedGroundIdentifier,
      identifier: null,
    };
    this.logger.info('Claims challenged form: ', this.claimsChallengedForm);
    this.claimsUpload.claims.push(this.claimUploadObj);
    // this[claimItem].push(this.claimsChallengedForm.value);

    this.initiatePetitionService
      .uploadClaims(this.claimsUpload)
      .pipe(take(1))
      .subscribe(
        (successUpload) => {
          this.claimsChallengedForm.reset();
          this.priorArtRequired = false;
          this.claimsUpload.claims = [];
          this.getClaimsList();
          this.commonUtils.showSuccess(`Challenged claim(s) added.`, '');
          this.adding = false;
        },
        (failureUpload) => {
          this.claimsUpload.claims = [];
          this.commonUtils.showError(failureUpload.error.message, '');
          this.adding = false;
        }
      );
  }

  disableNav(ea) {
    if (ea) {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.add('navdisabled');
    } else {
      document
        .getElementsByClassName('sidenav')[0]
        .classList.remove('navdisabled');
    }
  }
  editClaim(editValue) {
    this.editAction = true;
    this.priorArtReq(editValue.statutoryGndSummary.code);
    //this.disableNav(this.editAction);
    this.claimId = editValue.claimIdentifier;
    this.claimsChallengedForm.setValue({
      challengedGroupClaimList: editValue.challengedGroupClaimList,
      reasonText: editValue.reasonText === '-' ? '' : editValue.reasonText,
      selectedStatutoryGround: editValue.statutoryGndSummary.code,
    });
  }

  continue() {
    this.verifyRequiredFields();
    //if (this.flag) {
    this.router.navigate(['/ui/initiate-petition/petition-documents']);
    // } else {
    //   //this.openWarningModal();
    // }
  }

  updateClaims() {
    const claimItem = this.claimsChallengedForm.value.selectedStatutoryGround;
    this.statutoryGrounds.forEach((el) => {
      if (el.code === claimItem) {
        return (this.selectedGroundIdentifier = el.identifier);
      }
    });
    this.claimsUpload.claims = [];
    this.claimUploadObj = {
      asCaptured: this.claimsChallengedForm.value.challengedGroupClaimList,
      category:
        this.claimsChallengedForm.value.reasonText === ''
          ? '-'
          : this.claimsChallengedForm.value.reasonText,
      statGroundId: this.selectedGroundIdentifier,
      identifier: this.claimId,
    };
    this.claimsUpload.claims.push(this.claimUploadObj);
    this.initiatePetitionService.updateClaim(this.claimsUpload).subscribe(
      (data) => {
        this.editAction = false;
        this.priorArtRequired = false;
        //this.disableNav(this.editAction);
        this.claimsChallengedForm.reset();
        // this.claimUploadObj = {
        //   asCaptured: null,
        //   category: null,
        //   statGroundId: null,
        //   identifier: null
        // };
        // this.selectedGround = null;
        this.getClaimsList();
        this.commonUtils.showSuccess(`Claim successfully updated`, '');
      },
      (failureResponse) => {
        this.commonUtils.showError(failureResponse.error.message, '');
        this.editAction = true;
        //this.disableNav(this.editAction);
        this.claimsUpload.claims = [];
      }
    );
  }

  // openModal() {
  //   const initialState: any = {
  //     modal: {
  //       isConfirm: false,
  //       title: "Delete this claim?",
  //       infoText: ['Delete challenged claim(s)?   The challenged claim(s) under this statutory ground will be deleted from the table view.'],
  //       showLeftBtn: true,
  //       leftBtnClass: 'btn-default',
  //       leftBtnLabel: 'No, return to page',
  //       showRightBtn: true,
  //       rightBtnClass: 'btn-danger',
  //       rightBtnLabel: 'Yes, delete this record',
  //       modalHeight: 100,
  //     }
  //   };
  //   this.modalRef = this.modalService.show(
  //     animated: true,
  //     backdrop: 'static',
  //     class: 'confirm-delete-modal',
  //     initialState
  //   );
  //   this.modalRef.onHide.subscribe((reason: string | any) => {
  //     if (reason.initialState.continueWithPetition) {

  //       this.patentExists = true;
  //       // this.createPetition();
  //     }
  //   });
  // }

  deleteClaim(data) {
    const initialState: any = {
      modal: {
        isConfirm: false,
        title: 'Delete this ground?',
        infoText: [
          'The challenged claim(s) under this statutory ground will be deleted from the table view.',
        ],
        showLeftBtn: true,
        leftBtnClass: 'btn-light',
        leftBtnLabel: 'No, return to the page',
        showRightBtn: true,
        rightBtnClass: 'btn-danger',
        rightBtnLabel: 'Yes, delete this ground',
        modalHeight: 100,
      },
    };
    this.deleteModelRef = this.modalService.show(InfoModalComponent, {
      animated: true,
      backdrop: 'static',
      class: 'confirm-delete-modal modal-lg',
      initialState,
    });
    this.commonUtils.removeModalFadeClass();
    this.deleteModelRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        this.initiatePetitionService
          .deleteClaim(data.claimIdentifier)
          .subscribe((Response) => {
            this.getClaimsList();
            this.commonUtils.showSuccess(
              `The ground has been successfully deleted.`,
              ''
            );
          });
      }
    });
  }

  openWarningModal() {
    const initialState: ModalOptions = {
      initialState: {
        title: 'Warning',
        message: [
          'Performing this action will exit the current screen without saving your changes.',
          'Do you want to continue and clear changes?',
        ],
        leftBtnLabel: 'No, return to page',
        rightBtnLabel: 'Yes, abandon changes',
        selection: false,
      },
    };
    this.modalRef = this.modalService.show(WarningModalComponent, initialState);
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.selection) {
        this.router.navigate(['/ui/initiate-petition/petition-documents']);
      } else {
      }
    });
  }
}
