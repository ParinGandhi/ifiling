import { Component, OnInit } from '@angular/core';
import { FormBuilder, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { BsModalService, BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { InitiatePetitionService } from '../initiate-petition.service';
import { VerificationModalComponent } from './verification-modal/verification-modal.component';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CONSTANTS } from 'src/app/constants/constants';

import { Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import {
  setNewPetitionInfo,
  setTrialInfo,
  setUserIdAction,
} from 'src/app/store/ptacts/ptacts.actions';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.scss'],
})
export class VerificationComponent implements OnInit {
  selectedTrialType: string = 'default';
  patentExists: boolean = false;
  nonDERPatentExists: boolean = false;
  trialTypes: [] = [];
  info = { filingDate: '' };
  filingDate: any;
  invalidPatentNumber: string = null;
  modalRef: BsModalRef;
  petitionerRegexMatches: boolean = false;
  poRegexMatches: boolean = false;
  verifying: boolean = false;
  onBehalfOf: string = null;

  verifiedDERInfo = {
    petitionerExists: false,
    petitionerInfo: null,
    petitionerType: null,
    petitionerNumber: null,
    poExists: false,
    poInfo: null,
    poType: null,
    poNumber: null,
  };

  verifiedNonDERInfo = {
    patentExists: false,
    patentInfo: null,
  };

  creatingPetition: boolean = false;

  regex =
    /(PP\d{5,11}$)|(AI\d{6,11}$)|(RE\d{5,11})$|(D\d{6,12}$)|(T\d{6,12}$)|(US\d{11}$)|(H\d{6,12}$)|(^\d{6,13}$)|(RX\d{1,11}$)/i;

  verificationForm = this.fb.group({
    // selectedTrialType: ['', Validators.required],
    patentNumber: ['', Validators.required],
  });

  derivationForm = this.fb.group({
    firstListedPetitionerSelection: [
      'petitionerApplicationNumber',
      Validators.required,
    ],
    firstListedPetitionerApplicationValue: ['', Validators.required],
    firstListedPetitionerPatentValue: ['', Validators.required],
    firstListedPOSelection: ['POApplicationNumber', Validators.required],
    firstListedPOApplicationValue: [''],
    firstListedPOPatentValue: [''],
  });
  ecfr_url: any;
  ahd_url: any;

  constructor(
    private logger: NGXLogger,
    private initiatePetitionServices: InitiatePetitionService,
    private router: Router,
    private modalService: BsModalService,
    private fb: FormBuilder,
    public commonUtils: CommonUtilitiesService,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    //! To get user info when coming from internal application
    setTimeout(() => {
      this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    }, 500);
    const prefix = 'fromInternal';
    if (window.name.substring(0, prefix.length) === prefix) {
      window.sessionStorage.setItem('source', 'internal');
      const data = JSON.parse(atob(window.name.substring(prefix.length)));

      window.sessionStorage.setItem('userInfo', JSON.stringify(data));
      // this.store.dispatch(
      //   setUserIdAction({
      //     payload: `${data.lastName}, ${data.firstName}`,
      //   })
      // );
      window.sessionStorage.setItem('email', data.emailId);
      window.sessionStorage.setItem(
        'onBehalfOf',
        `${data.lastName}, ${data.firstName} (${data.emailId})`
      );
      if (data.cfkPatronId) {
        window.sessionStorage.setItem('cfkPatronId', data.cfkPatronId);
      }
    }

    this.getTrialTypes();
    this.getECFRUrls();
    this.getAHDUrls();
    this.initiatePetitionServices.setOption('prose', true);
    this.initiatePetitionServices.setOption('enableVerifications', true);
    document.getElementById('ipPetitionInformation').tabIndex = -1;
    const ipClaims = document.getElementById('ipClaims');
    if (ipClaims) {
      ipClaims.tabIndex = -1;
    }
    document.getElementById('ipDocs').tabIndex = -1;
    document.getElementById('ipRealParty').tabIndex = -1;
    document.getElementById('ipAddRealParty').tabIndex = -1;
    const ipCounsel = document.getElementById('ipCounsel');
    if (ipCounsel) {
      ipCounsel.tabIndex = -1;
    }
    document.getElementById('ipReview').tabIndex = -1;
    document.getElementById('ipVerification').tabIndex = 0;
  }

  getECFRUrls() {
    this.initiatePetitionServices
      .getECFRUrls()
      .pipe()
      .subscribe((urlResponse) => {
        this.ecfr_url = urlResponse[0].descriptionText;
      });
  }

  getAHDUrls() {
    this.initiatePetitionServices
      .getAHDUrls()
      .pipe()
      .subscribe((urlResponse) => {
        this.ahd_url = urlResponse[0].descriptionText;
      });
  }

  openECFRLink() {
    window.open(this.ecfr_url, '_blank');
  }

  openPetitionerInfoLink() {
    if (this.verifiedDERInfo?.petitionerInfo?.patentNumber) {
      window.open(
        this.ahd_url +
          '&pat=' +
          this.verifiedDERInfo.petitionerInfo.patentNumber,
        '_blank'
      );
    } else if (this.verifiedDERInfo?.petitionerInfo?.applicationNumberText) {
      window.open(
        this.ahd_url +
          '&app=' +
          this.verifiedDERInfo.petitionerInfo.applicationNumberText,
        '_blank'
      );
    }
  }

  openPoInfoLink() {
    if (this.verifiedDERInfo?.poInfo?.patentNumber) {
      window.open(
        this.ahd_url + '&pat=' + this.verifiedDERInfo.poInfo.patentNumber,
        '_blank'
      );
    } else if (this.verifiedDERInfo?.poInfo?.applicationNumberText) {
      window.open(
        this.ahd_url +
          '&app=' +
          this.verifiedDERInfo.poInfo.applicationNumberText,
        '_blank'
      );
    }
  }

  openNonDerLink() {
    if (this.verifiedNonDERInfo?.patentInfo?.patentNumber) {
      window.open(
        this.ahd_url +
          '&pat=' +
          this.verifiedNonDERInfo.patentInfo.patentNumber,
        '_blank'
      );
    } else if (this.verifiedNonDERInfo?.patentInfo?.applicationNumberText) {
      window.open(
        this.ahd_url +
          '&app=' +
          this.verifiedNonDERInfo.patentInfo.applicationNumberText,
        '_blank'
      );
    }
  }

  getTrialTypes() {
    this.initiatePetitionServices
      .getTrialTypes('trialType', true)
      .pipe(take(1))
      .subscribe(
        (trialTypes) => {
          this.trialTypes = trialTypes;
        },
        (trialTypeFailure) => {
          this.logger.error('Error getting trial types: ', trialTypeFailure);
        }
      );
  }

  verifyDERPetition() {
    if (this.verifyDuplicateNumbers()) {
      this.verifying = true;
      this.logger.info('Verification form: ', this.verificationForm);
      this.logger.info('Derivation form: ', this.derivationForm);
      let verifyBy = null;
      let numberToVerify = null;
      if (
        this.derivationForm.value.firstListedPetitionerSelection ===
        'petitionerApplicationNumber'
      ) {
        verifyBy = CONSTANTS.APPLICATION_NUMBER;
        // numberToVerify =
        //   this.derivationForm.value.firstListedPetitionerApplicationValue;
        numberToVerify = this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPetitionerApplicationValue
        );
      } else if (
        this.derivationForm.value.firstListedPetitionerSelection ===
        'petitionerPatentNumber'
      ) {
        verifyBy = CONSTANTS.PATENT_NUMBER;
        // numberToVerify =
        //   this.derivationForm.value.firstListedPetitionerPatentValue;
        numberToVerify = this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPetitionerPatentValue
        );
      }
      this.verifiedDERInfo.petitionerType =
        verifyBy === CONSTANTS.APPLICATION_NUMBER ? 'Application' : 'Patent';
      this.initiatePetitionServices
        .getGeneralInfo(numberToVerify, verifyBy)
        .pipe(take(1))
        .subscribe(
          (info) => {
            this.verifiedDERInfo.petitionerInfo = info;
            this.verifiedDERInfo.petitionerExists = true;
            this.verifyDERPO();
          },
          (generalInfoFailure) => {
            this.verifiedDERInfo.petitionerInfo = null;
            this.verifiedDERInfo.petitionerExists = false;
            this.verifiedDERInfo.petitionerNumber = numberToVerify;
            this.verifyDERPO();
          }
        );
    }
  }

  verifyDERPO() {
    if (this.derivationForm.value.firstListedPOSelection !== 'POUnknown') {
      let verifyBy = null;
      let numberToVerify = null;
      if (
        this.derivationForm.value.firstListedPOSelection ===
        'POApplicationNumber'
      ) {
        verifyBy = CONSTANTS.APPLICATION_NUMBER;
        numberToVerify = this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPOApplicationValue
        );
      } else if (
        this.derivationForm.value.firstListedPOSelection === 'POPatentNumber'
      ) {
        verifyBy = CONSTANTS.PATENT_NUMBER;
        numberToVerify = this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPOPatentValue
        );
      }
      this.verifiedDERInfo.poType =
        verifyBy === CONSTANTS.APPLICATION_NUMBER ? 'Application' : 'Patent';
      this.initiatePetitionServices
        .getGeneralInfo(numberToVerify, verifyBy)
        .pipe(take(1))
        .subscribe(
          (info) => {
            this.verifiedDERInfo.poInfo = info;
            this.verifiedDERInfo.poExists = true;
            this.verifying = false;
            if (!this.verifiedDERInfo.petitionerExists) {
              this.openModal();
            } else {
              this.patentExists = true;
            }
            // this.filingDate = new Date(parseInt(this.info.filingDate) * 1000)
          },
          (generalInfoFailure) => {
            this.verifying = false;
            this.verifiedDERInfo.poExists = false;
            this.verifiedDERInfo.poNumber = numberToVerify;
            this.openModal();
          }
        );
    } else if (
      this.derivationForm.value.firstListedPOSelection === 'POUnknown' &&
      !this.verifiedDERInfo.petitionerExists
    ) {
      // this.verifiedDERInfo.poExists = true;
      this.verifying = false;
      this.openModal();
    } else if (
      this.derivationForm.value.firstListedPOSelection === 'POUnknown' &&
      this.verifiedDERInfo.petitionerExists
    ) {
      this.verifying = false;
      this.patentExists = true;
    } else if (
      this.verifiedDERInfo.petitionerExists &&
      this.verifiedDERInfo.poExists
    ) {
      this.verifying = false;
      this.patentExists = true;
    }
  }

  verifyDuplicateNumbers() {
    if (this.selectedTrialType === 'DER') {
      if (
        this.derivationForm.value.firstListedPetitionerApplicationValue ===
          this.derivationForm.value.firstListedPOApplicationValue &&
        this.derivationForm.value.firstListedPetitionerSelection ===
          'petitionerApplicationNumber' &&
        this.derivationForm.value.firstListedPOSelection ===
          'POApplicationNumber'
      ) {
        this.commonUtils.showError(
          'Petitioner and Patent owner Application number cannot be the same',
          null
        );
        return false;
      } else if (
        this.derivationForm.value.firstListedPetitionerPatentValue ===
          this.derivationForm.value.firstListedPOPatentValue &&
        this.derivationForm.value.firstListedPetitionerSelection ===
          'petitionerPatentNumber' &&
        this.derivationForm.value.firstListedPOSelection === 'POPatentNumber'
      ) {
        this.commonUtils.showError(
          'Petitioner and Patent owner Patent number cannot be the same',
          null
        );
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  verifyPetition() {
    this.verifying = true;
    const cleanedNumber = this.commonUtils.cleanPatentAndApplicationNumbers(
      this.verificationForm.value.patentNumber.trim()
    );
    this.initiatePetitionServices
      .getGeneralInfo(cleanedNumber, 'patentNumber')
      .pipe(take(1))
      .subscribe(
        (patentVerifiedResponse) => {
          this.verifiedNonDERInfo.patentExists = true;
          this.verifiedNonDERInfo.patentInfo = patentVerifiedResponse;
          this.verifying = false;
        },
        (patentVerifiedFailed) => {
          this.logger.error(
            'Patent verification failed:',
            patentVerifiedFailed
          );
          this.verifying = false;
          this.openModal();
        }
      );
  }

  verifyPetitionPatenNumber(e) {
    this.petitionerRegexMatches = false;
    const cleanedNumber = this.commonUtils.cleanPatentAndApplicationNumbers(
      this.derivationForm.value.firstListedPetitionerPatentValue
    );
    if (!this.derivationForm.value.firstListedPetitionerPatentValue) {
      this.derivationForm.controls.firstListedPetitionerPatentValue.markAsPristine();
    }
    if (
      this.derivationForm.value.firstListedPetitionerPatentValue &&
      cleanedNumber.match(this.regex)
    ) {
      this.petitionerRegexMatches = true;
    }
  }

  verifyPOPatenNumber(e) {
    this.poRegexMatches = false;
    const cleanedNumber = this.commonUtils.cleanPatentAndApplicationNumbers(
      this.derivationForm.value.firstListedPOPatentValue
    );
    if (!this.derivationForm.value.firstListedPOPatentValue) {
      this.derivationForm.controls.firstListedPOPatentValue.markAsPristine();
    }
    if (
      this.derivationForm.value.firstListedPOPatentValue &&
      cleanedNumber.match(this.regex)
    ) {
      this.poRegexMatches = true;
    }
  }

  validateDerivationForm() {
    let isFormValid: boolean = false;
    const cleanedPetitionerNumber = this.derivationForm.value
      .firstListedPetitionerPatentValue
      ? this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPetitionerPatentValue
        )
      : null;
    const cleanedPONumber = this.derivationForm.value.firstListedPOPatentValue
      ? this.commonUtils.cleanPatentAndApplicationNumbers(
          this.derivationForm.value.firstListedPOPatentValue
        )
      : null;
    // this.petitionerRegexMatches = false;
    //! Verify first petitioner fields
    if (
      this.derivationForm.value.firstListedPetitionerSelection ===
      'petitionerPatentNumber'
    ) {
      isFormValid = false;
      if (
        this.derivationForm.value.firstListedPetitionerPatentValue &&
        cleanedPetitionerNumber.match(this.regex)
      ) {
        // this.petitionerRegexMatches = true;
        isFormValid = true;
      }
    } else if (
      this.derivationForm.value.firstListedPetitionerSelection ===
      'petitionerApplicationNumber'
    ) {
      isFormValid = false;
      if (this.derivationForm.value.firstListedPetitionerApplicationValue) {
        isFormValid = true;
      }
    }

    //! Verify first PO fields
    if (
      isFormValid &&
      this.derivationForm.value.firstListedPOSelection === 'POApplicationNumber'
    ) {
      isFormValid = false;
      if (this.derivationForm.value.firstListedPOApplicationValue) {
        isFormValid = true;
      }
    } else if (
      isFormValid &&
      this.derivationForm.value.firstListedPOSelection === 'POPatentNumber'
    ) {
      isFormValid = false;
      if (
        this.derivationForm.value.firstListedPOPatentValue &&
        cleanedPONumber.match(this.regex)
      ) {
        isFormValid = true;
      }
    } else if (
      isFormValid &&
      this.derivationForm.value.firstListedPOSelection === 'POUnknown'
    ) {
      isFormValid = true;
    }

    // if (this.derivationForm.value.firstListedPOSelection !== 'POUnknown') {
    //   let val1 =
    //     this.derivationForm.valid &&
    //     this.derivationForm.value.firstListedPOValue.trim();
    //   return !val1;
    // } else {
    //   let val2 = this.derivationForm.valid;
    //   return !val2;
    // }
    return !isFormValid;
  }

  clearForm() {
    this.verificationForm.reset();
    this.derivationForm.reset();
    this.derivationForm.controls.firstListedPetitionerSelection.setValue(
      'petitionerApplicationNumber'
    );
    this.derivationForm.controls.firstListedPOSelection.setValue(
      'POApplicationNumber'
    );
    this.logger.info('Derivation form after clearing', this.derivationForm);
  }

  createPetition() {
    this.creatingPetition = true;
    let petitionInfo = this.setPetitionObj();

    this.initiatePetitionServices
      .createPetition(petitionInfo)
      .pipe(take(1))
      .subscribe(
        (createPetitionSuccess) => {
          this.creatingPetition = false;
          window.sessionStorage.setItem(
            'petitionInfo',
            JSON.stringify(createPetitionSuccess)
          );
          this.store.dispatch(
            setNewPetitionInfo({ request: createPetitionSuccess })
          );
          document.getElementById('ipPetitionInformation').tabIndex = 0;
          const ipClaims = document.getElementById('ipClaims');
          if (ipClaims) {
            ipClaims.tabIndex = 0;
          }
          document.getElementById('ipDocs').tabIndex = 0;
          document.getElementById('ipRealParty').tabIndex = 0;
          document.getElementById('ipAddRealParty').tabIndex = 0;
          const ipCounsel = document.getElementById('ipCounsel');
          if (ipCounsel) {
            ipCounsel.tabIndex = 0;
          }
          document.getElementById('ipReview').tabIndex = 0;
          document.getElementById('ipVerification').tabIndex = -1;
          this.initiatePetitionServices.setOption('verificationComplete', true);
          this.initiatePetitionServices.setOption('enableVerifications', false);
          this.router.navigate(['ui/initiate-petition/petition-information']);
        },
        (createPetitionFailure) => {
          this.logger.info('Create petition failed: ', createPetitionFailure);
          this.commonUtils.showError(
            createPetitionFailure.error.message,
            'Failed creating petition'
          );
          this.creatingPetition = false;
        }
      );
  }

  setPetitionObj() {
    let petitionObj = null;
    if (this.selectedTrialType === 'DER') {
      petitionObj = {
        trialType: this.selectedTrialType,
        petitionerApplDetails: {
          applicationNumber: this.derivationForm.value
            .firstListedPetitionerApplicationValue
            ? this.commonUtils.cleanPatentAndApplicationNumbers(
                this.derivationForm.value.firstListedPetitionerApplicationValue
              )
            : null,
          patentNumber: this.derivationForm.value
            .firstListedPetitionerPatentValue
            ? this.commonUtils.cleanPatentAndApplicationNumbers(
                this.derivationForm.value.firstListedPetitionerPatentValue
              )
            : null,
        },
        patentOwnerApplDetails: {
          applicationNumber: this.derivationForm.value
            .firstListedPOApplicationValue
            ? this.commonUtils.cleanPatentAndApplicationNumbers(
                this.derivationForm.value.firstListedPOApplicationValue
              )
            : null,
          patentNumber: this.derivationForm.value.firstListedPOPatentValue
            ? this.commonUtils.cleanPatentAndApplicationNumbers(
                this.derivationForm.value.firstListedPOPatentValue
              )
            : null,
        },
        submitterEmailAddress: this.commonUtils.getLoggedInUser(),
        audit: {
          lastModifiedUserIdentifier: this.commonUtils.getLoggedInUser(),
          createUserIdentifier: this.commonUtils.getLoggedInUser(),
        },
      };

      if (
        !petitionObj.patentOwnerApplDetails.applicationNumber &&
        !petitionObj.patentOwnerApplDetails.patentNumber
      ) {
        delete petitionObj.patentOwnerApplDetails;
      }
    } else {
      petitionObj = {
        trialType: this.selectedTrialType,
        petitionerApplDetails: {
          applicationNumber: null,
          patentNumber: this.commonUtils.cleanPatentAndApplicationNumbers(
            this.verificationForm.value.patentNumber
          ),
        },
        submitterEmailAddress: this.commonUtils.getLoggedInUser(),
        audit: {
          lastModifiedUserIdentifier: this.commonUtils.getLoggedInUser(),
          createUserIdentifier: this.commonUtils.getLoggedInUser(),
        },
      };
    }
    return petitionObj;
  }

  openModal() {
    const initialState: ModalOptions = {
      initialState: {
        trialType: this.selectedTrialType,
        verifiedInfo: this.verifiedDERInfo,
        continueWithPetition: false,
      },
    };
    this.modalRef = this.modalService.show(
      VerificationModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.modalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.continueWithPetition) {
        this.store.dispatch(
          setTrialInfo({
            request: { trialType: this.selectedTrialType },
          })
        );
        if (this.selectedTrialType === 'DER') {
          this.patentExists = true;
          this.verifiedNonDERInfo.patentExists = false;
        } else {
          this.patentExists = false;
          this.verifiedNonDERInfo.patentExists = true;
        }
        // this.verifyDERPetition();
        // this.createPetition();
      } else {
        this.verifiedDERInfo.petitionerInfo = null;
        this.verifiedDERInfo.poInfo = null;
      }
    });
  }

  startOver() {
    this.patentExists = false;
    this.verifiedNonDERInfo.patentExists = false;
    this.verifiedNonDERInfo.patentInfo = null;
    this.clearForm();
    this.selectedTrialType = 'default';
    this.verifiedDERInfo.petitionerInfo = null;
    this.verifiedDERInfo.poInfo = null;
  }

  resetValue(selection) {
    switch (selection) {
      case 'petitionerAppl':
        this.derivationForm.controls.firstListedPetitionerPatentValue.setValue(
          null
        );
        break;
      case 'petitionerPatent':
        this.derivationForm.controls.firstListedPetitionerApplicationValue.setValue(
          null
        );
        break;
      case 'poApplication':
        this.derivationForm.controls.firstListedPOPatentValue.setValue(null);
        break;
      case 'poPatent':
        this.derivationForm.controls.firstListedPOApplicationValue.setValue(
          null
        );
        break;
      case 'poUnknown':
        this.derivationForm.controls.firstListedPOPatentValue.setValue(null);
        this.derivationForm.controls.firstListedPOApplicationValue.setValue(
          null
        );
        this.verifiedDERInfo.poNumber = null;
        break;
      default:
        break;
    }
  }
}
