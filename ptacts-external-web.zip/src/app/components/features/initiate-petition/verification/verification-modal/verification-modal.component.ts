import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-verification-modal',
  templateUrl: './verification-modal.component.html',
  styleUrls: ['./verification-modal.component.scss'],
})
export class VerificationModalComponent implements OnInit {
  modalData = this.modalService.config.initialState;

  constructor(
    public modalRef: BsModalRef,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {}

  closeModal(continueWithPetition) {
   
   
    this.modalService.config.initialState.continueWithPetition =
      continueWithPetition;
    this.modalService.hide();
  }
}
