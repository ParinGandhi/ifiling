import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Urls } from 'src/app/constants/urls';
import { environment } from 'src/environments/environment';

import { MultipleEmailModalComponent } from './parties/multiple-email-modal/multiple-email-modal.component';
import { NGXLogger } from 'ngx-logger';
import { DocumentToAdd } from 'src/app/models/documents/DocumentToAdd.model';
import { EditDocument } from 'src/app/models/documents/EditDocument.model';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { InfoModalComponent } from '../../common/info-modal/info-modal.component';
import { Router } from '@angular/router';
// import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class InitiatePetitionService {
  private COMMON_BASE_URL: string = environment.COMMON_SERVICE_API;
  private TRIAL_BASE_URL: string = environment.TRIAL_SERVICE_API;
  private EXTERNAL_SERVICE_BASE: string = environment.EXTERNAL_SERVICE_API;
  private CASEVIEWER_SERVICE_API: string = environment.CASEVIEWER_SERVICE_API;
  private completeOrNotFlag = {};
  withdrawModalRef: BsModalRef;

  constructor(
    private http: HttpClient,
    private logger: NGXLogger,
    public modalService: BsModalService,
    private router: Router,
    // private commonUtils: CommonUtilitiesService,
    private toastr: ToastrService
  ) {}

  setOption(option, value) {
    this.completeOrNotFlag[option] = value;
  }

  getOption() {
    return this.completeOrNotFlag;
  }

  getHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'user-name': emailId,
      }),
      withCredentials: true,
      crossDomain: true,
    };

    return httpOptions;
  }

  getDownloadHeaders() {
    const emailId = window.sessionStorage.getItem('email');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true,
      crossDomain: true,
      responseType: 'arraybuffer' as 'json',
    };

    return httpOptions;
  }

  getTrialTypes(referenceType: string, isPublic: boolean) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((trialTypes) => {
          return trialTypes;
        })
      );
  }

  // TODO Change to external service
  getCaseInfoByProceedingNo(proceedingNo: string): Observable<any> {
    const email = window.sessionStorage.getItem('email');
    let url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PETITIONS}${proceedingNo}`;
    if (email === 'anonymous') {
      url = `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.PETITIONS}${proceedingNo}`;
    }
    return (
      this.http
        // .get<any>(`${this.COMMON_BASE_URL}${Urls.PETITIONS}${proceedingNo}`)
        .get<any>(url)
        .pipe(
          map((proceedingNumberInfo) => {
            return proceedingNumberInfo;
          })
        )
    );
  }

  getStatutoryGrounds(
    referenceType: string,
    isPublic: boolean,
    trialType: string
  ) {
    return this.http
      .get<any>(
        // `${this.COMMON_BASE_URL}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}&trialType=${trialType}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}&trialType=${trialType}`
      )
      .pipe(
        map((statutoryGrounds) => {
          return statutoryGrounds;
        })
      );
  }

  getClaims(caseNum: string) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/petition-claims?proceedingNumber=${caseNum}`
        // `${this.TRIAL_BASE_URL}${Urls.CLAIMS_GET}?proceedingNumber=${caseNum}`
        // `https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/petition-claims?proceedingNumber=IPR2014-00497`
      )
      .pipe(
        map((claimsInfo) => {
          return claimsInfo;
        })
      );
  }

  uploadClaims(claimsData) {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CLAIMS_UPLOAD}`,
        // `https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/pcdng-claims/`,
        // `${this.TRIAL_BASE_URL}${Urls.CLAIMS_UPLOAD}`,
        claimsData
      )
      .pipe(
        map((claim) => {
          return claim;
        })
      );
  }

  updateClaim(claimsData) {
    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CLAIMS_UPLOAD}`,
        //`https://ptacts-intservices.pvt.uspto.gov/PTABTrialsServices/pcdng-claims/`,
        // `${this.TRIAL_BASE_URL}${Urls.CLAIMS_UPLOAD}`,
        claimsData
      )
      .pipe(
        map((claim) => {
          return claim;
        })
      );
  }

  deleteClaim(claimId) {
    return this.http.delete<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.CLAIMS_UPLOAD}/${claimId}`
      // `${this.TRIAL_BASE_URL}${Urls.CLAIMS_UPLOAD}${claimId}`
    );
  }

  getGeneralInfo(patentNumber: string, searchBy: string) {
    return this.http
      .get<any>(
        //`${this.COMMON_BASE_URL}${Urls.OPSG_GENERAL}?${searchBy}=${patentNumber}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.OPSG_GENERAL_NEW}?${searchBy}=${patentNumber}`
      )
      .pipe(
        map((generalInfo) => {
          if (generalInfo.grantDate) {
            generalInfo.grantDate = new Date(
              parseInt(generalInfo.grantDate) * 1000
            );
          }
          if (generalInfo.filingDate) {
            generalInfo.filingDate = new Date(
              parseInt(generalInfo.filingDate) * 1000
            );
          }
          // generalInfo.lastRecordedAssignmentDate = new Date(
          //   parseInt(generalInfo.lastRecordedAssignmentDate) * 1000
          // );
          return generalInfo;
        })
      );
  }

  getPaperTypes(
    referenceType: string,
    proceedingNumber: string,
    recipientType: string
  ) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.PAPER_TYPES}${referenceType}&proceedingNumber=${proceedingNumber}&recipientType=${recipientType}`
      )
      .pipe(
        map((paperTypes) => {
          return paperTypes.stateDocumentTypes;
        })
      );
  }

  getAvailabilities(referenceType: string, isPublic: boolean) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REFERENCE_TYPES}${referenceType}&isPublic=${isPublic}`
      )
      .pipe(
        map((availabilities) => {
          return availabilities;
        })
      );
  }

  getDocuments(proceedingNumber: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.GET}${proceedingNumber}`
      )
      .pipe(
        map((documentListResponse) => {
          return documentListResponse;
          // const documentList = [];
          // if (documentListResponse && documentListResponse.length > 0) {
          //   documentListResponse.forEach((document) => {
          //     const doc = {
          //       docNumber:
          //         document.category.toLowerCase() === 'paper'
          //           ? '--'
          //           : document.exhibitNumber,
          //       uploadedDate: document.filingDateString,
          //       docType: document.category,
          //       paperType:
          //         document.category.toLowerCase() === 'paper'
          //           ? document.documentTypeDescription
          //           : '',
          //       documentName: document.name,
          //       pages: document.pageCount,
          //       availability: document.availability,
          //       availabilityCode: document.availablitySummary.code,
          //       documentTypeIdentifier: document.documentTypeIdentifier,
          //       fileName: document.fileName,
          //       artifactIdentifer: document.artifactIdentifer,
          //     };
          //     documentList.push(doc);
          //   });
          // }
          // return documentList;
        })
      );
  }

  getUnsubmittedDocuments(proceedingNumber: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.UNSUBMITTEDGET}${proceedingNumber}`
      )
      .pipe(
        map((documentListResponse) => {
          return documentListResponse;
        })
      );
  }

  addToList(fileToUpload: any, category: string, petitionIdentifier: string) {
    const formData: FormData = new FormData();
    // formData.append('file', fileToUpload);
    formData.append('file', fileToUpload);
    formData.set('category', category);
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionIdentifier}/documents`,
        formData
      )
      .pipe(
        map(
          (documentData) => {
            return documentData;
          }
          // catchError((err) => {
          //   this.commonUtils.throwError('Testing error from service', err);
          //   return of();
          // })
        )
      );
  }

  saveToCMS(petitionDocument: DocumentToAdd): Observable<any> {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.SAVE_TO_CMS}`,
        petitionDocument
      )
      .pipe(
        map((savedDocument) => {
          return savedDocument;
        })
      );
  }

  updateDocument(docToUpdate: any, artifactId): Observable<any> {
    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.EDIT}${artifactId}`,
        docToUpdate
      )
      .pipe(
        map((editDocumentResponse) => {
          return editDocumentResponse;
        })
      );
  }

  deleteDocument(artifactIdentifer: number): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.DELETE}${artifactIdentifer}`
      )
      .pipe(
        map((deleteDocumentResponse) => {
          return deleteDocumentResponse;
        })
      );
  }

  getNextExhibitNumber(proceedingNumber: string) {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.NEXT_EXHIBIT_NO}${proceedingNumber}`
      )
      .pipe(
        map((exhibitNumbers) => {
          return exhibitNumbers;
        })
      );
  }

  createPetition(petitionInfo): Observable<any> {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.CREATE_PETITION}`,
        petitionInfo
      )
      .pipe(
        map((createPetitionResponse) => {
          return createPetitionResponse;
        })
      );
  }

  getCountries() {
    //
    return (
      this.http
        // .get<any>(`${this.TRIAL_BASE_URL}/geo-region/get-countriesinfo/TRAILS`)
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}/geo-region/get-countriesinfo/TRAILS`
        )
        .pipe(
          map((countriesList) => {
            // return countriesList.responseData[0];
            return countriesList;
          })
        )
    );
  }

  getStates(countryCode: string): Observable<any> {
    return this.http
      .get<any>(
        // `${this.TRIAL_BASE_URL}/geo-region/get-statesinfo/TRAILS/${countryCode}`
        `${this.EXTERNAL_SERVICE_BASE}/geo-region/get-statesinfo/TRAILS/${countryCode}`
      )
      .pipe(
        map((statesList) => {
          if (
            // statesList &&
            // statesList.responseData &&
            // statesList.responseData.length > 0
            statesList &&
            statesList.length > 0
          ) {
            // return statesList.responseData[0];
            return statesList;
          } else {
            return null;
          }
        })
      );
  }

  findByRegOrEmail(searchCriteria: string): Observable<any> {
    return this.http
      .get<any>(
        `${this.EXTERNAL_SERVICE_BASE}/proceeding-party-details/counsels/TRAILS?${searchCriteria}`
      )
      .pipe(
        map((foundListResponse) => {
          if (
            foundListResponse.length > 0 &&
            foundListResponse[0]?.parties.length > 0
          ) {
            return foundListResponse[0].parties;
          } else {
            return new Array();
          }
        })
      );
  }

  addRealParty(petitionerRealParty: any, isProSe: string): Observable<any> {
    // let url = `${this.TRIAL_BASE_URL}${Urls.REAL_PARTY.ADD}`;
    let url = `${this.EXTERNAL_SERVICE_BASE}${Urls.REAL_PARTY.ADD}`;
    if (isProSe === 'Yes') {
      url = `${url}?partyRepresentIndicator=Y`;
    }
    return this.http.post<any>(url, petitionerRealParty).pipe(
      map((addRealPartyResponse) => {
        return addRealPartyResponse;
      })
    );
  }

  updateRealParty(petitionerRealParty: any): Observable<any> {
    return this.http
      .put<any>(
        // `${this.TRIAL_BASE_URL}${Urls.REAL_PARTY.ADD}`,
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REAL_PARTY.ADD}`,
        petitionerRealParty
      )
      .pipe(
        map((updatePartyResponse) => {
          return updatePartyResponse;
        })
      );
  }

  getRealParty(proceedingNo: string): Observable<any> {
    return (
      this.http
        // .get<any>(`${this.TRIAL_BASE_URL}${Urls.REAL_PARTY.GET}${proceedingNo}`)
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}${Urls.REAL_PARTY.GET}${proceedingNo}`
        )
        .pipe(
          map((realPartyResponse) => {
            return realPartyResponse;
          })
        )
    );
  }

  deleteRealParty(
    proceedingNo: string,
    partyIdentifer: number
  ): Observable<any> {
    return this.http
      .delete<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.REAL_PARTY.DELETE}${proceedingNo}` +
          `&proceedingPartyIdentifier=` +
          `${partyIdentifer}`
      )
      .pipe(
        map((deleteRealPartyResponse) => {
          return deleteRealPartyResponse;
        })
      );
  }

  addCounsel(counsel: any, partyRepresentIndicator: string): Observable<any> {
    return this.http
      .post<any>(
        // `${this.TRIAL_BASE_URL}${Urls.COUNSEL.ADD}${partyRepresentIndicator}`,
        `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.ADD}${partyRepresentIndicator}`,
        counsel
      )
      .pipe(
        map((addCounselResponse) => {
          this.logger.info('Successfully added counsel: ', addCounselResponse);
          return addCounselResponse;
        })
      );
  }

  addRegNo(obj: any): Observable<any> {
    return this.http
      .put<any>(
        `${this.EXTERNAL_SERVICE_BASE}/rbac-okta/update-registration-number`,
        obj
      )
      .pipe(
        map((addRegNoResponse) => {
          this.logger.info('Successfully added regNo: ', addRegNoResponse);
          return addRegNoResponse;
        })
      );
  }

  getCounsels(proceedingNo: string): Observable<any> {
    return (
      this.http
        // .get<any>(`${this.TRIAL_BASE_URL}${Urls.COUNSEL.GET}${proceedingNo}`)
        .get<any>(
          `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.GET}${proceedingNo}`
        )
        .pipe(
          map((counselResponse) => {
            let tempCounselList = [];
            if (counselResponse?.petitionCounsel?.parties.length > 0) {
              this.logger.info(
                'Counsels:',
                counselResponse.petitionCounsel.parties
              );

              counselResponse.petitionCounsel.parties.forEach((element) => {
                let existingCounsel = {
                  counselType: element.partySubTypeDescription,
                  partySubType: element.partySubType,
                  name: `${element.personType[0].firstName} ${element.personType[0].lastName}`,
                  email: null,
                  regNo: element.registrationNo,
                  phoneNo: null,
                  fax: null,
                  counselInfo: element,
                };
                if (
                  element.personType[0].electronicAddress &&
                  element.personType[0].electronicAddress.length > 0
                ) {
                  element.personType[0].electronicAddress.forEach(
                    (electronicAddress) => {
                      if (electronicAddress.telephoneNumber) {
                        existingCounsel.phoneNo =
                          electronicAddress.telephoneNumber;
                      }
                      if (electronicAddress.fax) {
                        existingCounsel.fax = electronicAddress.fax;
                      }
                      if (electronicAddress.email) {
                        existingCounsel.email = electronicAddress.email;
                      }
                    }
                  );
                }
                tempCounselList.push(existingCounsel);
              });
            }
            return tempCounselList;
          })
        )
    );
  }

  updateCounsel(counselToUpdate: any): Observable<any> {
    return (
      this.http
        // .put<any>(`${this.TRIAL_BASE_URL}${Urls.COUNSEL.UPDATE}`, counselToUpdate)
        .put<any>(
          `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.UPDATE}`,
          counselToUpdate
        )
        .pipe(
          map((updateCounselResponse) => {
            return updateCounselResponse;
          })
        )
    );
  }

  swapCounsel(counselToUpdate: any, isLeadCounsel: boolean): Observable<any> {
    return this.http
      .put<any>(
        // `${this.TRIAL_BASE_URL}${Urls.COUNSEL.SWAP}${isLeadCounsel}`,
        `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.SWAP}${isLeadCounsel}`,
        counselToUpdate
      )
      .pipe(
        map((swapCounselResponse) => {
          return swapCounselResponse;
        })
      );
  }

  deleteCounsel(
    proceedingNumber: string,
    proceedingPartyIdentifier: number
  ): Observable<any> {
    return this.http
      .delete<any>(
        // `${this.TRIAL_BASE_URL}${Urls.COUNSEL.DELETE}${proceedingNumber}&proceedingPartyIdentifier=${proceedingPartyIdentifier}`
        `${this.EXTERNAL_SERVICE_BASE}${Urls.COUNSEL.DELETE}${proceedingNumber}&proceedingPartyIdentifier=${proceedingPartyIdentifier}`
      )
      .pipe(
        map((deleteCounselResponse) => {
          return deleteCounselResponse;
        })
      );
  }

  getECFRUrls(): Observable<any> {
    return (
      this.http
        // .get<any>(`${this.CASEVIEWER_SERVICE_API}${Urls.ECFR_URL}`)
        .get<any>(`${this.EXTERNAL_SERVICE_BASE}${Urls.ECFR_URL}`)
        .pipe(
          map((urlResponse) => {
            return urlResponse;
          })
        )
    );
  }

  getAHDUrls(): Observable<any> {
    return (
      this.http
        // .get<any>(`${this.CASEVIEWER_SERVICE_API}${Urls.AHD_URL}`)
        .get<any>(`${this.EXTERNAL_SERVICE_BASE}${Urls.AHD_URL}`)
        .pipe(
          map((urlResponse) => {
            return urlResponse;
          })
        )
    );
  }

  getPaymentInfoByProceedingNo(
    proceedingNo: string,
    isMotionFee: boolean
  ): Observable<any> {
    let url = `${this.EXTERNAL_SERVICE_BASE}${Urls.FEE_CALCULATION}${proceedingNo}`;
    let urlText = isMotionFee ? url + '&isMotionFeeCalculation=true' : url;
    return this.http.get<any>(urlText).pipe(
      map((paymentInfo) => {
        return paymentInfo;
      })
    );
  }

  submitPetition(data) {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.DOCUMENTS.submitDocuments}`,
        data
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  // TODO Change to external service
  openPdfWithFileName(url) {
    // window.open(this.COMMON_BASE_URL + url);
    // window.open(this.EXTERNAL_SERVICE_BASE + url);
    return this.http.get(
      this.EXTERNAL_SERVICE_BASE + url,
      // 'https://ptacts-pvt.etc.uspto.gov/ptacts' + url,
      this.getDownloadHeaders()
    );
  }

  withdraw(proceedingNumber: string) {
    const initialState: ModalOptions = {
      initialState: {
        modal: {
          isConfirm: false,
          title: 'Warning - Withdraw Petition',
          infoText: [
            'This action will delete the initiated AIA Review Petition including all saved data for this petition. Do you wish to continue?',
          ],
          showLeftBtn: true,
          leftBtnClass: 'btn-light',
          leftBtnLabel: 'No, Cancel and return to previous screen.',
          showRightBtn: true,
          rightBtnClass: 'btn-danger',
          rightBtnLabel: 'Yes, Delete this petition.',
          modalHeight: 175,
        },
      },
      class: 'modal-lg',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.withdrawModalRef = this.modalService.show(
      InfoModalComponent,
      initialState
    );
    this.removeModalFadeClass();
    this.withdrawModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.modal.isConfirm) {
        window.sessionStorage.setItem('withdrawPetition', 'deletePetition');
        this.deletePetition(proceedingNumber).subscribe(
          (Response) => {
            this.showSuccess(`The Petition has been successfully deleted.`, '');
            if (window.sessionStorage.getItem('source')) {
              setTimeout(() => {
                window.close();
              }, 2000);
            } else {
              this.router.navigate(['/ui/my-docket']);
            }
          },
          (withdrawPetitionError) => {
            this.showError('Withdraw petition failed', withdrawPetitionError);
          }
        );
        this.verificationRoute();
      }
    });
  }

  deletePetition(proceedingNumber) {
    return this.http.delete<any>(
      `${this.EXTERNAL_SERVICE_BASE}${Urls.PETITIONS}${proceedingNumber}`
    );
  }
  verificationRoute() {
    window.sessionStorage.setItem('petitionInfo', '');
    this.setOption('verificationComplete', '');
    this.setOption('verificationInComplete', '');
    this.setOption('informationComplete', '');
    this.setOption('informationInComplete', '');
    this.setOption('additionalRealPartyComplete', '');
    this.setOption('additionalRealPartyInComplete', '');
    this.setOption('claimsComplete', '');
    this.setOption('claimsInComplete', '');
    this.setOption('documentsComplete', '');
    this.setOption('documentsInComplete', '');
    this.setOption('realPartyInComplete', '');
    this.setOption('realPartyComplete', '');
    this.setOption('counselComplete', '');
    this.setOption('counselInComplete', '');
    this.setOption('noticePaperType', '');
    this.setOption('petitionPaperType', '');
    this.setOption('noNoticePaperType', '');
    this.setOption('noPetitionPaperType', '');
    this.setOption('hasAttorneyPaperType', '');
    this.setOption('proseFlag', '');
    this.setOption('isDER', '');
  }

  redirectToFPNG(petitionIdentifier, data) {
    return this.http
      .post<any>(
        `${this.EXTERNAL_SERVICE_BASE}/petitions/${petitionIdentifier}/payments`,
        data
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getPaymentsReceipt(proceedingNo: string): Observable<any> {
    let url = `${this.EXTERNAL_SERVICE_BASE}/petitions/${proceedingNo}/payments/receipt`;
    return this.http.get<any>(url).pipe(
      map((paymentReceipt) => {
        return paymentReceipt;
      })
    );
  }

  getBasicPetitionDetails(proceedingNumber: string): Observable<any> {
    let url = `${this.EXTERNAL_SERVICE_BASE}/proceeding/basic-petition-details?proceedingNumber=${proceedingNumber}`;
    return this.http.get<any>(url).pipe(
      map((petitionDetails) => {
        return petitionDetails;
      })
    );
  }

  getHelpLink() {
    return this.http
      .get(`${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.HELP_LINK}`, {
        headers: { 'user-name': 'anonymous' },
      })
      .pipe(
        map((helpLinkResponse) => {
          return helpLinkResponse;
        })
      );
  }

  getVersions() {
    return this.http
      .get(
        `${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.PTACTS_VERSIONS}`,
        {
          headers: { 'user-name': 'anonymous' },
        }
      )
      .pipe(
        map((versionsResponse) => {
          return versionsResponse;
        })
      );
  }

  getOktaLinks() {
    return this.http
      .get(`${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.OKTA_LINK}`, {
        headers: { 'user-name': 'anonymous' },
      })
      .pipe(
        map((oktaLinkResponse) => {
          return oktaLinkResponse;
        })
      );
  }

  getMyUSPTOLink() {
    return this.http
      .get(`${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.MYUSPTO_LINK}`, {
        headers: { 'user-name': 'anonymous' },
      })
      .pipe(
        map((myUSPTOLinkResponse) => {
          return myUSPTOLinkResponse;
        })
      );
  }

  getIFILING_LINK() {
    return this.http
      .get(`${this.EXTERNAL_SERVICE_BASE}${Urls.PUBLIC}${Urls.IFILING_LINK}`, {
        headers: { 'user-name': 'anonymous' },
      })
      .pipe(
        map((iFILING_LINKResponse) => {
          return iFILING_LINKResponse;
        })
      );
  }

  removeModalFadeClass() {
    setTimeout(() => {
      let modalContainer = document.getElementsByTagName(
        'modal-container'
      ) as HTMLCollectionOf<HTMLDivElement>;

      for (const tag of Array.from(modalContainer)) {
        tag.classList.remove('fade');
      }
    }, 200);
  }

  showSuccess(message, title) {
    this.toastr.success(message, title, {
      timeOut: 5500,
      closeButton: true,
    });
  }

  showError(title, message) {
    this.toastr.error(message?.error?.message, title, {
      timeOut: 9900,
      closeButton: true,
    });
  }
}
