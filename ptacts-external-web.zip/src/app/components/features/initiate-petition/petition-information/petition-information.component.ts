import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { CaseViewerService } from '../../case-viewer/case-viewer.service';
import { InitiatePetitionService } from '../initiate-petition.service';

@Component({
  selector: 'app-petition-information',
  templateUrl: './petition-information.component.html',
  styleUrls: ['./petition-information.component.scss'],
})
export class PetitionInformationComponent implements OnInit {
  petitionInfo = null;
  trialTypes: any;
  trialType: any;
  patentNumber: any;
  applicationNumberText: any;
  groupArtUnitNumber: any;
  techCenter: any;
  poPatentNumber: any;
  poApplicationNumberText: any;
  poGroupArtUnitNumber: any;
  poTechCenter: any;
  onBehalfOf: string = null;
  ptactsCaseInfo: any = null;

  constructor(
    private logger: NGXLogger,
    public initiatePetitionServices: InitiatePetitionService,
    private router: Router,
    private caseViewerService: CaseViewerService,
    private store: Store<PtactsState>
  ) {}

  ngOnInit(): void {
    this.onBehalfOf = window.sessionStorage.getItem('onBehalfOf');
    // this.store
    //   .select(PtactsSelectors.ptactsStateData)
    //   .pipe(take(1))
    //   .subscribe((savedState) => {
    //     this.petitionInfo = savedState.newPetitionInfo;
    //   });
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
     
    this.setValues();
    if (this.petitionInfo.trialType === 'DER') {
      // this.verifyPetition(this.petitionInfo.petitionerPatentNumber);
      // this.verifyPO(this.petitionInfo.patentNumber);
      this.getCaseHeaderInfo(); 
    } else {
      if(this.petitionInfo.patentNumber){
        this.verifyPetition(this.petitionInfo.patentNumber);
      }
      else if(this.petitionInfo?.petitionerApplDetails?.patentNumber){
        this.verifyPetition(this.petitionInfo?.petitionerApplDetails?.patentNumber);
      }
      
    }
    this.getTrialTypes();
  }

  getCaseHeaderInfo() {
    this.caseViewerService
      .getCaseHeaderInfo(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe((caseHeaderResponse) => {
        this.ptactsCaseInfo = caseHeaderResponse[0];
        this.patentNumber = this.ptactsCaseInfo?.petitionerPatentNumber;
        this.applicationNumberText = this.ptactsCaseInfo?.derproceedingTypeDetails.firstListedPetitionerApplicationNumber;
        this.groupArtUnitNumber = this.ptactsCaseInfo?.petitionerArtUnit;
        this.techCenter = this.ptactsCaseInfo?.petitionerTechCenterNum;
        this.poPatentNumber = this.ptactsCaseInfo?.patentNumberText;
        this.poApplicationNumberText = this.ptactsCaseInfo?.derproceedingTypeDetails.firstListedPatentOwnerRespondentApplicationNumber;
        this.poGroupArtUnitNumber = this.ptactsCaseInfo?.techCenterNum;
        this.poTechCenter = this.ptactsCaseInfo?.artUnit;
      });
  }

  getTrialTypes() {
    this.initiatePetitionServices
      .getTrialTypes('trialType', true)
      .pipe(take(1))
      .subscribe(
        (trialTypes) => {
          this.trialTypes = trialTypes;
          this.setTrailType();
        },
        (trialTypeFailure) => {
          this.logger.error('Error getting trial types: ', trialTypeFailure);
        }
      );
  }

  setTrailType() {
    this.trialTypes.forEach((element) => {
      if (this.petitionInfo.trialType == element.code) {
        this.trialType = element.descriptionText;
      }
    });
    if (this.petitionInfo.trialType === 'DER') {
      this.initiatePetitionServices.setOption('isDER', true);
    }
  }

  continue() {
    if (this.petitionInfo.trialType === 'DER') {
      this.initiatePetitionServices.setOption('isDER', true);
      this.router.navigate(['/ui/initiate-petition/petition-documents']);
    } else {
      this.initiatePetitionServices.setOption('isDER', false);
      this.router.navigate(['/ui/initiate-petition/claims-challenged']);
    }
    this.initiatePetitionServices.setOption('informationComplete', true);
  }

  verifyPetition(patentNumber) {
    this.initiatePetitionServices
      .getGeneralInfo(patentNumber, 'patentNumber')
      .pipe(take(1))
      .subscribe(
        (patentVerifiedResponse) => {
          this.patentNumber = patentVerifiedResponse.patentNumber;
          this.applicationNumberText =
            patentVerifiedResponse.applicationNumberText;
          this.groupArtUnitNumber = patentVerifiedResponse.groupArtUnitNumber;
          this.techCenter = patentVerifiedResponse.techCenter;
        },
        (patentVerifiedFailed) => {
          this.logger.error(
            'Patent verification failed:',
            patentVerifiedFailed
          );
          if(patentNumber!=undefined){
            this.patentNumber = patentNumber;
          }
          else if(this.petitionInfo?.petitionerApplDetails?.patentNumber){
            this.patentNumber = this.petitionInfo?.petitionerApplDetails?.patentNumber;
          }
          if(this.petitionInfo?.petitionerApplDetails?.applicationNumber){
            this.applicationNumberText = this.petitionInfo?.petitionerApplDetails?.applicationNumber;
          }
          else if(this.petitionInfo?.petitionerApplicationNumber){
            this.applicationNumberText = this.petitionInfo?.petitionerApplicationNumber;
          }
        }
      );
  }

  verifyPO(patentNumber) {
    this.initiatePetitionServices
      .getGeneralInfo(patentNumber, 'patentNumber')
      .pipe(take(1))
      .subscribe(
        (patentVerifiedResponse) => {
          this.poPatentNumber = patentVerifiedResponse.patentNumber;
          this.poApplicationNumberText =
            patentVerifiedResponse.applicationNumberText;
          this.poGroupArtUnitNumber = patentVerifiedResponse.groupArtUnitNumber;
          this.poTechCenter = patentVerifiedResponse.techCenter;
        },
        (patentVerifiedFailed) => {
          this.logger.error(
            'Patent verification failed:',
            patentVerifiedFailed
          );
          if(patentNumber!=undefined){
            this.poPatentNumber = patentNumber;
          }
          else if(this.petitionInfo?.patentOwnerApplDetails?.patentNumber){
            this.poPatentNumber = this.petitionInfo?.patentOwnerApplDetails?.patentNumber;
          }
          if(this.petitionInfo?.patentOwnerApplDetails?.applicationNumber){
            this.poApplicationNumberText = this.petitionInfo?.patentOwnerApplDetails?.applicationNumber;
          }
          else if(this.petitionInfo?.poApplicationNumber){
            this.poApplicationNumberText = this.petitionInfo?.poApplicationNumber;
          }
        }
      );
  }

  setValues() {
    if (this.petitionInfo?.petitionerApplDetails) {
      this.patentNumber =
        this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.patentNumber;
      this.applicationNumberText =
        this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.applicationNumberText;
      this.groupArtUnitNumber =
        this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.groupArtUnitNumber;
      this.techCenter =
        this.petitionInfo?.petitionerApplDetails?.applicationBasicInformation?.techCenter;
    }
    if (
      this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation
    ) {
      this.poPatentNumber =
        this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.patentNumber;
      this.poApplicationNumberText =
        this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.applicationNumberText;
      this.poGroupArtUnitNumber =
        this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.groupArtUnitNumber;
      this.poTechCenter =
        this.petitionInfo?.patentOwnerApplDetails?.applicationBasicInformation?.techCenter;
    }
  }
}
