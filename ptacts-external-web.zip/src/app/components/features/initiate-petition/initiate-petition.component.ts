import { Component, OnInit } from '@angular/core';
import { InitiatePetitionService } from './initiate-petition.service';
import { take } from 'rxjs/operators';
import { NGXLogger } from 'ngx-logger';
import { Router } from '@angular/router';

@Component({
  selector: 'app-initiate-petition',
  templateUrl: './initiate-petition.component.html',
  styleUrls: ['./initiate-petition.component.scss'],
})
export class InitiatePetitionComponent implements OnInit {
  public verificationFlag;
  petitionInfo: any = {};
  claimsInfo: any;
  petitionPaperType: boolean = false;
  noticePaperType: boolean = false;
  validLeadCounsel: boolean = false;
  showclaims: boolean = false;

  constructor(private initiatePetitionServices: InitiatePetitionService) {
    this.verificationFlag = initiatePetitionServices.getOption();
  }

  ngOnInit(): void {
    document.title = 'Initiate petition';
    setTimeout(() => {
      if (window.sessionStorage.getItem('petitionInfo')) {
        this.petitionInfo = JSON.parse(
          window.sessionStorage.getItem('petitionInfo')
        );
        if (this.petitionInfo.trialType === 'DER') {
          this.initiatePetitionServices.setOption('isDER', true);
        }
        if (this.petitionInfo.trialType !== 'DER') {
          this.showclaims = true;
          this.getClaimsList();
        }
        if(!this.verificationFlag.fpngCancel){
          this.initiatePetitionServices.setOption("fpngCancel", false);
          this.getDocuments();
          setTimeout(() => {
            this.getExistingRealParty();
          }, 500);
          this.getExistingCounsels();
        }
      }
    }, 200);
  }

  getClaimsList() {
    this.initiatePetitionServices
      .getClaims(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (claimsInfo) => {
          this.claimsInfo = claimsInfo;
          this.initiatePetitionServices.setOption('claimsComplete', true);
          this.initiatePetitionServices.setOption('claimsInComplete', false);
        },
        (claimsFailure) => {
          //this.logger.error('Failed to retrieve claims: ', claimsFailure);
          this.initiatePetitionServices.setOption('claimsComplete', false);
          this.initiatePetitionServices.setOption('claimsInComplete', true);
        }
      );
  }

  getDocuments() {
    this.initiatePetitionServices
      .getUnsubmittedDocuments(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (petitionDocumentList) => {
          for (let i = 0; i < petitionDocumentList.length; i++) {
            if (
              petitionDocumentList[i].documentTypeDescription ==
              'Petition: as filed'
            ) {
              this.initiatePetitionServices.setOption(
                'petitionPaperType',
                true
              );
              this.initiatePetitionServices.setOption(
                'noPetitionPaperType',
                false
              );
              break;
            } else {
              this.initiatePetitionServices.setOption(
                'noPetitionPaperType',
                true
              );
              this.initiatePetitionServices.setOption(
                'petitionPaperType',
                false
              );
            }
          }

          for (let i = 0; i < petitionDocumentList.length; i++) {
            if (
              petitionDocumentList[i].documentTypeDescription ==
              'Notice:  Power of Attorney'
            ) {
              this.initiatePetitionServices.setOption(
                'noNoticePaperType',
                false
              );
              this.initiatePetitionServices.setOption('noticePaperType', true);
              this.initiatePetitionServices.setOption(
                'hasAttorneyPaperType',
                true
              );
              break;
            } else {
              this.initiatePetitionServices.setOption(
                'noNoticePaperType',
                true
              );
              this.initiatePetitionServices.setOption('noticePaperType', false);
              this.initiatePetitionServices.setOption(
                'hasAttorneyPaperType',
                false
              );
            }
          }
        },
        (failure) => {
          this.initiatePetitionServices.setOption('petitionPaperType', false);
          this.initiatePetitionServices.setOption('noticePaperType', false);
          this.initiatePetitionServices.setOption('noPetitionPaperType', true);
          this.initiatePetitionServices.setOption('noNoticePaperType', true);
          this.initiatePetitionServices.setOption(
            'hasAttorneyPaperType',
            false
          );
        }
      );
  }

  getExistingRealParty() {
    this.initiatePetitionServices
      .getRealParty(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (existingRealPartyResponse) => {
         
          if (
            existingRealPartyResponse.petitionRealParty &&
            existingRealPartyResponse.petitionRealParty.parties.length > 0
          ) {
            for (
              var i =
                existingRealPartyResponse.petitionRealParty.parties.length - 1;
              i >= 0;
              i--
            ) {
              if (
                existingRealPartyResponse.petitionRealParty.parties[i]
                  .partyType == 'REAL PARTY'
              ) {
                if (
                  existingRealPartyResponse.petitionRealParty.parties[i]
                    .personType.length > 0
                ) {
                  this.initiatePetitionServices.setOption(
                    'realPartyInComplete',
                    false
                  );
                  this.initiatePetitionServices.setOption(
                    'realPartyComplete',
                    true
                  );
                  if (
                    existingRealPartyResponse.petitionRealParty.parties[i]
                      .proseIndicator == 'Y'
                  ) {
                    this.initiatePetitionServices.setOption('prose', true);
                    this.initiatePetitionServices.setOption('proseFlag', true);
                    this.initiatePetitionServices.setOption(
                      'noticePaperType',
                      true
                    );
                    this.initiatePetitionServices.setOption(
                      'noNoticePaperType',
                      false
                    );
                  }if (
                    existingRealPartyResponse.petitionRealParty.parties[i]
                      .proseIndicator == 'N'
                  ) {
                    this.initiatePetitionServices.setOption('prose', false);
                  }
                  break;
                } else if (
                  existingRealPartyResponse.petitionRealParty.parties[i].orgType
                    .length > 0
                ) {
                  this.initiatePetitionServices.setOption(
                    'realPartyInComplete',
                    false
                  );
                  this.initiatePetitionServices.setOption(
                    'realPartyComplete',
                    true
                  );
                  break;
                } else {
                  this.initiatePetitionServices.setOption(
                    'realPartyInComplete',
                    true
                  );
                  this.initiatePetitionServices.setOption(
                    'realPartyComplete',
                    false
                  );
                  this.initiatePetitionServices.setOption('prose', true);
                }
              } else {
                this.initiatePetitionServices.setOption(
                  'realPartyInComplete',
                  true
                );
                this.initiatePetitionServices.setOption(
                  'realPartyComplete',
                  false
                );
                if (
                  existingRealPartyResponse.petitionRealParty.parties[i]
                    .proseIndicator == 'Y'
                ) {
                  this.initiatePetitionServices.setOption('prose', true);
                }
              }
            }
            for (
              var i =
                existingRealPartyResponse.petitionRealParty.parties.length - 1;
              i >= 0;
              i--
            ) {
              if (
                existingRealPartyResponse.petitionRealParty.parties[i]
                  .partyType == 'ADD REAL PARTY'
              ) {
                if (
                  existingRealPartyResponse.petitionRealParty.parties[i]
                    .personType.length > 0
                ) {
                  //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                  this.initiatePetitionServices.setOption(
                    'additionalRealPartyComplete',
                    true
                  );
                  break;
                } else if (
                  existingRealPartyResponse.petitionRealParty.parties[i].orgType
                    .length > 0
                ) {
                  //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', false);
                  this.initiatePetitionServices.setOption(
                    'additionalRealPartyComplete',
                    true
                  );
                  break;
                } else {
                  //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                  this.initiatePetitionServices.setOption(
                    'additionalRealPartyComplete',
                    false
                  );
                }
              } else {
                //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
                this.initiatePetitionServices.setOption(
                  'additionalRealPartyComplete',
                  false
                );
              }
            }
          } else {
            this.initiatePetitionServices.setOption(
              'realPartyInComplete',
              true
            );
            this.initiatePetitionServices.setOption('realPartyComplete', false);
            //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
            this.initiatePetitionServices.setOption(
              'additionalRealPartyComplete',
              false
            );
            this.initiatePetitionServices.setOption('prose', true);
          }
        },
        (failure) => {
          this.initiatePetitionServices.setOption('realPartyInComplete', true);
          this.initiatePetitionServices.setOption('realPartyComplete', false);
          //this.initiatePetitionServices.setOption('additionalRealPartyInComplete', true);
          this.initiatePetitionServices.setOption(
            'additionalRealPartyComplete',
            false
          );
          this.initiatePetitionServices.setOption('prose', true);
        }
      );
  }

  getExistingCounsels() {
    this.initiatePetitionServices
      .getCounsels(this.petitionInfo.proceedingNumberText)
      .pipe(take(1))
      .subscribe(
        (existingCounsels) => {
          if (existingCounsels.length > 0) {
            for (var i = 0; i < existingCounsels.length; i++) {
              if (existingCounsels[i].counselType == 'Lead Counsel') {
                this.validLeadCounsel = true;
                break;
              } else {
                this.validLeadCounsel = false;
              }
            }
            if (this.validLeadCounsel) {
              this.initiatePetitionServices.setOption('counselComplete', true);
              this.initiatePetitionServices.setOption(
                'counselInComplete',
                false
              );
            } else {
              this.initiatePetitionServices.setOption('counselComplete', false);
              this.initiatePetitionServices.setOption(
                'counselInComplete',
                true
              );
            }
          } else {
            this.initiatePetitionServices.setOption('counselComplete', false);
            this.initiatePetitionServices.setOption('counselInComplete', true);
          }
        },
        (failure) => {
          this.initiatePetitionServices.setOption('counselComplete', false);
          this.initiatePetitionServices.setOption('counselInComplete', true);
        }
      );
  }
}
