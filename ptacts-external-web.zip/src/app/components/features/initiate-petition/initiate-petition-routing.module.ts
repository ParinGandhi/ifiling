import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { IpStatusIndicator } from 'src/app/guards/ip-status-indicator.guard';
import { ClaimsChallengedComponent } from './claims-challenged/claims-challenged.component';
import { InitiatePetitionComponent } from './initiate-petition.component';
import { AdditionalRealPartyComponent } from './parties/additional-real-party/additional-real-party.component';
import { CounselComponent } from './parties/counsel/counsel.component';
import { RealPartyComponent } from './parties/real-party/real-party.component';
import { PetitionDocumentsComponent } from './petition-documents/petition-documents.component';
import { PetitionInformationComponent } from './petition-information/petition-information.component';
import { ReviewComponent } from './review/review.component';
import { VerificationComponent } from './verification/verification.component';

const routes: Routes = [
  {
    path: '',
    component: InitiatePetitionComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'verification',
      },
      {
        path: 'verification',
        component: VerificationComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'petition-information',
        component: PetitionInformationComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'claims-challenged',
        component: ClaimsChallengedComponent,
        canActivate: [AuthGuard],
        canDeactivate: [IpStatusIndicator],
      },
      {
        path: 'petition-documents',
        component: PetitionDocumentsComponent,
        canActivate: [AuthGuard],
        canDeactivate: [IpStatusIndicator],
      },
      {
        path: 'real-party',
        component: RealPartyComponent,
        canActivate: [AuthGuard],
        canDeactivate: [IpStatusIndicator],
      },
      {
        path: 'additional-real-party',
        component: AdditionalRealPartyComponent,
        canActivate: [AuthGuard],
        canDeactivate: [IpStatusIndicator],
      },
      {
        path: 'counsel',
        component: CounselComponent,
        canActivate: [AuthGuard],
        canDeactivate: [IpStatusIndicator],
      },
      {
        path: 'review',
        component: ReviewComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InitiatePetitionRoutingModule {}
