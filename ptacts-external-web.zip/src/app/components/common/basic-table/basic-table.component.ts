import { Component, Input, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../../features/initiate-petition/initiate-petition.service';
import { MandatoryNoticeService } from '../../features/mandatory-notice/mandatory-notice.service';
import { Store, select } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';

@Component({
  selector: 'app-basic-table',
  templateUrl: './basic-table.component.html',
  styleUrls: ['./basic-table.component.scss'],
})
export class BasicTableComponent implements OnInit {
  @Input() tableOptions: any;
  @Input() proceedingNumber: string;

  mandatoryNoticeInfo: any = null;

  constructor(
    public commonUtils: CommonUtilitiesService,
    private mandatoryNoticeService: MandatoryNoticeService,
    private logger: NGXLogger,
    private initiatePetitionService: InitiatePetitionService,
    private store: Store<PtactsState>,
  ) {}

  ngOnInit(): void {
    this.getMandatoryNoticeInfo()
  }

  getMandatoryNoticeInfo() {
    this.store
      .select(PtactsSelectors.getMandatoryState)
      .pipe(take(1))
      .subscribe((mandatoryNoticeInfo) => {
        this.mandatoryNoticeInfo = mandatoryNoticeInfo;
      });
  }

  getPetitionIdentifier() {}

  copyEmailsToClipboard() {
    let emails = [];
    this.tableOptions.data.forEach((counsel) => {
      if (counsel.email) {
        emails.push(counsel.email);
      }
    });
    this.commonUtils.copyToClipboard(emails.join(', '), null);
  }

  openPdf(data, colName) {
   if (data.artifactIdentifer) {
    this.initiatePetitionService
    .getCaseInfoByProceedingNo(this.proceedingNumber)
    .subscribe((caseInfoByProceedingResponse) => {
      if (colName) {
        const dataToEmit = {
          colName: colName,
          data: data,
        };
        //this.pdfEmitter.emit(dataToEmit);
        this.mandatoryNoticeService
          .openPdf(
            caseInfoByProceedingResponse.petitionIdentifier,
            data.artifactIdentifer
          )
          //.pipe(take(1))
          // .subscribe(
          //   (pdfResponse) => {
          //     this.commonUtils.openPdfNew(pdfResponse);
          //   },
          //   (pdfResponseError) => {
          //     this.logger.error('Failed to open PDF', pdfResponseError);
          //   }
          // );
      } else {
        //this.pdfEmitter.emit(data);
        this.mandatoryNoticeService
          .openPdf(
            caseInfoByProceedingResponse.petitionIdentifier,
            data.artifactIdentifer
          )
          // .pipe(take(1))
          // .subscribe(
          //   (pdfResponse) => {
          //     this.commonUtils.openPdfNew(pdfResponse);
          //   },
          //   (pdfResponseError) => {
          //     this.logger.error('Failed to open PDF', pdfResponseError);
          //   }
          // );
      }
    });
   } else {
    this.mandatoryNoticeService.openPdfWithFileName(
      `/petitions/${this.mandatoryNoticeInfo.proceedingId}/documents?fileName=${data.fileToUpload.name}`
    ).subscribe(
      (pdfResponse: any) => {
        console.log(pdfResponse);
        var file = new Blob([pdfResponse], { type: 'application/pdf' });
        var fileURL = URL.createObjectURL(file);
        window.open(fileURL);
      },
      (pdfFailure) => {
        console.log(pdfFailure);
      }
    );
   }
  }
}
