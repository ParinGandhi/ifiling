import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-warning-modal',
  templateUrl: './warning-modal.component.html',
  styleUrls: ['./warning-modal.component.scss'],
})
export class WarningModalComponent implements OnInit {
  modalData = this.modalService.config.initialState;

  constructor(
    public modalRef: BsModalRef,
    private modalService: BsModalService
  ) {}

  ngOnInit(): void {}

  close(selection) {
    this.modalService.config.initialState.selection = selection;
    this.modalService.hide();
  }
}
