import { Component, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { CONSTANTS } from 'src/app/constants/constants';
import { MyDocketService } from '../../features/my-docket/my-docket.services';

@Component({
  selector: 'app-open-pdf',
  templateUrl: './open-pdf.component.html',
  styleUrls: ['./open-pdf.component.scss'],
})
export class OpenPdfComponent implements OnInit {
  params: any;
  proceedingNo = window.sessionStorage.getItem('proceedingNoForSearch');
  userId = window.sessionStorage.getItem('email');
  petitionIdentifier: string = null;
  ANONYMOUS_USER = CONSTANTS.ANONYMOUS_USER;

  constructor(
    private myDocketService: MyDocketService,
    private logger: NGXLogger
  ) {}

  ngOnInit(): void {
    // this.getPetitionIdentifier();
    // window.sessionStorage.removeItem('petitionIdentifier');
  }

  agInit(params) {
    this.params = params;
    // if (!this.petitionIdentifier) {
    //   window.sessionStorage.getItem('petitionIdentifier');
    // }
  }

  // getPetitionIdentifier() {
  //   if (!this.petitionIdentifierCalled) {
  //     this.petitionIdentifierCalled = true;
  //     this.initiatePetitionService
  //       .getCaseInfoByProceedingNo(this.proceedingNo)
  //       .subscribe((caseInfoByProceedingResponse) => {
  //         this.petitionIdentifier =
  //           caseInfoByProceedingResponse.petitionIdentifier;
  //       });
  //   }
  // }

  openPdf() {
    // this.initiatePetitionService
    //   .getCaseInfoByProceedingNo(this.proceedingNo)
    //   .subscribe((caseInfoByProceedingResponse) => {
    //     // this.petitionIdentifier =
    //     //   caseInfoByProceedingResponse.petitionIdentifier;

    //     this.myDocketService
    //       .openPdf(
    //         caseInfoByProceedingResponse.petitionIdentifier,
    //         this.params.data.artifactIdentifer
    //       )
    //       .pipe(take(1))
    //       .subscribe(
    //         (pdfResponse) => {
    //           this.commonUtils.openPdfNew(pdfResponse);
    //         },
    //         (pdfResponseError) => {
    //           this.commonUtils.showError('Failed to open PDF', 'PDF');
    //           this.logger.error('Failed to open PDF', pdfResponseError);
    //         }
    //       );
    //   });

    this.myDocketService
      .openPdf(
        this.params.data.petitionIdentifier,
        this.params.data.artifactIdentifer
      )
      // .pipe(take(1))
      // .subscribe(
      //   (pdfResponse) => {
      //     this.commonUtils.openPdfNew(pdfResponse);
      //   },
      //   (pdfResponseError) => {
      //     this.commonUtils.throwError('Failed to open PDF', pdfResponseError);
      //     // this.commonUtils.showError('Failed to open PDF', 'PDF');
      //     // this.logger.error('Failed to open PDF', pdfResponseError);
      //   }
      // );
  }
}
