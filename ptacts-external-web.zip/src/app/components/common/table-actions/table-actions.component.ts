import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';

@Component({
  selector: 'app-table-actions',
  templateUrl: './table-actions.component.html',
  styleUrls: ['./table-actions.component.scss'],
})
export class TableActionsComponent implements OnInit {
  @Input() numberOfFilters;
  @Output() clearFilterEmmiter: EventEmitter<any> = new EventEmitter();

  constructor(private commonUntils: CommonUtilitiesService) {}

  ngOnInit(): void {}

  getFilterCount() {
    let filterCount = 0;
    if (this.numberOfFilters) {
      this.numberOfFilters.forEach((searchCriteria) => {
        if (searchCriteria.searchText) {
          filterCount++;
        }
      });
    }
    return filterCount;
  }

  clearFilters() {
    this.commonUntils.clearTableFilter(this.numberOfFilters);
    // this.numberOfFilters.forEach((searchCriteria) => {
    //   searchCriteria.searchText = null;
    // });
    this.clearFilterEmmiter.emit();
  }
}
