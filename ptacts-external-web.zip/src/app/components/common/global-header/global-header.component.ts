import { AfterViewInit, Component, OnInit } from '@angular/core';

import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import {
  getUserDetails,
  setUserDetails,
  setUserIdAction,
  getLoginDetailsForNonOKTA,
} from 'src/app/store/ptacts/ptacts.actions';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../features/initiate-petition/initiate-petition.service';
import { HomeService } from '../../features/home/home.service';
import { NGXLogger } from 'ngx-logger';
import { environment } from 'src/environments/environment';
import { CONSTANTS } from 'src/app/constants/constants';
import { MandatoryNoticeService } from '../../features/mandatory-notice/mandatory-notice.service';
declare let $: any;

@Component({
  selector: 'app-global-header',
  templateUrl: './global-header.component.html',
  styleUrls: ['./global-header.component.scss'],
})
export class GlobalHeaderComponent implements OnInit, AfterViewInit {
  // loggedInUser$ = this.store.pipe(select(PtactsSelectors.ptactsStateData));
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.getUserDetailsState));
  loggedInUser;
  fullName: string = null;
  isCaseViewer: boolean = false;
  newLoggedInUser = null;
  helpLinkInfo = null;
  oktaLinks = {
    rbacServicesUrl: null,
    signoutLandingUrl: null,
  };
  versionsInfo = [];
  ifilingLink: any;

  constructor(
    private store: Store<PtactsState>,
    private router: Router,
    private initiatePetitionServices: InitiatePetitionService,
    private homeService: HomeService,
    private logger: NGXLogger,
    private mandatoryNoticeService: MandatoryNoticeService
  ) {}

  ngOnInit(): void {
    this.getDST();
    this.getOktaLinks();
    this.getIFILINGLINK();
    // $.sessionTimeoutWidget({
    //   resetBackendTimerUrl: '/stay-alive',
    //   checkRbacTimerUrl: 'https://session/time',
    //   logoutUrl: 'sign-out.html',
    //   warnAfter: 300000,
    //   warningTime: 30000,
    // });

    // $.sessionTimeoutWidget({
    //   logoutUrl: '',
    //   warnAfter: CONSTANTS.SESSION_TIMER.WARN_AFTER,
    //   warningTime: CONSTANTS.SESSION_TIMER.WARNING_TIME,
    //   // hideOtherModalClasses: hideOtherModalClasses,
    //   // sessionTimedOutUrl: 'reloadRandomText',
    //   // runRbacCounter: runRbacCounter,
    //   appSpecificDomain: window.location.hostname,
    //   rbacServicesUrl: 'https://rbac-services-fqt.etc.uspto.gov/rbac/services',
    // });

    // $.sessionTimeoutWidget.staySignedIn();

    // this.store.select(PtactsSelectors.getUserDetailsState).subscribe((obj) => {
    //   this.loggedInUser = obj;
    // });

    if (environment.production) {
      this.logger.info('***** This is production *****');
    } else {
      this.logger.info('***** This is NOT production *****');
    }
    this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    this.logger.info('Inside ngOnInit - loggedInUser', this.loggedInUser);

    this.checkIfCaseViewer();
  }

  getDST() {
    this.homeService
      .getDST()
      .pipe(take(1))
      .subscribe(
        (dstResponse: any) => {
          console.log('Daylight savings response: ', dstResponse);
          if (dstResponse && dstResponse.length > 0) {
            dstResponse.forEach((element) => {
              if (element.descriptionText === 'isDST') {
                window.sessionStorage.setItem('isDST', element.valueText);
              }
            });
          }
        },
        (daylightSavingsFailure) => {
          console.log(daylightSavingsFailure);
        }
      );
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      // this.getLoggedInUserDetails();
      this.logger.info('Inside after view init');
      const userDetails = JSON.parse(
        window.sessionStorage.getItem('userDetails')
      );
      this.logger.info('User details from session: ', userDetails);
      this.logger.info('First name, last name and email: ', userDetails);

      this.logger.info('Dispatching action to get user details');
      // const email = window.sessionStorage.getItem('email');
      // this.store.dispatch(getLoginDetailsForNonOKTA({ userName: email }));
      // if (
      //   !userDetails?.firstName &&
      //   !userDetails?.lastName &&
      //   !userDetails?.emailAddress
      // ) {
      //   this.logger.info('Dispatching action to get user details');
      //   this.store.dispatch(getUserDetails());
      // }
      // else {
      //   this.logger.info('Dispatching action to set user details from session');
      //   this.store.dispatch(setUserDetails({ payload: userDetails }));
      // }

      this.getHelpLink();
      this.getVersions();
    }, 500);
    // setTimeout(() => {
    //   if (
    //     this.loggedInUser?.firstName &&
    //     this.loggedInUser?.lastName &&
    //     !this.isInternalUser()
    //   ) {
    //     this.fullName = `${this.loggedInUser?.lastName}, ${this.loggedInUser?.firstName}`;
    //     if (!this.isInternalUser()) {
    //       this.store.dispatch(
    //         setUserIdAction({
    //           payload: `${this.loggedInUser?.lastName}, ${this.loggedInUser?.firstName}`,
    //         })
    //       );
    //     }
    //   }
    // }, 500);
  }

  getOktaLinks() {
    this.initiatePetitionServices
      .getOktaLinks()
      .pipe(take(1))
      .subscribe(
        (oktaLinkInfo: any) => {
          oktaLinkInfo.forEach((element) => {
            this.oktaLinks[element.valueText] = element.descriptionText;
          });
          console.log('OKTA links: ', this.oktaLinks);

          $.sessionTimeoutWidget({
            logoutUrl: '',
            warnAfter: CONSTANTS.SESSION_TIMER.WARN_AFTER,
            warningTime: CONSTANTS.SESSION_TIMER.WARNING_TIME,
            // hideOtherModalClasses: hideOtherModalClasses,
            // sessionTimedOutUrl: 'reloadRandomText',
            // runRbacCounter: runRbacCounter,
            appSpecificDomain: window.location.hostname,
            // rbacServicesUrl: 'https://rbac-services-fqt.etc.uspto.gov/rbac/services',
            rbacServicesUrl: this.oktaLinks.rbacServicesUrl,
          });

          setTimeout(() => {
            this.logger.info('Dispatching action to get user details');
            this.store.dispatch(getUserDetails());
            // const email = window.sessionStorage.getItem('email');
            // if (email !== 'anonymous') {
            //   this.store.dispatch(
            //     getLoginDetailsForNonOKTA({ userName: email })
            //   );
            // }
          }, 500);
        },
        (oktaLinkError) => {
          console.log('Unable to retrieve OKTA links', oktaLinkError);
          setTimeout(() => {
            this.logger.info('Dispatching action to get user details');
            this.store.dispatch(getUserDetails());
          }, 500);
        }
      );
  }

  getHelpLink() {
    this.helpLinkInfo = [];
    this.initiatePetitionServices
      .getHelpLink()
      .pipe(take(1))
      .subscribe(
        (helpLinkInfoResponse: any) => {
          helpLinkInfoResponse.forEach((link) => {
            if (link.valueText.toLowerCase().includes('training')) {
              link.icon = 'fa-book';
              this.helpLinkInfo[0] = link;
            }
            if (link.valueText.toLowerCase().includes('trial')) {
              link.icon = 'fa-gavel';
              this.helpLinkInfo[1] = link;
            }
            if (link.valueText.toLowerCase().includes('myuspto')) {
              link.icon = 'fa-question';
              this.helpLinkInfo[2] = link;
            }
          });
          // const helpLinkInfoTemp = helpLinkInfo.filter((link) => {
          //   if (link.valueText.toLowerCase().includes('training')) {
          //     link.icon = 'fa-book';
          //   }
          //   if (link.valueText.toLowerCase().includes('trial')) {
          //     link.icon = 'fa-gavel';
          //   }
          //   if (link.valueText.toLowerCase().includes('myuspto')) {
          //     link.icon = 'fa-question';
          //   }
          //   return (
          //     link.valueText.toLowerCase().includes('training') ||
          //     link.valueText.toLowerCase().includes('trial') ||
          //     link.valueText.toLowerCase().includes('myuspto')
          //   );
          // });
          // this.helpLinkInfo = helpLinkInfoTemp;
        },
        (helpLinkError) => {}
      );
  }

  getIFILINGLINK() {
    this.ifilingLink = '';
    this.initiatePetitionServices
      .getIFILING_LINK()
      .pipe(take(1))
      .subscribe(
        (IFILINGLINKInfoResponse: any) => {
          IFILINGLINKInfoResponse.forEach((link) => {
            if (link.valueText.toLowerCase().includes('search interference')) {
              this.ifilingLink = link.descriptionText;
            }
          });
        },
        (ifilingLinkError) => {}
      );
  }

  getVersions() {
    this.initiatePetitionServices
      .getVersions()
      .pipe(take(1))
      .subscribe(
        (versionsInfo: any) => {
          this.versionsInfo = versionsInfo;
        },
        (helpLinkError) => {}
      );
  }

  setHelpLink() {
    return this.helpLinkInfo;
  }

  signIn(signInMethod) {
    if (signInMethod === 'normal') {
      this.router.navigateByUrl('/ui/login');
    } else if (signInMethod === 'myuspto') {
      // window.open('https://my-pvt.etc.uspto.gov/', '_self');
      // this.router.navigateByUrl('/ui/my-docket/pending-aia-reviews');
      // this.router.navigateByUrl();
      // $.sessionTimeoutWidget.staySignedIn();
      window.open(
        `${window.location.protocol}//${window.location.host}/ptacts/ui/my-docket/pending-aia-reviews`,
        '_self'
      );
    }
  }

  getLoggedInUserDetails() {
    this.homeService
      .getLoggedInUserDetails()
      .pipe(take(1))
      .subscribe((loggedInUserDetails: any) => {
        this.newLoggedInUser = loggedInUserDetails;
        this.store.dispatch(setUserDetails({ payload: loggedInUserDetails }));
        if (loggedInUserDetails && loggedInUserDetails.userId) {
          window.sessionStorage.setItem('email', loggedInUserDetails.userId);
        }
        // $.sessionTimeoutWidget.staySignedIn();
      });
  }

  checkIfCaseViewer() {
    this.isCaseViewer = window.location.href.includes('case-viewer');
    // if (this.isCaseViewer) {
    //   const email = window.sessionStorage.getItem('email');
    //   if (email !== 'anonymous') {
    //     this.store.dispatch(getLoginDetailsForNonOKTA({ userName: email }));
    //   }
    // }
  }

  verificationRoute() {
    window.sessionStorage.setItem('petitionInfo', '');
    this.initiatePetitionServices.setOption('verificationComplete', '');
    this.initiatePetitionServices.setOption('verificationInComplete', '');
    this.initiatePetitionServices.setOption('informationComplete', '');
    this.initiatePetitionServices.setOption('informationInComplete', '');
    this.initiatePetitionServices.setOption('additionalRealPartyComplete', '');
    this.initiatePetitionServices.setOption(
      'additionalRealPartyInComplete',
      ''
    );
    this.initiatePetitionServices.setOption('claimsComplete', '');
    this.initiatePetitionServices.setOption('claimsInComplete', '');
    this.initiatePetitionServices.setOption('documentsComplete', '');
    this.initiatePetitionServices.setOption('documentsInComplete', '');
    this.initiatePetitionServices.setOption('realPartyInComplete', '');
    this.initiatePetitionServices.setOption('realPartyComplete', '');
    this.initiatePetitionServices.setOption('counselComplete', '');
    this.initiatePetitionServices.setOption('counselInComplete', '');
    this.initiatePetitionServices.setOption('noticePaperType', '');
    this.initiatePetitionServices.setOption('petitionPaperType', '');
    this.initiatePetitionServices.setOption('noNoticePaperType', '');
    this.initiatePetitionServices.setOption('noPetitionPaperType', '');
    this.initiatePetitionServices.setOption('hasAttorneyPaperType', '');
    this.initiatePetitionServices.setOption('proseFlag', '');
    this.router.navigate(['/ui/initiate-petition']);
  }

  verifyMandatoryNotice() {
    this.mandatoryNoticeService.clearState();
    this.mandatoryNoticeService.clearValidations();
    this.router.navigate(['/ui/mandatory-notice']);
  }

  logout() {
    this.store.dispatch(setUserIdAction({ payload: null }));
    window.sessionStorage.removeItem('email');
    window.sessionStorage.removeItem('userInfo');
    window.sessionStorage.removeItem('userDetails');
    this.loggedInUser = null;
    this.fullName = null;
    this.router.navigate(['/ui/home']);
  }

  isInternalUser() {
    let internalUser = window.sessionStorage.getItem('source');
    let anonUser = window.sessionStorage.getItem('email') === 'anonymous';
    return internalUser || anonUser;
  }

  signOut() {
    this.store.dispatch(setUserIdAction({ payload: null }));
    // window.sessionStorage.removeItem('email');
    // window.sessionStorage.removeItem('userInfo');
    // window.sessionStorage.removeItem('userDetails');
    window.sessionStorage.clear();
    this.loggedInUser = null;
    this.fullName = null;
    // this.router.navigate(['/ui/home']);
    this.homeService.signOut(this.oktaLinks);
  }

  // isAnonUser() {
  //   let anonUser = window.sessionStorage.getItem('email') === 'anonymous';
  //   return anonUser;
  // }
}
