import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-checkbox-dropdown',
  templateUrl: './checkbox-dropdown.component.html',
  styleUrls: ['./checkbox-dropdown.component.scss'],
})
export class CheckboxDropdownComponent implements OnInit {
  @Input() dropdownValues;
  @Input() disableDropdown;
  @Output() selectedValueEmitter: EventEmitter<Array<string>> =
    new EventEmitter();

  selectedValues: Array<string> = [];
  selectedDescriptions: Array<string> = [];
  initialLoad: boolean = true;

  constructor() {}

  ngOnInit(): void {
    // this.toggleAll('all', null);
    this.dropdownValues.forEach((caseType) => {
      this.toggleSelect(caseType);
    });
    this.initialLoad = false;
  }

  toggleSelect(selectedItem) {
    if (selectedItem.val) {
      this.selectedValues.push(selectedItem.code);
      this.selectedDescriptions.push(selectedItem.description);
    } else if (!this.initialLoad) {
      this.selectedValues.splice(
        this.selectedValues.indexOf(selectedItem.code),
        1
      );
      this.selectedDescriptions.splice(
        this.selectedDescriptions.indexOf(selectedItem.description),
        1
      );
    }
    if (!this.initialLoad) {
      this.selectedValueEmitter.emit(this.selectedValues);
    }
  }

  toggleAll(selection, e) {
    if (e) {
      e.stopPropagation();
    }
    this.selectedValues = [];
    this.selectedDescriptions = [];
    if (this.dropdownValues && this.dropdownValues.length > 0) {
      if (selection === 'all') {
        this.dropdownValues.forEach((item) => {
          item.val = true;
          // this.selectedValues.push(item.description);
          this.selectedValues.push(item.code);
          this.selectedDescriptions.push(item.description);
        });
      } else {
        this.dropdownValues.forEach((item) => {
          item.val = false;
        });
      }
    }
    this.selectedValueEmitter.emit(this.selectedValues);
  }

  clearSelection() {
    this.selectedValues = [];
    this.selectedDescriptions = [];
    this.dropdownValues.forEach((item) => {
      item.val = false;
    });
  }
}
