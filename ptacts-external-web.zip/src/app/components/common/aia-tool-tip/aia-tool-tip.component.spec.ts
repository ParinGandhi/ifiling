import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiaToolTipComponent } from './aia-tool-tip.component';

describe('AiaToolTipComponent', () => {
  let component: AiaToolTipComponent;
  let fixture: ComponentFixture<AiaToolTipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AiaToolTipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AiaToolTipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
