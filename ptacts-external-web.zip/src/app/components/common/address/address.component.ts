import { Component, Input, OnInit } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../features/initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss'],
})
export class AddressComponent implements OnInit {
  @Input() isProSe: string;
  countries: [] = [];
  states: [] = [];
  selectedCountry = '1';

  constructor(
    private initiatePetitionService: InitiatePetitionService,
    private logger: NGXLogger
  ) {}

  ngOnInit(): void {
    this.getCountries();
   
  }

  getCountries() {
    this.initiatePetitionService
      .getCountries()
      .pipe(take(1))
      .subscribe((countriesResponse) => {
        this.countries = countriesResponse;
        this.logger.info('Countries list: ', this.countries);
      });
  }

  getStates(countryCode) {
    this.initiatePetitionService
      .getStates(countryCode.value)
      .pipe(take(1))
      .subscribe((statesList) => {
        this.states = statesList;
      });
  }
}
