import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { UnauthorizedService } from './unauthorized.service';

@Component({
  selector: 'app-unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.scss'],
})
export class UnauthorizedComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.ptactsStateData));
  htmlContent = {
    ERROR_MSG: '',
  };

  constructor(
    private store: Store<PtactsState>,
    private unauthService: UnauthorizedService
  ) {}

  ngOnInit(): void {
    this.getErrorMessageHtml();
  }

  getErrorMessageHtml() {
    this.unauthService
      .getErrorMessageHtml()
      .subscribe((htmlDataResponse: any) => {
        if (htmlDataResponse) {
          htmlDataResponse.forEach((html) => {
            this.htmlContent[html.valueText] = html.descriptionText;
          });
        }
      });
  }
}
