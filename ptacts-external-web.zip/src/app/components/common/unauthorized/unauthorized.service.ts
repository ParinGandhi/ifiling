import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UnauthorizedService {
  private EXTERNAL_SERVICE_BASE: string = environment.EXTERNAL_SERVICE_API;
  constructor(private http: HttpClient) {}

  getErrorMessageHtml() {
    return this.http
      .get(
        `${this.EXTERNAL_SERVICE_BASE}/public-informations/code-reference-types?typeCode=PORTAL_ACCESS`,
        {
          headers: { 'user-name': 'anonymous' },
        }
      )
      .pipe(
        map((htmlData) => {
          return htmlData;
        })
      );
  }
}
