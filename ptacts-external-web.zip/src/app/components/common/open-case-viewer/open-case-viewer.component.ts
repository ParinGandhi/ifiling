import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';
import { Urls } from 'src/app/constants/urls';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { CaseViewerService } from '../../features/case-viewer/case-viewer.service';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { ViewDocumentsModalComponent } from '../../features/advanced-search/view-documents-modal/view-documents-modal.component';

@Component({
  selector: 'app-open-case-viewer',
  templateUrl: './open-case-viewer.component.html',
  styleUrls: ['./open-case-viewer.component.scss'],
})
export class OpenCaseViewerComponent implements OnInit {
  proceedingNo: any;
  params: any;
  checkForUser: boolean = false;
  checkForInactivePetitions: boolean = false;
  fromNotifications: boolean = false;
  documentsModalRef: BsModalRef = null;

  constructor(
    private commonUtils: CommonUtilitiesService,
    private caseViewerService: CaseViewerService,
    private modalService: BsModalService
  ) {}

  agInit(params) {
    this.params = params;
    this.proceedingNo = params.value;
    if (
      this.params.fromComponent &&
      this.params.fromComponent === 'searchDocuments'
    ) {
      this.checkForUser = true;
    } else if (
      this.params.fromComponent &&
      this.params.fromComponent === 'notifications'
    ) {
      this.checkForInactivePetitions = true;
    }
  }

  ngOnInit(): void {}

  openCaseViewer() {
    this.checkForPartyRepresenting();
    // if (
    //   this.params.fromComponent &&
    //   this.params.fromComponent === 'notifications'
    // ) {
    //   this.checkForPartyRepresenting();
    // } else {
    //   this.commonUtils.openCaseViewer(this.proceedingNo, '/aia-review-info');
    // }
  }

  checkForPartyRepresenting() {
    this.caseViewerService
      .getPartyRepresenting(this.proceedingNo)
      .pipe(take(1))
      .subscribe(
        (partyResponse) => {
          // this.commonUtils.openCaseViewer(proceedingNo, '/aia-review-info');
          if (partyResponse !== '') {
            this.commonUtils.openCaseViewer(
              this.proceedingNo,
              '/aia-review-info'
            );
          } else {
            this.openDocumentsModal();
          }
        },
        (partyFailure) => {
          this.commonUtils.throwError('', partyFailure);
        }
      );
  }

  openDocumentsModal() {
    window.sessionStorage.setItem('proceedingNoForSearch', this.proceedingNo);
    //
    //
    const initialState: ModalOptions = {
      initialState: {
        proceedingNo: this.proceedingNo,
        closeModal: false,
      },
      class: 'modal-xl',
      animated: true,
      ignoreBackdropClick: true,
    };
    this.documentsModalRef = this.modalService.show(
      ViewDocumentsModalComponent,
      initialState
    );
    this.commonUtils.removeModalFadeClass();
    this.documentsModalRef.onHide.subscribe((reason: string | any) => {
      if (reason.initialState.closeModal) {
      }
    });
  }
}
