import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-public-availability-modal',
  templateUrl: './public-availability-modal.component.html',
  styleUrls: ['./public-availability-modal.component.scss'],
})
export class PublicAvailabilityModalComponent implements OnInit {
  constructor(
    private modalService: BsModalService,
    public bsModalRef: BsModalRef
  ) {}

  ngOnInit(): void {}

  close(selection) {
    this.modalService.config.initialState.keepPublic = selection;
    this.bsModalRef.hide();
  }
}
