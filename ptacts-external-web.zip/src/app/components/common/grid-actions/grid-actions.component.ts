import { Component, Input, OnInit } from '@angular/core';
import { GridHelperService } from 'src/app/services/grid-helper.service';

@Component({
  selector: 'app-grid-actions',
  templateUrl: './grid-actions.component.html',
  styleUrls: ['./grid-actions.component.scss'],
})
export class GridActionsComponent implements OnInit {
  @Input() gridParams;

  constructor(public gridHelperService: GridHelperService) {}

  ngOnInit(): void {}
}
