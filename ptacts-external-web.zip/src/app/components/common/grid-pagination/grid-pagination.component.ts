import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CONSTANTS } from 'src/app/constants/constants';
import { PaginationModel } from 'src/app/models/common/Pagination.model';

@Component({
  selector: 'app-grid-pagination',
  templateUrl: './grid-pagination.component.html',
  styleUrls: ['./grid-pagination.component.scss'],
})
export class GridPaginationComponent implements OnInit {
  // @Input() dataLength;
  // @Input() pageSize;
  // @Input() currentPage;
  // @Input() totalPages;
  @Input() paginationInfo: PaginationModel;

  @Output() gridAction: EventEmitter<any> = new EventEmitter();
  @Output() pageSizeEmitter: EventEmitter<any> = new EventEmitter();

  totalPageList: Array<any> = new Array<any>();
  paginationSizeList = CONSTANTS.PAGINATION.SIZES;
  selectedPageSize = 25;

  constructor() {}

  ngOnInit(): void {
    //
    // this.calculateTotalPages();
  }

  // calculateTotalPages() {
  //   let totalPagesTemp = Math.ceil(this.dataLength / parseInt(this.pageSize));
  //   this.totalPageList = [];
  //   for (let i = 1; i <= totalPagesTemp; i++) {
  //     this.totalPageList.push(i);
  //   }
  // }

  gridPaginationAction(pageAction, pageNo) {
    if (pageNo) {
      pageNo = parseInt(pageNo) - 1;
    }
    const action = {
      pageAction: pageAction,
      pageNo: pageNo,
    };
    this.gridAction.emit(action);
  }

  changePageSize(pageSize) {
    this.selectedPageSize = pageSize;
    this.pageSizeEmitter.emit(pageSize);
  }
}
