import { Component, OnInit } from '@angular/core';

import { select, Store } from '@ngrx/store';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { setUserIdAction } from 'src/app/store/ptacts/ptacts.actions';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { InitiatePetitionService } from '../../features/initiate-petition/initiate-petition.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  loggedInUser$ = this.store.pipe(select(PtactsSelectors.ptactsStateData));
  loggedInUser;
  fullName: string = null;
  isCaseViewer: boolean = false;

  constructor(
    private store: Store<PtactsState>,
    private router: Router,
    private initiatePetitionServices: InitiatePetitionService
  ) {}

  ngOnInit(): void {
    this.loggedInUser = JSON.parse(window.sessionStorage.getItem('userInfo'));
    if (this.loggedInUser?.firstName && this.loggedInUser?.lastName) {
      this.fullName = `${this.loggedInUser?.lastName}, ${this.loggedInUser?.firstName}`;
      this.store.dispatch(
        setUserIdAction({
          payload: `${this.loggedInUser?.lastName}, ${this.loggedInUser?.firstName}`,
        })
      );
    }

    this.checkIfCaseViewer();
    // let currentRoute = window.location.hash.substring(1);
    // let savedState = JSON.parse(window.sessionStorage.getItem('state'));
    // this.store
    //   .select(PtactsSelectors.ptactsStateData)
    //   .pipe(take(1))
    //   .subscribe((savedState) => {
    //     if (savedState.userId) {
    //       this.router.navigate(['/my-docket/pending-aia-reviews']);
    //     } else if (savedState && savedState.userId) {
    //       this.store.dispatch(setUserIdAction({ payload: savedState.userId }));
    //       this.router.navigate([currentRoute]);
    //     } else {
    //       this.router.navigate(['/']);
    //     }
    //   });
  }

  checkIfCaseViewer() {
    this.isCaseViewer = window.location.href.includes('case-viewer');
  }

  verificationRoute() {
    window.sessionStorage.setItem('petitionInfo', '');
    this.initiatePetitionServices.setOption('verificationComplete', '');
    this.initiatePetitionServices.setOption('verificationInComplete', '');
    this.initiatePetitionServices.setOption('informationComplete', '');
    this.initiatePetitionServices.setOption('informationInComplete', '');
    this.initiatePetitionServices.setOption('additionalRealPartyComplete', '');
    this.initiatePetitionServices.setOption(
      'additionalRealPartyInComplete',
      ''
    );
    this.initiatePetitionServices.setOption('claimsComplete', '');
    this.initiatePetitionServices.setOption('claimsInComplete', '');
    this.initiatePetitionServices.setOption('documentsComplete', '');
    this.initiatePetitionServices.setOption('documentsInComplete', '');
    this.initiatePetitionServices.setOption('realPartyInComplete', '');
    this.initiatePetitionServices.setOption('realPartyComplete', '');
    this.initiatePetitionServices.setOption('counselComplete', '');
    this.initiatePetitionServices.setOption('counselInComplete', '');
    this.initiatePetitionServices.setOption('noticePaperType', '');
    this.initiatePetitionServices.setOption('petitionPaperType', '');
    this.initiatePetitionServices.setOption('noNoticePaperType', '');
    this.initiatePetitionServices.setOption('noPetitionPaperType', '');
    this.initiatePetitionServices.setOption('hasAttorneyPaperType', '');
    this.initiatePetitionServices.setOption('proseFlag', '');
    this.initiatePetitionServices.setOption('isDER', '');
    this.router.navigate(['/initiate-petition']);
  }

  verifyMandatoryNotice() {
    this.router.navigate(['/mandatory-notice']);
  }

  logout() {
    this.store.dispatch(setUserIdAction({ payload: null }));
    window.sessionStorage.removeItem('email');
    window.sessionStorage.removeItem('userInfo');
    this.loggedInUser = null;
    this.fullName = null;
    this.router.navigate(['/']);
  }
}
