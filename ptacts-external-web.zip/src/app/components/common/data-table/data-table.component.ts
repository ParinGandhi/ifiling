import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PtactsState } from 'src/app/store/ptacts/ptacts.state';
import { Store, select } from '@ngrx/store';
import { CommonUtilitiesService } from 'src/app/services/common-utilities.service';
import { InitiatePetitionService } from '../../features/initiate-petition/initiate-petition.service';
import { MyDocketService } from '../../features/my-docket/my-docket.services';
import { NGXLogger } from 'ngx-logger';
import { take } from 'rxjs/operators';

import * as PtactsSelectors from 'src/app/store/ptacts/ptacts.selectors';
import { getPetitionIdentifier } from 'src/app/store/ptacts/ptacts.actions';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
})
export class DataTableComponent implements OnInit {
  @Output() sortColumnEmitter: EventEmitter<any> = new EventEmitter();
  @Output() pdfEmitter: EventEmitter<any> = new EventEmitter();
  @Output() rowSelection: EventEmitter<any> = new EventEmitter();
  @Output() caseInfoEmitter: EventEmitter<any> = new EventEmitter();

  @Input() tableOptions: any;
  @Input() orderByField?: any;
  @Input() enableCheckbox?: boolean;
  show = true;
  petitionInfo: any;
  petitionIdentifier: any;
  showhyperLink: boolean = false;
  constructor(
    private initiatePetitionService: InitiatePetitionService,
    private store: Store<PtactsState>,
    private commonUtils: CommonUtilitiesService,
    private myDocketService: MyDocketService,
    private logger: NGXLogger
  ) {}
  keys: string[];

  ngOnInit(): void {
    if (window.sessionStorage.getItem('petitionInfo')) {
      this.petitionInfo = JSON.parse(
        window.sessionStorage.getItem('petitionInfo')
      );
    }

    this.store
      .select(PtactsSelectors.getPetitionIdentifierState)
      .subscribe((petitionIdentifier) => {
        this.petitionIdentifier = petitionIdentifier;
      });
    // this.getPetitionIdentifier();
  }

  getNumberOfFilters() {
    let count = 0;
    if (
      this.tableOptions &&
      this.tableOptions.data &&
      this.tableOptions.data.length > 0
    ) {
      this.tableOptions.data.forEach((row) => {
        if (row.artifactIdentifer && row.contentManagementId) {
          row.showhyperLink = true;
        } else {
          row.showhyperLink = false;
        }
      });
    }
    if (
      this.tableOptions &&
      this.tableOptions.columnDefs &&
      this.tableOptions.columnDefs.length > 0
    ) {
      this.tableOptions.columnDefs.forEach((column) => {
        if (
          column.searchText &&
          column.searchText !== '' &&
          column.searchText !== null
        ) {
          count++;
        }
      });
    }
    return count;
  }

  clearAll() {
    this.tableOptions.columnDefs.forEach((column) => {
      column.searchText = null;
    });
  }

  sortColumn(columnToSort) {
    this.sortColumnEmitter.emit(columnToSort);
  }

  openPdf(data, colName) {
    if (colName) {
      const dataToEmit = {
        colName: colName,
        data: data,
      };
      //this.pdfEmitter.emit(dataToEmit);
      this.myDocketService.openPdf(
        this.petitionIdentifier,
        data.artifactIdentifer
      );
      // .pipe(take(1))
      // .subscribe(
      //   (pdfResponse) => {
      //     this.commonUtils.openPdfNew(pdfResponse);
      //   },
      //   (pdfResponseError) => {
      //     this.logger.error('Failed to open PDF', pdfResponseError);
      //   }
      // );
    } else {
      //this.pdfEmitter.emit(data);
      this.myDocketService.openPdf(
        this.petitionIdentifier,
        data.artifactIdentifer
      );
      // .pipe(take(1))
      // .subscribe(
      //   (pdfResponse) => {
      //     this.commonUtils.openPdfNew(pdfResponse);
      //   },
      //   (pdfResponseError) => {
      //     this.logger.error('Failed to open PDF', pdfResponseError);
      //   }
      // );
    }
  }

  openCaseViewer = function (data) {
    this.commonUtils.openInCaseViewer(data.relatedProceedingNo);
  };

  onSelection(row, qty, record) {
    let rowData = {
      row: row,
      valueToEmit: null,
    };
    if (qty === 'all') {
      let allCheckboxes: any = document.getElementsByClassName(
        this.tableOptions.checkboxClass
      );
      for (let i = 0; i < allCheckboxes.length; i++) {
        allCheckboxes[i].checked = row.target.checked;
      }
      rowData.valueToEmit = row.target.checked ? 'all' : 'none';
    } else {
      rowData.valueToEmit = record;
    }
    this.rowSelection.emit(rowData);
  }

  // getPetitionIdentifier() {
  //   this.initiatePetitionService
  //     .getCaseInfoByProceedingNo(this.petitionInfo.proceedingNumberText)
  //     .subscribe((caseInfoByProceedingResponse) => {
  //       this.petitionIdentifier =
  //         caseInfoByProceedingResponse.petitionIdentifier;
  //     });
  // }
}
