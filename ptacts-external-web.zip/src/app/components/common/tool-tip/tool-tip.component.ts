import { Component } from '@angular/core';
import { ITooltipAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';


interface ToolTipParams extends ICellRendererParams {
  lineBreak?: boolean;
  tooltipType?: string;
  toolTipArray?: any[];
  commentList?: any[];
  toolTip?: string;
  petitionVsPo?: string;
  stringValue?: string;
}


@Component({
  selector: 'app-tool-tip',
  templateUrl: './tool-tip.component.html',
  styleUrls: ['./tool-tip.component.less']
})
export class ToolTipComponent implements ITooltipAngularComp {

  public params: any;
  public data: any;
  public displayText: Array<string> = [];
  toolTip: any;

  /* istanbul ignore next */
  agInit(params): void {
    this.params = params;

    this.data = params.api.getDisplayedRowAtIndex(params.rowIndex).data;
    if (this.params.data === "proceedingMetadata.petiRealParty") {
      this.displayText.push(this.data.proceedingMetadata.petiRealParty);
    } else if (this.params.data === "proceedingMetadata.poRealParty") {
      this.displayText.push(this.data.proceedingMetadata.poRealParty);
    } else if (this.params.data === "proceedingMetadata.judges") {
      this.displayText = [...this.data.proceedingMetadata.judges];
    } else if (Array.isArray(this.data[this.params.data])) {
      this.displayText = [...this.data[this.params.data]];
    }
    else {
      this.displayText.push(this.data[this.params.data]);
    }
  }

}
