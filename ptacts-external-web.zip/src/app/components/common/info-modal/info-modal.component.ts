import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.less']
})
export class InfoModalComponent implements OnInit {

  constructor(public bsModalRef: BsModalRef) { }

  infoText: Array<string>;
  title: string;
  showLeftBtn: boolean;
  leftBtnClass: string;
  leftBtnLabel: string;
  showRightBtn: boolean;
  rightBtnClass: string;
  rightBtnLabel: string;
  modalHeight: number;
  isConfirm: boolean;
  modal: any;

  ngOnInit(): void {
  }

  close(val) {
    if (this.modal) {
      this.modal.isConfirm = val;
    } else {
      this.isConfirm = val;
    }
    this.bsModalRef.hide();
  }

}
