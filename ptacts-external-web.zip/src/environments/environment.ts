// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
import { NgxLoggerLevel } from 'ngx-logger';
import { Urls } from 'src/app/constants/urls';

export const environment = {
  production: false,
  logLevel: NgxLoggerLevel.INFO,
  serverLogLevel: NgxLoggerLevel.OFF,
  EXTERNAL_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.EXTERNAL_SERVICES}`,
  COMMON_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.COMMON_SERVICES}`,
  TRIAL_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.TRIAL_SERVICES}`,
  CASEVIEWER_SERVICE_API: `${window.location.protocol}//${window.location.host}${Urls.CASEVIEWER_SERVICES}`,
  ENV_SERVICES: `https://rbac-services.uspto.gov/rbac/services`,
  // ENV_SERVICES: `https://rbac-services-fqt.etc.uspto.gov/rbac/services`,
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
