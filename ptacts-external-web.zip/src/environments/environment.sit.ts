import { NgxLoggerLevel } from 'ngx-logger';
import { Urls } from 'src/app/constants/urls';

export const environment = {
  production: false,
  logLevel: NgxLoggerLevel.DEBUG,
  serverLogLevel: NgxLoggerLevel.WARN,
  EXTERNAL_SERVICE_API: `${Urls.ENVIRONMENTS.SIT}${Urls.EXTERNAL_SERVICES}`,
  COMMON_SERVICE_API: `${Urls.ENVIRONMENTS.SIT}${Urls.COMMON_SERVICES}`,
  TRIAL_SERVICE_API: `${Urls.ENVIRONMENTS.SIT}${Urls.TRIAL_SERVICES}`,
  CASEVIEWER_SERVICE_API: `${Urls.ENVIRONMENTS.PVT}${Urls.CASEVIEWER_SERVICES}`,
  ENV_SERVICES: `https://rbac-services-fqt.etc.uspto.gov/rbac/services`,
};
