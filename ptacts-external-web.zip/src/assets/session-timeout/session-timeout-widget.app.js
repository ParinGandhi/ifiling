// const { set } = require("grunt");

(function ($) {
    'use strict';
    $.sessionTimeoutWidget = function (options) {

        /**
         * Default options for the session timeout widget
         * These can be replaced during widget initialization
         */
        var defaults = {
            /**
             * @name resetBackendTimerUrl
             * @description This url will be used to reset backend timer.
             * @default window.location + '/reset-timer'
             * @type {String}
             */
            resetBackendTimerUrl: window.location + '/reset-timer',
            /**
             * @name ajaxType
             * @description Ajax call type for backend timer reset request.
             * @default GET
             * @type {String}
             */
            ajaxType: 'GET',
            /**
             * @name ajaxData
             * @description Ajax request data for backend timer reset call.
             * @default null
             * @type {String}
             */
            ajaxData: '',
            /**
             * @name logoutUrl
             * @description User will be directed this url when session timed out button is clicked.
             * @default reload
             * @type {String}
             */
            sessionTimedOutUrl: 'reload',
            /**
             * @name addRandomString
             * @description Adds a random string at the end of logout url.
             * @default true
             * @type {Boolean}
             */
            addRandomString: true,
            /**
             * @name logoutUrl
             * @description User will be directed this url when logout button is clicked.
             * @default https://iamint.uspto.gov/oam/server/logout?end_url=https://my.uspto.gov/home
             * @type {String}
             */
            logoutUrl: 'https://iamint.uspto.gov/oam/server/logout?end_url=https://my.uspto.gov/home',
            /**
             * @name warnAfter
             * @description Alert time until session timeout warning dialog appears.
             * @default 1500000 (25 mins)
             * @type {Number}
             */
            warnAfter: 1500000,
            /**
             * @name warningTime
             * @description Warning time until the page is routed to sessionTimedOutUrl.
             * @default 300000 (5 mins)
             * @type {Number}
             */
            warningTime: 300000,
            /**
             * @name sessionModalZIndex
             * @description Z-index of the session timeout modal.
             * @default 3000
             * @type {Number}
             */
            sessionModalZIndex: 3000,
            /**
             * @name hideOtherModals
             * @description Hides other models while session timeout modal is open.
             * @default True
             * @type {Boolean}
             */
            hideOtherModals: true,
            /**
             * @name hideOtherModalClasses
             * @description Used in a jquery selector to find any modals and hide them.
             * @default .modal
             * @type {String}
             */
            hideOtherModalClasses: '.modal',
            /**
             * @name checkRbacTimerUrl
             * @description This url will be used to check RBAC session timer.
             * @default null
             * @type {String}
             */
            //checkRbacTimerUrl: '',
            /**
             * @name delayForBootstrapAnimation
             * @description Delay added to fix bootstrap animation fade issue. Time in milliseconds.
             * @default 500
             * @type {number}
             */
            delayForBootstrapAnimation: 500,
            /**
             * @name onBlurFunction
             * @description Turns on blur function on or off.
             * @default True
             * @type {Boolean}
             */
            onBlurFunction: true,
            /**
             * @name runRbacCounter
             * @description Turns checkRbacCounter function on or off.
             * @default True
             * @type {Boolean}
             */
            runRbacCounter: true,
            /**
             * @name appSpecificDomain
             * @description will be used to set application specific session timer
             * @default null
             * @type {String}
             */
            appSpecificDomain: '',
            /**
             * @name rbacServicesUrl
             * @description based on the environemnt you are in will make the respective calls to rbac.
             * @default null
             * @type {String}
             */
            rbacServicesUrl: '',
            /**
             * @name isInternal
             * @description it will tell if the application is internal or external
             * @default false
             * @type {boolean}
             */
            isInternal : false,
            /**
             * @name switchDebugMode
             * @description it will turn on and off the console.log
             * @default false
             * @type {boolean}
             */
            switchDebugMode : false
        };
        /**
         * @name modalConfig
         * @description Contains headers, body text and button labels for the session timeout modal.
         * @type {Object}
         */
        var modalConfig = {
            warningHeaderMsg: 'Are you still working?',
            countDownMessage: 'Your session may end in <span class="stm-countdown-holder black"></span> minutes. Any unsaved changes will be lost.',
            sessionTimedOutMsg: 'Your session may have timed out',
            logOutButtonMsg: 'No, sign me out',
            staySignedInMsg: 'Yes, keep me signed in',
            timedOutButtonMsg: 'Continue'
        };
        var opt = defaults,
            sessionTimer,
            warningTimer,
            modalShowDialog,
            modalShowTimedoutDialog,
            modalTotalSessionTime,
            countdown = {};
        // Extend user-set options over defaults
        if (options) {
            opt = $.extend(defaults, options);
        }

        var rbacChecked = false;
        var bodyHasModalOpen = false;
        var sessionModalCount = 0;
        var modalAlreadyExists = false;
        var self = this;
        var intervalOffFocus = {};
        var currentFocusElement = '';
        var rbacErrorCount = 0;
        var interval;
        var inactivityTimeRemaining;
        var cookieInterval = {};


        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.startSessionTimer
         * @description This is an external function used to start session timers. Calls the startSessionTimer function.
         * @returns {void}
         */
        $.sessionTimeoutWidget.startSessionTimer = function () {
            self.startSessionTimer();
        };
        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.staySignedIn
         * @description This is an external function used to reset timers. Calls the staySigned function.
         * @returns {void}
         */
        $.sessionTimeoutWidget.staySignedIn = function () {
            // sessionModalCount = 0;
            self.staySignedIn();
        };

        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.sessionEnded
         * @description This is an external function used to reload page when session ends.
         * @returns {void}
         */
        $.sessionTimeoutWidget.sessionEnded = function () {
            // sessionModalCount = 0;
            self.sessionEnded();
        };

        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.stmLogout
         * @description This is an external function used to logout.
         * @returns {void}
         */
        $.sessionTimeoutWidget.stmLogout = function () {
            // sessionModalCount = 0;
            self.stmLogout();
        };

        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.stopAllTimers
         * @description This is an external function used to stop all timers. Calls the clearAllTimers function.
         * @returns {void}
         */
        $.sessionTimeoutWidget.stopAllTimers = function () {
            self.clearAllTimers();
        };
        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.changeSessionTimer
         * @description This function is a external method declaration handler. Changes the warning dialog display timers.
         * @param {Number} newWarnAfterTimer changes the warning
         * @param {Number} newWarningTime changes the warning
         * @returns {void}
         */
        $.sessionTimeoutWidget.changeSessionTimer = function (newWarnAfterTimer, newWarningTime) {
            if (!newWarnAfterTimer) {
                newWarnAfterTimer = opt.warnAfter;
            }
            if (newWarningTime) {
                newWarningTime = opt.warningTime;
            }
            self.resetModalTimers(newWarnAfterTimer, newWarningTime);
            self.startSessionTimer();
        };

        /**
         * @ngdoc method
         * @name $.sessionTimeoutWidget.clearTimer
         * @description This function is a external method declaration handler. Clears and will reset the session timers.
         * @returns {void}
         */
        $.sessionTimeoutWidget.clearTimer = function () {
            self.clearTimer();
        }

        // Create timeout warning dialog
        var modalBody = '<div class="stm-modal-class fade" data-backdrop="static" data-keyboard="false" id="session-timeout-dialog" style="z-index:' + opt.sessionModalZIndex + '">' +
            '           <div class="modal-dialog">' +
            '               <div id="stmTimerContent"  class="modal-content">' +
            '                   <div class="modal-body">' +
            '                       <a id="stmHeaderMessageAnchor" href="javascript:void(0);" tabindex="-1" class="sr-only" aria-hidden="true">session timeout modal</a>' +
            '                       <h4 id="stmHeaderMessage" class="stm-header-text"></h4>' +
            '                       <p id="stmMainContext"></p>' +
            '                   </div>' +
            '                   <div class="modal-footer">' +
            '                       <button type="button" onclick= "$.sessionTimeoutWidget.stmLogout()" id="stmLogoutBtn" class="btn btn-default">' + modalConfig.logOutButtonMsg + '</button>' +
            '                       <button type="submit" onclick= "$.sessionTimeoutWidget.staySignedIn()" id="stmStaySignedInBtn" class="btn btn-primary pull-right">' + modalConfig.staySignedInMsg + '</button>' +
            '                       <button type="submit" onclick= "$.sessionTimeoutWidget.sessionEnded()" id="stmTimedOutBtn" class="btn btn-primary pull-right">' + modalConfig.timedOutButtonMsg + '</button>' +
            '                   </div>' +
            '               </div>' +
            '           </div>' +
            '        </div>';
        /**
         * ngdoc function
         * @name resetModalTimers
         * @description Resets all the timers used in the application.
         * @param {Number} showAlert Time before alert message is shown.
         * @param {Number} timedOut Time before session times out.
         * @returns {void}
         */
        this.resetModalTimers = function (showAlertAfter, showWarningTill) {
            if (showAlertAfter !== 0) {
                var modalTimerTest = showAlertAfter - opt.warningTime;
                if (modalTimerTest > 0) {
                    modalShowDialog = modalTimerTest;
                } else {
                    modalShowDialog = showAlertAfter;
                }
            } else {
                modalShowDialog = showAlertAfter;
            }
            modalShowTimedoutDialog = showWarningTill;
            modalTotalSessionTime = showAlertAfter + modalShowTimedoutDialog;
        };

        /**
         * ngdoc function
         * @name calculateTimeInMinutes
         * @description Opens modal to display session time out alert.
         * @param {Number} t Input time that needs to be converted to String fomat.
         * @returns {String} stringMinTime
         */
        this.calculateTimeInMinutes = function (t) {
            var mins = Math.floor(t / 60);
            var seconds = t % 60;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            var stringMinTime = mins + ':' + seconds;
            return stringMinTime;
        };
        this.clearAllTimers = function () {
            // Clear session timer
            clearTimeout(sessionTimer);
            // Clear warning timer
            clearTimeout(warningTimer);
            // Clear session countDown
            clearTimeout(countdown.sessionCountDown);
            // Clear warning countDown
            clearTimeout(countdown.warningTimer);
        };
        /**
         * @ngdoc method
         * @name getRandomString
         * @description This function generates a random string.
         * @return {string} A random string.
         */
        this.getRandomString = function () {
            var result = '',
                length = 32,
                chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            for (var i = length; i > 0; --i) {
                result += chars[Math.round(Math.random() * (chars.length - 1))];
            }
            return result;
        };

        /**
         * ngdoc function
         * @name removeAlertModal
         * @description Closes session time out alert.
         * @returns {void}
         */
        this.removeAlertModal = function () {
            //  self.consoleLog('remove alert modal' + modalAlreadyExists);
            $('#session-timeout-dialog').on('hidden.bs.modal', function (e) {
                sessionModalCount = 0;
                $('#session-timeout-dialog, .session-timeout-backdrop').remove();
                if ($('#session-timeout-dialog').is(':visible')) {
                    $('body').removeClass('modal-open');
                }
                if (bodyHasModalOpen) {
                    $('body').addClass('modal-open');
                }
                if (opt.hideOtherModals) {
                    $(opt.hideOtherModalClasses).removeClass('hideNonStmModal');
                }
                currentFocusElement.focus();
                modalAlreadyExists = false;
            }).modal('hide');
        };

        /**
         * ngdoc function
         * @name openSessionAlert
         * @description Opens modal to display session time out alert.
         * @returns {void}
         */
        this.openSessionAlert = function (showEndingAlert) {
            // self.consoleLog('modal alert ')
            if (!modalAlreadyExists) {
                currentFocusElement = document.activeElement;
                if ($('body').hasClass('modal-open')) {
                    bodyHasModalOpen = true;
                } else {
                    bodyHasModalOpen = false;
                }
                $('body').append(modalBody);
                if (opt.hideOtherModals) {
                    $(opt.hideOtherModalClasses).addClass('hideNonStmModal');
                }
                if (showEndingAlert) {
                    $('#stmLogoutBtn').hide();
                    $('#stmStaySignedInBtn').hide();
                    $('#stmTimedOutBtn').show();
                    $('#stmHeaderMessage').text(modalConfig.sessionTimedOutMsg);
                    $('#stmMainContext').html('');
                } else {
                    $('#stmLogoutBtn').show();
                    $('#stmStaySignedInBtn').show();
                    $('#stmTimedOutBtn').hide();
                    $('#stmHeaderMessage').text(modalConfig.warningHeaderMsg);
                    $('#stmMainContext').html(modalConfig.countDownMessage);
                }
                $('#session-timeout-dialog').on('shown.bs.modal', function (e) {

                    $('#stmHeaderMessageAnchor').focus();

                    // self.consoleLog('adding class to modal backdrop');
                    self.offFocus(false);
                    $('#session-timeout-dialog').next().addClass('session-timeout-backdrop');

                    // redirect last element shift+tab to last input
                    $('#stmStaySignedInBtn').on('keydown', function (e) {
                        if ((e.which === 9 && !e.shiftKey)) {
                            e.preventDefault();
                            $('#stmLogoutBtn').focus();
                        }
                    });

                    // redirect first element shift+tab to last input
                    $('#stmLogoutBtn').on('keydown', function (e) {
                        if ((e.which === 9 && e.shiftKey)) {
                            e.preventDefault();
                            $('#stmStaySignedInBtn').focus();
                        }

                        // prevent any tabbing on the timed out button
                        $('#stmTimedOutBtn').on('keydown', function (e) {
                            if ((e.which === 9)) {
                                e.preventDefault();
                            }
                        });
                    });
                }).modal('show');
                modalAlreadyExists = true;
            }
        };
        /**
         * ngdoc function
         * @name sessionEndedAlert
         * @description Changes modal to display session ended alert view.
         * @returns {void}
         */
        this.sessionEndedAlert = function () {
            $('#stmLogoutBtn').hide();
            $('#stmStaySignedInBtn').hide();
            $('#stmTimedOutBtn').show();
            $('#stmHeaderMessage').text(modalConfig.sessionTimedOutMsg);
            $('#stmMainContext').html('');
        };
        /**
         * ngdoc function
         * @name sessionEnded
         * @description Logs user out and then routes user to sessionTimedOutUrl or reloads current page.
         * @returns {void}
         */
        this.sessionEnded = function () {
            if (opt.sessionTimedOutUrl === 'reload') {
                window.location.reload();
            } else if (opt.sessionTimedOutUrl === 'reloadRandomText') {
                var randomString = self.getRandomString();
                var currentLocation = window.location.href;
                if (currentLocation.indexOf('?') === -1) {
                    window.location = currentLocation + '?' + randomString;
                } else {
                    window.location = currentLocation + '&' + randomString;
                }
            } else {
                window.location = opt.sessionTimedOutUrl;
            }
        };

        this.stmLogout = function () {
            self.clearTimer();
            localStorage.removeItem(opt.appSpecificDomain);
            localStorage.clear();

            if(opt.isInternal){
                var randomString = self.getRandomString();
                if (opt.addRandomString) {
                    window.location = opt.logoutUrl + '?' + randomString;
                } else {
                    window.location = opt.logoutUrl;
                }                      
            } else{
                $.ajax({
                    type: 'GET',
                    url: opt.rbacServicesUrl + '/authentication/logout/urls',
                    dataType: 'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    success: function (data) {
                        self.consoleLog(data);
                        for (var i = 0; i < data.length; i++) {
    
                            if(data[i].search('TAB') != -1){
                                self.consoleLog("Okta Global logout being opened in new Tab to kill the session: "+data[i].split('::')[1]);
                                var new_Window = window.open(data[i].split('::')[1],"_blank");
                                setTimeout(function () {
                                    new_Window.close();
                                    self.consoleLog("New Okta Window closed!!!!!!!!");
                                },2000);
                            } else if(data[i].search('LANDING') != -1){
                                var redirectUri = data[i].split('::')[1];
                                if(opt.logoutUrl === ''){
                                    setTimeout(function () {
                                        window.location.href = redirectUri;
                                    },3000);
                                } else {
                                    setTimeout(function () {
                                        var randomString = self.getRandomString();
                                        if (opt.addRandomString) {
                                            window.location = opt.logoutUrl + '?' + randomString;
                                        } else {
                                            window.location = opt.logoutUrl;
                                        }
                                    }, 3000);
                                }  
                            } else{
                                $.ajax({
                                    type: 'GET',
                                    url: data[i],
                                    dataType: 'text',
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    success: function (response) {
                                        self.consoleLog("Logged from Session Widget !!!!!!" + data[i]);
                                    },
                                    error: function (response) {
                                        self.consoleLog("Failed to logout user!!!!!",true);
                                    }
                                });
                            }
                        }
                    },
                    error: function (data) {
                        self.consoleLog("Failed to fetch the urls!!!!!",true);
                    }
                });
            }
        };
        /**
         * ngdoc function
         * @name staySignedIn
         * @description Resets user's session on the back-end and front-end.
         * @returns {void}
         */
        this.staySignedIn = function () {
            // self.consoleLog('stay sign in. current time: ' + countdown.timeLeft);
            self.clearAllTimers();
            self.clearTimer();
            self.resetModalTimers(opt.warnAfter, opt.warningTime);
            sessionModalCount = 0;
            // Start session timer
            self.startSessionTimer();
            $.ajax({
                type: opt.ajaxType,
                url: opt.resetBackendTimerUrl,
                data: opt.ajaxData,
                xhrFields: {
                    withCredentials: true
                },
                success: function (data) {
                    // self.consoleLog('success: stay signed in success');
                    // reset all timer
                    self.clearTimer();
                    self.resetModalTimers(opt.warnAfter, opt.warningTime);
                    sessionModalCount = 0;
                    // Start session timer
                    self.startSessionTimer();
                }, error: function (data, status, headers, config) {
                    // self.consoleLog('error: stay signed in failed ' + status);
                    // reset all timer
                    self.clearTimer();
                    self.resetModalTimers(opt.warnAfter, opt.warningTime);
                    sessionModalCount = 0;
                    // Start session timer
                    self.startSessionTimer();
                }
            });
        };

        /**
         * ngdoc function
         * @name startSessionTimer
         * @description Starts the main timer for session widget.
         * @returns {void}
         */
        this.startSessionTimer = function () {
            sessionModalCount++;
            if (sessionModalCount === 1) {
                // Clear all timers
                self.clearAllTimers();
                self.startSessionCountdown(true);
                self.removeAlertModal();
                // Set session timer
                // self.consoleLog('startSessionTimer to show warning time remaining:' + modalShowDialog);
                sessionTimer = setTimeout(function () {
                    setTimeout(function () {
                        // self.consoleLog('invoke warning timer');
                        self.openSessionAlert();
                    }, opt.delayForBootstrapAnimation);
                    self.startTimer();
                }, modalShowDialog);

            }
        };
        /**
         * ngdoc function
         * @name startTimer
         * @description Starts the warning timer of the session widget.
         * @returns {void}
         */
        this.startTimer = function () {
            // Clear all timers
            self.clearAllTimers();
            if (!$('#session-timeout-dialog').hasClass('in')) {
                //start warning countdown
                self.startMinuteWarning(true);
            }

            warningTimer = setTimeout(function () {
                //session timed out change display
                //self.checkRbacTimer();
                // self.openSessionAlert();
                self.openSessionAlert(true);
                self.sessionEndedAlert();
            }, (modalShowTimedoutDialog));
        };
        /**
         * ngdoc function
         * @name startSessionCountdown
         * @description Starts the countdown for the total session.
         * @param {Boolean} reset Resets the session countdown.
         * @returns {void}
         */
        this.startSessionCountdown = function (reset) {
            // Clear session timer
            clearTimeout(countdown.sessionCountDown);
            if (reset) {
                //set the session time to Total session time
                countdown.sessionTimeLeft = Math.floor(modalTotalSessionTime / 1000);
            }

            // Set countdown message time value
            var totalMinutes = countdown.sessionTimeLeft >= 0 ? countdown.sessionTimeLeft : 0;
            // self.consoleLog('current time: ' + self.calculateTimeInMinutes(totalMinutes));
            $('#sessionTimerDiv').append(self.calculateTimeInMinutes(totalMinutes) + ' ');
            // Countdown by one second
            countdown.sessionTimeLeft--;
            countdown.sessionCountDown = setTimeout(function () {
                // Call self after one second
                self.startSessionCountdown();
            }, 1000);
        };
        /**
         * ngdoc function
         * @name startMinuteWarning
         * @description Sets time out for warning limit.
         * @param {Boolean} reset Resets the warning time.
         * @returns {void}
         */
        this.startMinuteWarning = function (reset) {
            // Clear warning timer
            clearTimeout(countdown.warningTimer);
            if (reset) {
                // set warning count to warning time
                countdown.warningTimeLeft = Math.floor(modalShowTimedoutDialog / 1000);
            }

            // Set countdown message time value
            var displayElement = $('.stm-countdown-holder');
            var totalMinutes = countdown.warningTimeLeft >= 0 ? countdown.warningTimeLeft : 0;
            displayElement.text(self.calculateTimeInMinutes(totalMinutes));
            $('#warningTimerDiv').append(self.calculateTimeInMinutes(totalMinutes) + ' ');
            // Countdown by one second
            countdown.warningTimeLeft--;
            countdown.warningTimer = setTimeout(function () {
                // Call self after one second
                if (countdown.warningTimeLeft > 0) {
                    self.startMinuteWarning();
                }
            }, 1000);
        };
        /**
         * @ngdoc function
         * @name stmLogoutBtn.onClick
         * @description This event based function will logout the user.
         * @returns {void}
         */
        $('#stmLogoutBtn').on('click', function () {
            // sessionModalCount = 0;
            self.stmLogout();
        });

        /**
         * @ngdoc function
         * @name stmStaySignedIn.onClick
         * @description This event based function will reset the session timer by calling the stay signed in function.
         * @returns {void}
         */
        $('#stmStaySignedInBtn').on('click', function () {
            // sessionModalCount = 0;
            self.staySignedIn();
        });

        /**
         * ngdoc function
         * @name checkRbacTimer
         * @description Checks RBAC session timer and sync's current timer values to RBAC timer.
         * @returns {void}
         */
        this.checkRbacCounter = function () {
            /*if (rbacErrorCount < 6) {
              setTimeout(function () {
                self.checkRbacTimer();
              }, 500);
            } else {*/
            self.clearAllTimers();
            if (modalAlreadyExists) {
                self.sessionEndedAlert();
            } else {
                self.openSessionAlert(true);
            }
            //}
        };

        this.clearTimer = function () {
            //resetting the session timer, when user click "keep me logged in on session timer widget".
            inactivityTimeRemaining = 30 * 60;
            localStorage.removeItem(opt.appSpecificDomain);
            localStorage.clear();
            clearInterval(interval);
            clearInterval(cookieInterval);
            this.thirtyMinSessionTimer();
            self.consoleLog("Timer is reset");
        }


        this.thirtyMinSessionTimer = function () {
            inactivityTimeRemaining = 30 * 60; //session timeout is set for 30 minutes.
            localStorage.setItem(opt.appSpecificDomain, inactivityTimeRemaining);
            interval = setInterval(function () {
                --inactivityTimeRemaining;
            }, 1000);
        }


        this.checkRbacTimer = function () {

            self.consoleLog("Inactivity time remaining in milliseconds: " + (inactivityTimeRemaining * 1000));
            if ((inactivityTimeRemaining * 1000) > 0) {
                if ((inactivityTimeRemaining * 1000) < opt.warningTime) {
                    var testTimer = Math.floor((inactivityTimeRemaining * 1000) / 1000);
                    if (testTimer !== countdown.warningTimeLeft) {
                        self.resetModalTimers(0, inactivityTimeRemaining * 1000);
                        sessionModalCount = 0;
                        self.startSessionTimer();
                    }
                } else if ((inactivityTimeRemaining * 1000) > opt.warningTime) {
                    self.resetModalTimers(inactivityTimeRemaining * 1000, opt.warningTime);
                    sessionModalCount = 0;
                    self.startSessionTimer();
                } else {

                }
            }
        };
        /**
         * @ngdoc function
         * @name stmSignoutBtn.onClick
         * @description This event based function will reset the session timer by calling the stay signed in function.
         * @returns {void}
         */
        $('#stmTimedOutBtn').on('click', function () {
            self.sessionEnded();
        });

        this.offFocus = function (isOffFocus) {
            if (isOffFocus) {
                // intervalOffFocus = setInterval(function () {
                //   self.checkRbacTimer();
                // }, 240000);
            } else {
                clearInterval(intervalOffFocus);
            }
        };


        /**
         * @ngdoc function
         * @name self.consoleLog
         * @description This function will enabled of disable loggin based on switchDebugMode flag.
         * @param {}
         * @returns {void}
         */
        this.consoleLog = function (msg, flag) {
            if(opt.switchDebugMode == true){
                if(flag){
                    console.error(msg);
                } else{
                    console.log(msg);
                }  
            }
        }

        /**
         * @ngdoc function
         * @name stmSignoutBtn.onClick
         * @description This event based function will reset the session timer by calling the stay signed in function.
         * @param {Object} e is the event that has occured
         * @returns {void}
         */
        $(window).on("blur focus", function (e) {
            if (opt.onBlurFunction) {
                var prevType = $(this).data("prevType");
                if (prevType !== e.type) {   //  reduce double fire issues
                    switch (e.type) {
                        case "blur":
                            $('#msgDiv').text("Blured");
                            self.offFocus(true);
                            break;
                        case "focus":
                            $('#msgDiv').text("Focused");
                            self.offFocus(false);
                            self.checkRbacTimer();
                            break;
                    }
                }
                $(this).data("prevType", e.type);
            }
        });

        document.onvisibilitychange = function(){
            if(document.visibilityState == 'visible'){
                self.consoleLog("I am visisble !!!!"+ document.visibilityState);
                if (!Number.isNaN(Number.parseInt(localStorage.getItem(opt.appSpecificDomain)))) {
                    if(Number.parseInt(localStorage.getItem(opt.appSpecificDomain)) > inactivityTimeRemaining){
                        inactivityTimeRemaining = Number.parseInt(localStorage.getItem(opt.appSpecificDomain));
                    }
                }
                self.checkRbacTimer();

            } else if (document.visibilityState == 'hidden'){
                self.consoleLog("I am Hidden!!!!!"+ document.visibilityState);
                self.consoleLog("Blur before"+localStorage.getItem(opt.appSpecificDomain));
                localStorage.setItem(opt.appSpecificDomain,inactivityTimeRemaining);
                self.consoleLog("Blur after"+localStorage.getItem(opt.appSpecificDomain));

            }
        }

        //reset all timers
        this.resetModalTimers(opt.warnAfter, opt.warningTime);
        // Start session timer
        this.checkRbacTimer();

        //start timer
        this.thirtyMinSessionTimer();


        // $(window).ready(function () {
        //     if (!Number.isNaN(Number.parseInt(localStorage.getItem(opt.appSpecificDomain)))) {
        //         inactivityTimeRemaining = Number.parseInt(localStorage.getItem(opt.appSpecificDomain));
        //         self.consoleLog("Session Timer After getting from local: " + inactivityTimeRemaining);
        //     }
        // });
    };
}
)
    (jQuery);
